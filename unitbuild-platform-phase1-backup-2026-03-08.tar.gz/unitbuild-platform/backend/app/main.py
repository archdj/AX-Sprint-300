"""
UnitBuild Platform — FastAPI 메인 앱 엔트리포인트

LH 신축매입약정 연동 모듈러 사업지 자동평가 플랫폼
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

from app.core.config import settings
from app.core.database import init_db
from app.api.v1 import sites, sitec, hazard, demand, cluster, modules, parcel, auto_eval, bulk

# 로깅 설정
logging.basicConfig(
    level=logging.INFO if not settings.DEBUG else logging.DEBUG,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """앱 시작/종료 시 처리"""
    logger.info("🚀 UnitBuild Platform 시작 중...")
    await init_db()
    logger.info("✅ DB 초기화 완료")
    yield
    logger.info("🛑 UnitBuild Platform 종료")


app = FastAPI(
    title="UnitBuild Platform API",
    description="""
## 🏗️ LH 신축매입약정 연동 모듈러 사업지 자동평가 플랫폼

### 주요 기능
- **SITE-C 자동 평가**: LH 심의기준 정량화 (A/B/C/탈락 등급)
- **위해시설 자동 검증**: GPS·GIS 기반 이격거리 판정
- **AI 수요 예측**: 지역별 주택 수요 확신도 점수
- **클러스터 최적화**: ILP 기반 포트폴리오 최적 선택
- **BIM 연동**: IFC 파싱 + 물량산출(QTO) + 원가 산정 (Phase 3)

### 데이터 소스 (Phase 2 연동 예정)
- LH OpenAPI (공실률, 공급 현황)
- 국토교통부 실거래가 API
- 브이월드 GIS API
- 카카오맵 API
    """,
    version=settings.APP_VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API 라우터 등록
app.include_router(sites.router)
app.include_router(sitec.router)
app.include_router(hazard.router)
app.include_router(demand.router)
app.include_router(cluster.router)
app.include_router(modules.router)
app.include_router(parcel.router)
app.include_router(auto_eval.router)
app.include_router(bulk.router)


@app.get("/", tags=["헬스체크"])
async def root():
    return {
        "service": "UnitBuild Platform API",
        "version": settings.APP_VERSION,
        "status": "running",
        "docs": "/docs",
    }


@app.get("/health", tags=["헬스체크"])
async def health_check():
    return {
        "status": "healthy",
        "database": "connected",
        "modules": {
            "sitec_engine": "ready",
            "hazard_verifier": "ready (mock mode)",
            "demand_predictor": "ready (simulation mode)",
            "cluster_optimizer": "ready",
            "bim_processor": "phase3",
        }
    }
