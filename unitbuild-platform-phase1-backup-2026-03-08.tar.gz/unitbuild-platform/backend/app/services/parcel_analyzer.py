"""
필지 자동 분석 엔진 (Parcel Analyzer)

지번 입력 → 자동 분석 파이프라인:
  1. 지번 → 좌표 변환 (카카오맵/브이월드 API, 현재: 시뮬레이션)
  2. 필지 형상 및 면적 조회 (국토부 필지정보, 현재: 시뮬레이션)
  3. 용도지역 판별 (국토계획법 기반)
  4. 건폐율/용적률 한도 산출
  5. 건축 가능 층수 및 세대수 자동 계산
  6. UnitBuild Gen 2 모듈 최적 배치 추천
"""

import logging
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum

from app.services.module_catalog import (
    ModuleType, ModuleSpec, LHUnitType, CorridorType,
    GEN2_MODULE_CATALOG, module_catalog
)

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────
# 용도지역 (국토의 계획 및 이용에 관한 법률 §36)
# ─────────────────────────────────────────────────────────

class ZoneType(str, Enum):
    """도시지역 용도지역 분류"""
    # 주거지역
    RESIDENTIAL_1_EXCLUSIVE = "제1종전용주거지역"   # 건폐율50% 용적률100%
    RESIDENTIAL_2_EXCLUSIVE = "제2종전용주거지역"   # 건폐율50% 용적률150%
    RESIDENTIAL_1_GENERAL   = "제1종일반주거지역"   # 건폐율60% 용적률200%
    RESIDENTIAL_2_GENERAL   = "제2종일반주거지역"   # 건폐율60% 용적률250%
    RESIDENTIAL_3_GENERAL   = "제3종일반주거지역"   # 건폐율50% 용적률300%
    RESIDENTIAL_SEMI        = "준주거지역"           # 건폐율70% 용적률500%
    # 상업지역
    COMMERCIAL_CENTER       = "중심상업지역"
    COMMERCIAL_GENERAL      = "일반상업지역"
    COMMERCIAL_NEIGHBOR     = "근린상업지역"
    COMMERCIAL_DISTRIBUTION = "유통상업지역"
    # 공업지역
    INDUSTRIAL_EXCLUSIVE    = "전용공업지역"
    INDUSTRIAL_GENERAL      = "일반공업지역"
    INDUSTRIAL_SEMI         = "준공업지역"          # 건폐율70% 용적률400%
    # 녹지지역
    GREENBELT_CONSERVATION  = "보전녹지지역"
    GREENBELT_PRODUCTION    = "생산녹지지역"
    GREENBELT_NATURAL       = "자연녹지지역"        # 건폐율20% 용적률100%


# ─────────────────────────────────────────────────────────
# 용도지역별 건축 규제 한도
# 국토의 계획 및 이용에 관한 법률 시행령 별표
# ─────────────────────────────────────────────────────────

ZONE_REGULATIONS: Dict[ZoneType, Dict] = {
    ZoneType.RESIDENTIAL_1_EXCLUSIVE: {
        "coverage_ratio_max": 50,   # 건폐율 %
        "floor_area_ratio_max": 100, # 용적률 %
        "max_floors": 4,
        "allowed_uses": ["단독주택", "공동주택(아파트 제외)", "근린생활시설(1종)"],
        "note": "저층 단독주거지역. 아파트 불가. 단독주택, 연립주택, 다세대주택 가능"
    },
    ZoneType.RESIDENTIAL_2_EXCLUSIVE: {
        "coverage_ratio_max": 50,
        "floor_area_ratio_max": 150,
        "max_floors": 4,
        "allowed_uses": ["단독주택", "공동주택(아파트 제외)", "근린생활시설(1종)"],
        "note": "제2종 전용주거지역. 단독·공동주택 중심"
    },
    ZoneType.RESIDENTIAL_1_GENERAL: {
        "coverage_ratio_max": 60,
        "floor_area_ratio_max": 200,
        "max_floors": 4,
        "allowed_uses": ["단독주택", "공동주택", "근린생활시설(1종)", "교육연구시설"],
        "note": "4층 이하 저층주거지역. 아파트 포함 공동주택 가능"
    },
    ZoneType.RESIDENTIAL_2_GENERAL: {
        "coverage_ratio_max": 60,
        "floor_area_ratio_max": 250,
        "max_floors": 12,
        "allowed_uses": ["공동주택", "단독주택", "근린생활시설", "교육연구시설"],
        "note": "12층 이하 중층주거지역. 아파트 가능"
    },
    ZoneType.RESIDENTIAL_3_GENERAL: {
        "coverage_ratio_max": 50,
        "floor_area_ratio_max": 300,
        "max_floors": 0,  # 층수 제한 없음 (용적률로 제어)
        "allowed_uses": ["공동주택", "근린생활시설", "오피스텔"],
        "note": "층수 제한 없음. 용적률 300% 이내"
    },
    ZoneType.RESIDENTIAL_SEMI: {
        "coverage_ratio_max": 70,
        "floor_area_ratio_max": 500,
        "max_floors": 0,
        "allowed_uses": ["공동주택", "상업시설", "업무시설", "근린생활시설"],
        "note": "주거+상업 혼합지역. 높은 용적률"
    },
    ZoneType.INDUSTRIAL_SEMI: {
        "coverage_ratio_max": 70,
        "floor_area_ratio_max": 400,
        "max_floors": 0,
        "allowed_uses": ["공동주택", "공장", "창고", "상업시설"],
        "note": "준공업지역. 공동주택 가능. LH 매입 신청 주의 필요"
    },
    ZoneType.GREENBELT_NATURAL: {
        "coverage_ratio_max": 20,
        "floor_area_ratio_max": 100,
        "max_floors": 4,
        "allowed_uses": ["단독주택", "농어업용 시설"],
        "note": "자연녹지지역. 공동주택 원칙적 불가. LH 매입 부적합"
    },
}

# 간단 접근을 위한 보조 딕셔너리
ZONE_REGULATIONS_SIMPLE: Dict[str, Dict] = {
    "제1종전용주거지역": {"coverage": 50, "far": 100, "max_floors": 4},
    "제2종전용주거지역": {"coverage": 50, "far": 150, "max_floors": 4},
    "제1종일반주거지역": {"coverage": 60, "far": 200, "max_floors": 4},
    "제2종일반주거지역": {"coverage": 60, "far": 250, "max_floors": 12},
    "제3종일반주거지역": {"coverage": 50, "far": 300, "max_floors": 0},
    "준주거지역":        {"coverage": 70, "far": 500, "max_floors": 0},
    "준공업지역":        {"coverage": 70, "far": 400, "max_floors": 0},
    "근린상업지역":      {"coverage": 70, "far": 900, "max_floors": 0},
    "일반상업지역":      {"coverage": 80, "far": 1300,"max_floors": 0},
    "자연녹지지역":      {"coverage": 20, "far": 100, "max_floors": 4},
}


# ─────────────────────────────────────────────────────────
# 주차 기준 (주차장법 시행규칙)
# ─────────────────────────────────────────────────────────

PARKING_REQUIREMENTS: Dict[str, Dict] = {
    "공동주택_전용60이하": {
        "ratio": 0.5,          # 세대당 0.5대 (기준 완화 적용시)
        "base_ratio": 0.7,     # 일반 기준
        "note": "주차장법 시행규칙 제6조. 전용 60㎡ 이하 세대"
    },
    "공동주택_전용85이하": {
        "ratio": 1.0,
        "base_ratio": 1.0,
        "note": "전용 60~85㎡ 세대"
    },
    "공동주택_전용85초과": {
        "ratio": 1.5,
        "base_ratio": 1.5,
        "note": "전용 85㎡ 초과 세대"
    },
}

PARKING_SPACE_SIZE_M2 = 2.5 * 5.0  # 2.5m × 5.0m = 12.5㎡/대


# ─────────────────────────────────────────────────────────
# 데이터 클래스
# ─────────────────────────────────────────────────────────

@dataclass
class ParcelInfo:
    """필지 기본 정보"""
    parcel_number: str           # 지번 (예: 서울시 강남구 역삼동 123-45)
    address: str                 # 도로명 주소
    latitude: float
    longitude: float

    # 필지 형상
    area_m2: float               # 필지 면적
    width_m: float               # 필지 폭 (도로 접면)
    depth_m: float               # 필지 깊이
    shape: str = "rectangular"   # rectangular / irregular / L-shape

    # 용도지역
    zone_type: str = "제2종일반주거지역"
    zone_detail: str = ""

    # 도로 현황
    road_width_m: float = 6.0    # 접면 도로 폭
    road_count: int = 1          # 접면 도로 수

    # 지형
    slope_percent: float = 3.0
    ground_condition: str = "양호"  # 양호/보통/불량

    # 데이터 소스
    data_source: str = "simulation"  # vworld / kakao / simulation
    data_accuracy: str = "medium"


@dataclass
class RegulatoryLimits:
    """건축 규제 한도"""
    zone_type: str
    coverage_ratio_max_pct: float    # 건폐율 최대 %
    floor_area_ratio_max_pct: float  # 용적률 최대 %
    max_floors: int                  # 최고 층수 (0=제한없음)
    height_limit_m: float            # 높이 제한 (m)

    # 이격거리 (건축법 시행령)
    front_setback_m: float = 3.0     # 전면 이격
    side_setback_m: float = 0.5      # 측면 이격
    rear_setback_m: float = 0.5      # 후면 이격

    # 허용 최대 건축 면적
    max_building_footprint_m2: float = 0.0   # 건폐율 × 필지면적
    max_total_floor_area_m2: float = 0.0     # 용적률 × 필지면적

    parking_required: int = 0        # 필요 주차 대수
    parking_area_m2: float = 0.0     # 주차장 소요 면적

    notes: List[str] = field(default_factory=list)


@dataclass
class ModulePlacementPlan:
    """모듈 배치 계획"""
    module_type: ModuleType
    corridor_type: CorridorType
    units_per_floor: int
    recommended_floors: int
    total_units: int
    building_footprint_m2: float
    total_floor_area_m2: float
    coverage_ratio_pct: float
    floor_area_ratio_pct: float

    # 세대 구성
    unit_types: List[Dict]          # [{"type": "BALCONY-2", "count": 20, "area": 28.82}, ...]
    lh_type_breakdown: Dict[str, int]
    small_unit_ratio: float
    avg_unit_area_m2: float

    # 사업성
    estimated_construction_cost_100m: float
    estimated_lh_purchase_price_100m: float
    estimated_profit_100m: float
    roi_pct: float

    # 법규 적합성
    regulation_compliant: bool
    compliance_notes: List[str]
    warnings: List[str]


@dataclass
class ParcelAnalysisResult:
    """필지 종합 분석 결과"""
    parcel_info: ParcelInfo
    regulatory_limits: RegulatoryLimits
    placement_plans: List[ModulePlacementPlan]    # 복수의 배치 계획
    best_plan: Optional[ModulePlacementPlan]
    sitec_pre_score: float                        # SITE-C 예비 점수
    sitec_grade: str
    overall_feasibility: str                      # "우수" / "양호" / "검토요" / "부적합"
    key_insights: List[str]
    next_steps: List[str]
    analysis_timestamp: str


# ─────────────────────────────────────────────────────────
# 필지 분석 서비스
# ─────────────────────────────────────────────────────────

class ParcelAnalyzer:
    """
    지번 입력 → 자동 필지 분석 + 모듈 배치 최적화
    """

    MODULE_HEIGHT_M = 3.2   # 층당 높이 (m) - 모듈러 기준

    def analyze(
        self,
        parcel_number: str,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        area_m2: Optional[float] = None,
        zone_type: Optional[str] = None,
        target_units: Optional[int] = None,
    ) -> ParcelAnalysisResult:
        """
        필지 종합 분석 메인 엔트리포인트

        Args:
            parcel_number: 지번 (예: "서울시 강남구 역삼동 123-45")
            lat, lng: 좌표 (없으면 지번으로부터 추정)
            area_m2: 필지 면적 (없으면 추정)
            zone_type: 용도지역 (없으면 자동 판별)
            target_units: 목표 세대수 (없으면 자동 계산)
        """
        import datetime

        # 1. 필지 정보 취득 (시뮬레이션 / API)
        parcel_info = self._fetch_parcel_info(
            parcel_number, lat, lng, area_m2, zone_type
        )

        # 2. 규제 한도 계산
        reg_limits = self._calculate_regulatory_limits(parcel_info)

        # 3. 모듈 배치 계획 수립
        plans = self._generate_placement_plans(parcel_info, reg_limits, target_units)

        # 4. 최적 계획 선택
        best_plan = self._select_best_plan(plans)

        # 5. SITE-C 예비 평가
        sitec_score, sitec_grade = self._pre_evaluate_sitec(parcel_info, best_plan)

        # 6. 종합 사업성 판단
        feasibility, insights, next_steps = self._assess_feasibility(
            parcel_info, reg_limits, best_plan, sitec_score
        )

        return ParcelAnalysisResult(
            parcel_info=parcel_info,
            regulatory_limits=reg_limits,
            placement_plans=plans,
            best_plan=best_plan,
            sitec_pre_score=sitec_score,
            sitec_grade=sitec_grade,
            overall_feasibility=feasibility,
            key_insights=insights,
            next_steps=next_steps,
            analysis_timestamp=datetime.datetime.now().isoformat(),
        )

    # ─────────────────────────────────────────────────────
    # 필지 정보 취득
    # ─────────────────────────────────────────────────────

    def _fetch_parcel_info(
        self,
        parcel_number: str,
        lat: Optional[float],
        lng: Optional[float],
        area_m2: Optional[float],
        zone_type: Optional[str],
    ) -> ParcelInfo:
        """
        필지 정보 취득
        Phase 2에서 실제 API 연동 (브이월드, 카카오맵)
        현재: 지번 패턴 기반 시뮬레이션
        """
        # 지번에서 지역 추출
        region_estimate = self._estimate_region_from_address(parcel_number)

        # 기본값 설정 (시뮬레이션)
        default_lat = lat or region_estimate.get("lat", 37.5665)
        default_lng = lng or region_estimate.get("lng", 126.9780)
        default_area = area_m2 or self._estimate_area_from_address(parcel_number)
        default_zone = zone_type or region_estimate.get("zone", "제2종일반주거지역")

        # 필지 형상 추정 (정방형 기준)
        estimated_width = math.sqrt(default_area * 0.6)  # 폭:깊이 = 0.6:1
        estimated_depth = default_area / estimated_width if estimated_width > 0 else 20

        # 도로폭 추정 (면적에 따라)
        road_width = 8.0 if default_area > 500 else 6.0

        return ParcelInfo(
            parcel_number=parcel_number,
            address=f"{parcel_number} (시뮬레이션)",
            latitude=default_lat,
            longitude=default_lng,
            area_m2=default_area,
            width_m=round(estimated_width, 1),
            depth_m=round(estimated_depth, 1),
            zone_type=default_zone,
            road_width_m=road_width,
            slope_percent=region_estimate.get("slope", 3.0),
            data_source="simulation",
            data_accuracy="medium",
        )

    def _estimate_region_from_address(self, address: str) -> Dict:
        """주소 문자열에서 지역 정보 추정"""
        # 실제 API 연동 전 패턴 매칭
        if "서울" in address or "강남" in address or "종로" in address:
            return {"lat": 37.5665, "lng": 126.9780, "zone": "제2종일반주거지역",
                    "region": "수도권", "slope": 2.0}
        elif "경기" in address or "수원" in address or "성남" in address:
            return {"lat": 37.2636, "lng": 127.0286, "zone": "제2종일반주거지역",
                    "region": "수도권", "slope": 3.0}
        elif "인천" in address:
            return {"lat": 37.4563, "lng": 126.7052, "zone": "제2종일반주거지역",
                    "region": "수도권", "slope": 2.5}
        elif "부산" in address or "대구" in address or "광주" in address:
            return {"lat": 35.1796, "lng": 129.0756, "zone": "제2종일반주거지역",
                    "region": "광역시", "slope": 4.0}
        else:
            return {"lat": 36.5, "lng": 127.5, "zone": "제1종일반주거지역",
                    "region": "지방", "slope": 5.0}

    def _estimate_area_from_address(self, address: str) -> float:
        """주소 기반 대표 필지 면적 추정 (시뮬레이션)"""
        # 도심 = 소규모, 외곽 = 대규모
        if "서울" in address:
            return 350.0   # 도심 소형 필지
        elif "경기" in address or "인천" in address:
            return 500.0   # 수도권 중형 필지
        else:
            return 700.0   # 지방 대형 필지

    # ─────────────────────────────────────────────────────
    # 규제 한도 계산
    # ─────────────────────────────────────────────────────

    def _calculate_regulatory_limits(self, parcel: ParcelInfo) -> RegulatoryLimits:
        """
        용도지역별 건폐율/용적률/층수 제한 계산
        건축법 시행령, 국토계획법 기반
        """
        zone_regs = ZONE_REGULATIONS_SIMPLE.get(
            parcel.zone_type,
            {"coverage": 60, "far": 250, "max_floors": 12}
        )

        coverage_pct = zone_regs["coverage"]
        far_pct = zone_regs["far"]
        max_floors = zone_regs["max_floors"]

        # 최대 건축 면적
        max_footprint = parcel.area_m2 * coverage_pct / 100

        # 이격거리 적용 후 실효 건축 면적
        # 전면3m + 후면0.5m + 양측면0.5m
        setback_area_reduction = (
            (parcel.depth_m - 3.0 - 0.5) *
            (parcel.width_m - 0.5 - 0.5)
        ) if parcel.depth_m > 4 and parcel.width_m > 2 else parcel.area_m2 * 0.7
        effective_footprint = min(max_footprint, max(setback_area_reduction, 0))

        # 최대 연면적
        max_floor_area = parcel.area_m2 * far_pct / 100

        # 층수 계산 (용적률/건폐율로 역산)
        if max_floors == 0:
            # 층수 제한 없음 → 용적률로 계산
            calc_floors = math.floor(max_floor_area / effective_footprint) if effective_footprint > 0 else 5
            actual_max_floors = min(calc_floors, 20)  # 합리적 상한
        else:
            actual_max_floors = max_floors

        # 높이 제한 계산 (층수 × 층고 + 옥탑)
        height_limit = actual_max_floors * self.MODULE_HEIGHT_M + 2.0

        # 주차 기준 (Gen2 모듈: 전용 28~29㎡ → 60㎡ 이하 기준 적용)
        # 간이 계산: 전체 세대 × 0.5대 (완화 기준)
        est_units = int(max_floor_area / 28.0)  # 평균 28㎡ 가정
        parking_required = math.ceil(est_units * 0.5)
        parking_area = parking_required * PARKING_SPACE_SIZE_M2

        notes = [
            f"용도지역: {parcel.zone_type}",
            f"건폐율 한도: {coverage_pct}% → 최대 건축면적 {effective_footprint:.0f}㎡",
            f"용적률 한도: {far_pct}% → 최대 연면적 {max_floor_area:.0f}㎡",
        ]
        if max_floors > 0:
            notes.append(f"층수 제한: {max_floors}층 이하")
        if parcel.road_width_m < 4:
            notes.append("⚠️ 접면 도로 4m 미만 → 건축허가 불가 (건축법 §44)")

        return RegulatoryLimits(
            zone_type=parcel.zone_type,
            coverage_ratio_max_pct=coverage_pct,
            floor_area_ratio_max_pct=far_pct,
            max_floors=actual_max_floors,
            height_limit_m=round(height_limit, 1),
            max_building_footprint_m2=round(effective_footprint, 1),
            max_total_floor_area_m2=round(max_floor_area, 1),
            parking_required=parking_required,
            parking_area_m2=round(parking_area, 1),
            notes=notes,
        )

    # ─────────────────────────────────────────────────────
    # 모듈 배치 계획 수립
    # ─────────────────────────────────────────────────────

    def _generate_placement_plans(
        self,
        parcel: ParcelInfo,
        reg: RegulatoryLimits,
        target_units: Optional[int],
    ) -> List[ModulePlacementPlan]:
        """
        여러 모듈 타입에 대한 배치 계획 생성
        """
        plans = []

        # 검토할 모듈 타입들 (Gen 2 우선순위)
        priority_types = [
            ModuleType.BALCONY_2,    # Gen 2 핵심 상품
            ModuleType.BASIC_1_C1,   # 경제적 기본형
            ModuleType.BASIC_2_C1,   # LH 26㎡ 대응
            ModuleType.BALCONY_3,    # 고급형
        ]

        for mt in priority_types:
            spec = GEN2_MODULE_CATALOG.get(mt)
            if not spec:
                continue
            plan = self._create_placement_plan(parcel, reg, spec, target_units)
            if plan and plan.total_units >= 10:  # 최소 규모 필터
                plans.append(plan)

        return plans

    def _create_placement_plan(
        self,
        parcel: ParcelInfo,
        reg: RegulatoryLimits,
        spec: ModuleSpec,
        target_units: Optional[int],
    ) -> Optional[ModulePlacementPlan]:
        """단일 모듈 타입에 대한 배치 계획 생성"""

        module_w_m = spec.width_mm / 1000.0    # 3.2m
        module_l_m = spec.length_mm / 1000.0   # 예: 9.6m

        # 이격거리 적용 유효 면적
        eff_width = parcel.width_m - 1.0   # 양측 0.5m
        eff_depth = parcel.depth_m - 3.5   # 전면3m + 후면0.5m

        if eff_width <= 0 or eff_depth <= 0:
            return None

        # 가로 방향 모듈 수
        modules_x = int(eff_width / module_w_m)
        # 세로 방향 모듈 수 (편복도 제외)
        # BALCONY/BASIC 모듈은 자체 복도 포함 또는 별도 복도 블록
        if spec.corridor_length_mm == 0:
            # 복도 별도: 1.4m 공용복도 별도 배치
            corridor_depth = 1.4
            usable_depth = eff_depth - corridor_depth
        else:
            usable_depth = eff_depth

        modules_y = max(1, int(usable_depth / module_l_m))
        units_per_floor = max(1, modules_x * modules_y)

        # 건축 면적 (기둥 중심선 기준)
        footprint = units_per_floor * spec.building_area_m2

        if footprint > reg.max_building_footprint_m2:
            # 건폐율 초과 시 세대수 조정
            units_per_floor = max(1, int(reg.max_building_footprint_m2 / spec.building_area_m2))
            footprint = units_per_floor * spec.building_area_m2

        # 층수 결정
        if target_units:
            # 목표 세대수 기준
            needed_floors = math.ceil(target_units / units_per_floor)
        else:
            # 용적률 최대화
            max_possible_floor_area = reg.max_total_floor_area_m2
            needed_floors = math.floor(max_possible_floor_area / footprint) if footprint > 0 else 5

        # 층수 제한 적용
        if reg.max_floors > 0:
            recommended_floors = min(needed_floors, reg.max_floors)
        else:
            recommended_floors = min(needed_floors, 15)  # 15층 상한 (모듈러 현실성)

        recommended_floors = max(1, recommended_floors)
        total_units = units_per_floor * recommended_floors

        # 주차장 면적 고려 (지상주차 가정)
        parking_lots = math.ceil(total_units * 0.5)  # Gen2: 소형 세대 0.5대/세대
        parking_area_needed = parking_lots * PARKING_SPACE_SIZE_M2

        # 실제 건폐율, 용적률
        total_floor_area = footprint * recommended_floors
        actual_coverage = (footprint / parcel.area_m2 * 100) if parcel.area_m2 > 0 else 0
        actual_far = (total_floor_area / parcel.area_m2 * 100) if parcel.area_m2 > 0 else 0

        # 법규 적합 검토
        compliant = True
        compliance_notes = []
        warnings = []

        if actual_coverage > reg.coverage_ratio_max_pct:
            compliant = False
            compliance_notes.append(f"⚠️ 건폐율 초과: {actual_coverage:.1f}% > {reg.coverage_ratio_max_pct}%")

        if actual_far > reg.floor_area_ratio_max_pct:
            compliant = False
            compliance_notes.append(f"⚠️ 용적률 초과: {actual_far:.1f}% > {reg.floor_area_ratio_max_pct}%")

        if reg.max_floors > 0 and recommended_floors > reg.max_floors:
            compliant = False
            compliance_notes.append(f"⚠️ 층수 초과: {recommended_floors}층 > {reg.max_floors}층")

        if parcel.road_width_m < 6 and total_units > 30:
            warnings.append(f"도로폭 {parcel.road_width_m}m — 30세대 이상 공동주택 접근성 검토 필요")

        if total_units < 20:
            warnings.append(f"계획 세대수 {total_units}세대 — 20세대 이상 시 SITE-C 가점 획득")

        if compliant:
            compliance_notes.append(f"✅ 건폐율 {actual_coverage:.1f}% / 용적률 {actual_far:.1f}% — 법규 적합")

        # 세대 구성 (LH 매칭)
        lh_breakdown = {}
        if spec.lh_type_match:
            lh_breakdown[spec.lh_type_match.value] = total_units

        small_unit_ratio = 1.0 if spec.net_area_m2 <= 60 else 0.5

        # 사업비 계산
        from app.services.module_catalog import (
            TOTAL_CONSTRUCTION_COST_PER_M2, LH_PURCHASE_PRICE_PER_M2
        )
        region = self._get_region_key(parcel)
        lh_price_per_m2 = LH_PURCHASE_PRICE_PER_M2.get(region, LH_PURCHASE_PRICE_PER_M2["지방"])

        const_cost = total_units * spec.building_area_m2 * TOTAL_CONSTRUCTION_COST_PER_M2 / 1e8
        lh_price = total_units * spec.net_area_m2 * lh_price_per_m2 / 1e8
        profit = lh_price - const_cost
        roi = (profit / const_cost * 100) if const_cost > 0 else 0

        return ModulePlacementPlan(
            module_type=spec.module_type,
            corridor_type=spec.corridor_type or CorridorType.STANDARD,
            units_per_floor=units_per_floor,
            recommended_floors=recommended_floors,
            total_units=total_units,
            building_footprint_m2=round(footprint, 1),
            total_floor_area_m2=round(total_floor_area, 1),
            coverage_ratio_pct=round(actual_coverage, 1),
            floor_area_ratio_pct=round(actual_far, 1),
            unit_types=[{
                "type": spec.module_type.value,
                "count": total_units,
                "area_m2": spec.net_area_m2,
                "building_area_m2": spec.building_area_m2,
            }],
            lh_type_breakdown=lh_breakdown,
            small_unit_ratio=small_unit_ratio,
            avg_unit_area_m2=spec.net_area_m2,
            estimated_construction_cost_100m=round(const_cost, 2),
            estimated_lh_purchase_price_100m=round(lh_price, 2),
            estimated_profit_100m=round(profit, 2),
            roi_pct=round(roi, 1),
            regulation_compliant=compliant,
            compliance_notes=compliance_notes,
            warnings=warnings,
        )

    def _get_region_key(self, parcel: ParcelInfo) -> str:
        """필지 위치 기반 LH 매입 단가 지역 분류"""
        if parcel.latitude > 37.0 and parcel.latitude < 37.8:
            return "수도권"
        elif parcel.latitude > 34.5:
            return "광역시"
        else:
            return "지방"

    # ─────────────────────────────────────────────────────
    # 최적 계획 선택
    # ─────────────────────────────────────────────────────

    def _select_best_plan(
        self, plans: List[ModulePlacementPlan]
    ) -> Optional[ModulePlacementPlan]:
        """최적 배치 계획 선택 (ROI × 법규적합 × 세대수 종합)"""
        if not plans:
            return None

        compliant_plans = [p for p in plans if p.regulation_compliant]
        if not compliant_plans:
            # 법규 위반이 있더라도 최고 ROI 선택
            return max(plans, key=lambda p: p.roi_pct)

        # ROI와 세대수를 복합 점수화
        def score(p: ModulePlacementPlan) -> float:
            roi_score = min(p.roi_pct / 30.0, 1.0) * 50          # ROI 30% = 만점
            unit_score = min(p.total_units / 50.0, 1.0) * 30      # 50세대 = 만점
            area_util = min(p.floor_area_ratio_pct / 200.0, 1.0) * 20  # 용적률 활용
            return roi_score + unit_score + area_util

        return max(compliant_plans, key=score)

    # ─────────────────────────────────────────────────────
    # SITE-C 예비 평가
    # ─────────────────────────────────────────────────────

    def _pre_evaluate_sitec(
        self,
        parcel: ParcelInfo,
        plan: Optional[ModulePlacementPlan],
    ) -> Tuple[float, str]:
        """간이 SITE-C 예비 점수 계산"""
        if not plan:
            return 0.0, "탈락"

        score = 0.0

        # A. 교통 접근성 (25점 만점) — 위치 기반 추정
        if parcel.latitude > 37.4 and parcel.latitude < 37.7:  # 서울 중심부 추정
            score += 20.0
        else:
            score += 14.0

        # B. 생활 인프라 (20점) — 시가화 지역 추정
        if "서울" in parcel.address or "수도권" in parcel.zone_detail:
            score += 16.0
        else:
            score += 12.0

        # C. 사업 규모 (20점)
        if plan.total_units >= 30:
            score += 20.0
        elif plan.total_units >= 20:
            score += 16.0
        else:
            score += 10.0

        # D. 구조·안전 (15점)
        if parcel.slope_percent <= 5:
            score += 13.5
        elif parcel.slope_percent <= 10:
            score += 10.0
        else:
            score += 6.0

        # E. 에너지·환경 (10점) — Gen 2 모듈러 = 에너지1등급 기본
        score += 9.0  # Gen 2 = 에너지 1등급 기본 설계

        # F. 사업자 가점 (10점) — 모듈러 + LH 매입 계획
        score += 7.2  # 모듈러(4점) + 장기임대(3.2점)

        score = round(min(score, 100.0), 1)

        if score >= 80:
            grade = "A"
        elif score >= 65:
            grade = "B"
        elif score >= 50:
            grade = "C"
        else:
            grade = "탈락"

        return score, grade

    # ─────────────────────────────────────────────────────
    # 종합 사업성 평가
    # ─────────────────────────────────────────────────────

    def _assess_feasibility(
        self,
        parcel: ParcelInfo,
        reg: RegulatoryLimits,
        plan: Optional[ModulePlacementPlan],
        sitec_score: float,
    ) -> Tuple[str, List[str], List[str]]:
        """종합 사업성 판단 및 인사이트 도출"""

        insights = []
        next_steps = []

        if not plan:
            return "부적합", ["배치 가능한 계획 없음"], ["대안 사업지 검토 필요"]

        # 사업성 등급
        if sitec_score >= 80 and plan.roi_pct >= 15 and plan.regulation_compliant:
            feasibility = "우수"
        elif sitec_score >= 65 and plan.roi_pct >= 8:
            feasibility = "양호"
        elif sitec_score >= 50 or plan.total_units >= 20:
            feasibility = "검토요"
        else:
            feasibility = "부적합"

        # 주요 인사이트
        insights.append(
            f"📐 필지 {parcel.area_m2:.0f}㎡ → {plan.module_type.value} {plan.total_units}세대 "
            f"({plan.recommended_floors}층) 배치 가능"
        )

        if plan.regulation_compliant:
            insights.append(
                f"✅ 법규 적합: 건폐율 {plan.coverage_ratio_pct}% / 용적률 {plan.floor_area_ratio_pct}%"
            )
        else:
            insights.append("⚠️ 법규 검토 필요 — 건폐율/용적률 초과 위험")

        if plan.roi_pct > 20:
            insights.append(f"💰 ROI {plan.roi_pct}% — 수익성 우수 (LH 매입가 기준)")
        elif plan.roi_pct > 10:
            insights.append(f"💰 ROI {plan.roi_pct}% — 수익성 양호")
        else:
            insights.append(f"⚠️ ROI {plan.roi_pct}% — 토지비 포함 시 수익성 재검토 필요")

        insights.append(
            f"🏗️ Gen 2 모듈 특이사항: "
            f"{'발코니 완전공장조립 가능' if 'BALCONY' in plan.module_type.value else '기본형 공장조립'}"
        )

        # 다음 단계 제안
        next_steps = [
            "① 정밀 현장 조사 (지형·지질·매설물 확인)",
            "② 인근 위해시설 GPS 검증 (hazard-verifier 실행)",
            "③ SITE-C 정밀 평가 실행 (교통·인프라 직접 입력)",
            "④ LH 매입 단가 현행화 (LH OpenAPI 연동)",
            f"⑤ {'건축사 사전 상담 (법규 면밀 검토)' if not plan.regulation_compliant else 'BIM 기본 설계 착수'}",
        ]

        return feasibility, insights, next_steps


# 싱글톤 인스턴스
parcel_analyzer = ParcelAnalyzer()
