"""
ILP 기반 클러스터 포트폴리오 최적화 서비스

목적: 주어진 사업지 후보군에서 최적 포트폴리오 선택
제약: 투자 자본, 공장 CAPA, 최소 모듈 수, 동시 진행 현장
"""

import logging
from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
import pulp

logger = logging.getLogger(__name__)


@dataclass
class SiteCandidate:
    site_id: str
    name: str
    sitec_score: float
    estimated_roi: float        # %
    completion_prob: float      # 0~1
    investment_cost: float      # 억원
    module_count: int
    factory_capacity_usage: float  # %
    construction_months: int
    region: str


@dataclass
class OptimizationConstraints:
    max_total_investment: float     # 억원
    max_factory_capacity: float = 100.0  # %
    min_cluster_modules: int = 200
    max_concurrent_sites: int = 5


@dataclass
class OptimizationResult:
    selected_sites: List[SiteCandidate]
    total_portfolio_value: float
    total_investment: float
    total_modules: int
    expected_roi: float
    risk_penalty: float
    gantt_schedule: List[Dict]
    sensitivity_analysis: Dict
    optimization_status: str  # optimal / infeasible / feasible


class ClusterOptimizer:
    """
    ILP 기반 포트폴리오 최적화

    목적함수:
      Maximize Σ_i [SITE_C_i × ROI_i × completion_prob_i × x_i] - risk_penalty

    제약조건:
      1. Σ(investment_cost_i × x_i) ≤ max_total_investment
      2. Σ(factory_capacity_usage_i × x_i) ≤ max_factory_capacity
      3. Σ(module_count_i × x_i) ≥ min_cluster_modules
      4. Σ(x_i) ≤ max_concurrent_sites
      5. x_i ∈ {0, 1}
    """

    def optimize(
        self,
        candidates: List[SiteCandidate],
        constraints: OptimizationConstraints,
    ) -> OptimizationResult:
        """ILP 최적화 실행"""

        if not candidates:
            return OptimizationResult(
                selected_sites=[],
                total_portfolio_value=0,
                total_investment=0,
                total_modules=0,
                expected_roi=0,
                risk_penalty=0,
                gantt_schedule=[],
                sensitivity_analysis={},
                optimization_status='infeasible',
            )

        prob = pulp.LpProblem("ClusterPortfolioOptimization", pulp.LpMaximize)

        # 결정변수: 각 사업지 선택 여부 (0 or 1)
        x = {
            site.site_id: pulp.LpVariable(f"x_{site.site_id}", cat='Binary')
            for site in candidates
        }

        # 포트폴리오 가치 (SITE-C × ROI × 완료확률)
        portfolio_value = pulp.lpSum(
            (site.sitec_score / 100.0) * (site.estimated_roi / 100.0) * site.completion_prob
            * 1000  # 스케일 조정
            * x[site.site_id]
            for site in candidates
        )

        # 리스크 패널티: 동일 지역 집중도
        regions = list(set(s.region for s in candidates))
        region_concentration_penalty = pulp.lpSum(
            pulp.lpSum(
                x[site.site_id] for site in candidates if site.region == region
            )
            for region in regions
        ) * 0.01  # 패널티 계수

        # 목적함수
        prob += portfolio_value - region_concentration_penalty

        # 제약 1: 총 투자 자본
        prob += (
            pulp.lpSum(site.investment_cost * x[site.site_id] for site in candidates)
            <= constraints.max_total_investment,
            "TotalInvestment"
        )

        # 제약 2: 공장 CAPA
        prob += (
            pulp.lpSum(site.factory_capacity_usage * x[site.site_id] for site in candidates)
            <= constraints.max_factory_capacity,
            "FactoryCapacity"
        )

        # 제약 3: 클러스터 최소 모듈 수 (규모의 경제) — 소프트 제약 처리
        total_possible_modules = sum(s.module_count for s in candidates)
        if total_possible_modules >= constraints.min_cluster_modules:
            prob += (
                pulp.lpSum(site.module_count * x[site.site_id] for site in candidates)
                >= constraints.min_cluster_modules,
                "MinModules"
            )

        # 제약 4: 동시 진행 최대 현장 수
        prob += (
            pulp.lpSum(x[site.site_id] for site in candidates)
            <= constraints.max_concurrent_sites,
            "MaxConcurrentSites"
        )

        # 최적화 실행 (CBC 솔버, 로그 억제)
        try:
            status = prob.solve(pulp.PULP_CBC_CMD(msg=0, timeLimit=30))
            opt_status = pulp.LpStatus[prob.status]
        except Exception as e:
            logger.error(f"ILP 최적화 오류: {e}")
            opt_status = 'error'

        # 결과 추출
        selected = []
        if opt_status in ('Optimal', 'Feasible'):
            selected = [
                site for site in candidates
                if pulp.value(x[site.site_id]) is not None
                and round(pulp.value(x[site.site_id])) == 1
            ]

        total_modules = sum(s.module_count for s in selected)
        total_investment = sum(s.investment_cost for s in selected)
        avg_roi = (
            sum(s.estimated_roi for s in selected) / len(selected)
            if selected else 0.0
        )

        obj_val = pulp.value(prob.objective) or 0.0
        risk_pen = pulp.value(region_concentration_penalty) or 0.0

        gantt = self._generate_gantt(selected)
        sensitivity = self._sensitivity_analysis(candidates, constraints, selected)

        return OptimizationResult(
            selected_sites=selected,
            total_portfolio_value=round(obj_val, 4),
            total_investment=round(total_investment, 2),
            total_modules=total_modules,
            expected_roi=round(avg_roi, 2),
            risk_penalty=round(risk_pen, 4),
            gantt_schedule=gantt,
            sensitivity_analysis=sensitivity,
            optimization_status=opt_status.lower() if opt_status else 'unknown',
        )

    def _generate_gantt(self, selected: List[SiteCandidate]) -> List[Dict]:
        """
        공장 생산 → 운송 → 현장 설치 통합 간트 일정 생성
        SITE-C 점수 높은 순서로 우선 배정
        """
        schedule = []
        current_month = 0

        for site in sorted(selected, key=lambda s: s.sitec_score, reverse=True):
            factory_months = max(1, site.construction_months // 2)
            install_months = site.construction_months - factory_months

            factory_start = current_month
            factory_end = current_month + factory_months
            install_start = factory_end
            install_end = install_start + install_months

            schedule.append({
                'site_id': site.site_id,
                'site_name': site.name,
                'region': site.region,
                'modules': site.module_count,
                'factory_period': [factory_start, factory_end],
                'installation_period': [install_start, install_end],
                'total_months': site.construction_months,
                'sitec_score': site.sitec_score,
                'investment_cost': site.investment_cost,
            })

            # 다음 현장은 공장 생산 완료 후 시작 (순차 모드)
            current_month = factory_end

        return schedule

    def _sensitivity_analysis(
        self,
        candidates: List[SiteCandidate],
        constraints: OptimizationConstraints,
        selected: List[SiteCandidate],
    ) -> Dict:
        """제약조건 변화에 따른 민감도 분석"""
        analysis = {
            'current_investment': sum(s.investment_cost for s in selected),
            'investment_utilization_pct': (
                sum(s.investment_cost for s in selected) / constraints.max_total_investment * 100
                if constraints.max_total_investment > 0 else 0
            ),
            'capacity_utilization_pct': (
                sum(s.factory_capacity_usage for s in selected) / constraints.max_factory_capacity * 100
                if constraints.max_factory_capacity > 0 else 0
            ),
            'module_coverage': sum(s.module_count for s in selected),
            'excluded_sites': [
                {
                    'site_id': s.site_id,
                    'name': s.name,
                    'sitec_score': s.sitec_score,
                    'reason': self._exclusion_reason(s, constraints, selected),
                }
                for s in candidates if s not in selected
            ],
            'notes': [
                f"자본 10억 증가 시 추가 선택 가능 사업지 검토 필요",
                f"공장 CAPA 110% 확장 시 최대 {len(candidates)}개 동시 진행 가능",
            ],
        }
        return analysis

    def _exclusion_reason(
        self,
        site: SiteCandidate,
        constraints: OptimizationConstraints,
        selected: List[SiteCandidate],
    ) -> str:
        current_investment = sum(s.investment_cost for s in selected)
        if current_investment + site.investment_cost > constraints.max_total_investment:
            return f"투자자본 초과 ({site.investment_cost}억원 추가 필요)"
        if len(selected) >= constraints.max_concurrent_sites:
            return f"동시 진행 현장 한도 초과 (최대 {constraints.max_concurrent_sites}개)"
        if site.sitec_score < 50:
            return f"SITE-C 점수 미달 ({site.sitec_score:.1f}점, 탈락 등급)"
        return "포트폴리오 가치 최적화에서 제외"


# 싱글톤 인스턴스
cluster_optimizer = ClusterOptimizer()
