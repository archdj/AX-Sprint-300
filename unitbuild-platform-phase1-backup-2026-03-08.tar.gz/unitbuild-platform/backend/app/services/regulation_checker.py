"""
법규 자동 검토 엔진 (Regulation Checker)

적용 법령:
  - 건축법 (법률 제21065호, 20251001)
  - 건축법 시행령 (대통령령 제35082호, 20251218)
  - 건축법 시행규칙 (국토교통부령 제01531호, 20251031)
  - 주차장법 (법률 제21185호, 20251202)
  - 주차장법 시행규칙 (국토교통부령 제01527호, 20250930)
  - 국토의 계획 및 이용에 관한 법률 (법률 제21065호, 20260102)
  - 건축물의 피난·방화구조 등의 기준에 관한 규칙 (국토교통부령 제01531호)

주요 검토 항목:
  1. 건폐율/용적률 (국토계획법 §78, §79)
  2. 최고 높이 및 층수 제한 (건축법 §60, §61)
  3. 이격거리 (건축법 시행령 §80~§86)
  4. 주차장 설치 기준 (주차장법 시행규칙 §6)
  5. 피난·방화구조 기준 (피난방화규칙)
  6. 모듈러 건축물 특례 (건축법 시행령 §6의3)
"""

import math
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────
# 검토 결과 상태
# ─────────────────────────────────────────────────────────

class CheckStatus(str, Enum):
    PASS    = "적합"
    WARNING = "주의"
    FAIL    = "부적합"
    N_A     = "해당없음"


@dataclass
class CheckItem:
    """개별 법규 검토 항목"""
    item_id: str
    category: str           # 건축법 / 주차장법 / 국토계획법 / 피난방화
    name: str               # 검토 항목명
    legal_basis: str        # 근거 법령 조항
    required_value: str     # 기준값
    actual_value: str       # 실제값
    status: CheckStatus
    message: str
    recommendation: str = ""


@dataclass
class RegulationCheckReport:
    """법규 검토 종합 보고서"""
    # 입력 조건
    zone_type: str
    parcel_area_m2: float
    planned_units: int
    total_floors: int
    building_footprint_m2: float
    total_floor_area_m2: float
    module_type: str

    # 검토 결과
    check_items: List[CheckItem]
    overall_status: CheckStatus
    pass_count: int
    warning_count: int
    fail_count: int

    # 모듈러 특례 적용 여부
    modular_exemption_applied: bool
    modular_exemption_items: List[str]

    # 권고사항
    critical_issues: List[str]
    recommendations: List[str]

    # 계산된 기준값
    required_coverage_pct: float
    required_far_pct: float
    required_parking_spaces: int
    required_emergency_exits: int
    required_staircase_count: int


# ─────────────────────────────────────────────────────────
# 주차 기준 (주차장법 시행규칙 §6, 별표 1)
# ─────────────────────────────────────────────────────────

class ParkingCalculator:
    """
    공동주택 주차 기준 계산기
    주차장법 시행규칙 §6 및 별표 1 기준
    """

    @staticmethod
    def calculate(
        unit_count: int,
        avg_unit_area_m2: float,
        region: str = "일반지역",
        is_lh_purchase: bool = True,
    ) -> Dict:
        """
        주차 대수 산정

        기준:
          - 전용 60㎡ 이하: 세대당 0.5대 이상
            (LH 매입임대 완화 적용 시 일부 지자체 0.3대)
          - 전용 60~85㎡: 세대당 1.0대
          - 전용 85㎡ 초과: 세대당 1.5대

        단, 지자체별 조례로 달라질 수 있음
        """

        if avg_unit_area_m2 <= 60:
            # 소형 세대 (Gen 2 주력 타입)
            base_ratio = 0.5
            lh_ratio = 0.3 if is_lh_purchase else 0.5
            note = "주차장법 시행규칙 §6: 전용60㎡이하 세대당 0.5대 (LH매입완화시 0.3대)"
        elif avg_unit_area_m2 <= 85:
            base_ratio = 1.0
            lh_ratio = 1.0
            note = "주차장법 시행규칙 §6: 전용60~85㎡ 세대당 1.0대"
        else:
            base_ratio = 1.5
            lh_ratio = 1.5
            note = "주차장법 시행규칙 §6: 전용85㎡초과 세대당 1.5대"

        required_spaces = math.ceil(unit_count * lh_ratio)
        space_area = required_spaces * 12.5  # 2.5 × 5.0 m (자주식 최소 기준)
        mechanical_area = required_spaces * 9.0  # 기계식 2단 기준

        return {
            "required_spaces": required_spaces,
            "base_ratio": base_ratio,
            "applied_ratio": lh_ratio,
            "surface_parking_area_m2": round(space_area, 1),
            "mechanical_parking_area_m2": round(mechanical_area, 1),
            "parking_type_recommendation": (
                "기계식(2단)" if required_spaces > 20 else "자주식"
            ),
            "note": note,
            "legal_basis": "주차장법 시행규칙 §6, 별표1",
        }


# ─────────────────────────────────────────────────────────
# 피난·방화구조 기준 검토
# 건축물의 피난·방화구조 등의 기준에 관한 규칙
# ─────────────────────────────────────────────────────────

class FireSafetyChecker:
    """
    피난·방화구조 기준 검토
    """

    @staticmethod
    def check_emergency_exits(
        total_units: int,
        total_floors: int,
        building_height_m: float,
    ) -> Dict:
        """
        피난계단 및 비상구 기준 검토
        건축물의 피난·방화구조 규칙 §8, §9
        """
        results = {}

        # 피난계단 수
        if total_floors >= 5 or building_height_m > 16:
            required_stairs = 2  # 피난계단 2개 이상
            stair_type = "피난계단(특별피난계단)"
            if building_height_m > 31:
                stair_type = "특별피난계단(필수)"
        else:
            required_stairs = 1
            stair_type = "직통계단"

        results["required_stairs"] = required_stairs
        results["stair_type"] = stair_type

        # 복도 폭 기준 (건축물의 피난·방화구조 규칙 §15의2)
        # 양측 거실: 1.8m 이상
        # 편측 거실: 1.2m 이상 (모듈러 편복도 해당)
        results["min_corridor_width_m"] = 1.2  # 편복도(모듈러)
        results["gen2_corridor_standard_m"] = 1.4  # Gen 2 표준복도 — 적합
        results["gen2_corridor_wide_m"] = 2.0  # Gen 2 광폭복도 — 여유

        # 발코니 안전 난간 (건축법 시행령 §40의2)
        results["balcony_railing_required"] = True
        results["balcony_railing_height_min_m"] = 1.2

        # 스프링클러 (소방시설 설치 및 관리에 관한 법률)
        results["sprinkler_required"] = total_floors >= 6 or total_units >= 16
        results["sprinkler_note"] = (
            "6층 이상 또는 16세대 이상 → 스프링클러 의무 설치"
        )

        # 방화구획 (건축법 시행령 §46)
        results["fire_partition_required"] = total_floors >= 3
        results["fire_partition_area_m2"] = 1000  # 층별 1,000㎡ 이하 구획

        # 내화구조 (건축법 시행령 §56)
        results["fire_resistance_required"] = True
        results["fire_resistance_grade"] = (
            "3시간" if total_floors >= 12 else
            "2시간" if total_floors >= 5 else "1시간"
        )

        return results

    @staticmethod
    def check_modular_exemptions(total_floors: int) -> Dict:
        """
        모듈러 건축물 관련 특례/완화 사항
        건축법 시행령 §6의3 (공업화건축물)
        """
        exemptions = []

        # 모듈러 = 공업화건축물 인정 시 적용 특례
        exemptions.append({
            "item": "공업화건축물 인정",
            "basis": "건축법 §23조의3, 시행령 §6의3",
            "benefit": "건축물 공장생산 허용, 현장조립 방식 인정",
            "applicable": True,
        })

        if total_floors <= 4:
            exemptions.append({
                "item": "저층 모듈러 완화",
                "basis": "건축법 시행령 §6의3",
                "benefit": "경량철골구조 적용 시 일부 구조기준 완화",
                "applicable": True,
            })

        exemptions.append({
            "item": "에너지효율 우대",
            "basis": "건축물 에너지효율등급 인증 제도",
            "benefit": "공장제작 단열시스템 → 1등급 인증 유리",
            "applicable": True,
        })

        return {
            "exemptions": exemptions,
            "total_applicable": sum(1 for e in exemptions if e["applicable"]),
            "notes": "모듈러 공업화건축물 인정 신청 필요 (착공 전 건축허가 단계)"
        }


# ─────────────────────────────────────────────────────────
# 건축선 및 이격거리 (건축법 시행령 §80~§86)
# ─────────────────────────────────────────────────────────

class SetbackCalculator:
    """이격거리 계산기"""

    @staticmethod
    def calculate(
        road_width_m: float,
        parcel_width_m: float,
        parcel_depth_m: float,
        building_height_m: float,
        zone_type: str,
    ) -> Dict:
        """
        건축선 후퇴 및 이격거리 계산
        건축법 시행령 §80 (대지면적의 최소한도)
        """
        results = {}

        # 도로 접면 이격 (건축법 §46, §47)
        if road_width_m < 4:
            front_setback = max(0, (4 - road_width_m) / 2 + 0.5)
            results["road_setback_issue"] = True
            results["road_setback_note"] = (
                f"도로폭 {road_width_m}m < 4m → 건축선 후퇴 필요 "
                f"(건축법 §46: 도로 중심선으로부터 2m 이상 확보)"
            )
        else:
            front_setback = 3.0  # 일반적 전면 이격
            results["road_setback_issue"] = False

        results["front_setback_m"] = front_setback

        # 인접 대지 경계선 이격
        # 건축법 시행령 §86: 정북방향 일조권
        # 9m 이하 건물: 인접 경계로부터 1.5m 이상
        # 9m 초과 건물: 높이의 1/2 이상
        if building_height_m <= 9:
            north_setback = 1.5
        else:
            north_setback = max(1.5, building_height_m * 0.5)

        results["north_setback_m"] = round(north_setback, 1)
        results["side_setback_m"] = 0.5    # 최소 측면 이격 (건축법 §58)
        results["rear_setback_m"] = 0.5    # 최소 후면 이격

        # 유효 건축 면적 (이격 적용 후)
        eff_width = parcel_width_m - results["side_setback_m"] * 2
        eff_depth = parcel_depth_m - results["front_setback_m"] - results["rear_setback_m"]
        effective_area = max(0, eff_width * eff_depth)

        results["effective_building_area_m2"] = round(effective_area, 1)
        results["effective_width_m"] = round(eff_width, 1)
        results["effective_depth_m"] = round(eff_depth, 1)
        results["legal_basis"] = "건축법 §46, §58, §61, 시행령 §86"

        return results


# ─────────────────────────────────────────────────────────
# 통합 법규 검토 엔진
# ─────────────────────────────────────────────────────────

class RegulationChecker:
    """
    UnitBuild Gen 2 모듈러 건축물 법규 자동 검토 엔진

    검토 순서:
      1. 국토계획법: 용도지역 건폐율/용적률
      2. 건축법: 층수/높이/이격거리
      3. 주차장법: 주차 대수
      4. 피난·방화: 계단/스프링클러/방화구획
      5. 모듈러 특례: 공업화건축물 인정사항
    """

    def check(
        self,
        zone_type: str,
        parcel_area_m2: float,
        parcel_width_m: float,
        parcel_depth_m: float,
        road_width_m: float,
        planned_units: int,
        avg_unit_area_m2: float,
        total_floors: int,
        building_footprint_m2: float,
        total_floor_area_m2: float,
        module_type: str = "BALCONY-2",
        is_lh_purchase: bool = True,
    ) -> RegulationCheckReport:
        """종합 법규 검토 실행"""

        from app.services.parcel_analyzer import ZONE_REGULATIONS_SIMPLE

        check_items: List[CheckItem] = []
        zone_regs = ZONE_REGULATIONS_SIMPLE.get(
            zone_type, {"coverage": 60, "far": 250, "max_floors": 12}
        )

        building_height_m = total_floors * 3.2 + 2.0  # 층고 3.2m + 옥탑
        modular_exemptions = []

        # ── 1. 건폐율 검토 (국토계획법 §78) ────────────────
        actual_coverage_pct = (building_footprint_m2 / parcel_area_m2 * 100
                               if parcel_area_m2 > 0 else 0)
        required_coverage = zone_regs["coverage"]

        check_items.append(CheckItem(
            item_id="C01",
            category="국토계획법",
            name="건폐율",
            legal_basis=f"국토의 계획 및 이용에 관한 법률 §78, {zone_type}",
            required_value=f"≤ {required_coverage}%",
            actual_value=f"{actual_coverage_pct:.1f}%",
            status=(CheckStatus.PASS if actual_coverage_pct <= required_coverage
                    else CheckStatus.FAIL),
            message=(f"건폐율 {actual_coverage_pct:.1f}% — {'적합' if actual_coverage_pct <= required_coverage else '초과'}"
                     f" (한도: {required_coverage}%)"),
            recommendation=(
                "" if actual_coverage_pct <= required_coverage
                else f"건축 면적을 {building_footprint_m2 * required_coverage / actual_coverage_pct:.0f}㎡ 이하로 축소"
            )
        ))

        # ── 2. 용적률 검토 (국토계획법 §79) ────────────────
        actual_far_pct = (total_floor_area_m2 / parcel_area_m2 * 100
                         if parcel_area_m2 > 0 else 0)
        required_far = zone_regs["far"]

        check_items.append(CheckItem(
            item_id="C02",
            category="국토계획법",
            name="용적률",
            legal_basis=f"국토의 계획 및 이용에 관한 법률 §79, {zone_type}",
            required_value=f"≤ {required_far}%",
            actual_value=f"{actual_far_pct:.1f}%",
            status=(CheckStatus.PASS if actual_far_pct <= required_far
                    else CheckStatus.FAIL),
            message=(f"용적률 {actual_far_pct:.1f}% — {'적합' if actual_far_pct <= required_far else '초과'}"
                     f" (한도: {required_far}%)"),
            recommendation=(
                "" if actual_far_pct <= required_far
                else f"연면적을 {parcel_area_m2 * required_far / 100:.0f}㎡ 이하로 조정 또는 층수 감소"
            )
        ))

        # ── 3. 층수 제한 (건축법 §60, 국토계획법) ─────────
        max_floors = zone_regs["max_floors"]
        if max_floors > 0:
            check_items.append(CheckItem(
                item_id="C03",
                category="건축법",
                name="최고 층수",
                legal_basis="건축법 §60, 국토계획법 시행령 별표",
                required_value=f"≤ {max_floors}층",
                actual_value=f"{total_floors}층",
                status=(CheckStatus.PASS if total_floors <= max_floors
                        else CheckStatus.FAIL),
                message=(f"{total_floors}층 — {'적합' if total_floors <= max_floors else '초과'}"
                         f" (한도: {max_floors}층)"),
                recommendation=(
                    "" if total_floors <= max_floors
                    else f"층수를 {max_floors}층 이하로 조정 (세대당 단가 상승 주의)"
                )
            ))

        # ── 4. 도로 접면 너비 (건축법 §44) ────────────────
        check_items.append(CheckItem(
            item_id="C04",
            category="건축법",
            name="도로 접면",
            legal_basis="건축법 §44: 대지의 접도 의무",
            required_value="도로폭 ≥ 4m, 대지 접면 2m 이상",
            actual_value=f"도로폭 {road_width_m}m",
            status=(CheckStatus.PASS if road_width_m >= 4
                    else CheckStatus.WARNING if road_width_m >= 2
                    else CheckStatus.FAIL),
            message=(f"도로폭 {road_width_m}m — {'적합' if road_width_m >= 4 else '주의: 건축허가 조건 검토 필요'}"),
            recommendation=(
                "도로 확포장 협의 또는 대안 접근로 확보" if road_width_m < 4 else ""
            )
        ))

        # ── 5. 이격거리 (건축법 시행령 §86) ─────────────
        setback = SetbackCalculator.calculate(
            road_width_m, parcel_width_m, parcel_depth_m,
            building_height_m, zone_type
        )

        check_items.append(CheckItem(
            item_id="C05",
            category="건축법",
            name="정북 일조권 이격",
            legal_basis="건축법 §61, 시행령 §86: 정북방향 이격거리",
            required_value=f"≥ {setback['north_setback_m']}m",
            actual_value="설계 도서 확인 필요",
            status=CheckStatus.WARNING,
            message=(f"건물높이 {building_height_m:.1f}m → 정북 이격 {setback['north_setback_m']}m 이상 확보 필요"),
            recommendation="배치도에서 정북 방향 이격거리 확인 후 확정"
        ))

        # ── 6. 주차 기준 (주차장법 시행규칙 §6) ──────────
        parking = ParkingCalculator.calculate(
            planned_units, avg_unit_area_m2, is_lh_purchase=is_lh_purchase
        )
        required_parking = parking["required_spaces"]
        # 주차장 면적을 건축 면적에 포함 여부 검토
        parking_feasible = (
            parking["surface_parking_area_m2"] <= parcel_area_m2 * 0.3
        )

        check_items.append(CheckItem(
            item_id="C06",
            category="주차장법",
            name="주차 대수",
            legal_basis="주차장법 시행규칙 §6, 별표1",
            required_value=f"{required_parking}대 이상 (세대당 {parking['applied_ratio']}대)",
            actual_value=f"설계 반영 필요",
            status=(CheckStatus.WARNING if not parking_feasible else CheckStatus.PASS),
            message=(f"{planned_units}세대 × {parking['applied_ratio']}대 = {required_parking}대 필요 "
                     f"({parking['parking_type_recommendation']} 권장)"),
            recommendation=(
                f"기계식 주차(2단) 도입 시 면적 {parking['mechanical_parking_area_m2']:.0f}㎡로 절감 가능"
                if not parking_feasible else ""
            )
        ))

        # ── 7. 피난 계단 (피난방화규칙 §8, §9) ──────────
        fire = FireSafetyChecker.check_emergency_exits(
            planned_units, total_floors, building_height_m
        )

        check_items.append(CheckItem(
            item_id="C07",
            category="피난방화",
            name="피난계단",
            legal_basis="건축물의 피난·방화구조 등의 기준에 관한 규칙 §8, §9",
            required_value=f"{fire['required_stairs']}개 이상 ({fire['stair_type']})",
            actual_value="설계 반영 필요",
            status=CheckStatus.WARNING,
            message=f"{total_floors}층 건물 → {fire['stair_type']} {fire['required_stairs']}개 이상 설치 필요",
            recommendation=(
                "공용 계단·엘리베이터 코어를 별도 모듈로 설계 권장 (Gen 2 코어모듈 적용 검토)"
            )
        ))

        # ── 8. 복도 폭 기준 (피난방화규칙 §15의2) ───────
        # Gen 2 표준복도 1,400mm > 최소기준 1,200mm (편복도) — 적합
        check_items.append(CheckItem(
            item_id="C08",
            category="피난방화",
            name="복도 폭",
            legal_basis="건축물의 피난·방화구조 등의 기준에 관한 규칙 §15의2",
            required_value="편복도 최소 1,200mm 이상",
            actual_value="Gen 2 표준복도 1,400mm / 광폭복도 2,000mm",
            status=CheckStatus.PASS,
            message="Gen 2 표준복도(1,400mm) — 최소기준(1,200mm) 초과 적합",
            recommendation=""
        ))

        # ── 9. 스프링클러 (소방시설법) ──────────────────
        sprinkler_req = fire["sprinkler_required"]
        check_items.append(CheckItem(
            item_id="C09",
            category="소방법",
            name="스프링클러",
            legal_basis="소방시설 설치 및 관리에 관한 법률, 6층 이상/16세대 이상",
            required_value=f"{'설치 의무' if sprinkler_req else '임의'}",
            actual_value=f"{total_floors}층, {planned_units}세대",
            status=(CheckStatus.WARNING if sprinkler_req else CheckStatus.PASS),
            message=(f"{'⚠️ 스프링클러 설치 의무 (6층 이상 또는 16세대 이상)' if sprinkler_req else '스프링클러 설치 의무 없음'}"),
            recommendation=(
                "Gen 2 샤프트(1000×650mm)에 스프링클러 입상관 포함 설계 권장"
                if sprinkler_req else ""
            )
        ))

        # ── 10. 모듈러 건축 특례 (건축법 시행령 §6의3) ──
        modular_check = FireSafetyChecker.check_modular_exemptions(total_floors)
        modular_exemptions = [e["item"] for e in modular_check["exemptions"] if e["applicable"]]

        check_items.append(CheckItem(
            item_id="C10",
            category="건축법(특례)",
            name="모듈러 공업화건축물 특례",
            legal_basis="건축법 §23의3, 시행령 §6의3",
            required_value="공업화건축물 인정 신청",
            actual_value=f"적용 가능 항목 {modular_check['total_applicable']}건",
            status=CheckStatus.PASS,
            message=f"모듈러 공법 특례 {modular_check['total_applicable']}항목 적용 가능",
            recommendation=modular_check["notes"]
        ))

        # ── 결과 집계 ────────────────────────────────────
        pass_count    = sum(1 for i in check_items if i.status == CheckStatus.PASS)
        warning_count = sum(1 for i in check_items if i.status == CheckStatus.WARNING)
        fail_count    = sum(1 for i in check_items if i.status == CheckStatus.FAIL)

        if fail_count > 0:
            overall_status = CheckStatus.FAIL
        elif warning_count > 0:
            overall_status = CheckStatus.WARNING
        else:
            overall_status = CheckStatus.PASS

        critical_issues = [i.message for i in check_items if i.status == CheckStatus.FAIL]
        recommendations = [
            i.recommendation for i in check_items
            if i.recommendation and i.status in (CheckStatus.WARNING, CheckStatus.FAIL)
        ]

        return RegulationCheckReport(
            zone_type=zone_type,
            parcel_area_m2=parcel_area_m2,
            planned_units=planned_units,
            total_floors=total_floors,
            building_footprint_m2=building_footprint_m2,
            total_floor_area_m2=total_floor_area_m2,
            module_type=module_type,
            check_items=check_items,
            overall_status=overall_status,
            pass_count=pass_count,
            warning_count=warning_count,
            fail_count=fail_count,
            modular_exemption_applied=len(modular_exemptions) > 0,
            modular_exemption_items=modular_exemptions,
            critical_issues=critical_issues,
            recommendations=recommendations,
            required_coverage_pct=zone_regs["coverage"],
            required_far_pct=zone_regs["far"],
            required_parking_spaces=required_parking,
            required_emergency_exits=fire["required_stairs"],
            required_staircase_count=fire["required_stairs"],
        )


# 싱글톤 인스턴스
regulation_checker = RegulationChecker()
