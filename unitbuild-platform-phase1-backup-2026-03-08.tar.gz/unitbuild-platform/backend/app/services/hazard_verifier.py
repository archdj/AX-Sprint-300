"""
GPS·GIS 기반 위해시설 자동 검증 서비스

LH 신축매입약정 기준 이격거리 자동 판정
- Phase 1: Mock 데이터 기반 (실제 API 연동은 Phase 2)
- Phase 2: 브이월드 API, 카카오맵 API 실제 연동
"""

import math
import random
import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime
from typing import List, Dict, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class HazardCheckResult:
    hazard_type: str
    hazard_label: str
    is_compliant: bool
    nearest_distance_m: float
    required_distance_m: int
    nearest_facility_name: str
    nearest_facility_coords: Tuple[float, float]
    improvement: str


@dataclass
class HazardVerificationReport:
    site_lat: float
    site_lng: float
    overall_compliant: bool
    results: List[HazardCheckResult]
    compliant_count: int
    non_compliant_count: int
    risk_level: str  # SAFE / WARNING / DANGER
    verification_timestamp: str
    data_source: str = "mock"


class HazardVerifier:
    """
    위해시설 이격거리 검증기

    검증 항목 (LH 신축매입약정 기준):
      주유소·LPG충전소 : 25m 이상
      고압선 철탑       : 30m 이상
      공장·창고         : 50m 이상
      유해업소          : 200m 이상
      소각장·납골당     : 300m 이상
    """

    HAZARD_RULES: Dict[str, Dict] = {
        'gas_station': {
            'label': '주유소·LPG충전소',
            'min_distance_m': 25,
            'kakao_category': 'OL7',
            'vworld_layer': 'LP_LDGP_LHST',
            'icon': '⛽',
        },
        'power_tower': {
            'label': '고압선 철탑',
            'min_distance_m': 30,
            'vworld_layer': 'LP_LDGP_POWR',
            'icon': '⚡',
        },
        'factory': {
            'label': '공장·창고',
            'min_distance_m': 50,
            'kakao_category': 'AT4',
            'vworld_layer': 'LP_LDGP_FCTY',
            'icon': '🏭',
        },
        'harmful_business': {
            'label': '유해업소',
            'min_distance_m': 200,
            'kakao_category': 'FD6',
            'icon': '🚫',
        },
        'incinerator': {
            'label': '소각장·납골당',
            'min_distance_m': 300,
            'vworld_layer': 'LP_LDGP_INCN',
            'icon': '🔥',
        },
    }

    def haversine_distance(
        self, lat1: float, lng1: float, lat2: float, lng2: float
    ) -> float:
        """두 좌표간 직선거리 계산 (미터, Haversine 공식)"""
        R = 6_371_000  # 지구 반경 (m)
        phi1, phi2 = math.radians(lat1), math.radians(lat2)
        delta_phi = math.radians(lat2 - lat1)
        delta_lambda = math.radians(lng2 - lng1)
        a = (
            math.sin(delta_phi / 2) ** 2
            + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2
        )
        return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    # ─────────────────────────────────────────────────────────
    # Mock 데이터 생성 (Phase 1)
    # ─────────────────────────────────────────────────────────

    def _generate_mock_facilities(
        self,
        lat: float,
        lng: float,
        hazard_type: str,
        radius_m: int,
    ) -> List[Dict]:
        """
        실제 API 미연동 상태에서 테스트용 Mock 위해시설 데이터 생성
        실제 프로젝트에서는 브이월드/카카오맵 API로 교체
        """
        rule = self.HAZARD_RULES[hazard_type]
        facilities = []

        # 시드 기반 난수 → 동일 좌표에 대해 재현 가능한 결과
        seed = int((lat * 1000 + lng * 1000 + hash(hazard_type)) % 10000)
        rng = random.Random(seed)

        # 위해시설 존재 확률 (유형별 빈도 반영)
        exist_prob = {
            'gas_station': 0.7,
            'power_tower': 0.4,
            'factory': 0.5,
            'harmful_business': 0.6,
            'incinerator': 0.2,
        }

        if rng.random() > exist_prob.get(hazard_type, 0.5):
            return []  # 해당 없음

        # 1~3개 시설 생성
        count = rng.randint(1, 3)
        for i in range(count):
            # 반경 내 무작위 위치 생성
            angle = rng.uniform(0, 2 * math.pi)
            dist_m = rng.uniform(rule['min_distance_m'] * 0.3, radius_m)

            # 미터 → 위경도 변환 (근사)
            delta_lat = (dist_m * math.cos(angle)) / 111_320
            delta_lng = (dist_m * math.sin(angle)) / (111_320 * math.cos(math.radians(lat)))

            facilities.append({
                'name': f"{rule['label']} {i+1}호",
                'lat': lat + delta_lat,
                'lng': lng + delta_lng,
                'address': f"Mock 주소 ({hazard_type})",
                'source': 'mock',
            })

        return facilities

    # ─────────────────────────────────────────────────────────
    # 실제 API 연동 (Phase 2 — 현재 Stub)
    # ─────────────────────────────────────────────────────────

    async def _fetch_from_vworld(
        self, lat: float, lng: float, layer: str, radius_m: int
    ) -> List[Dict]:
        """브이월드 공간정보 API (Phase 2 구현 예정)"""
        # TODO: https://api.vworld.kr/req/data 연동
        return []

    async def _fetch_from_kakao(
        self, lat: float, lng: float, category_code: str, radius_m: int
    ) -> List[Dict]:
        """카카오맵 장소 검색 API (Phase 2 구현 예정)"""
        # TODO: https://dapi.kakao.com/v2/local/search/category.json 연동
        return []

    async def _fetch_nearby_facilities(
        self, lat: float, lng: float, hazard_type: str, radius_m: int
    ) -> List[Dict]:
        """위해시설 데이터 수집 (Phase 1: Mock, Phase 2: 실제 API)"""
        rule = self.HAZARD_RULES[hazard_type]

        # Phase 2: 실제 API 시도
        facilities = []
        if 'vworld_layer' in rule:
            try:
                facilities = await self._fetch_from_vworld(
                    lat, lng, rule['vworld_layer'], radius_m
                )
            except Exception as e:
                logger.warning(f"VWorld API 오류: {e}")

        if not facilities and 'kakao_category' in rule:
            try:
                facilities = await self._fetch_from_kakao(
                    lat, lng, rule['kakao_category'], radius_m
                )
            except Exception as e:
                logger.warning(f"Kakao API 오류: {e}")

        # Mock 데이터로 폴백 (Phase 1)
        if not facilities:
            facilities = self._generate_mock_facilities(lat, lng, hazard_type, radius_m)
            logger.debug(f"Mock 데이터 사용: {hazard_type}, {len(facilities)}개")

        return facilities

    # ─────────────────────────────────────────────────────────
    # 메인 검증 함수
    # ─────────────────────────────────────────────────────────

    async def verify(
        self,
        lat: float,
        lng: float,
        search_radius_m: int = 500
    ) -> HazardVerificationReport:
        """
        좌표 기반 전체 위해시설 자동 검증

        Args:
            lat: 사업지 위도
            lng: 사업지 경도
            search_radius_m: 검색 반경 (m)

        Returns:
            HazardVerificationReport
        """
        tasks = []
        for hazard_type, rule in self.HAZARD_RULES.items():
            fetch_radius = max(search_radius_m, rule['min_distance_m'] * 5)
            tasks.append(
                self._fetch_nearby_facilities(lat, lng, hazard_type, fetch_radius)
            )

        all_facilities = await asyncio.gather(*tasks)
        results: List[HazardCheckResult] = []

        for (hazard_type, rule), facilities in zip(self.HAZARD_RULES.items(), all_facilities):
            if not facilities:
                results.append(HazardCheckResult(
                    hazard_type=hazard_type,
                    hazard_label=rule['label'],
                    is_compliant=True,
                    nearest_distance_m=float('inf'),
                    required_distance_m=rule['min_distance_m'],
                    nearest_facility_name='해당 없음',
                    nearest_facility_coords=(0.0, 0.0),
                    improvement='',
                ))
                continue

            # 가장 가까운 시설 탐색
            nearest = min(
                facilities,
                key=lambda f: self.haversine_distance(lat, lng, f['lat'], f['lng'])
            )
            nearest_dist = self.haversine_distance(lat, lng, nearest['lat'], nearest['lng'])
            compliant = nearest_dist >= rule['min_distance_m']

            improvement = ''
            if not compliant:
                shortage = rule['min_distance_m'] - nearest_dist
                improvement = (
                    f"현재 {nearest_dist:.1f}m — "
                    f"{rule['min_distance_m']}m 이상 이격 필요 "
                    f"(추가 {shortage:.1f}m 확보 필요)"
                )

            results.append(HazardCheckResult(
                hazard_type=hazard_type,
                hazard_label=rule['label'],
                is_compliant=compliant,
                nearest_distance_m=round(nearest_dist, 1),
                required_distance_m=rule['min_distance_m'],
                nearest_facility_name=nearest.get('name', ''),
                nearest_facility_coords=(nearest['lat'], nearest['lng']),
                improvement=improvement,
            ))

        non_compliant = [r for r in results if not r.is_compliant]
        compliant_count = len(results) - len(non_compliant)

        if len(non_compliant) == 0:
            risk_level = 'SAFE'
        elif len(non_compliant) == 1:
            risk_level = 'WARNING'
        else:
            risk_level = 'DANGER'

        data_source = 'mock'  # Phase 2에서 'vworld+kakao'로 변경

        return HazardVerificationReport(
            site_lat=lat,
            site_lng=lng,
            overall_compliant=(len(non_compliant) == 0),
            results=results,
            compliant_count=compliant_count,
            non_compliant_count=len(non_compliant),
            risk_level=risk_level,
            verification_timestamp=datetime.now().isoformat(),
            data_source=data_source,
        )

    def get_hazard_rules_summary(self) -> List[Dict]:
        """위해시설 기준 요약 반환"""
        return [
            {
                'type': k,
                'label': v['label'],
                'min_distance_m': v['min_distance_m'],
                'icon': v.get('icon', ''),
            }
            for k, v in self.HAZARD_RULES.items()
        ]


# 싱글톤 인스턴스
hazard_verifier = HazardVerifier()
