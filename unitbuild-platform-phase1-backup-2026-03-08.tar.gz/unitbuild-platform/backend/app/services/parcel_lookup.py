"""
필지 자동 조회 엔진 (Parcel Lookup Service)

지번 입력 → 자동 데이터 수집 파이프라인:
  1. 주소 문자열 파싱 (시도/시군구/읍면동/번지)
  2. VWorld 주소검색 API → WGS84 좌표 (위경도)
  3. VWorld 토지임야정보 API (PNU) → 면적, 지목
  4. VWorld 토지특성정보 API → 용도지역, 지형
  5. VWorld 토지이용계획 API → 용도지역지구 확인
  6. 카카오 로컬 API → 주변 시설 거리 계산 (SITE-C B항목)
  7. 주변 대중교통 검색 (SITE-C A항목)

설계 원칙:
  - API 키 없이도 시뮬레이션 모드로 동작
  - 실제 API 키 환경변수 설정 시 실데이터 조회
  - 비동기 병렬 처리로 응답 속도 최적화
"""

import os
import re
import logging
import asyncio
import math
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Tuple
import httpx

logger = logging.getLogger(__name__)

# ─── 환경변수 API 키 ───────────────────────────────────────────
# .env 파일 또는 환경변수에서 읽어옴
VWORLD_API_KEY   = os.getenv("VWORLD_API_KEY", "")       # 지도/검색 API 키
VWORLD_NED_KEY   = os.getenv("VWORLD_NED_API_KEY", "")   # NED 국가중점데이터 전용 키
VWORLD_DOMAIN    = os.getenv("VWORLD_DOMAIN", "")         # 등록 URL (domain 파라미터용)
KAKAO_REST_KEY   = os.getenv("KAKAO_REST_API_KEY", "")
SEOUL_GIS_KEY    = os.getenv("SEOUL_GIS_API_KEY", "")      # 서울시 공간정보포털 OpenAPI 키
DATA_GO_KR_KEY   = os.getenv("DATA_GO_KR_API_KEY", "")    # 공공데이터포털 서비스키 (토지이용계획정보)

# VWorld API 기본 URL (2024-2025 공식 엔드포인트)
VWORLD_GEOCODER  = "https://api.vworld.kr/req/address"     # 주소→좌표 변환
VWORLD_DATA_API  = "https://api.vworld.kr/ned/data"         # 토지임야/특성 정보
VWORLD_SEARCH    = "https://api.vworld.kr/req/search"       # 검색
VWORLD_2D_DATA   = "https://api.vworld.kr/req/data"         # 2D 데이터 API (토지이용계획 등)

# 서울시 공간정보포털
SEOUL_WFS_URL    = "https://map.seoul.go.kr/smgis2/wfs"     # 서울시 스마트서울맵 WFS

# 카카오 로컬 API
KAKAO_LOCAL_API  = "https://dapi.kakao.com/v2/local" 

# ─── 데이터 클래스 ─────────────────────────────────────────────

@dataclass
class CoordResult:
    """좌표 변환 결과"""
    lat: float
    lng: float
    address_road: str = ""
    address_parcel: str = ""
    pnu: str = ""          # 고유필지번호 (19자리)
    sigungu_code: str = "" # 시군구 코드 (5자리)
    emd_code: str = ""     # 읍면동 코드 (10자리)
    source: str = "simulation"


@dataclass
class ParcelInfo:
    """필지 기본 정보"""
    area_m2: float           # 필지 면적 (m²)
    land_category: str       # 지목 (대, 전, 답 등)
    land_category_code: str  # 지목 코드
    address: str             # 표준 주소
    pnu: str                 # 고유필지번호


@dataclass
class LandCharacteristics:
    """토지 특성 정보"""
    zone_name: str           # 용도지역 명칭 (예: 제2종일반주거지역)
    zone_name2: str = ""     # 용도지구 명칭
    land_use: str = ""       # 토지이용상황
    topography_high: str = "" # 지형고저
    topography_form: str = "" # 지형형상
    road_side: str = ""      # 도로접면


@dataclass
class FacilityDistance:
    """시설 거리 정보"""
    name: str
    category: str
    distance_m: float
    lat: float
    lng: float


@dataclass
class ParcelLookupResult:
    """필지 조회 통합 결과 — SITE-C 자동 평가용"""
    # 기본 위치
    address_input: str
    lat: float
    lng: float
    pnu: str

    # 필지 정보
    area_m2: float
    land_category: str
    zone_name: str           # 용도지역
    zone_name2: str          # 용도지구

    # SITE-C A. 교통 접근성 (자동 계산)
    cbd_distance_km: float
    subway_distance_m: float
    bus_stop_distance_m: float

    # SITE-C B. 생활 인프라
    elementary_school_distance_m: float
    hospital_distance_m: float
    mart_distance_m: float

    # SITE-C D. 구조·안전 (지형 기반 추정)
    slope_percent: float
    seismic_grade: int       # 지진위험지도 기반 (1 or 2)

    # SITE-C E. 에너지 (일조 추정)
    sunshine_hours: float

    # 추가 시설 목록
    nearby_subway: List[FacilityDistance] = field(default_factory=list)
    nearby_bus: List[FacilityDistance] = field(default_factory=list)
    nearby_school: List[FacilityDistance] = field(default_factory=list)
    nearby_hospital: List[FacilityDistance] = field(default_factory=list)
    nearby_mart: List[FacilityDistance] = field(default_factory=list)

    # 도로 정보
    road_width_m: float = 6.0
    road_side: str = ""

    # 지역지구 코드 목록 (VWorld getLandUseAttr)
    land_use_codes: list = None

    def __post_init__(self):
        if self.land_use_codes is None:
            self.land_use_codes = []

    # 데이터 소스 메타
    data_sources: List[str] = field(default_factory=list)
    lookup_errors: List[str] = field(default_factory=list)
    is_simulation: bool = True


# ─── 주소 파싱 유틸리티 ────────────────────────────────────────

def parse_address(address: str) -> Dict[str, str]:
    """
    다양한 형식의 주소를 파싱합니다.
    입력 예시:
      - "서울시 강남구 역삼동 123-45"
      - "강남구 역삼동 123"
      - "서울특별시 강남구 역삼동 123-45번지"
      - "경기도 성남시 분당구 정자동 1-1"
    """
    addr = address.strip()

    # 번지 제거
    addr = re.sub(r'번지\s*$', '', addr)

    # 시도/시군구/읍면동/지번 패턴 분리
    parts = addr.split()

    result = {
        "full_address": address.strip(),
        "cleaned": addr,
        "sido": "",
        "sigungu": "",
        "eupmyeondong": "",
        "jibun": "",
        "main_no": "",
        "sub_no": "0",
    }

    # 지번 패턴 (숫자-숫자 or 숫자)
    jibun_pattern = re.compile(r'^(\d+)(?:-(\d+))?$')

    for i, part in enumerate(parts):
        m = jibun_pattern.match(part)
        if m:
            result["jibun"] = part
            result["main_no"] = m.group(1)
            result["sub_no"] = m.group(2) or "0"
            # 앞부분 조합
            prefix = " ".join(parts[:i])
            if prefix:
                prefix_parts = prefix.split()
                if len(prefix_parts) >= 3:
                    result["sido"] = prefix_parts[0]
                    result["sigungu"] = prefix_parts[1]
                    result["eupmyeondong"] = " ".join(prefix_parts[2:])
                elif len(prefix_parts) == 2:
                    result["sigungu"] = prefix_parts[0]
                    result["eupmyeondong"] = prefix_parts[1]
                elif len(prefix_parts) == 1:
                    result["eupmyeondong"] = prefix_parts[0]
            break

    return result


def haversine_distance(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    """
    두 좌표 사이의 직선 거리 계산 (미터)
    """
    R = 6371000  # 지구 반지름 (m)
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lng2 - lng1)
    a = math.sin(dphi/2)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


# ─── VWorld API 연동 ─────────────────────────────────────────

async def vworld_geocode(address: str, addr_type: str = "PARCEL") -> Optional[CoordResult]:
    """
    VWorld 주소검색 API (Geocoder 2.0): 주소 → 좌표
    addr_type: "PARCEL" (지번주소) | "ROAD" (도로명주소)
    엔드포인트: https://api.vworld.kr/req/address
    공식 파라미터: service=address, request=GetCoord, type=PARCEL|ROAD
    """
    if not VWORLD_API_KEY:
        return None

    try:
        params = {
            "service": "address",
            "version": "2.0",
            "request": "GetCoord",       # 주소→좌표 변환
            "format": "json",
            "errorFormat": "json",
            "refine": "true",
            "simple": "false",
            "key": VWORLD_API_KEY,
            "address": address,
            "type": addr_type,           # PARCEL=지번, ROAD=도로명
            "crs": "epsg:4326",          # WGS84 경위도
        }
        # Referer 헤더 설정 (도메인 인증 우회 시도)
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "application/json, */*",
        }
        if VWORLD_DOMAIN:
            headers["Referer"] = VWORLD_DOMAIN
            params["domain"] = VWORLD_DOMAIN
        logger.info(f"VWorld 지오코딩 요청: {address} (type={addr_type}, domain={VWORLD_DOMAIN!r})")
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(VWORLD_GEOCODER, params=params, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        logger.debug(f"VWorld 지오코딩 응답: status={data.get('response', {}).get('status')}")

        response = data.get("response", {})
        status = response.get("status", "")

        if status == "OK":
            result = response.get("result", {})
            point = result.get("point", {})
            if point.get("x") and point.get("y"):
                return CoordResult(
                    lat=float(point["y"]),
                    lng=float(point["x"]),
                    address_parcel=result.get("refined", {}).get("text", address),
                    source="vworld",
                )
        elif status == "NOT_FOUND":
            logger.info(f"VWorld 지오코딩: 결과 없음 ({address})")
        elif status == "ERROR":
            error_code = response.get("error", {}).get("code", "")
            error_text = response.get("error", {}).get("text", "")
            logger.warning(f"VWorld 지오코딩 에러: {error_code} - {error_text}")
    except Exception as e:
        logger.warning(f"VWorld 지오코딩 오류: {e}")
    return None


async def vworld_get_land_info(pnu: str) -> Optional[ParcelInfo]:
    """
    VWorld NED 토지임야정보 API: PNU(19자리) → 필지 기본 정보 (면적, 지목)
    엔드포인트: https://api.vworld.kr/ned/data/ladfrlList
    키: VWORLD_NED_API_KEY (국가중점데이터 전용 키)
    domain 파라미터 필수: 발급 시 등록한 URL과 일치해야 함
    """
    ned_key = VWORLD_NED_KEY or VWORLD_API_KEY
    if not ned_key:
        return None

    try:
        url = f"{VWORLD_DATA_API}/ladfrlList"
        params = {
            "format": "json",
            "key": ned_key,
            "pnu": pnu,
            "numOfRows": "1",
        }
        # domain 파라미터: 발급 시 등록한 URL (필수)
        if VWORLD_DOMAIN:
            params["domain"] = VWORLD_DOMAIN
        headers = {
            "User-Agent": "Mozilla/5.0 (compatible; UnitBuild/1.0)",
        }
        logger.info(f"VWorld NED 토지임야정보 요청: PNU={pnu}")
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(url, params=params, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        # JSON 응답 구조: {"ladfrlVOList": {"totalCount":"1", "ladfrlVOList":[...]}}
        vo_root = data.get("ladfrlVOList", {})
        # NED API 특성: 정상 응답에도 "error": "" 빈문자열이 포함됨 → 빈 문자열은 무시
        ned_error = vo_root.get("error", "")
        if ned_error and str(ned_error).strip():
            logger.warning(f"VWorld NED 토지임야정보 오류: {ned_error} - {vo_root.get('message', '')}")
            return None

        try:
            total_count = int(vo_root.get("totalCount", 0))
        except (ValueError, TypeError):
            total_count = 0
        if total_count == 0:
            logger.info(f"VWorld NED 토지임야정보: 결과 없음 (PNU={pnu})")
            return None

        items = vo_root.get("ladfrlVOList", [])
        if isinstance(items, dict):
            items = [items]
        if not items:
            return None

        item = items[0]
        area = float(item.get("lndpclAr", 0))
        address = item.get("ldCodeNm", "")

        logger.info(f"VWorld NED 토지임야정보 수신 (실데이터): 면적={area}m2, 지목={item.get('lndcgrCodeNm', '')}")
        return ParcelInfo(
            area_m2=area,
            land_category=item.get("lndcgrCodeNm", "대"),
            land_category_code=item.get("lndcgrCode", "08"),
            address=address,
            pnu=pnu,
        )
    except Exception as e:
        logger.warning(f"VWorld NED 토지임야정보 오류: {e}")
    return None


async def vworld_get_land_characteristics(pnu: str) -> Optional[LandCharacteristics]:
    """
    VWorld NED 토지특성정보 API: PNU → 용도지역, 지형 정보
    엔드포인트: https://api.vworld.kr/ned/data/getLandCharacteristics
    키: VWORLD_NED_API_KEY (국가중점데이터 전용 키)
    응답 구조: {"landCharacteristicss": {"totalCount":N, "field":[...]}}
    핵심 필드: prposArea1Nm (용도지역), prposArea2Nm (용도지구), roadSideCodeNm (도로접면)
    """
    ned_key = VWORLD_NED_KEY or VWORLD_API_KEY
    if not ned_key:
        return None

    try:
        url = f"{VWORLD_DATA_API}/getLandCharacteristics"
        import datetime
        current_year = datetime.datetime.now().year
        params = {
            "format": "json",
            "key": ned_key,
            "pnu": pnu,
            "stdrYear": str(current_year - 1),
            "numOfRows": "10",
        }
        if VWORLD_DOMAIN:
            params["domain"] = VWORLD_DOMAIN
        headers = {
            "User-Agent": "Mozilla/5.0 (compatible; UnitBuild/1.0)",
        }
        logger.info(f"VWorld NED 토지특성정보 요청: PNU={pnu}, 기준년도={current_year-1}")
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(url, params=params, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        # 응답 구조: {"landCharacteristicss": {"resultCode":"...", "totalCount":N, "field":[...]}}
        lc_root = data.get("landCharacteristicss", {})
        rc = lc_root.get("resultCode", "")
        if rc and str(rc).strip() and rc not in ("OK", "00"):
            logger.warning(f"VWorld NED 토지특성정보 오류: {rc} - {lc_root.get('resultMsg', '')}")
            return None
        # NED API 특성: "error" 빈문자열 무시
        lc_error = lc_root.get("error", "")
        if lc_error and str(lc_error).strip():
            logger.warning(f"VWorld NED 토지특성정보 오류: {lc_error}")
            return None

        try:
            total_count = int(lc_root.get("totalCount", 0))
        except (ValueError, TypeError):
            total_count = 0
        if total_count == 0:
            logger.info(f"VWorld NED 토지특성정보: 결과 없음 (PNU={pnu})")
            return None

        field_list = lc_root.get("field", [])
        if not field_list:
            return None

        # 최신 데이터 선택 (lastUpdtDt 기준 정렬)
        items = field_list if isinstance(field_list, list) else [field_list]
        items_sorted = sorted(
            items,
            key=lambda x: x.get("lastUpdtDt", "0000-00-00"),
            reverse=True
        )
        item = items_sorted[0]

        # 용도지역명 추출 (코드→명칭 우선, 없으면 코드)
        zone_name = (
            item.get("prposArea1Nm") or
            _zone_code_to_name(item.get("prposArea1", "")) or
            item.get("prposArea1", "")
        )
        zone_name2 = (
            item.get("prposArea2Nm") or
            item.get("prposArea2", "")
        )

        logger.info(f"VWorld 토지특성정보 수신: 용도지역={zone_name}")
        return LandCharacteristics(
            zone_name=zone_name,
            zone_name2=zone_name2,
            land_use=item.get("ladUseSittnNm", item.get("ladUseSittn", "")),
            topography_high=item.get("tpgrphHgCodeNm", item.get("tpgrphHgCode", "")),
            topography_form=item.get("tpgrphFrmCodeNm", item.get("tpgrphFrmCode", "")),
            road_side=item.get("roadSideCodeNm", item.get("roadSideCode", "")),
        )
    except Exception as e:
        logger.warning(f"VWorld 토지특성정보 오류: {e}")
    return None



async def vworld_get_land_use_attr(pnu: str) -> list:
    """VWorld NED getLandUseAttr로 지역지구 코드 목록 반환.
    DATA_GO_KR_API_KEY 설정 시 공공데이터포털 토지이용계획 속성조회로 '제2종일반주거지역(7층이하)' 등
    상세 용도지역명까지 함께 반환.
    반환값: ['UQA122', 'UNE200', ...]  (코드 리스트, 7층이하 감지 시 'ZONE_7F' 포함)
    """
    ned_key = VWORLD_NED_KEY or VWORLD_API_KEY
    if not ned_key:
        return []

    # ── Step A: 공공데이터포털 토지이용계획 속성조회 (DATA_GO_KR_API_KEY 설정 시) ──
    # 이 API는 '제2종일반주거지역(7층이하)' 텍스트를 prposAreaDstrcCodeNm 필드로 반환함
    if DATA_GO_KR_KEY:
        try:
            luris_result = await _datagokr_get_land_use_detail(pnu)
            if luris_result is not None:
                return luris_result
        except Exception as e:
            logger.warning(f"공공데이터포털 토지이용계획 조회 실패, VWorld fallback: {e}")

    # ── Step B: VWorld NED getLandUseAttr (기존 로직) ──
    try:
        url = VWORLD_DATA_API + "/getLandUseAttr"
        params = {"format": "json", "key": ned_key, "pnu": pnu, "numOfRows": "30"}
        if VWORLD_DOMAIN:
            params["domain"] = VWORLD_DOMAIN
        headers = {"User-Agent": "Mozilla/5.0 (compatible; UnitBuild/1.0)"}
        logger.info("VWorld 토지이용계획 요청: PNU=" + pnu)
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(url, params=params, headers=headers)
            resp.raise_for_status()
            data = resp.json()
        root = data.get("landUses", {})
        rc = root.get("resultCode", "")
        if rc and str(rc).strip() and rc not in ("OK", "00", ""):
            logger.warning("VWorld 토지이용계획 오류: " + rc)
            return []
        items = root.get("field", [])
        if not isinstance(items, list):
            return []
        codes = [item.get("prposAreaDstrcCode", "") for item in items if item.get("prposAreaDstrcCode")]
        logger.info("VWorld 토지이용계획: " + str(len(codes)) + "개 지역지구")
        return codes
    except Exception as e:
        logger.warning("VWorld 토지이용계획 오류: " + str(e))
    return []


async def _datagokr_get_land_use_detail(pnu: str) -> "Optional[list]":
    """공공데이터포털 토지이용계획정보 속성조회 API (VWorld NED 연동).
    '제2종일반주거지역(7층이하)' 텍스트를 직접 반환하는 유일한 공식 API.
    
    신청: https://www.data.go.kr/data/15123973/openapi.do
    키 등록: DATA_GO_KR_API_KEY 환경변수
    자동 승인 (1~3일 이내)
    
    반환: 코드 리스트. 7층이하 감지 시 특수 코드 'ZONE_7F' 포함.
    반환 None: API 오류 또는 응답 없음 → VWorld fallback 사용
    """
    try:
        # data.go.kr 토지이용계획 속성조회는 VWorld NED 엔드포인트를 사용
        # (data.go.kr 15123973은 VWorld로 연결되는 LINK 타입)
        url = VWORLD_DATA_API + "/getLandUseAttr"
        params = {
            "format": "json",
            "key": DATA_GO_KR_KEY,
            "pnu": pnu,
            "numOfRows": "30",
            "pageNo": "1",
        }
        if VWORLD_DOMAIN:
            params["domain"] = VWORLD_DOMAIN
        headers = {"User-Agent": "Mozilla/5.0 (compatible; UnitBuild/1.0)"}
        logger.info(f"공공데이터포털 토지이용계획 조회: PNU={pnu}")
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(url, params=params, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        root = data.get("landUses", {})
        rc = str(root.get("resultCode", "")).strip()
        if rc and rc not in ("OK", "00", ""):
            logger.warning(f"공공데이터포털 토지이용계획 오류코드: {rc}")
            return None  # VWorld fallback 허용

        items = root.get("field", [])
        if not isinstance(items, list) or not items:
            return None

        codes = []
        is_7floor = False
        for item in items:
            code = item.get("prposAreaDstrcCode", "")
            name = item.get("prposAreaDstrcCodeNm", "")
            if code:
                codes.append(code)
            # ★ 핵심: prposAreaDstrcCodeNm에 '7층' 텍스트 포함 여부 감지
            if "7층" in name:
                is_7floor = True
                logger.info(f"7층이하 지정구역 감지: {name} (PNU={pnu})")

        if is_7floor:
            codes.append("ZONE_7F")   # 7층이하 마커 코드 추가

        logger.info(
            f"공공데이터포털 토지이용계획: {len(codes)}개 "
            f"(7층이하={'YES' if is_7floor else 'NO'})"
        )
        return codes

    except Exception as e:
        logger.warning(f"공공데이터포털 토지이용계획 오류: {e}")
        return None  # None 반환 → VWorld fallback


async def seoul_smgis_get_zone_info(lat: float, lng: float) -> "Optional[str]":
    """서울시 공간정보포털 WFS로 용도지역 상세 조회 (SEOUL_GIS_API_KEY 필요)"""
    if not SEOUL_GIS_KEY:
        return None
    try:
        params = {
            "SERVICE": "WFS", "VERSION": "2.0.0", "REQUEST": "GetFeature",
            "TYPENAME": "UQ111", "SRSNAME": "EPSG:4326",
            "outputFormat": "application/json",
            "CQL_FILTER": f"INTERSECTS(geom,POINT({lng} {lat}))",
            "count": "5", "authKey": SEOUL_GIS_KEY,
        }
        headers = {"User-Agent": "Mozilla/5.0", "Referer": "https://map.seoul.go.kr/smgis2/"}
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(SEOUL_WFS_URL, params=params, headers=headers)
            if resp.status_code != 200:
                return None
            data = resp.json()
            for feat in data.get("features", []):
                props = feat.get("properties", {})
                zone_nm = (props.get("LUSE_NM") or props.get("uname") or
                          props.get("ZONE_NM") or props.get("prposArea1Nm") or "")
                if zone_nm and zone_nm.strip():
                    logger.info(f"서울시 WFS 용도지역: {zone_nm}")
                    return zone_nm.strip()
    except Exception as e:
        logger.warning(f"서울시 WFS 오류: {e}")
    return None


async def check_seoul_zone_7floor(lat: float, lng: float, zone_name: str) -> bool:
    """서울시 제2종일반주거지역 7층이하 지정구역 여부 확인"""
    if "7층" in zone_name:
        return True
    if SEOUL_GIS_KEY and "제2종일반" in zone_name:
        seoul_zone = await seoul_smgis_get_zone_info(lat, lng)
        if seoul_zone and "7층" in seoul_zone:
            return True
    return False


# 용도지역 코드 → 명칭 매핑 (rev1: 코드 기반 파싱)
_ZONE_CODE_MAP = {
    "UQA": "제1종전용주거지역",
    "UQB": "제2종전용주거지역",
    "UGA": "제1종일반주거지역",
    "UGB": "제2종일반주거지역",
    "UGC": "제3종일반주거지역",
    "UQD": "준주거지역",
    "UIA": "중심상업지역",
    "UIB": "일반상업지역",
    "UIC": "근린상업지역",
    "UID": "유통상업지역",
    "UJA": "전용공업지역",
    "UJB": "일반공업지역",
    "UJC": "준공업지역",
    "UKA": "보전녹지지역",
    "UKB": "생산녹지지역",
    "UKC": "자연녹지지역",
    "ULA": "보전관리지역",
    "ULB": "생산관리지역",
    "ULC": "계획관리지역",
    "UMA": "농림지역",
    "UNA": "자연환경보전지역",
}

def _zone_code_to_name(code: str) -> str:
    """VWorld 용도지역 코드를 한국어 명칭으로 변환"""
    return _ZONE_CODE_MAP.get(code.strip(), "")


async def kakao_geocode(address: str) -> Optional[CoordResult]:
    """
    카카오 주소검색 API: 주소 → 좌표 + PNU 자동 생성
    엔드포인트: https://dapi.kakao.com/v2/local/search/address.json
    카카오 개발자 콘솔에서 '지도/로컬' 서비스 활성화 필요.

    카카오 응답에서 b_code(법정동 코드 10자리), 본번, 부번을 추출해
    PNU(19자리) = b_code(10) + 산구분(1) + 본번(4) + 부번(4) 자동 생성.
    """
    if not KAKAO_REST_KEY:
        return None

    try:
        url = f"{KAKAO_LOCAL_API}/search/address.json"
        headers = {"Authorization": f"KakaoAK {KAKAO_REST_KEY}"}
        params = {
            "query": address,
            "size": "1",
        }
        logger.info(f"카카오 주소검색 요청: {address}")
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(url, headers=headers, params=params)
            if resp.status_code == 403:
                logger.warning(
                    "카카오 API 403: 개발자 콘솔에서 '지도/로컬(OPEN_MAP_AND_LOCAL)' "
                    "서비스를 활성화하세요. https://developers.kakao.com"
                )
                return None
            resp.raise_for_status()
            data = resp.json()

        docs = data.get("documents", [])
        if not docs:
            logger.info(f"카카오 주소검색: 결과 없음 ({address})")
            return None

        doc = docs[0]
        lat = float(doc.get("y", 0))
        lng = float(doc.get("x", 0))

        road_address = doc.get("road_address") or {}
        address_data = doc.get("address") or {}
        address_name = road_address.get("address_name", "") or address_data.get("address_name", "")

        # ── PNU 자동 생성 (카카오 응답 활용) ──────────────
        pnu = ""
        b_code = address_data.get("b_code", "")          # 법정동 코드 10자리
        mountain_yn = address_data.get("mountain_yn", "N")
        main_no = address_data.get("main_address_no", "0")
        sub_no  = address_data.get("sub_address_no", "0")

        if b_code and len(b_code) == 10 and main_no:
            try:
                san_code = "2" if mountain_yn == "Y" else "1"
                main_padded = str(int(main_no)).zfill(4)
                sub_padded  = str(int(sub_no or "0")).zfill(4)
                pnu = f"{b_code}{san_code}{main_padded}{sub_padded}"
                logger.info(f"카카오 PNU 생성: {pnu} (b_code={b_code}, 본번={main_no}, 부번={sub_no})")
            except (ValueError, TypeError):
                logger.warning(f"PNU 생성 실패: b_code={b_code}, main={main_no}, sub={sub_no}")

        # 시군구 코드 (앞 5자리)
        sigungu_code = b_code[:5] if b_code else ""

        logger.info(f"카카오 주소검색 수신: lat={lat}, lng={lng}, pnu={pnu}")
        return CoordResult(
            lat=lat,
            lng=lng,
            address_road=address_name,
            address_parcel=doc.get("address_name", address),
            pnu=pnu,
            sigungu_code=sigungu_code,
            emd_code=b_code,
            source="kakao",
        )
    except Exception as e:
        logger.warning(f"카카오 주소검색 오류: {e}")
    return None


async def kakao_reverse_geocode(lat: float, lng: float) -> Optional[Dict[str, str]]:
    """
    카카오 좌표→법정동 역지오코딩
    법정동 코드(B타입)와 행정동 코드(H타입) 반환
    용도지역 추정에 활용
    """
    if not KAKAO_REST_KEY:
        return None
    try:
        url = f"{KAKAO_LOCAL_API}/geo/coord2regioncode.json"
        headers = {"Authorization": f"KakaoAK {KAKAO_REST_KEY}"}
        params = {"x": str(lng), "y": str(lat)}
        async with httpx.AsyncClient(timeout=8.0) as client:
            resp = await client.get(url, headers=headers, params=params)
            if resp.status_code != 200:
                return None
            data = resp.json()

        docs = data.get("documents", [])
        result = {}
        for doc in docs:
            rtype = doc.get("region_type", "")
            if rtype == "B":
                result["b_code"]    = doc.get("code", "")
                result["sido"]      = doc.get("region_1depth_name", "")
                result["sigungu"]   = doc.get("region_2depth_name", "")
                result["eupmyeondong"] = doc.get("region_3depth_name", "")
            elif rtype == "H":
                result["h_code"]    = doc.get("code", "")
                result["admin_dong"]= doc.get("region_3depth_name", "")
        return result if result else None
    except Exception as e:
        logger.warning(f"카카오 역지오코딩 오류: {e}")
    return None


# 카카오 카테고리 코드 (카카오 공식 지원 코드만)
# MT1=대형마트, CS2=편의점, PS3=어린이집/유치원, SC4=학교, AC5=학원
# PK6=주차장, OL7=주유소, SW8=지하철역, BK9=은행, CT1=문화시설, AG2=중개업소
# ※ BU1(버스정류장), HP8(병원)은 카테고리 검색 미지원 → 키워드 검색으로 대체
_KAKAO_CATEGORY = {
    "subway":      "SW8",   # 지하철역
    "school":      "SC4",   # 학교 (초/중/고 포함)
    "mart":        "MT1",   # 대형마트
    "convenience": "CS2",   # 편의점
}


async def kakao_search_category(
    lat: float, lng: float,
    category_key: str,
    radius_m: int = 2000,
    size: int = 5
) -> List[FacilityDistance]:
    """
    카카오 카테고리 검색 API: 카테고리 코드 기반 정확한 시설 검색
    keyword 검색보다 정확도가 높음 (예: 학원이 학교로 잘못 검색되는 문제 방지)
    """
    if not KAKAO_REST_KEY:
        return []

    category_code = _KAKAO_CATEGORY.get(category_key, "")
    if not category_code:
        return []

    try:
        url = f"{KAKAO_LOCAL_API}/search/category.json"
        headers = {"Authorization": f"KakaoAK {KAKAO_REST_KEY}"}
        params = {
            "category_group_code": category_code,
            "x": str(lng),
            "y": str(lat),
            "radius": str(min(radius_m, 20000)),
            "sort": "distance",
            "size": str(min(size, 15)),
        }
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(url, headers=headers, params=params)
            if resp.status_code == 403:
                logger.warning("카카오 카테고리 API 403: 지도/로컬 서비스 활성화 확인 필요")
                return []
            resp.raise_for_status()
            data = resp.json()

        results = []
        for item in data.get("documents", []):
            d = haversine_distance(lat, lng, float(item["y"]), float(item["x"]))
            results.append(FacilityDistance(
                name=item.get("place_name", ""),
                category=item.get("category_name", ""),
                distance_m=round(d),
                lat=float(item["y"]),
                lng=float(item["x"]),
            ))
        return results
    except Exception as e:
        logger.warning(f"카카오 카테고리 검색 오류 ({category_key}): {e}")
    return []


async def kakao_search_nearby(
    lat: float, lng: float,
    query: str,
    radius_m: int = 1000,
    size: int = 5
) -> List[FacilityDistance]:
    """
    카카오 키워드 검색 API: 반경 내 시설 검색 (레거시, 카테고리 검색 우선 사용)
    """
    if not KAKAO_REST_KEY:
        return []

    try:
        url = f"{KAKAO_LOCAL_API}/search/keyword.json"
        headers = {"Authorization": f"KakaoAK {KAKAO_REST_KEY}"}
        params = {
            "query": query,
            "x": str(lng),
            "y": str(lat),
            "radius": str(min(radius_m, 20000)),
            "sort": "distance",
            "size": str(min(size, 15)),
        }
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(url, headers=headers, params=params)
            if resp.status_code == 403:
                logger.warning(f"카카오 로컬 API 403 ({query}): 지도/로컬 서비스 활성화 필요")
                return []
            resp.raise_for_status()
            data = resp.json()

        results = []
        for item in data.get("documents", []):
            d = haversine_distance(lat, lng, float(item["y"]), float(item["x"]))
            results.append(FacilityDistance(
                name=item.get("place_name", ""),
                category=item.get("category_name", ""),
                distance_m=round(d),
                lat=float(item["y"]),
                lng=float(item["x"]),
            ))
        return results
    except Exception as e:
        logger.warning(f"카카오 시설 검색 오류 ({query}): {e}")
    return []


# ─── 시뮬레이션 로직 (API 키 없을 때) ──────────────────────────

CITY_CBD_COORDS: Dict[str, Tuple[float, float]] = {
    "서울": (37.5665, 126.9780),
    "부산": (35.1796, 129.0756),
    "대구": (35.8714, 128.6014),
    "인천": (37.4563, 126.7052),
    "광주": (35.1595, 126.8526),
    "대전": (36.3504, 127.3845),
    "울산": (35.5384, 129.3114),
    "세종": (36.4800, 127.2890),
    "경기": (37.4138, 127.5183),
    "강원": (37.8228, 128.1555),
    "충북": (36.6357, 127.4913),
    "충남": (36.6588, 126.6728),
    "전북": (35.7175, 127.1530),
    "전남": (34.8679, 126.9910),
    "경북": (36.4919, 128.8889),
    "경남": (35.4606, 128.2132),
    "제주": (33.4996, 126.5312),
}

SEISMIC_GRADE_BY_REGION: Dict[str, int] = {
    "서울": 1, "경기": 1, "인천": 1,
    "부산": 1, "울산": 1, "경남": 1,
    "대구": 1, "경북": 1,
    "광주": 2, "전남": 2, "전북": 2,
    "대전": 2, "충남": 2, "충북": 2,
    "강원": 2, "세종": 2,
    "제주": 2,
}

def _simulate_coords(parsed_addr: Dict[str, str]) -> CoordResult:
    """주소 파싱 결과로 좌표 시뮬레이션"""
    sido = parsed_addr.get("sido", "")

    # 주요 도시 기준 좌표 설정
    base_coords: Dict[str, Tuple[float, float]] = {
        "서울": (37.5665 + 0.01, 126.9780 + 0.02),
        "서울특별시": (37.5665, 126.9780),
        "부산": (35.1796, 129.0756),
        "부산광역시": (35.1796, 129.0756),
        "대구": (35.8714, 128.6014),
        "인천": (37.4563, 126.7052),
        "광주": (35.1595, 126.8526),
        "대전": (36.3504, 127.3845),
        "울산": (35.5384, 129.3114),
        "세종": (36.4800, 127.2890),
        "경기": (37.4138, 127.5183),
        "강원": (37.8228, 128.1555),
        "충북": (36.6357, 127.4913),
        "충남": (36.6588, 126.6728),
        "전북": (35.7175, 127.1530),
        "전남": (34.8679, 126.9910),
        "경북": (36.4919, 128.8889),
        "경남": (35.4606, 128.2132),
        "제주": (33.4996, 126.5312),
    }

    lat, lng = base_coords.get(sido, (37.5665, 126.9780))

    # 지번을 이용한 미세 조정 (같은 주소 반복 시 일관성)
    main_no = parsed_addr.get("main_no", "1")
    sub_no = parsed_addr.get("sub_no", "0")
    try:
        offset_lat = (int(main_no) % 100) * 0.0001
        offset_lng = (int(sub_no) % 100) * 0.0001
        lat += offset_lat
        lng += offset_lng
    except ValueError:
        pass

    return CoordResult(
        lat=round(lat, 6),
        lng=round(lng, 6),
        address_parcel=parsed_addr["full_address"],
        source="simulation",
    )


def _simulate_facility_distances(
    lat: float, lng: float,
    sido: str
) -> Dict[str, float]:
    """
    지역 특성 기반 시설 거리 시뮬레이션
    서울 중심부일수록 가까운 거리 부여
    """
    is_metro = sido in ["서울", "서울특별시", "부산", "부산광역시", "대구", "인천", "광주", "대전", "울산"]

    if is_metro:
        # 대도시: 도보 접근 가능 범위
        return {
            "subway": round(300 + (abs(lat - 37.5) * 10000) % 700),
            "bus": round(100 + (abs(lng - 126.9) * 10000) % 300),
            "school": round(400 + (abs(lat - 37.5) * 10000) % 600),
            "hospital": round(300 + (abs(lng - 126.9) * 10000) % 500),
            "mart": round(100 + (abs(lat + lng) * 1000) % 400),
        }
    else:
        # 지방: 상대적으로 먼 거리
        return {
            "subway": round(1500 + (abs(lat - 36.0) * 10000) % 2000),
            "bus": round(300 + (abs(lng - 127.5) * 10000) % 500),
            "school": round(700 + (abs(lat - 36.0) * 10000) % 1000),
            "hospital": round(800 + (abs(lng - 127.5) * 10000) % 1200),
            "mart": round(400 + (abs(lat + lng) * 1000) % 600),
        }


def _simulate_cbd_distance(lat: float, lng: float, sido: str) -> float:
    """시도별 CBD 거리 추정 (km)"""
    cbd_key = sido.replace("특별시", "").replace("광역시", "").replace("도", "").strip()
    cbd_lat, cbd_lng = CITY_CBD_COORDS.get(cbd_key, (37.5665, 126.9780))
    dist_m = haversine_distance(lat, lng, cbd_lat, cbd_lng)
    return round(dist_m / 1000, 1)


def _simulate_slope(lat: float, lng: float, sido: str) -> float:
    """지형 기반 경사도 추정"""
    # 산지 많은 지역 (강원, 경북, 전북 등) → 높은 경사도
    hilly_regions = ["강원", "경북", "전북", "경남", "충북"]
    sido_clean = sido.replace("특별시", "").replace("광역시", "").replace("도", "").strip()
    if sido_clean in hilly_regions:
        return round(3 + (abs(lat * lng) % 10), 1)
    return round(1 + (abs(lat * lng) % 7), 1)


def _simulate_sunshine(lat: float) -> float:
    """위도 기반 일조시간 추정"""
    # 남쪽일수록 일조시간 증가
    base = 4.5 - (lat - 33.0) * 0.1
    return round(max(3.0, min(6.0, base)), 1)


def _simulate_land_area(addr_parsed: Dict[str, str]) -> float:
    """지번 기반 면적 시뮬레이션 (일반적인 도심 필지)"""
    main_no = addr_parsed.get("main_no", "100")
    try:
        # 지번이 작을수록 오래된 필지 → 상대적으로 작은 경향
        n = int(main_no)
        if n < 100:
            return round(200 + (n % 50) * 5, 0)
        elif n < 500:
            return round(300 + (n % 100) * 3, 0)
        else:
            return round(400 + (n % 200) * 2, 0)
    except ValueError:
        return 400.0


def _infer_zone_from_kakao(
    b_code: str,
    sido: str,
    sigungu: str,
    eupmyeondong: str = "",
) -> str:
    """
    카카오 역지오코딩 법정동 코드 기반 용도지역 정밀 추정
    b_code 앞 5자리 = 시군구 코드 기준 우선, 이후 동 단위 보정

    주요 시군구 코드 (법정코드 5자리):
      서울 종로구=11110, 중구=11140, 용산구=11170, 성동구=11200,
      광진구=11215, 동대문=11230, 중랑구=11260, 성북구=11290,
      강북구=11305, 도봉구=11320, 노원구=11350, 은평구=11380,
      서대문=11410, 마포구=11440, 양천구=11470, 강서구=11500,
      구로구=11530, 금천구=11545, 영등포=11560, 동작구=11590,
      관악구=11620, 서초구=11650, 강남구=11680, 송파구=11710,
      강동구=11740
    """
    sigungu_code = b_code[:5] if b_code and len(b_code) >= 5 else ""

    # ─ 서울 구별 용도지역 ─────────────────────────────────
    SEOUL_ZONE_MAP = {
        "11110": "제3종일반주거지역",  # 종로구 (상업지역 혼재, 평균)
        "11140": "일반상업지역",        # 중구 (CBD 핵심)
        "11170": "제3종일반주거지역",  # 용산구
        "11200": "제2종일반주거지역",  # 성동구
        "11215": "제2종일반주거지역",  # 광진구
        "11230": "제2종일반주거지역",  # 동대문구
        "11260": "제2종일반주거지역",  # 중랑구
        "11290": "제1종일반주거지역",  # 성북구
        "11305": "제1종일반주거지역",  # 강북구
        "11320": "제1종일반주거지역",  # 도봉구
        "11350": "제2종일반주거지역",  # 노원구
        "11380": "제1종일반주거지역",  # 은평구
        "11410": "제2종일반주거지역",  # 서대문구
        "11440": "준주거지역",          # 마포구 (홍대·합정 준주거)
        "11470": "제2종일반주거지역",  # 양천구
        "11500": "제2종일반주거지역",  # 강서구
        "11530": "준공업지역",          # 구로구 (구로디지털단지)
        "11545": "준공업지역",          # 금천구
        "11560": "준주거지역",          # 영등포구
        "11590": "제2종일반주거지역",  # 동작구
        "11620": "제2종일반주거지역",  # 관악구
        "11650": "제2종일반주거지역",  # 서초구 (주거 위주)
        "11680": "제2종일반주거지역",  # 강남구 (역삼·대치 일반주거)
        "11710": "제2종일반주거지역",  # 송파구
        "11740": "제2종일반주거지역",  # 강동구
    }

    # ─ 경기 주요 시군구 ───────────────────────────────────
    GYEONGGI_ZONE_MAP = {
        "41111": "제2종일반주거지역",  # 수원 장안구
        "41113": "제2종일반주거지역",  # 수원 권선구
        "41115": "제2종일반주거지역",  # 수원 팔달구
        "41117": "제2종일반주거지역",  # 수원 영통구
        "41131": "제2종일반주거지역",  # 성남 수정구
        "41133": "제2종일반주거지역",  # 성남 중원구
        "41135": "제3종일반주거지역",  # 성남 분당구
        "41150": "제2종일반주거지역",  # 의정부
        "41171": "제2종일반주거지역",  # 안양 만안
        "41173": "제2종일반주거지역",  # 안양 동안
        "41190": "제2종일반주거지역",  # 부천
        "41210": "제2종일반주거지역",  # 광명
        "41250": "제1종일반주거지역",  # 평택
        "41271": "준주거지역",          # 안산 단원구
        "41273": "제2종일반주거지역",  # 안산 상록구
        "41281": "제3종일반주거지역",  # 고양 덕양
        "41285": "제3종일반주거지역",  # 고양 일산동
        "41287": "제3종일반주거지역",  # 고양 일산서
        "41310": "제2종일반주거지역",  # 과천
        "41360": "제2종일반주거지역",  # 구리
        "41410": "제2종일반주거지역",  # 하남
        "41430": "제2종일반주거지역",  # 용인 처인
        "41435": "제3종일반주거지역",  # 용인 수지
        "41450": "제2종일반주거지역",  # 파주
        "41461": "제2종일반주거지역",  # 시흥
        "41465": "제2종일반주거지역",  # 김포
        "41480": "제2종일반주거지역",  # 화성
        "41500": "제1종일반주거지역",  # 광주(경기)
        "41550": "제2종일반주거지역",  # 양주
        "41570": "제1종일반주거지역",  # 포천
        "41590": "제1종일반주거지역",  # 여주
        "41610": "자연녹지지역",        # 연천
        "41630": "자연녹지지역",        # 가평
        "41650": "자연녹지지역",        # 양평
    }

    # ─ 부산 주요 구 ──────────────────────────────────────
    BUSAN_ZONE_MAP = {
        "26110": "일반상업지역",        # 중구
        "26140": "제2종일반주거지역",  # 서구
        "26170": "제3종일반주거지역",  # 동구
        "26200": "제3종일반주거지역",  # 영도구
        "26230": "제3종일반주거지역",  # 부산진구
        "26260": "제2종일반주거지역",  # 동래구
        "26290": "제2종일반주거지역",  # 남구
        "26320": "제2종일반주거지역",  # 북구
        "26350": "제2종일반주거지역",  # 해운대구
        "26380": "제2종일반주거지역",  # 사하구
        "26410": "자연녹지지역",        # 금정구
        "26440": "자연녹지지역",        # 강서구
        "26470": "제2종일반주거지역",  # 연제구
        "26500": "제2종일반주거지역",  # 수영구
        "26530": "준공업지역",          # 사상구
        "26710": "자연녹지지역",        # 기장군
    }

    # 법정동 코드 기반 우선 조회
    if sigungu_code:
        # 서울
        if sigungu_code.startswith("11"):
            zone = SEOUL_ZONE_MAP.get(sigungu_code)
            if zone:
                # 강남구 내 세부 동 보정 (역삼/삼성/논현/청담 등 지역 특이사항)
                if sigungu_code == "11680" and eupmyeondong:
                    if any(k in eupmyeondong for k in ["압구정", "청담", "삼성"]):
                        return "제3종일반주거지역"
                    if any(k in eupmyeondong for k in ["논현", "개포", "수서"]):
                        return "제2종일반주거지역"
                # 마포구 내 세부 보정
                if sigungu_code == "11440" and eupmyeondong:
                    if any(k in eupmyeondong for k in ["도화", "신공덕", "아현"]):
                        return "제3종일반주거지역"
                return zone
        # 경기
        elif sigungu_code.startswith("41"):
            zone = GYEONGGI_ZONE_MAP.get(sigungu_code)
            if zone:
                return zone
        # 부산
        elif sigungu_code.startswith("26"):
            zone = BUSAN_ZONE_MAP.get(sigungu_code)
            if zone:
                return zone

    # ─ 키워드 기반 fallback ────────────────────────────
    return _simulate_zone_name(sido, sigungu)


def _simulate_zone_name(sido: str, sigungu: str) -> str:
    """지역 특성 기반 용도지역 추정 (키워드 fallback)"""
    sido_clean = sido.replace("특별시", "").replace("광역시", "").strip()

    industrial_keywords = ["구로구", "금천구", "사상구"]
    if any(k in sigungu for k in industrial_keywords):
        return "준공업지역"

    commercial_keywords = ["중구", "종로구"]
    if any(k in sigungu for k in commercial_keywords):
        return "일반상업지역"

    high_density_keywords = ["강남구", "서초구", "해운대구", "수영구", "분당구", "수지구"]
    if any(k in sigungu for k in high_density_keywords):
        return "제2종일반주거지역"

    semi_keywords = ["마포구", "영등포구"]
    if any(k in sigungu for k in semi_keywords):
        return "준주거지역"

    if sido_clean in ["서울", "부산", "대구", "인천"]:
        return "제2종일반주거지역"
    elif sido_clean in ["광주", "대전", "울산"]:
        return "제1종일반주거지역"
    else:
        return "제2종일반주거지역"


def _simulate_seismic_grade(sido: str) -> int:
    """지역 기반 내진등급 추정"""
    sido_clean = sido.replace("특별시", "").replace("광역시", "").replace("도", "").strip()
    return SEISMIC_GRADE_BY_REGION.get(sido_clean, 2)


# ─── 메인 서비스 클래스 ─────────────────────────────────────────

class ParcelLookupService:
    """
    필지 자동 조회 서비스

    사용 방법:
      result = await parcel_lookup.lookup("서울시 강남구 역삼동 123-45")

    반환값 ParcelLookupResult 에는 SITE-C 자동 평가에 필요한 모든 수치가 포함됩니다.
    """

    async def lookup(self, address: str) -> ParcelLookupResult:
        """
        주소/지번 입력 → 필지 정보 + SITE-C 요소 전체 자동 조회

        파이프라인:
        1. 카카오 주소검색 → 좌표 + PNU 자동생성 (b_code 활용)
        2. 카카오 역지오코딩 → 법정동 코드 확인 + 용도지역 정밀 추정
        3. VWorld (작동 시) → 실제 면적, 지목, 용도지역
        4. 카카오 카테고리 검색 → 주변 시설 거리 (SITE-C)
        """
        errors = []
        data_sources = []
        parsed = parse_address(address)

        logger.info(f"필지 조회 시작: {address} → 파싱={parsed}")

        # ── Step 1: 좌표 조회 ──────────────────────────────
        coord: Optional[CoordResult] = None
        is_simulation = True

        # 카카오 주소검색 우선 (PNU 자동생성 포함)
        if KAKAO_REST_KEY:
            coord = await kakao_geocode(address)
            if coord:
                data_sources.append("카카오 주소검색 API")
                is_simulation = False

        # 카카오 실패 시 VWorld 시도
        if not coord and VWORLD_API_KEY and VWORLD_API_KEY not in ("", "REPLACE_WITH_VWORLD_KEY"):
            coord = await vworld_geocode(address, "PARCEL")
            if coord:
                data_sources.append("VWorld 지오코딩 API")
                is_simulation = False
            else:
                coord = await vworld_geocode(address, "ROAD")
                if coord:
                    data_sources.append("VWorld 지오코딩 API (도로명)")
                    is_simulation = False

        if not coord:
            coord = _simulate_coords(parsed)
            data_sources.append("좌표 시뮬레이션")

        lat, lng = coord.lat, coord.lng

        # ── Step 2: 역지오코딩으로 법정동 정보 보완 ───────
        # 카카오 geocode에서 b_code 없을 때 역지오코딩으로 보완
        region_info: Optional[Dict[str, str]] = None
        if KAKAO_REST_KEY and (not coord.emd_code):
            region_info = await kakao_reverse_geocode(lat, lng)
            if region_info:
                # coord에 법정동 코드 보완
                coord.emd_code = region_info.get("b_code", "")
                coord.sigungu_code = region_info.get("b_code", "")[:5]

        # 행정구역 정보 결정 (카카오 결과 우선, 없으면 파싱 결과)
        if region_info or coord.emd_code:
            b_code  = coord.emd_code
            # 역지오코딩 결과가 있으면 사용, 없으면 파싱
            sido    = (region_info or {}).get("sido", "") or parsed.get("sido", "서울")
            sigungu = (region_info or {}).get("sigungu", "") or parsed.get("sigungu", "")
            eupmyeondong = (region_info or {}).get("eupmyeondong", "") or parsed.get("eupmyeondong", "")
        else:
            b_code = ""
            sido    = parsed.get("sido", "서울")
            sigungu = parsed.get("sigungu", "")
            eupmyeondong = parsed.get("eupmyeondong", "")

        # ── Step 3: 필지 정보 + 토지특성 (VWorld, 작동 시) ─
        parcel_info: Optional[ParcelInfo] = None
        land_chars: Optional[LandCharacteristics] = None

        pnu = coord.pnu or ""

        land_use_codes = []
        if VWORLD_API_KEY and VWORLD_API_KEY not in ("", "REPLACE_WITH_VWORLD_KEY") and pnu:
            try:
                parcel_info, land_chars, land_use_codes_raw = await asyncio.gather(
                    vworld_get_land_info(pnu),
                    vworld_get_land_characteristics(pnu),
                    vworld_get_land_use_attr(pnu),
                    return_exceptions=True
                )
                if parcel_info and not isinstance(parcel_info, Exception):
                    data_sources.append("VWorld 토지임야정보 API")
                if land_chars and not isinstance(land_chars, Exception):
                    data_sources.append("VWorld 토지특성정보 API")
                if land_use_codes_raw and not isinstance(land_use_codes_raw, Exception):
                    land_use_codes = land_use_codes_raw
                    data_sources.append("VWorld 토지이용계획 API")
            except Exception as e:
                errors.append(f"VWorld 데이터 조회 오류: {e}")

        # ── Step 4: 주변 시설 검색 (카카오 API) ──────────
        nearby_subway = []
        nearby_bus = []
        nearby_school = []
        nearby_hospital = []
        nearby_mart = []
        facility_dists: Dict[str, float] = {}

        if KAKAO_REST_KEY:
            try:
                results = await asyncio.gather(
                    kakao_search_category(lat, lng, "subway",  2000, 3),
                    kakao_search_nearby(lat, lng, "버스정류장", 500,  3),
                    kakao_search_category(lat, lng, "school",  1500, 3),
                    kakao_search_nearby(lat, lng, "병원",      1000, 3),
                    kakao_search_category(lat, lng, "mart",    1000, 3),
                    return_exceptions=True
                )
                nearby_subway, nearby_bus, nearby_school, nearby_hospital, nearby_mart = [
                    r if isinstance(r, list) else [] for r in results
                ]
                if not nearby_mart:
                    convenience = await kakao_search_category(lat, lng, "convenience", 500, 3)
                    nearby_mart = convenience

                if any([nearby_subway, nearby_bus, nearby_school, nearby_hospital, nearby_mart]):
                    data_sources.append("카카오 로컬 API (카테고리)")
                    is_simulation = False
                    logger.info(
                        f"카카오 시설 검색 완료: "
                        f"지하철={len(nearby_subway)}개, "
                        f"버스={len(nearby_bus)}개, "
                        f"학교={len(nearby_school)}개, "
                        f"병원={len(nearby_hospital)}개, "
                        f"마트={len(nearby_mart)}개"
                    )
            except Exception as e:
                errors.append(f"카카오 시설 검색 오류: {e}")

        # 시설 거리 계산
        if nearby_subway:
            facility_dists["subway"] = min(f.distance_m for f in nearby_subway)
        if nearby_bus:
            facility_dists["bus"] = min(f.distance_m for f in nearby_bus)
        if nearby_school:
            facility_dists["school"] = min(f.distance_m for f in nearby_school)
        if nearby_hospital:
            facility_dists["hospital"] = min(f.distance_m for f in nearby_hospital)
        if nearby_mart:
            facility_dists["mart"] = min(f.distance_m for f in nearby_mart)

        if not facility_dists:
            facility_dists = _simulate_facility_distances(lat, lng, sido)
            data_sources.append("시설거리 시뮬레이션")

        # ── Step 5: 나머지 필드 결정 ─────────────────────
        area_m2 = (
            parcel_info.area_m2
            if parcel_info and not isinstance(parcel_info, Exception)
            else _simulate_land_area(parsed)
        )

        land_category = (
            parcel_info.land_category
            if parcel_info and not isinstance(parcel_info, Exception)
            else "대"
        )

        # 용도지역: VWorld 실데이터 > 법정동 코드 정밀 룩업 > 키워드 fallback
        if land_chars and not isinstance(land_chars, Exception) and land_chars.zone_name:
            zone_name = land_chars.zone_name
        elif b_code:
            zone_name = _infer_zone_from_kakao(b_code, sido, sigungu, eupmyeondong)
            data_sources.append("법정동 코드 기반 용도지역 추정")
        else:
            zone_name = _simulate_zone_name(sido, sigungu)

        # ── 서울시 공간정보포털 WFS 조회 (SEOUL_GIS_API_KEY 설정 시 활성화) ──
        # zone_name을 서울시 WFS로 보강 - "제2종일반주거지역(7층이하)" 등 상세 구분
        if sido == "서울특별시" and SEOUL_GIS_KEY and lat and lng:
            try:
                seoul_zone_detail = await seoul_smgis_get_zone_info(lat, lng)
                if seoul_zone_detail and seoul_zone_detail != zone_name:
                    logger.info(f"서울시 WFS 용도지역 보강: {zone_name} → {seoul_zone_detail}")
                    zone_name = seoul_zone_detail
                    data_sources.append("서울시 공간정보포털 WFS")
            except Exception as _e:
                logger.debug(f"서울시 WFS 조회 실패: {_e}")

        zone_name2 = (
            land_chars.zone_name2
            if land_chars and not isinstance(land_chars, Exception)
            else ""
        )

        road_side = (
            land_chars.road_side
            if land_chars and not isinstance(land_chars, Exception)
            else ""
        )

        # CBD 거리 (카카오 좌표 기반 정확한 계산)
        cbd_km = _simulate_cbd_distance(lat, lng, sido)

        # PNU 최종 결정 (카카오 생성 > 시뮬레이션)
        if not pnu:
            pnu = f"SIM_{abs(hash(address)) % 10**15:015d}"

        # 경사도 & 내진
        slope = _simulate_slope(lat, lng, sido)
        seismic = _simulate_seismic_grade(sido)

        # 일조시간
        sunshine = _simulate_sunshine(lat)

        logger.info(
            f"필지 조회 완료: {address} → "
            f"좌표=({lat:.6f},{lng:.6f}), PNU={pnu}, "
            f"면적={area_m2}㎡, 용도지역={zone_name}, "
            f"데이터소스={data_sources}, 시뮬레이션={is_simulation}"
        )

        return ParcelLookupResult(
            address_input=address,
            lat=lat,
            lng=lng,
            pnu=pnu,
            area_m2=area_m2,
            land_category=land_category,
            zone_name=zone_name,
            zone_name2=zone_name2,
            cbd_distance_km=cbd_km,
            subway_distance_m=facility_dists.get("subway", 800),
            bus_stop_distance_m=facility_dists.get("bus", 300),
            elementary_school_distance_m=facility_dists.get("school", 600),
            hospital_distance_m=facility_dists.get("hospital", 500),
            mart_distance_m=facility_dists.get("mart", 200),
            slope_percent=slope,
            seismic_grade=seismic,
            sunshine_hours=sunshine,
            nearby_subway=nearby_subway,
            nearby_bus=nearby_bus,
            nearby_school=nearby_school,
            nearby_hospital=nearby_hospital,
            nearby_mart=nearby_mart,
            road_side=road_side,
            land_use_codes=land_use_codes,
            data_sources=data_sources,
            lookup_errors=errors,
            is_simulation=is_simulation,
        )

    async def batch_lookup(self, addresses: List[str]) -> List[ParcelLookupResult]:
        """복수 주소 병렬 조회"""
        tasks = [self.lookup(addr) for addr in addresses]
        return await asyncio.gather(*tasks, return_exceptions=False)


# 싱글톤 인스턴스
parcel_lookup = ParcelLookupService()
