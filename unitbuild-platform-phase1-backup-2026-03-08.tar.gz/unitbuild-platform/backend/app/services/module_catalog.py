"""
UnitBuild Gen 2 모듈 카탈로그 엔진 (v2.0 Gen2 Spec)

Gen 2 사양 (2026 기준):
  - 모듈 폭 고정: 3,200 mm
  - 운송 길이 한도: 9,600 mm (완전 공장 제작)
  - 기둥 규격: SQ-Pipe 150×150 mm (주기둥 & 보조기둥)
  - 중심선 폭: 3,050 mm (3,200 - 150)
  - 건축면적 산식: 3.05 × (전체 길이 - 0.15) [단위: m, m²]
  - 복도폭: 표준 1,400mm / 광폭 2,000mm

블록 치수 옵션 (mm):
  - 욕실: 2,400 / 3,200
  - 주거실: 4,900 / 5,700
  - 발코니: 1,500 (선택)
  - 복도: 1,400 / 2,000

면적 계산 방식 (Gen2 Spec v2.0):
  건축면적 = 3.05 × (전체_길이_m - 0.15)
  전용면적 = 건축면적 - 복도면적 (복도폭_m × 3.05 × 0.85)
  공급면적 = 전용면적 × 1.12
  평 환산  = 면적_m² × 0.3025
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum
import logging

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────
# 열거형 정의
# ─────────────────────────────────────────────────────────

class ModuleType(str, Enum):
    BASIC_1_C1 = "BASIC-1-C1"    # 욕실2400 + 주거실4900 + 복도1400
    BASIC_1_C2 = "BASIC-1-C2"    # 욕실2400 + 주거실4900 + 복도2000
    BASIC_2_C1 = "BASIC-2-C1"    # 욕실3200 + 주거실4900 + 복도1400
    BASIC_2_C2 = "BASIC-2-C2"    # 욕실3200 + 주거실4900 + 복도2000
    BASIC_3_C1 = "BASIC-3-C1"    # 욕실2400 + 주거실5700 + 복도1400
    BASIC_4_C1 = "BASIC-4-C1"    # 욕실3200 + 주거실5700 + 복도없음 (분리납품형)
    BALCONY_2  = "BALCONY-2"     # 욕실2400 + 주거실5700 + 발코니1500 (9600mm)
    BALCONY_3  = "BALCONY-3"     # 욕실3200 + 주거실4900 + 발코니1500 (9600mm)
    CORRIDOR_ONLY = "CORRIDOR"   # 복도 전용 모듈

class CorridorType(str, Enum):
    STANDARD = "standard"   # 1,400mm
    WIDE     = "wide"       # 2,000mm
    NONE     = "none"       # 복도 없음 (발코니형/분리납품형)

class LHUnitType(str, Enum):
    TYPE_19 = "19㎡형"
    TYPE_26 = "26㎡형"
    TYPE_29 = "29㎡형"


# ─────────────────────────────────────────────────────────
# 데이터 클래스
# ─────────────────────────────────────────────────────────

@dataclass
class ModuleSpec:
    """단일 모듈 사양 (Gen2 v2.0)"""
    module_type: ModuleType
    width_mm: int                    # 항상 3200
    length_mm: int                   # 운송 길이 (≤9600)
    centerline_width_mm: int = 3050  # 3200 - 150(기둥)
    column_size_mm: str = "150×150"  # SQ-Pipe

    # 치수 구성 (mm)
    bath_length_mm: int = 0
    room_length_mm: int = 0
    balcony_length_mm: int = 0
    corridor_length_mm: int = 0
    corridor_type: Optional[CorridorType] = None

    # 면적 (자동 계산)
    building_area_m2: float = 0.0   # 건축면적: 3.05 × (length_m - 0.15)
    net_area_m2: float = 0.0        # 전용면적 (건축면적 - 복도면적)
    gross_area_m2: float = 0.0      # 공급면적 = 전용 × 1.12
    net_area_py: float = 0.0        # 전용 평수 (× 0.3025)
    gross_area_py: float = 0.0      # 공급 평수

    # LH 대응
    lh_type_match: Optional[LHUnitType] = None
    lh_area_m2: float = 0.0         # LH 기준 면적
    area_advantage_m2: float = 0.0  # Gen2 - LH 기준 면적차

    # 사업성
    factory_assembly: bool = True   # 완전 공장 조립 가능 여부
    transport_feasible: bool = True  # 9600mm 이하
    wet_joint_required: bool = False # 현장 습식 접합 필요 여부

    # 비용 지수
    cost_index: float = 1.0         # 기준=1.0 대비 상대 원가
    notes: str = ""

    def __post_init__(self):
        """면적 자동 계산 (Gen2 Spec v2.0)"""
        length_m = self.length_mm / 1000.0
        # 건축면적 = 3.05 × (전체 길이_m - 0.15)
        self.building_area_m2 = round(3.05 * (length_m - 0.15), 2)

        # 전용면적 = 건축면적 - 복도면적
        if self.corridor_length_mm > 0:
            corridor_m = self.corridor_length_mm / 1000.0
            corridor_area = 3.05 * corridor_m * 0.85  # 공용복도 비율 85% 적용
            self.net_area_m2 = round(self.building_area_m2 - corridor_area, 2)
        else:
            # 발코니형/분리납품형: 발코니 면적은 서비스 면적(전용 불산입)
            if self.balcony_length_mm > 0:
                balcony_m = self.balcony_length_mm / 1000.0
                balcony_area = 3.05 * balcony_m  # 발코니는 전용면적에서 제외
                self.net_area_m2 = round(self.building_area_m2 - balcony_area, 2)
            else:
                self.net_area_m2 = self.building_area_m2

        # 공급면적 = 전용 × 1.12
        self.gross_area_m2 = round(self.net_area_m2 * 1.12, 2)

        # 평 환산 (1㎡ = 0.3025평)
        self.net_area_py = round(self.net_area_m2 * 0.3025, 2)
        self.gross_area_py = round(self.gross_area_m2 * 0.3025, 2)

        # 운송/공장조립 가능 여부
        self.transport_feasible = self.length_mm <= 9600
        self.factory_assembly = self.transport_feasible

        # LH 면적 우위
        if self.lh_area_m2 > 0:
            self.area_advantage_m2 = round(self.net_area_m2 - self.lh_area_m2, 2)

    @property
    def description(self) -> str:
        parts = []
        if self.bath_length_mm:
            parts.append(f"욕실{self.bath_length_mm}")
        if self.room_length_mm:
            parts.append(f"주거실{self.room_length_mm}")
        if self.balcony_length_mm:
            parts.append(f"발코니{self.balcony_length_mm}")
        if self.corridor_length_mm:
            ctype = "광폭복도" if self.corridor_type == CorridorType.WIDE else "표준복도"
            parts.append(f"{ctype}{self.corridor_length_mm}")
        return " + ".join(parts)

    @property
    def area_summary(self) -> str:
        """면적 요약 문자열"""
        return (
            f"전용 {self.net_area_m2}㎡ ({self.net_area_py}평) / "
            f"공급 {self.gross_area_m2}㎡ ({self.gross_area_py}평)"
        )


@dataclass
class ModulePlacementResult:
    """필지에 대한 모듈 배치 결과"""
    parcel_area_m2: float
    parcel_width_m: float
    parcel_depth_m: float

    # 배치 결과
    modules_per_floor: int
    total_floors: int
    total_units: int
    total_building_area_m2: float
    total_floor_area_m2: float
    coverage_ratio_pct: float       # 건폐율 %
    floor_area_ratio_pct: float     # 용적률 %

    # 모듈 구성
    module_type: ModuleType
    unit_mix: Dict[str, int]        # {"BASIC-1-C1": 20, "BALCONY-2": 10}

    # LH 매칭
    lh_type_breakdown: Dict[str, int]  # {"19㎡형": 15, "26㎡형": 10, "29㎡형": 5}
    small_unit_ratio: float

    # 법규 적합
    regulation_compliant: bool
    issues: List[str]

    # 사업성
    estimated_construction_cost_100m: float  # 억원
    estimated_lh_purchase_price_100m: float  # 억원 (LH 매입 예상가)
    estimated_profit_100m: float             # 억원
    roi_pct: float


# ─────────────────────────────────────────────────────────
# 모듈 카탈로그 (Gen 2 v2.0 기준)
# ─────────────────────────────────────────────────────────
# 건축면적 = 3.05 × (length_mm/1000 - 0.15)
# 전용면적 = 건축면적 - (복도 또는 발코니 면적)
# ─────────────────────────────────────────────────────────

GEN2_MODULE_CATALOG: Dict[ModuleType, ModuleSpec] = {

    # ── BASIC-1 시리즈: 욕실2400 + 주거실4900 ──────────────
    # 전체 길이 = 2400 + 4900 + 복도 (mm)
    # 건축면적 = 3.05 × (length_m - 0.15)

    ModuleType.BASIC_1_C1: ModuleSpec(
        module_type=ModuleType.BASIC_1_C1,
        width_mm=3200,
        length_mm=8700,           # 2400 + 4900 + 1400(표준복도)
        bath_length_mm=2400,
        room_length_mm=4900,
        corridor_length_mm=1400,
        corridor_type=CorridorType.STANDARD,
        lh_type_match=LHUnitType.TYPE_19,
        lh_area_m2=19.0,
        cost_index=1.00,
        notes="LH 19㎡형 대응 기본형. 공장 일체형 복도(표준 1,400mm). ⚠️ 전용면적 LH 기준 초과"
    ),

    ModuleType.BASIC_1_C2: ModuleSpec(
        module_type=ModuleType.BASIC_1_C2,
        width_mm=3200,
        length_mm=9300,           # 2400 + 4900 + 2000(광폭복도)
        bath_length_mm=2400,
        room_length_mm=4900,
        corridor_length_mm=2000,
        corridor_type=CorridorType.WIDE,
        lh_type_match=LHUnitType.TYPE_19,
        lh_area_m2=19.0,
        cost_index=1.08,
        notes="광폭복도(2,000mm) 일체형. 휠체어 접근성 확보. ⚠️ 전용면적 LH 기준 초과"
    ),

    # ── BASIC-2 시리즈: 욕실3200 + 주거실4900 ──────────────

    ModuleType.BASIC_2_C1: ModuleSpec(
        module_type=ModuleType.BASIC_2_C1,
        width_mm=3200,
        length_mm=9500,           # 3200 + 4900 + 1400(표준복도)
        bath_length_mm=3200,
        room_length_mm=4900,
        corridor_length_mm=1400,
        corridor_type=CorridorType.STANDARD,
        lh_type_match=LHUnitType.TYPE_26,
        lh_area_m2=26.0,
        cost_index=1.05,
        notes="LH 26㎡형 대응. 확장욕실(3,200mm). 전용면적 LH 기준 소폭 초과"
    ),

    ModuleType.BASIC_2_C2: ModuleSpec(
        module_type=ModuleType.BASIC_2_C2,
        width_mm=3200,
        length_mm=9600,           # 3200 + 4900 + 1500 = 운송한계 정확히
        bath_length_mm=3200,
        room_length_mm=4900,
        corridor_length_mm=1500,
        corridor_type=CorridorType.WIDE,
        lh_type_match=LHUnitType.TYPE_26,
        lh_area_m2=26.0,
        cost_index=1.12,
        notes="욕실3,200mm + 중복도(1,500mm). 9,600mm 운송한계 정확히 맞춤"
    ),

    # ── BASIC-3: 욕실2400 + 주거실5700 + 표준복도 ──────────
    # 전체 길이 = 2400 + 5700 + 1400 = 9500mm ✅ (운송 가능)

    ModuleType.BASIC_3_C1: ModuleSpec(
        module_type=ModuleType.BASIC_3_C1,
        width_mm=3200,
        length_mm=9500,           # 2400 + 5700 + 1400(표준복도)
        bath_length_mm=2400,
        room_length_mm=5700,
        corridor_length_mm=1400,
        corridor_type=CorridorType.STANDARD,
        lh_type_match=LHUnitType.TYPE_26,
        lh_area_m2=26.0,
        cost_index=1.08,
        notes="LH 26㎡형 대응 (주거실 최대화). 욕실2,400mm + 확장 주거실5,700mm + 표준복도. ⚠️ 전용 LH 기준 초과"
    ),

    # ── BASIC-4: 분리납품형 (욕실3200 + 주거실5700, 복도 없음) ──

    ModuleType.BASIC_4_C1: ModuleSpec(
        module_type=ModuleType.BASIC_4_C1,
        width_mm=3200,
        length_mm=8900,           # 3200 + 5700 = 8900 (복도 별도 모듈)
        bath_length_mm=3200,
        room_length_mm=5700,
        corridor_length_mm=0,
        corridor_type=CorridorType.NONE,
        lh_type_match=LHUnitType.TYPE_26,
        lh_area_m2=26.0,
        cost_index=1.10,
        notes="LH 26㎡형 최적 대응. 복도 모듈 별도(CORRIDOR). 전용면적 LH 기준 근접. 주거실 최대화"
    ),

    # ── BALCONY 시리즈: Gen 2 핵심 신제품 ──────────────────
    # 발코니 1,500mm는 서비스 면적 (전용면적 불산입)

    ModuleType.BALCONY_2: ModuleSpec(
        module_type=ModuleType.BALCONY_2,
        width_mm=3200,
        length_mm=9600,           # 욕실2400 + 주거실5700 + 발코니1500 = 9600 정확
        bath_length_mm=2400,
        room_length_mm=5700,
        balcony_length_mm=1500,
        corridor_length_mm=0,
        corridor_type=CorridorType.NONE,
        lh_type_match=LHUnitType.TYPE_29,
        lh_area_m2=29.0,
        cost_index=1.18,
        notes="Gen2 최우선 핵심 제품. 9,600mm 정확. 완전공장조립+발코니. 현장 습식조인트 불필요. LH 29㎡ 대응"
    ),

    ModuleType.BALCONY_3: ModuleSpec(
        module_type=ModuleType.BALCONY_3,
        width_mm=3200,
        length_mm=9600,           # 욕실3200 + 주거실4900 + 발코니1500 = 9600
        bath_length_mm=3200,
        room_length_mm=4900,
        balcony_length_mm=1500,
        corridor_length_mm=0,
        corridor_type=CorridorType.NONE,
        lh_type_match=LHUnitType.TYPE_29,
        lh_area_m2=29.0,
        cost_index=1.20,
        notes="확장욕실(3,200mm)+발코니. 9,600mm 정확. 고급형 LH 29㎡ 대응. 주거실4,900mm"
    ),

    # ── 복도 전용 모듈 ──────────────────────────────────────

    ModuleType.CORRIDOR_ONLY: ModuleSpec(
        module_type=ModuleType.CORRIDOR_ONLY,
        width_mm=3200,
        length_mm=3200,           # 표준 복도 단위
        corridor_length_mm=3200,
        corridor_type=CorridorType.STANDARD,
        cost_index=0.35,
        notes="복도 전용 모듈. BASIC-4 / BALCONY 시리즈와 결합 사용"
    ),
}


# ─────────────────────────────────────────────────────────
# 샤프트 기준
# ─────────────────────────────────────────────────────────

@dataclass
class ShaftSpec:
    """MEP 샤프트 표준 규격"""
    width_mm: int = 1000
    depth_mm: int = 650
    location: str = "입구/욕실 옆 (모듈폭 미영향)"
    includes: List[str] = field(default_factory=lambda: [
        "급수관", "배수관", "오배수관",
        "전기간선", "약전 EPS", "스프링클러 입상관", "환기 덕트"
    ])
    note: str = "3,200mm 그리드 외부 배치 → 모듈 폭 영향 없음"


STANDARD_SHAFT = ShaftSpec()


# ─────────────────────────────────────────────────────────
# LH 매입 단가 기준 (2025년 기준)
# ─────────────────────────────────────────────────────────

LH_PURCHASE_PRICE_PER_M2 = {
    "수도권": 4_800_000,   # 원/㎡ (서울·경기·인천)
    "광역시": 3_500_000,   # 원/㎡ (부산·대구·인천·광주·대전·울산)
    "지방": 2_800_000,     # 원/㎡ (기타)
}

# 모듈러 공법 공사비 단가 (Gen 2 기준)
CONSTRUCTION_COST_PER_M2 = {
    "공장제작": 1_800_000,  # 원/㎡
    "운송": 150_000,        # 원/㎡
    "현장설치": 250_000,    # 원/㎡
    "공통공사": 400_000,    # 원/㎡ (기초, 외장, 공용부)
}

TOTAL_CONSTRUCTION_COST_PER_M2 = sum(CONSTRUCTION_COST_PER_M2.values())  # 2,600,000 원/㎡


# ─────────────────────────────────────────────────────────
# 카탈로그 서비스
# ─────────────────────────────────────────────────────────

class ModuleCatalogService:
    """Gen 2 모듈 카탈로그 조회 및 추천 서비스 (v2.0)"""

    def get_all_modules(self) -> List[ModuleSpec]:
        """전체 모듈 목록 반환"""
        return list(GEN2_MODULE_CATALOG.values())

    def get_module(self, module_type: ModuleType) -> Optional[ModuleSpec]:
        """특정 모듈 사양 조회"""
        return GEN2_MODULE_CATALOG.get(module_type)

    def get_transportable_modules(self) -> List[ModuleSpec]:
        """완전 운송 가능 모듈만 (≤9,600mm)"""
        return [m for m in GEN2_MODULE_CATALOG.values() if m.transport_feasible]

    def get_modules_by_lh_type(self, lh_type: LHUnitType) -> List[ModuleSpec]:
        """LH 주택유형별 대응 모듈 목록"""
        return [
            m for m in GEN2_MODULE_CATALOG.values()
            if m.lh_type_match == lh_type
        ]

    def recommend_module_mix(
        self,
        target_units: int,
        preferred_lh_type: Optional[LHUnitType] = None,
        require_balcony: bool = False,
        require_wide_corridor: bool = False,
    ) -> List[Tuple[ModuleSpec, int]]:
        """세대 수와 조건에 따른 최적 모듈 조합 추천"""
        candidates = self.get_transportable_modules()
        candidates = [m for m in candidates if m.module_type != ModuleType.CORRIDOR_ONLY]

        if require_balcony:
            candidates = [m for m in candidates if m.balcony_length_mm > 0]
        if require_wide_corridor:
            candidates = [m for m in candidates if m.corridor_type == CorridorType.WIDE]
        if preferred_lh_type:
            type_filtered = [m for m in candidates if m.lh_type_match == preferred_lh_type]
            if type_filtered:
                candidates = type_filtered

        if not candidates:
            candidates = self.get_transportable_modules()

        balcony_modules = [m for m in candidates if m.balcony_length_mm > 0]
        basic_modules = [m for m in candidates if m.balcony_length_mm == 0]

        recommendations = []
        if balcony_modules:
            balcony_count = max(1, int(target_units * 0.4))
            balcony_choice = sorted(balcony_modules, key=lambda m: m.cost_index)[0]
            recommendations.append((balcony_choice, balcony_count))
            remaining = target_units - balcony_count
        else:
            remaining = target_units

        if basic_modules and remaining > 0:
            basic_choice = sorted(basic_modules, key=lambda m: m.cost_index)[0]
            recommendations.append((basic_choice, remaining))

        return recommendations

    def calculate_floor_plan(
        self,
        parcel_width_m: float,
        parcel_depth_m: float,
        module_type: ModuleType,
        corridor_shared: bool = True,
    ) -> Dict:
        """필지 크기에 따른 층별 배치 계산 (Gen2 v2.0)"""
        spec = GEN2_MODULE_CATALOG.get(module_type)
        if not spec:
            return {"error": f"Unknown module type: {module_type}"}

        module_width_m = spec.width_mm / 1000.0  # 3.2m
        module_length_m = spec.length_mm / 1000.0

        # 이격거리 적용
        # 전면: 3.0m, 후면: 0.5m, 측면: 0.5m×2
        eff_width = parcel_width_m - 1.0   # 양측 0.5m
        eff_depth = parcel_depth_m - 3.5   # 전면3m + 후면0.5m

        # 발코니/분리납품형은 별도 복도 공간 필요
        if corridor_shared and spec.corridor_length_mm == 0:
            corridor_depth = 1.4  # 표준 복도 1,400mm
            eff_depth -= corridor_depth

        if eff_width <= 0 or eff_depth <= 0:
            return {
                "error": "필지 크기 불충분",
                "min_width_m": module_width_m + 1.0,
                "min_depth_m": module_length_m + 3.5
            }

        units_horizontal = max(1, int(eff_width / module_width_m))
        units_vertical = max(1, int(eff_depth / module_length_m))
        units_per_floor = units_horizontal * units_vertical

        footprint_m2 = units_per_floor * spec.building_area_m2

        return {
            "module_type": module_type,
            "module_width_m": module_width_m,
            "module_length_m": module_length_m,
            "units_horizontal": units_horizontal,
            "units_vertical": units_vertical,
            "units_per_floor": units_per_floor,
            "building_footprint_m2": round(footprint_m2, 2),
            "net_area_per_unit_m2": spec.net_area_m2,
            "net_area_per_unit_py": spec.net_area_py,
            "gross_area_per_unit_m2": spec.gross_area_m2,
            "gross_area_per_unit_py": spec.gross_area_py,
            "area_summary": spec.area_summary,
            "notes": [
                f"이격거리(전3m/측1m/후0.5m) 적용",
                f"유효 폭 {eff_width:.1f}m × 유효 깊이 {eff_depth:.1f}m",
                f"모듈 건축면적: {spec.building_area_m2}㎡/세대",
                f"전용: {spec.net_area_m2}㎡({spec.net_area_py}평) / 공급: {spec.gross_area_m2}㎡({spec.gross_area_py}평)",
            ]
        }

    def get_area_table(self) -> List[Dict]:
        """
        Gen2 모듈 면적 비교표 (㎡ + 평 표기)
        프론트엔드 모듈 카탈로그 테이블 용도
        """
        rows = []
        for mt, spec in GEN2_MODULE_CATALOG.items():
            if mt == ModuleType.CORRIDOR_ONLY:
                continue
            rows.append({
                "module_type": spec.module_type.value,
                "description": spec.description,
                "length_mm": spec.length_mm,
                "building_area_m2": spec.building_area_m2,
                "net_area_m2": spec.net_area_m2,
                "net_area_py": spec.net_area_py,
                "gross_area_m2": spec.gross_area_m2,
                "gross_area_py": spec.gross_area_py,
                "lh_type": spec.lh_type_match.value if spec.lh_type_match else "-",
                "lh_area_m2": spec.lh_area_m2,
                "area_advantage_m2": spec.area_advantage_m2,
                "transport_feasible": spec.transport_feasible,
                "cost_index": spec.cost_index,
                "notes": spec.notes,
            })
        return rows

    def compare_with_lh_standard(self) -> List[Dict]:
        """Gen 2 vs LH 면적 기준 비교표"""
        results = []
        lh_standards = {
            LHUnitType.TYPE_19: 19.0,
            LHUnitType.TYPE_26: 26.0,
            LHUnitType.TYPE_29: 29.0,
        }

        for lh_type, lh_area in lh_standards.items():
            modules = self.get_modules_by_lh_type(lh_type)
            for m in modules:
                results.append({
                    "lh_type": lh_type.value,
                    "lh_area_m2": lh_area,
                    "module_type": m.module_type.value,
                    "module_net_area_m2": m.net_area_m2,
                    "module_net_area_py": m.net_area_py,
                    "module_building_area_m2": m.building_area_m2,
                    "area_difference_m2": round(m.net_area_m2 - lh_area, 2),
                    "area_advantage": "우수" if m.net_area_m2 > lh_area else (
                        "근접" if abs(m.net_area_m2 - lh_area) < 1.5 else "부족"
                    ),
                    "transport_feasible": m.transport_feasible,
                    "factory_assembly": m.factory_assembly,
                    "notes": m.notes,
                })

        return results

    def estimate_project_cost(
        self,
        total_units: int,
        module_type: ModuleType,
        region: str = "수도권",
    ) -> Dict:
        """사업비 개산 견적"""
        spec = GEN2_MODULE_CATALOG.get(module_type)
        if not spec:
            return {"error": "Invalid module type"}

        total_net_area = total_units * spec.net_area_m2
        total_building_area = total_units * spec.building_area_m2

        construction_cost = total_building_area * TOTAL_CONSTRUCTION_COST_PER_M2
        lh_price_per_m2 = LH_PURCHASE_PRICE_PER_M2.get(region, LH_PURCHASE_PRICE_PER_M2["지방"])
        lh_purchase_price = total_net_area * lh_price_per_m2
        profit = lh_purchase_price - construction_cost
        roi = (profit / construction_cost * 100) if construction_cost > 0 else 0

        return {
            "total_units": total_units,
            "module_type": module_type.value,
            "region": region,
            "total_net_area_m2": round(total_net_area, 1),
            "total_net_area_py": round(total_net_area * 0.3025, 1),
            "total_building_area_m2": round(total_building_area, 1),
            "construction_cost_100m": round(construction_cost / 1e8, 2),
            "lh_purchase_price_100m": round(lh_purchase_price / 1e8, 2),
            "profit_100m": round(profit / 1e8, 2),
            "roi_pct": round(roi, 1),
            "cost_breakdown": {
                k: round(total_building_area * v / 1e8, 2)
                for k, v in CONSTRUCTION_COST_PER_M2.items()
            },
            "lh_price_per_m2": lh_price_per_m2,
            "per_unit_summary": {
                "net_area_m2": spec.net_area_m2,
                "net_area_py": spec.net_area_py,
                "gross_area_m2": spec.gross_area_m2,
                "gross_area_py": spec.gross_area_py,
                "construction_cost_m": round(spec.building_area_m2 * TOTAL_CONSTRUCTION_COST_PER_M2 / 1e6, 1),
                "lh_price_m": round(spec.net_area_m2 * lh_price_per_m2 / 1e6, 1),
            },
            "notes": [
                f"LH 매입가: {lh_price_per_m2:,}원/㎡ ({region} 기준)",
                f"총 공사비 단가: {TOTAL_CONSTRUCTION_COST_PER_M2:,}원/㎡",
                "토지비 미포함 (사업지 특성에 따라 별도 산정 필요)",
                f"세대당 전용: {spec.net_area_m2}㎡({spec.net_area_py}평)",
            ]
        }


# 싱글톤 인스턴스
module_catalog = ModuleCatalogService()


# ─────────────────────────────────────────────────────────
# 모듈 스펙 검증 (임포트 시 자동 실행)
# ─────────────────────────────────────────────────────────

def _validate_catalog():
    """카탈로그 데이터 무결성 검증"""
    for mt, spec in GEN2_MODULE_CATALOG.items():
        if mt == ModuleType.CORRIDOR_ONLY:
            continue
        assert spec.width_mm == 3200, f"{mt}: 폭 3,200mm 아님"
        assert spec.length_mm <= 9600, f"{mt}: 운송 한도(9,600mm) 초과"
        assert spec.net_area_m2 > 0, f"{mt}: 전용면적 0 이하"
        total_blocks = spec.bath_length_mm + spec.room_length_mm + spec.balcony_length_mm + spec.corridor_length_mm
        assert total_blocks == spec.length_mm, (
            f"{mt}: 블록합({total_blocks}mm) ≠ 전체길이({spec.length_mm}mm)"
        )
    logger.info(f"Gen2 모듈 카탈로그 검증 완료: {len(GEN2_MODULE_CATALOG)}종")

_validate_catalog()
