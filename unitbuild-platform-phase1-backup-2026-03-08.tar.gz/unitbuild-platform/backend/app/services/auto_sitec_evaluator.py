"""
자동 SITE-C 통합 평가 엔진 (Auto SITE-C Evaluator)

지번 입력 하나로 전체 평가 파이프라인을 자동 실행:
  1. parcel_lookup: 지번 → 좌표/용도지역/주변시설거리
  2. parcel_analyzer: 용도지역 → 건폐율/용적률/모듈배치
  3. sitec_engine: SITE-C A~F 자동 채점
  4. demand_predictor: AI 수요 예측
  5. regulation_checker: 건축법 규제 자동 검토

전체 결과를 단일 응답으로 반환하여 프론트엔드 단일 탭에서 표시
"""

import logging
import asyncio
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime

from app.services.parcel_lookup import ParcelLookupResult, parcel_lookup
from app.services.sitec_engine import sitec_engine, SiteCCriteria, SiteCResult
from app.services.demand_predictor import demand_predictor
from app.services.parcel_analyzer import ParcelAnalyzer, ParcelInfo as AnalyzerParcelInfo

logger = logging.getLogger(__name__)

parcel_analyzer = ParcelAnalyzer()


# ─── 결과 데이터 클래스 ────────────────────────────────────────

@dataclass
class SiteCAutoInput:
    """SITE-C 자동 채점 입력 (parcel_lookup 결과로 자동 채워짐)"""
    planned_units: int = 30
    small_unit_ratio: float = 0.8   # 전용 60㎡ 이하 비율 (모듈러 특성상 높음)
    is_modular: bool = True
    long_term_rental: bool = False
    lh_certified: bool = False
    energy_efficiency_grade: int = 2  # 모듈러 공법 기본 2등급


@dataclass
class AutoEvalStep:
    """단계별 평가 진행 상태"""
    step: str
    label: str
    status: str   # "pending" | "running" | "done" | "error"
    result: Any = None
    error: str = ""


@dataclass
class ParcelBasicInfo:
    """필지 기본 정보 (응답용)"""
    address: str
    lat: float
    lng: float
    area_m2: float
    land_category: str
    zone_name: str
    zone_name2: str
    coverage_ratio_max: float
    floor_area_ratio_max: float
    max_floors: int
    is_simulation: bool
    data_sources: List[str]
    # SITE-C 자동 수집 거리 (실데이터 or 시뮬레이션)
    cbd_distance_km: float = 0.0
    subway_distance_m: float = 0.0
    bus_stop_distance_m: float = 0.0
    elementary_school_distance_m: float = 0.0
    hospital_distance_m: float = 0.0
    mart_distance_m: float = 0.0
    slope_percent: float = 0.0
    seismic_grade: int = 1
    sunshine_hours: float = 4.0


@dataclass
class SiteCAutoResult:
    """SITE-C 자동 평가 결과 (단일 탭 전체 데이터)"""
    # 입력 정보
    address_input: str
    evaluated_at: str

    # 단계 1: 필지 기본 정보
    parcel: ParcelBasicInfo

    # 단계 2: 건축 규제
    regulations: Dict[str, Any]

    # 단계 3: 모듈 배치 추천
    best_module: str
    best_floor: int
    best_units: int
    coverage_ratio: float
    floor_area_ratio: float
    roi_pct: float
    module_plans: List[Dict[str, Any]]

    # 단계 4: SITE-C 평가
    sitec_score: float
    sitec_grade: str
    sitec_approval_prob: float
    sitec_breakdown: Dict[str, float]
    sitec_suggestions: List[str]
    sitec_criteria_used: Dict[str, Any]  # 자동으로 채워진 값들

    # 단계 5: 수요 예측
    demand_score: float
    recommended_units: int
    demand_confidence: float
    demand_region: str
    demand_risk_factors: List[str]

    # 사업성 요약
    construction_cost_bn: float
    lh_purchase_bn: float
    profit_bn: float
    profit_margin_pct: float

    # 종합 판정
    overall_grade: str          # A+ / A / B / C / 검토요
    overall_summary: str
    key_strengths: List[str]
    key_risks: List[str]
    next_actions: List[str]

    # 데이터 품질
    is_simulation: bool
    data_sources: List[str]
    errors: List[str]


# ─── 헬퍼 함수 ────────────────────────────────────────────────

def _zone_to_regulations(zone_name: str) -> Dict[str, Any]:
    """용도지역 → 건축 규제 한도 변환
    
    서울시 도시계획 조례 기준:
    - 제2종일반주거지역(7층이하): zone_name에 '7층' 포함 시 max_floors=7 적용
      (서울시 도시계획조례 별도 지정구역, 토지이음 표시와 동일)
    - 수평표면구역(비행안전구역): 높이 45m → 14층 (별도 처리)
    """
    ZONE_REGS = {
        "제1종전용주거지역": {"coverage": 50, "far": 100,  "max_floors": 4,  "height": 12},
        "제2종전용주거지역": {"coverage": 50, "far": 150,  "max_floors": 4,  "height": 12},
        "제1종일반주거지역": {"coverage": 60, "far": 200,  "max_floors": 4,  "height": 13.6},
        "제2종일반주거지역": {"coverage": 60, "far": 200,  "max_floors": 12, "height": 40.4},  # 서울조례
        "제3종일반주거지역": {"coverage": 50, "far": 250,  "max_floors": 0,  "height": 0},  # 서울조례
        "준주거지역":        {"coverage": 70, "far": 400,  "max_floors": 0,  "height": 0},  # 서울조례
        "준공업지역":        {"coverage": 70, "far": 400,  "max_floors": 0,  "height": 0},
        "근린상업지역":      {"coverage": 70, "far": 900,  "max_floors": 0,  "height": 0},
        "일반상업지역":      {"coverage": 80, "far": 1300, "max_floors": 0,  "height": 0},
        "자연녹지지역":      {"coverage": 20, "far": 100,  "max_floors": 4,  "height": 12},
    }
    # ── 7층이하 특별 지정구역 처리 ──────────────────────────────
    # zone_name에 "7층" 또는 "7층이하" 포함 시 서울시 도시계획조례상 7층 제한 적용
    # 예: "제2종일반주거지역(7층이하)", "제2종일반주거지역 7층이하" 등
    if "제2종일반주거" in zone_name and ("7층" in zone_name or "7F" in zone_name.upper()):
        return {"coverage": 60, "far": 200, "max_floors": 7, "height": 22.4}  # 7층×3.2m=22.4m
    # 부분 매칭
    for key in sorted(ZONE_REGS.keys(), key=len, reverse=True):
        if key in zone_name:
            return ZONE_REGS[key]
    return {"coverage": 60, "far": 200, "max_floors": 12, "height": 40.4}  # 서울조례 기본


def _calc_module_plans(
    area_m2: float,
    zone_name: str,
    regs: Dict[str, Any]
) -> List[Dict[str, Any]]:
    """
    필지 면적 + 용도지역 → 모듈 배치 계획 자동 계산
    Gen 2 모듈 스펙 기반
    """
    MODULE_WIDTH = 3.2  # m
    MODULE_CENTERLINE = 3.05  # m
    MODULE_HEIGHT = 3.2  # m (층당)

    # Gen 2 모듈 정보
    MODULES = [
        {"type": "BALCONY-2",  "length": 9.6,  "net_area": 28.82, "lh_type": "29㎡", "cost_idx": 1.15},
        {"type": "BALCONY-3",  "length": 9.6,  "net_area": 28.82, "lh_type": "29㎡", "cost_idx": 1.15},
        {"type": "BASIC-2-C1", "length": 9.5,  "net_area": 28.52, "lh_type": "26㎡", "cost_idx": 1.10},
        {"type": "BASIC-1-C2", "length": 9.3,  "net_area": 27.91, "lh_type": "19㎡", "cost_idx": 1.08},
        {"type": "BASIC-1-C1", "length": 8.7,  "net_area": 22.45, "lh_type": "19㎡", "cost_idx": 1.00},
        {"type": "BASIC-4-C1", "length": 9.6,  "net_area": 26.69, "lh_type": "26㎡", "cost_idx": 1.12},
    ]

    max_coverage = regs["coverage"] / 100
    max_far = regs["far"] / 100
    max_floors_reg = regs["max_floors"] if regs["max_floors"] > 0 else 20

    plans = []

    for mod in MODULES:
        building_length = mod["length"]
        net_area = mod["net_area"]

        # ── 건물 바닥면적 기반 최대 세대/층 역산 ──────────────────────
        # 단위 모듈 1세대 바닥면적 = 3.05 × (length - 0.15) ㎡
        unit_footprint = MODULE_CENTERLINE * (building_length - 0.15)
        if unit_footprint <= 0:
            continue

        # 건폐율 허용 최대 바닥면적
        max_footprint = area_m2 * max_coverage

        # 건폐율 내 최대 세대/층 (상한 없이 면적으로만 제한)
        units_per_floor = max(1, int(max_footprint / unit_footprint))

        # 건물 바닥면적 계산
        building_footprint = unit_footprint * units_per_floor

        if building_footprint <= 0:
            continue

        # 건폐율 재검증 (정수화 오차 보정)
        coverage_pct = building_footprint / area_m2
        if coverage_pct > max_coverage:
            units_per_floor = max(1, units_per_floor - 1)
            building_footprint = unit_footprint * units_per_floor
            coverage_pct = building_footprint / area_m2

        # 층수 계산 (용적률 기반)
        max_gfa = area_m2 * max_far
        max_floors_far = int(max_gfa / building_footprint) if building_footprint > 0 else 1
        max_floors = min(max_floors_far, max_floors_reg)

        # 높이 제한 체크
        if regs["height"] > 0:
            floors_by_height = int(regs["height"] / MODULE_HEIGHT)
            max_floors = min(max_floors, floors_by_height)

        max_floors = max(1, min(max_floors, 20))

        total_units = units_per_floor * max_floors
        total_gfa = building_footprint * max_floors
        far_pct = total_gfa / area_m2 * 100

        if total_units <= 0:
            continue

        # ─── 사업비 추정 (억원) ─────────────────────────────────────
        # 모듈러 건축 표준 공사비: 약 250만원/㎡ (전용면적 기준) × 보정
        # 연면적 기준으로 환산 (전용률 약 65%)
        gfa_per_unit = net_area / 0.65   # 세대당 연면적 (공용 포함)
        unit_const_cost_wan = gfa_per_unit * 250 * mod["cost_idx"]  # 만원/세대
        # 총 공사비 (억원)
        total_const_cost = total_units * unit_const_cost_wan / 10000  # 억원

        # LH 매입가: 전용면적 × 지역 단가
        # 수도권 기준 약 450~550만원/㎡ (2024 기준 신축매입약정)
        lh_price_per_m2 = 500  # 만원/㎡ (수도권 평균)
        lh_unit_price_wan = net_area * lh_price_per_m2  # 만원/세대
        total_lh_price = total_units * lh_unit_price_wan / 10000  # 억원

        profit = total_lh_price - total_const_cost
        roi = (profit / total_const_cost * 100) if total_const_cost > 0 else 0

        # 전용 60㎡ 이하 비율 (모든 Gen 2 모듈이 60㎡ 이하)
        small_ratio = 1.0

        plans.append({
            "module_type": mod["type"],
            "module_length_mm": int(building_length * 1000),
            "net_area_m2": net_area,
            "lh_type": mod["lh_type"],
            "units_per_floor": units_per_floor,
            "floors": max_floors,
            "total_units": total_units,
            "building_footprint_m2": round(building_footprint, 1),
            "total_gfa_m2": round(total_gfa, 1),
            "coverage_ratio_pct": round(coverage_pct * 100, 1),
            "floor_area_ratio_pct": round(far_pct, 1),
            "small_unit_ratio": small_ratio,
            "construction_cost_100m": round(total_const_cost, 2),  # 억원
            "lh_purchase_100m": round(total_lh_price, 2),          # 억원
            "profit_100m": round(profit, 2),                        # 억원
            "roi_pct": round(roi, 1),
            "is_compliant": (
                coverage_pct * 100 <= regs["coverage"] + 0.5 and
                far_pct <= regs["far"] + 1.0
            ),
        })

    # ROI 기준 정렬
    plans.sort(key=lambda x: (x["is_compliant"], x["roi_pct"]), reverse=True)
    return plans


def _determine_overall_grade(
    sitec_grade: str,
    roi_pct: float,
    demand_score: float,
    zone_name: str
) -> str:
    """
    SITE-C 등급 + 사업성 + 수요 → 종합 등급
    """
    score = 0

    # SITE-C 등급 점수
    sitec_pts = {"A": 3, "B": 2, "C": 1}.get(sitec_grade, 0)
    score += sitec_pts * 30  # 최대 90점

    # ROI
    if roi_pct >= 80:
        score += 40
    elif roi_pct >= 60:
        score += 30
    elif roi_pct >= 40:
        score += 20
    else:
        score += 10

    # 수요
    if demand_score >= 70:
        score += 30
    elif demand_score >= 50:
        score += 20
    else:
        score += 10

    # 용도지역 적합성
    bad_zones = ["자연녹지", "전용공업", "보전녹지"]
    if any(z in zone_name for z in bad_zones):
        score -= 30

    if score >= 130:
        return "A+"
    elif score >= 100:
        return "A"
    elif score >= 70:
        return "B"
    elif score >= 50:
        return "C"
    else:
        return "검토요"


def _generate_summary(
    overall_grade: str,
    parcel_area: float,
    best_units: int,
    sitec_grade: str,
    roi_pct: float,
    zone_name: str
) -> str:
    """종합 사업성 요약 문장 생성"""
    grade_desc = {
        "A+": "탁월한 사업지",
        "A":  "우수한 사업지",
        "B":  "양호한 사업지",
        "C":  "검토가 필요한 사업지",
        "검토요": "신중한 검토가 필요한 사업지",
    }
    desc = grade_desc.get(overall_grade, "평가 결과")

    return (
        f"{parcel_area:.0f}㎡ {zone_name} 필지로 {desc}입니다. "
        f"모듈러 공법 적용 시 {best_units}세대 구성이 가능하며, "
        f"SITE-C {sitec_grade}등급 (LH 심의 통과 확률 "
        f"{'90%+' if sitec_grade=='A' else '75%' if sitec_grade=='B' else '50%'})으로 "
        f"예상 ROI {roi_pct:.1f}%를 달성할 수 있습니다."
    )


def _build_sitec_criteria(
    lookup: ParcelLookupResult,
    user_input: SiteCAutoInput
) -> SiteCCriteria:
    """
    ParcelLookupResult + 사용자 입력 → SiteCCriteria 자동 구성
    """
    return SiteCCriteria(
        # A. 교통 접근성
        cbd_distance_km=lookup.cbd_distance_km,
        subway_distance_m=lookup.subway_distance_m,
        bus_stop_distance_m=lookup.bus_stop_distance_m,
        # B. 생활 인프라
        elementary_school_distance_m=lookup.elementary_school_distance_m,
        hospital_distance_m=lookup.hospital_distance_m,
        mart_distance_m=lookup.mart_distance_m,
        # C. 사업 규모
        planned_units=user_input.planned_units,
        small_unit_ratio=user_input.small_unit_ratio,
        # D. 구조·안전
        seismic_grade=lookup.seismic_grade,
        slope_percent=lookup.slope_percent,
        # E. 에너지·환경
        energy_efficiency_grade=user_input.energy_efficiency_grade,
        sunshine_hours=lookup.sunshine_hours,
        # F. 사업자 가점
        is_modular=user_input.is_modular,
        long_term_rental=user_input.long_term_rental,
        lh_certified=user_input.lh_certified,
    )


# ─── 메인 평가 서비스 ─────────────────────────────────────────

class AutoSiteCEvaluator:
    """
    지번 하나로 SITE-C 전체 자동 평가 서비스

    사용 방법:
      result = await auto_sitec_evaluator.evaluate("서울시 강남구 역삼동 123-45")
      # 또는 세대수 지정:
      result = await auto_sitec_evaluator.evaluate("서울시 강남구 역삼동 123-45", planned_units=40)
    """

    async def evaluate(
        self,
        address: str,
        planned_units: Optional[int] = None,
        small_unit_ratio: float = 0.8,
        long_term_rental: bool = False,
        lh_certified: bool = False,
        energy_grade: int = 2,
    ) -> SiteCAutoResult:
        """
        주소/지번 → 전체 자동 평가 실행
        """
        errors = []
        evaluated_at = datetime.now().isoformat()

        logger.info(f"자동 SITE-C 평가 시작: {address}")

        # ──────────────────────────────────────────────────
        # STEP 1: 필지 기본 정보 조회
        # ──────────────────────────────────────────────────
        try:
            lookup: ParcelLookupResult = await parcel_lookup.lookup(address)
        except Exception as e:
            errors.append(f"필지 조회 실패: {e}")
            lookup = _make_default_lookup(address)

        # 용도지역 → 건축 규제
        regs = _zone_to_regulations(lookup.zone_name)

        # ── 지역지구 코드 기반 높이 제한 override ─────────────
        # 비행안전구역(항공법 시행규칙): 수평표면구역 45m, 원추표면 60m
        # UIG520=수평표면구역(45m), UIG510=원추표면구역(60m), UIG530=전이표면구역
        land_use_codes = getattr(lookup, "land_use_codes", []) or []
        if land_use_codes:
            # ── ZONE_7F: 공공데이터포털에서 감지된 7층이하 지정구역 ──────────────
            if "ZONE_7F" in land_use_codes and "제2종일반주거" in lookup.zone_name:
                regs = dict(regs)
                regs["max_floors"] = 7
                regs["height"]     = 22.4
                logger.info("공공데이터포털 ZONE_7F 감지: 제2종일반주거지역(7층이하) 적용")

            flight_height_m = None
            if "UIG520" in land_use_codes:  # 수평표면구역: 45m
                flight_height_m = 45.0
            elif "UIG510" in land_use_codes:  # 원추표면구역: 60m
                flight_height_m = 60.0
            elif "UIG530" in land_use_codes:  # 전이표면구역: 가변 (보수적 30m)
                flight_height_m = 30.0
            if flight_height_m is not None:
                # 현재 높이 제한보다 엄격한 경우만 적용
                if regs["height"] == 0 or flight_height_m < regs["height"]:
                    import copy
                    regs = dict(regs)  # 복사 (원본 ZONE_REGS 수정 방지)
                    regs["height"] = flight_height_m
                    flight_floors = int(flight_height_m / 3.2)
                    if regs["max_floors"] == 0 or flight_floors < regs["max_floors"]:
                        regs["max_floors"] = flight_floors
                    logger.info(f"비행안전구역 높이제한 적용: {flight_height_m}m → 최대 {regs['max_floors']}층")

        parcel_info = ParcelBasicInfo(
            address=address,
            lat=lookup.lat,
            lng=lookup.lng,
            area_m2=lookup.area_m2,
            land_category=lookup.land_category,
            zone_name=lookup.zone_name,
            zone_name2=lookup.zone_name2,
            coverage_ratio_max=float(regs["coverage"]),
            floor_area_ratio_max=float(regs["far"]),
            max_floors=regs["max_floors"],
            is_simulation=lookup.is_simulation,
            data_sources=lookup.data_sources,
            # SITE-C 자동 수집 거리 필드
            cbd_distance_km=lookup.cbd_distance_km,
            subway_distance_m=lookup.subway_distance_m,
            bus_stop_distance_m=lookup.bus_stop_distance_m,
            elementary_school_distance_m=lookup.elementary_school_distance_m,
            hospital_distance_m=lookup.hospital_distance_m,
            mart_distance_m=lookup.mart_distance_m,
            slope_percent=lookup.slope_percent,
            seismic_grade=lookup.seismic_grade,
            sunshine_hours=lookup.sunshine_hours,
        )

        # ──────────────────────────────────────────────────
        # STEP 2: 모듈 배치 계획 계산
        # ──────────────────────────────────────────────────
        module_plans = _calc_module_plans(lookup.area_m2, lookup.zone_name, regs)

        if not module_plans:
            # 기본 플랜
            module_plans = [{
                "module_type": "BASIC-1-C1",
                "net_area_m2": 22.45,
                "lh_type": "19㎡",
                "units_per_floor": 2,
                "floors": 4,
                "total_units": 8,
                "coverage_ratio_pct": 55.0,
                "floor_area_ratio_pct": 220.0,
                "roi_pct": 60.0,
                "is_compliant": True,
            }]

        best_plan = module_plans[0]

        # planned_units가 지정된 경우 SITE-C 계산에 반영, 아니면 추천값 사용
        recommended_units = best_plan["total_units"]
        if planned_units is None:
            planned_units = recommended_units

        # ──────────────────────────────────────────────────
        # STEP 3: SITE-C 자동 평가
        # ──────────────────────────────────────────────────
        user_input = SiteCAutoInput(
            planned_units=planned_units,
            small_unit_ratio=small_unit_ratio,
            long_term_rental=long_term_rental,
            lh_certified=lh_certified,
            energy_efficiency_grade=energy_grade,
        )

        criteria = _build_sitec_criteria(lookup, user_input)

        try:
            sitec_result: SiteCResult = sitec_engine.calculate(criteria)
        except Exception as e:
            errors.append(f"SITE-C 평가 오류: {e}")
            from dataclasses import asdict
            sitec_result = _make_default_sitec_result()

        # ──────────────────────────────────────────────────
        # STEP 4: 수요 예측 (비동기)
        # ──────────────────────────────────────────────────
        try:
            demand_result = await demand_predictor.predict_demand(
                lat=lookup.lat,
                lng=lookup.lng,
                radius_m=1000,
            )
        except Exception as e:
            errors.append(f"수요 예측 오류: {e}")
            demand_result = _make_default_demand_result(lookup.lat, lookup.lng)

        # ──────────────────────────────────────────────────
        # STEP 5: 결과 취합 & 종합 판정
        # ──────────────────────────────────────────────────
        best_roi = best_plan.get("roi_pct", 60.0)
        best_units_count = best_plan.get("total_units", 20)

        overall_grade = _determine_overall_grade(
            sitec_result.grade,
            best_roi,
            demand_result.demand_score,
            lookup.zone_name,
        )

        overall_summary = _generate_summary(
            overall_grade,
            lookup.area_m2,
            best_units_count,
            sitec_result.grade,
            best_roi,
            lookup.zone_name,
        )

        # 강점 분석
        key_strengths = []
        key_risks = []

        if lookup.subway_distance_m <= 500:
            key_strengths.append(f"역세권 우수: 지하철역 {lookup.subway_distance_m:.0f}m")
        if sitec_result.grade in ["A", "B"]:
            key_strengths.append(f"SITE-C {sitec_result.grade}등급 — 심의 통과 확률 {'90%' if sitec_result.grade == 'A' else '75%'}")
        if best_roi >= 70:
            key_strengths.append(f"ROI {best_roi:.1f}% — 우수한 사업성")
        if user_input.is_modular:
            key_strengths.append("모듈러 공법 가점 적용 — 건축 기간 단축")
        if lookup.area_m2 >= 500:
            key_strengths.append(f"충분한 필지 면적: {lookup.area_m2:.0f}㎡")

        if lookup.slope_percent > 10:
            key_risks.append(f"경사도 {lookup.slope_percent:.1f}% — 기초공사 추가 비용 발생")
        if lookup.subway_distance_m > 2000:
            key_risks.append(f"지하철역 거리 {lookup.subway_distance_m:.0f}m — SITE-C A항목 감점")
        if "녹지" in lookup.zone_name:
            key_risks.append("녹지지역 — 공동주택 건축 제한 가능")
        if lookup.area_m2 < 300:
            key_risks.append(f"소규모 필지 {lookup.area_m2:.0f}㎡ — 세대수 제한")
        if sitec_result.grade == "탈락":
            key_risks.append("SITE-C 탈락 등급 — 사업지 재선정 권장")
        # 7층이하/비행안전구역 경고
        _land_use_codes_risk = getattr(lookup, "land_use_codes", []) or []
        if "제2종일반주거" in lookup.zone_name:
            _is_7f = (
                "7층" in lookup.zone_name
                or "7층" in lookup.zone_name2
                or "ZONE_7F" in _land_use_codes_risk
            )
            if _is_7f:
                key_risks.append(
                    "제2종일반주거지역(7층이하) 지정구역 확인됨 — "
                    "개별 건축허가 시 최고 7층 제한. "
                    "재건축·지구단위계획 수립 시 최대 25층 가능 (2021 조례)"
                )
            elif "UIG520" in _land_use_codes_risk:
                key_risks.append("수평표면구역(비행안전구역) 포함 — 층수 제한 현장 확인 필요")
            elif lookup.is_simulation is False:
                key_risks.append(
                    "서울시 제2종일반주거지역: 7층이하 지정 여부 미확인 — "
                    "토지이음(eum.go.kr) 또는 DATA_GO_KR_API_KEY 설정으로 자동 감지 권장"
                )

        # 다음 단계
        next_actions = [
            "정밀 현장 조사 (지형측량, 지반조사)",
            "GPT 기반 인허가 시뮬레이션 (건축위원회 사전 협의)",
            "LH 신축매입약정 신청서 초안 작성",
            "실제 API 키 연동으로 정밀 데이터 재분석 (VWorld, 카카오)",
        ]

        if sitec_result.grade == "C":
            next_actions.insert(0, "SITE-C 개선 포인트 반영 후 재평가")
        if best_units_count < 20:
            next_actions.insert(0, "인접 필지 통합 검토 (세대수 확보)")

        # 사업비 계산 (억원) - 이미 억원 단위로 저장됨
        const_cost_bn = best_plan.get("construction_cost_100m", 0)  # 억원
        lh_bn = best_plan.get("lh_purchase_100m", 0)
        profit_bn = best_plan.get("profit_100m", 0)
        profit_margin = (profit_bn / const_cost_bn * 100) if const_cost_bn > 0 else 0

        # 규제 정보 dict
        # 7층이하 경고 메시지 생성
        floor_limit_note = ""
        land_use_codes_for_note = getattr(lookup, "land_use_codes", []) or []
        if "제2종일반주거" in lookup.zone_name:
            _is_7f_note = (
                "7층" in lookup.zone_name
                or "7층" in lookup.zone_name2
                or "ZONE_7F" in land_use_codes_for_note
            )
            if _is_7f_note:
                floor_limit_note = (
                    "제2종일반주거지역(7층이하) 지정구역: 개별 건축허가 시 최고 7층 제한. "
                    "재건축·신속통합기획·지구단위계획 수립 시 최대 25층 가능 (서울시 2021.10 조례 개정). "
                    "구청 건축과 사전 상담 권장."
                )
            elif "UIG520" in land_use_codes_for_note:
                floor_limit_note = (
                    "수평표면구역(비행안전구역) 포함: 지상고 45m 이하 제한. "
                    "제2종일반주거지역의 경우 7층이하 지정구역 여부를 토지이음에서 추가 확인 권장."
                )
            else:
                floor_limit_note = (
                    "서울시 제2종일반주거지역 중 약 14%(85km2)는 7층이하 지정구역. "
                    "정확한 확인: 토지이음(eum.go.kr) 조회 또는 "
                    "DATA_GO_KR_API_KEY 환경변수 설정으로 자동 감지 가능."
                )
        regulations_dict = {
            "zone_name": lookup.zone_name,
            "zone_name2": lookup.zone_name2,
            "coverage_ratio_max": regs["coverage"],
            "floor_area_ratio_max": regs["far"],
            "max_floors": regs["max_floors"],
            "height_limit_m": regs["height"],
            "max_building_footprint_m2": round(lookup.area_m2 * regs["coverage"] / 100, 1),
            "max_total_gfa_m2": round(lookup.area_m2 * regs["far"] / 100, 1),
            "parking_required": max(1, int(planned_units * 0.5)),
            "floor_limit_note": floor_limit_note,
            "land_use_codes": land_use_codes_for_note,
        }

        # SITE-C 자동 채워진 기준값
        sitec_criteria_used = {
            "A_transportation": {
                "cbd_distance_km": lookup.cbd_distance_km,
                "subway_distance_m": lookup.subway_distance_m,
                "bus_stop_distance_m": lookup.bus_stop_distance_m,
                "source": "자동조회 (VWorld/시뮬레이션)",
            },
            "B_infrastructure": {
                "elementary_school_distance_m": lookup.elementary_school_distance_m,
                "hospital_distance_m": lookup.hospital_distance_m,
                "mart_distance_m": lookup.mart_distance_m,
                "source": "자동조회 (카카오/시뮬레이션)",
            },
            "C_scale": {
                "planned_units": planned_units,
                "small_unit_ratio": small_unit_ratio,
                "source": "모듈 배치 계산값 + 사용자 설정",
            },
            "D_structure": {
                "seismic_grade": lookup.seismic_grade,
                "slope_percent": lookup.slope_percent,
                "source": "지형 분석 (지역 기반 추정)",
            },
            "E_energy": {
                "energy_efficiency_grade": energy_grade,
                "sunshine_hours": lookup.sunshine_hours,
                "source": "모듈러 표준 등급 + 위도 기반 추정",
            },
            "F_bonus": {
                "is_modular": True,
                "long_term_rental": long_term_rental,
                "lh_certified": lh_certified,
                "source": "사용자 설정",
            },
        }

        return SiteCAutoResult(
            address_input=address,
            evaluated_at=evaluated_at,
            parcel=parcel_info,
            regulations=regulations_dict,
            best_module=best_plan.get("module_type", "BALCONY-2"),
            best_floor=best_plan.get("floors", 4),
            best_units=best_units_count,
            coverage_ratio=best_plan.get("coverage_ratio_pct", 55.0),
            floor_area_ratio=best_plan.get("floor_area_ratio_pct", 220.0),
            roi_pct=best_roi,
            module_plans=module_plans[:6],  # 최대 6개 플랜
            sitec_score=sitec_result.total_score,
            sitec_grade=sitec_result.grade,
            sitec_approval_prob=sitec_result.approval_probability,
            sitec_breakdown=sitec_result.breakdown,
            sitec_suggestions=sitec_result.improvement_suggestions,
            sitec_criteria_used=sitec_criteria_used,
            demand_score=demand_result.demand_score,
            recommended_units=demand_result.recommended_units,
            demand_confidence=demand_result.confidence,
            demand_region=demand_result.region_name,
            demand_risk_factors=demand_result.risk_factors,
            construction_cost_bn=round(const_cost_bn, 2),
            lh_purchase_bn=round(lh_bn, 2),
            profit_bn=round(profit_bn, 2),
            profit_margin_pct=round(profit_margin, 1),
            overall_grade=overall_grade,
            overall_summary=overall_summary,
            key_strengths=key_strengths,
            key_risks=key_risks,
            next_actions=next_actions,
            is_simulation=lookup.is_simulation,
            data_sources=lookup.data_sources,
            errors=errors,
        )


# ─── 기본값 헬퍼 ─────────────────────────────────────────────

def _make_default_lookup(address: str) -> ParcelLookupResult:
    from app.services.parcel_lookup import ParcelLookupResult
    return ParcelLookupResult(
        address_input=address,
        lat=37.5665,
        lng=126.9780,
        pnu="SIM_0000000000000000000",
        area_m2=500.0,
        land_category="대",
        zone_name="제2종일반주거지역",
        zone_name2="",
        cbd_distance_km=5.0,
        subway_distance_m=800.0,
        bus_stop_distance_m=300.0,
        elementary_school_distance_m=600.0,
        hospital_distance_m=500.0,
        mart_distance_m=200.0,
        slope_percent=3.0,
        seismic_grade=1,
        sunshine_hours=4.5,
        data_sources=["기본값"],
        is_simulation=True,
    )


def _make_default_sitec_result():
    """기본 SITE-C 결과 (오류 시 사용)"""
    from app.services.sitec_engine import SiteCResult
    return SiteCResult(
        total_score=65.0,
        grade="B",
        approval_probability=0.75,
        breakdown={
            "A_교통접근성": 0.65,
            "B_생활인프라": 0.70,
            "C_사업규모": 0.80,
            "D_구조안전": 0.90,
            "E_에너지환경": 0.80,
            "F_사업자가점": 1.00,
        },
        improvement_suggestions=["교통 접근성 개선 필요"],
        transportation_score=0.65,
        infrastructure_score=0.70,
        scale_score=0.80,
        structure_score=0.90,
        energy_score=0.80,
        bonus_score=1.00,
    )


def _make_default_demand_result(lat: float, lng: float):
    """기본 수요 예측 결과 (오류 시 사용)"""
    from app.services.demand_predictor import DemandPredictionResult
    from datetime import datetime
    return DemandPredictionResult(
        lat=lat,
        lng=lng,
        demand_score=65.0,
        recommended_units=25,
        confidence=0.6,
        sigungu_score=65.0,
        emd_score=65.0,
        parcel_score=65.0,
        forecast_monthly=[],
        risk_factors=["시뮬레이션 모드 — 실제 데이터 연동 권장"],
        region_name="조회 중",
        sigungu_code="00000",
        model_version="simulation-v1",
        predicted_at=datetime.now().isoformat(),
    )


# 싱글톤 인스턴스
auto_sitec_evaluator = AutoSiteCEvaluator()
