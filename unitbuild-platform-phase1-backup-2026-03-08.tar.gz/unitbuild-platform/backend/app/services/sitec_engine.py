"""
SITE-C 자동 평가 엔진

LH 신축매입약정 심의 기준 정량화
SITE-C = Σ(w_k × criterion_k) × 100

등급 기준:
  A등급 (≥80): 심의 통과 확률 90%+
  B등급 (65~79): 75%
  C등급 (50~64): 50%
  탈락 (<50): 10%
"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional
import asyncio
import logging

logger = logging.getLogger(__name__)


@dataclass
class SiteCCriteria:
    """SITE-C 평가 입력 기준"""
    # A. 교통 접근성
    cbd_distance_km: float
    subway_distance_m: float
    bus_stop_distance_m: float

    # B. 생활 인프라
    elementary_school_distance_m: float
    hospital_distance_m: float
    mart_distance_m: float

    # C. 사업 규모
    planned_units: int
    small_unit_ratio: float  # 0~1

    # D. 구조·안전
    seismic_grade: int  # 1 or 2
    slope_percent: float

    # E. 에너지·환경
    energy_efficiency_grade: int  # 1~5
    sunshine_hours: float

    # F. 사업자 가점
    is_modular: bool = True
    long_term_rental: bool = False
    lh_certified: bool = False


@dataclass
class SiteCResult:
    """SITE-C 평가 결과"""
    total_score: float
    grade: str
    approval_probability: float
    breakdown: Dict[str, float]
    improvement_suggestions: List[str]
    # 항목별 raw 점수 (0~1)
    transportation_score: float = 0.0
    infrastructure_score: float = 0.0
    scale_score: float = 0.0
    structure_score: float = 0.0
    energy_score: float = 0.0
    bonus_score: float = 0.0


class SiteCEngine:
    """
    SITE-C 자동 평가 엔진

    가중치 구성:
      A. 교통 접근성   25%
      B. 생활 인프라   20%
      C. 사업 규모     20%
      D. 구조·안전     15%
      E. 에너지·환경   10%
      F. 사업자 가점   10%
    """

    WEIGHTS: Dict[str, float] = {
        'A': 0.25,
        'B': 0.20,
        'C': 0.20,
        'D': 0.15,
        'E': 0.10,
        'F': 0.10,
    }

    GRADE_MAP: Dict[str, Tuple[float, float]] = {
        'A': (80.0, 0.90),
        'B': (65.0, 0.75),
        'C': (50.0, 0.50),
        '탈락': (0.0, 0.10),
    }

    def calculate(self, criteria: SiteCCriteria) -> SiteCResult:
        """SITE-C 점수 전체 계산"""

        raw_scores = {
            'A': self._score_transportation(criteria),
            'B': self._score_infrastructure(criteria),
            'C': self._score_scale(criteria),
            'D': self._score_structure(criteria),
            'E': self._score_energy(criteria),
            'F': self._score_bonus(criteria),
        }

        # 가중치 적용 → 100점 만점
        total = sum(raw_scores[k] * self.WEIGHTS[k] * 100 for k in raw_scores)
        total = round(total, 2)

        grade, prob = self._determine_grade(total)
        suggestions = self._generate_suggestions(criteria, raw_scores)

        breakdown = {
            'A_교통접근성': round(raw_scores['A'] * self.WEIGHTS['A'] * 100, 2),
            'B_생활인프라': round(raw_scores['B'] * self.WEIGHTS['B'] * 100, 2),
            'C_사업규모': round(raw_scores['C'] * self.WEIGHTS['C'] * 100, 2),
            'D_구조안전': round(raw_scores['D'] * self.WEIGHTS['D'] * 100, 2),
            'E_에너지환경': round(raw_scores['E'] * self.WEIGHTS['E'] * 100, 2),
            'F_사업자가점': round(raw_scores['F'] * self.WEIGHTS['F'] * 100, 2),
        }

        return SiteCResult(
            total_score=total,
            grade=grade,
            approval_probability=prob,
            breakdown=breakdown,
            improvement_suggestions=suggestions,
            transportation_score=round(raw_scores['A'], 3),
            infrastructure_score=round(raw_scores['B'], 3),
            scale_score=round(raw_scores['C'], 3),
            structure_score=round(raw_scores['D'], 3),
            energy_score=round(raw_scores['E'], 3),
            bonus_score=round(raw_scores['F'], 3),
        )

    # ─────────────────────────────────────────────────────────
    # 항목별 점수 계산 (0.0 ~ 1.0)
    # ─────────────────────────────────────────────────────────

    def _score_transportation(self, c: SiteCCriteria) -> float:
        """A. 교통 접근성 (25%)"""
        # A1. CBD 접근성
        if c.cbd_distance_km <= 30:
            a1 = 1.0
        elif c.cbd_distance_km <= 50:
            a1 = 0.7
        else:
            a1 = 0.3

        # A2. 지하철 역세권
        if c.subway_distance_m <= 500:
            a2 = 1.0
        elif c.subway_distance_m <= 1000:
            a2 = 0.7
        elif c.subway_distance_m <= 2000:
            a2 = 0.4
        else:
            a2 = 0.0

        # A3. 버스 정류장
        if c.bus_stop_distance_m <= 300:
            a3 = 1.0
        elif c.bus_stop_distance_m <= 500:
            a3 = 0.7
        else:
            a3 = 0.3

        return (a1 + a2 + a3) / 3.0

    def _score_infrastructure(self, c: SiteCCriteria) -> float:
        """B. 생활 인프라 (20%)"""
        # B1. 초등학교
        if c.elementary_school_distance_m <= 500:
            b1 = 1.0
        elif c.elementary_school_distance_m <= 1000:
            b1 = 0.7
        else:
            b1 = 0.3

        # B2. 병원
        b2 = 1.0 if c.hospital_distance_m <= 500 else 0.5

        # B3. 마트/편의점
        b3 = 1.0 if c.mart_distance_m <= 300 else 0.5

        return (b1 + b2 + b3) / 3.0

    def _score_scale(self, c: SiteCCriteria) -> float:
        """C. 사업 규모 (20%)"""
        # C1. 세대수
        if c.planned_units >= 30:
            c1 = 1.0
        elif c.planned_units >= 20:
            c1 = 0.8
        else:
            c1 = 0.5

        # C2. 전용면적 60㎡ 이하 비율
        if c.small_unit_ratio >= 0.5:
            c2 = 1.0
        elif c.small_unit_ratio >= 0.4:
            c2 = 0.8
        else:
            c2 = 0.5

        return (c1 + c2) / 2.0

    def _score_structure(self, c: SiteCCriteria) -> float:
        """D. 구조·안전 (15%)"""
        # D1. 내진등급
        d1 = 1.0 if c.seismic_grade == 1 else 0.8

        # D2. 경사도
        if c.slope_percent <= 5:
            d2 = 1.0
        elif c.slope_percent <= 10:
            d2 = 0.7
        else:
            d2 = 0.3

        return (d1 + d2) / 2.0

    def _score_energy(self, c: SiteCCriteria) -> float:
        """E. 에너지·환경 (10%)"""
        # E1. 에너지효율등급
        if c.energy_efficiency_grade == 1:
            e1 = 1.0
        elif c.energy_efficiency_grade == 2:
            e1 = 0.8
        else:
            e1 = 0.5

        # E2. 일조시간
        e2 = 1.0 if c.sunshine_hours >= 4.0 else 0.5

        return (e1 + e2) / 2.0

    def _score_bonus(self, c: SiteCCriteria) -> float:
        """F. 사업자 가점 (10%) — 최대 1.0 캡"""
        f1 = 1.0 if c.is_modular else 0.0
        f2 = 0.8 if c.long_term_rental else 0.0
        f3 = 0.7 if c.lh_certified else 0.0
        raw = f1 + f2 + f3
        # 정규화: 최대 가점 합 2.5 → 1.0
        return min(1.0, raw / 2.5)

    # ─────────────────────────────────────────────────────────
    # 등급 판정
    # ─────────────────────────────────────────────────────────

    def _determine_grade(self, score: float) -> Tuple[str, float]:
        if score >= 80:
            return 'A', 0.90
        elif score >= 65:
            return 'B', 0.75
        elif score >= 50:
            return 'C', 0.50
        else:
            return '탈락', 0.10

    # ─────────────────────────────────────────────────────────
    # 개선 제안 자동 생성
    # ─────────────────────────────────────────────────────────

    def _generate_suggestions(
        self, c: SiteCCriteria, scores: Dict[str, float]
    ) -> List[str]:
        suggestions = []

        # A. 교통
        if scores['A'] < 0.7:
            if c.subway_distance_m > 2000:
                suggestions.append(
                    f"지하철역 거리 {c.subway_distance_m:.0f}m → 2,000m 이내 사업지 우선 검토"
                )
            if c.cbd_distance_km > 50:
                suggestions.append(
                    f"CBD 거리 {c.cbd_distance_km:.0f}km — 30km 이내 지역 대안 검토 권장"
                )

        # C. 사업 규모
        if c.planned_units < 30:
            suggestions.append(
                f"계획 세대수 {c.planned_units}세대 → 30세대 이상으로 확대 시 C1 만점 획득"
            )
        if c.small_unit_ratio < 0.4:
            suggestions.append(
                f"전용 60㎡ 이하 비율 {c.small_unit_ratio*100:.0f}% → 40% 이상 확보 시 C2 점수 향상"
            )

        # D. 구조
        if c.seismic_grade > 1:
            suggestions.append("내진등급 1등급 설계 적용 시 D1 만점(+0.2점 향상)")

        # E. 에너지
        if c.energy_efficiency_grade > 2:
            suggestions.append(
                f"에너지효율 {c.energy_efficiency_grade}등급 → 1·2등급 인증 취득 시 E1 향상"
            )
        if c.sunshine_hours < 4.0:
            suggestions.append(
                f"일조시간 {c.sunshine_hours:.1f}h — 남향·이격거리 조정으로 4h+ 확보 검토"
            )

        # F. 사업자 가점
        if not c.is_modular:
            suggestions.append("모듈러 공법 적용 시 F1 가점 획득 (유닛랩 솔루션 연동)")
        if not c.long_term_rental:
            suggestions.append("장기임대 10년 이상 계획 시 F2 추가 가점")

        # 점수가 높으면 긍정 메시지
        current_total = sum(scores[k] * self.WEIGHTS[k] * 100 for k in scores)
        if current_total >= 80:
            suggestions.insert(0, "✅ A등급 달성 — LH 심의 통과 확률 90% 이상")
        elif current_total >= 65:
            suggestions.insert(0, "🔵 B등급 — 소규모 보완으로 A등급 진입 가능")

        return suggestions

    # ─────────────────────────────────────────────────────────
    # 시나리오 시뮬레이션
    # ─────────────────────────────────────────────────────────

    def simulate(
        self,
        criteria: SiteCCriteria,
        changes: Dict[str, float]
    ) -> Tuple[SiteCResult, SiteCResult]:
        """
        변경 전/후 점수 비교
        Args:
            criteria: 현재 기준
            changes: {'planned_units': 35, 'subway_distance_m': 800, ...}
        Returns:
            (before_result, after_result)
        """
        before = self.calculate(criteria)

        # 변경 적용
        updated = SiteCCriteria(**{
            **criteria.__dict__,
            **{k: v for k, v in changes.items() if hasattr(criteria, k)}
        })
        after = self.calculate(updated)

        return before, after

    # ─────────────────────────────────────────────────────────
    # 배치 평가 (비동기)
    # ─────────────────────────────────────────────────────────

    async def batch_evaluate_criteria(
        self, criteria_list: List[SiteCCriteria]
    ) -> List[SiteCResult]:
        """복수 기준 병렬 평가"""
        loop = asyncio.get_event_loop()
        results = await asyncio.gather(
            *[loop.run_in_executor(None, self.calculate, c) for c in criteria_list]
        )
        return list(results)


# 싱글톤 인스턴스
sitec_engine = SiteCEngine()
