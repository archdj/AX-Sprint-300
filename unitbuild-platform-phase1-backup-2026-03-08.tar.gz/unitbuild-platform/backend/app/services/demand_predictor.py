"""
AI 기반 주택 수요 예측 서비스 (Phase 1: 시뮬레이션 기반)

Phase 1: 공공 API 미연동 상태에서 지역 특성 기반 시뮬레이션
Phase 2: LH OpenAPI, 통계청, 국토교통부 실거래가 API 실제 연동 + LSTM 모델
"""

import math
import random
import logging
from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


@dataclass
class DemandPredictionResult:
    lat: float
    lng: float
    demand_score: float         # 0~100 수요 확신도
    recommended_units: int      # 추천 세대수
    confidence: float           # 예측 신뢰도 (0~1)
    
    # 계층별 점수
    sigungu_score: float
    emd_score: float
    parcel_score: float
    
    # 12개월 수요 예측 시계열
    forecast_monthly: List[Dict]
    
    # 리스크 요인
    risk_factors: List[str]
    
    # 지역 정보
    region_name: str
    sigungu_code: str
    
    # 메타
    model_version: str = "1.0-simulation"
    predicted_at: str = ""


class DemandPredictorService:
    """
    수요예측 서비스

    Phase 1 시뮬레이션 로직:
    - 좌표 기반 지역 특성 추정 (서울/수도권/지방 구분)
    - 인구 밀도, 개발 호재 등 가중치 적용
    - 계층적 예측 (시군구 → 읍면동 → 필지)
    
    Phase 2 실제 연동:
    - LH OpenAPI (공실률, 공급 현황)
    - 통계청 KOSIS API (인구, 소득, 혼인)
    - 국토교통부 실거래가 API
    - LSTM/Transformer 모델 추론
    """

    # 지역 구분 기준 (서울 중심 좌표)
    SEOUL_CENTER = (37.5665, 126.9780)
    
    # 서울 CBD 좌표 (광화문)
    SEOUL_CBD = (37.5750, 126.9769)
    
    def _haversine_km(self, lat1: float, lng1: float, lat2: float, lng2: float) -> float:
        R = 6371.0
        phi1, phi2 = math.radians(lat1), math.radians(lat2)
        dphi = math.radians(lat2 - lat1)
        dlambda = math.radians(lng2 - lng1)
        a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
        return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))

    def _estimate_region_type(self, lat: float, lng: float) -> Tuple[str, str, float]:
        """
        좌표 → 지역 유형, 지역명, CBD 거리 추정
        Returns: (region_type, region_name, cbd_distance_km)
        """
        dist_from_seoul = self._haversine_km(lat, lng, *self.SEOUL_CENTER)
        cbd_dist = self._haversine_km(lat, lng, *self.SEOUL_CBD)
        
        # 서울 내부
        if lat >= 37.42 and lat <= 37.70 and lng >= 126.80 and lng <= 127.18:
            if cbd_dist <= 10:
                return 'seoul_core', '서울 도심', cbd_dist
            else:
                return 'seoul_outer', '서울 외곽', cbd_dist
        
        # 수도권 (서울 60km 이내)
        elif dist_from_seoul <= 60:
            if dist_from_seoul <= 30:
                return 'metropolitan_near', '수도권 근교', cbd_dist
            else:
                return 'metropolitan_far', '수도권 광역', cbd_dist
        
        # 지방 광역시 추정 (부산, 대구, 광주, 대전 인근)
        elif any(
            self._haversine_km(lat, lng, clat, clng) < 30
            for clat, clng in [
                (35.1796, 129.0756),  # 부산
                (35.8714, 128.6014),  # 대구
                (35.1595, 126.8526),  # 광주
                (36.3504, 127.3845),  # 대전
            ]
        ):
            return 'provincial_metro', '지방 광역시', cbd_dist
        
        else:
            return 'provincial', '지방 도시', cbd_dist

    def _compute_base_demand(self, region_type: str, cbd_dist: float) -> float:
        """지역 유형 및 CBD 거리 기반 기본 수요 점수 계산"""
        base_scores = {
            'seoul_core': 85.0,
            'seoul_outer': 75.0,
            'metropolitan_near': 70.0,
            'metropolitan_far': 60.0,
            'provincial_metro': 55.0,
            'provincial': 40.0,
        }
        
        base = base_scores.get(region_type, 50.0)
        
        # CBD 거리 패널티 (10km당 약 2점 감소)
        distance_penalty = min(15.0, cbd_dist * 0.2)
        
        return max(20.0, base - distance_penalty)

    async def predict_demand(
        self,
        lat: float,
        lng: float,
        radius_m: int = 1000,
    ) -> DemandPredictionResult:
        """
        좌표 기반 수요 예측 메인 함수
        
        1. 지역 특성 분류
        2. 기본 수요 점수 계산
        3. 계층적 점수 보정
        4. 12개월 예측 시계열 생성
        5. 리스크 요인 도출
        """
        region_type, region_name, cbd_dist = self._estimate_region_type(lat, lng)
        
        # 재현성 보장 시드
        seed = int((lat * 10000 + lng * 10000) % 99999)
        rng = random.Random(seed)
        
        # 기본 수요 점수
        base_score = self._compute_base_demand(region_type, cbd_dist)
        
        # 노이즈 추가 (±8점)
        noise = rng.uniform(-8, 8)
        
        # 시군구 → 읍면동 → 필지 계층 보정
        sigungu_score = round(base_score + noise * 0.3, 1)
        emd_score = round(sigungu_score + rng.uniform(-5, 5), 1)
        parcel_score = round(emd_score + rng.uniform(-3, 3), 1)
        
        # 최종 수요 점수 (0~100 클리핑)
        demand_score = round(max(0, min(100, parcel_score + noise * 0.5)), 1)
        
        # 추천 세대수 계산
        recommended_units = self._calculate_recommended_units(demand_score, region_type)
        
        # 신뢰도 (지역 데이터 품질 기반)
        confidence = {
            'seoul_core': 0.88,
            'seoul_outer': 0.82,
            'metropolitan_near': 0.78,
            'metropolitan_far': 0.72,
            'provincial_metro': 0.68,
            'provincial': 0.60,
        }.get(region_type, 0.65)
        
        confidence += rng.uniform(-0.05, 0.05)
        confidence = round(max(0.5, min(0.95, confidence)), 2)
        
        # 12개월 수요 예측 시계열
        forecast = self._generate_forecast(demand_score, rng)
        
        # 리스크 요인
        risks = self._identify_risks(demand_score, region_type, cbd_dist, rng)
        
        # 임시 행정구역 코드
        sigungu_code = f"{int(lat*100):04d}{int(lng*100):04d}"[:10]
        
        return DemandPredictionResult(
            lat=lat,
            lng=lng,
            demand_score=demand_score,
            recommended_units=recommended_units,
            confidence=confidence,
            sigungu_score=sigungu_score,
            emd_score=emd_score,
            parcel_score=parcel_score,
            forecast_monthly=forecast,
            risk_factors=risks,
            region_name=region_name,
            sigungu_code=sigungu_code,
            predicted_at=datetime.now().isoformat(),
        )

    def _calculate_recommended_units(self, demand_score: float, region_type: str) -> int:
        """수요 점수 기반 추천 세대수"""
        base_units = {
            'seoul_core': 80,
            'seoul_outer': 60,
            'metropolitan_near': 50,
            'metropolitan_far': 40,
            'provincial_metro': 35,
            'provincial': 25,
        }.get(region_type, 30)
        
        # 수요 점수 비례 조정
        multiplier = demand_score / 70.0  # 70점 기준 정규화
        units = int(base_units * multiplier)
        
        # 최소 10세대, 최대 200세대
        return max(10, min(200, units))

    def _generate_forecast(self, base_score: float, rng: random.Random) -> List[Dict]:
        """12개월 수요 예측 시계열 데이터 생성"""
        forecast = []
        current_score = base_score
        
        now = datetime.now()
        
        for month_offset in range(1, 13):
            # 트렌드 + 계절성 + 노이즈
            trend = 0.3  # 월 0.3점 완만한 상승
            seasonal = 2.0 * math.sin(2 * math.pi * month_offset / 12)  # 봄/가을 피크
            noise = rng.uniform(-1.5, 1.5)
            
            current_score = current_score + trend + seasonal * 0.5 + noise
            current_score = max(0, min(100, current_score))
            
            forecast_date = (now + timedelta(days=30 * month_offset)).strftime('%Y-%m')
            
            forecast.append({
                'month': forecast_date,
                'demand_score': round(current_score, 1),
                'estimated_units': max(5, int(current_score * 0.5)),
                'confidence_low': round(max(0, current_score - 8), 1),
                'confidence_high': round(min(100, current_score + 8), 1),
            })
        
        return forecast

    def _identify_risks(
        self,
        demand_score: float,
        region_type: str,
        cbd_dist: float,
        rng: random.Random,
    ) -> List[str]:
        """리스크 요인 자동 식별"""
        risks = []
        
        if demand_score < 50:
            risks.append("수요 불확실성 높음 — 공실 위험 존재")
        
        if region_type in ('provincial', 'provincial_metro'):
            risks.append("지방 인구 감소 추세 — 장기 수요 모니터링 필요")
        
        if cbd_dist > 50:
            risks.append(f"CBD 거리 {cbd_dist:.0f}km — 교통 인프라 의존도 높음")
        
        if rng.random() < 0.3:
            risks.append("인근 신규 임대주택 공급 계획 — 경쟁 공급 리스크")
        
        if rng.random() < 0.2:
            risks.append("금리 상승 리스크 — 임대 수요 위축 가능성")
        
        if not risks:
            risks.append("주요 리스크 요인 없음 — 안정적 수요 예상")
        
        return risks


# 싱글톤 인스턴스
demand_predictor = DemandPredictorService()
