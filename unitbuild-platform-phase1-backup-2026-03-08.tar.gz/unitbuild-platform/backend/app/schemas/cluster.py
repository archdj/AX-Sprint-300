"""
클러스터 Pydantic 스키마
"""
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime


class SiteCandidateSchema(BaseModel):
    site_id: str
    name: str
    sitec_score: float
    estimated_roi: float = Field(..., description="예상 ROI(%)")
    completion_prob: float = Field(..., ge=0, le=1)
    investment_cost: float = Field(..., description="투자비용(억원)")
    module_count: int
    factory_capacity_usage: float = Field(..., description="공장 CAPA 사용률(%)")
    construction_months: int
    region: str


class OptimizationConstraintsSchema(BaseModel):
    max_total_investment: float = Field(..., description="최대 총 투자자본(억원)")
    max_factory_capacity: float = Field(100.0, description="공장 최대 CAPA(%)")
    min_cluster_modules: int = Field(200, description="클러스터 최소 모듈 수")
    max_concurrent_sites: int = Field(5, description="최대 동시 진행 현장")


class GanttItemSchema(BaseModel):
    site_id: str
    site_name: str
    factory_period: List[int]
    installation_period: List[int]
    modules: int


class OptimizationResultSchema(BaseModel):
    selected_sites: List[SiteCandidateSchema]
    total_portfolio_value: float
    total_investment: float
    total_modules: int
    expected_roi: float
    risk_penalty: float
    gantt_schedule: List[GanttItemSchema]
    sensitivity_analysis: Dict[str, Any]
    optimization_status: str = "optimal"


class ClusterCreate(BaseModel):
    name: str
    description: Optional[str] = None
    site_ids: List[int]
    max_total_investment: float
    max_factory_capacity: float = 100.0
    min_cluster_modules: int = 200


class ClusterResponse(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    site_ids: Optional[List[int]] = None
    total_modules: Optional[int] = None
    total_investment: Optional[float] = None
    expected_roi: Optional[float] = None
    portfolio_value: Optional[float] = None
    gantt_schedule: Optional[List[Dict]] = None
    status: str
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
