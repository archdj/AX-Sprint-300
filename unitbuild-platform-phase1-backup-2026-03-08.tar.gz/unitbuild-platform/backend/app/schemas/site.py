"""
사업지 Pydantic 스키마
"""
from pydantic import BaseModel, Field
from typing import Optional, Dict, List, Any
from datetime import datetime
from enum import Enum


class SiteGradeEnum(str, Enum):
    A = "A"
    B = "B"
    C = "C"
    FAIL = "탈락"


class SiteCreate(BaseModel):
    name: str = Field(..., description="사업지명")
    address: str = Field(..., description="주소")
    lat: float = Field(..., ge=-90, le=90, description="위도")
    lng: float = Field(..., ge=-180, le=180, description="경도")
    pnu: Optional[str] = None
    land_area_m2: Optional[float] = None
    planned_units: Optional[int] = None
    small_unit_ratio: Optional[float] = Field(None, ge=0, le=1)
    floor_count: Optional[int] = None
    
    # 교통
    cbd_distance_km: Optional[float] = None
    subway_distance_m: Optional[float] = None
    bus_stop_distance_m: Optional[float] = None
    
    # 인프라
    elementary_school_distance_m: Optional[float] = None
    hospital_distance_m: Optional[float] = None
    mart_distance_m: Optional[float] = None
    
    # 구조·안전
    seismic_grade: Optional[int] = Field(None, ge=1, le=2)
    slope_percent: Optional[float] = None
    
    # 에너지
    energy_efficiency_grade: Optional[int] = Field(None, ge=1, le=5)
    sunshine_hours: Optional[float] = None
    
    # 사업자
    is_modular: bool = True
    long_term_rental: bool = False
    lh_certified: bool = False
    notes: Optional[str] = None


class SiteUpdate(BaseModel):
    name: Optional[str] = None
    address: Optional[str] = None
    planned_units: Optional[int] = None
    small_unit_ratio: Optional[float] = None
    notes: Optional[str] = None


class SiteResponse(BaseModel):
    id: int
    name: str
    address: str
    lat: float
    lng: float
    pnu: Optional[str] = None
    land_area_m2: Optional[float] = None
    planned_units: Optional[int] = None
    small_unit_ratio: Optional[float] = None
    sitec_score: Optional[float] = None
    sitec_grade: Optional[SiteGradeEnum] = None
    sitec_approval_prob: Optional[float] = None
    hazard_compliant: Optional[bool] = None
    hazard_risk_level: Optional[str] = None
    demand_score: Optional[float] = None
    estimated_cost: Optional[float] = None
    expected_margin: Optional[float] = None
    status: str
    is_modular: bool
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class SiteDetailResponse(SiteResponse):
    sitec_breakdown: Optional[Dict[str, float]] = None
    sitec_suggestions: Optional[List[str]] = None
    hazard_report: Optional[Dict] = None
    cbd_distance_km: Optional[float] = None
    subway_distance_m: Optional[float] = None
    bus_stop_distance_m: Optional[float] = None
    elementary_school_distance_m: Optional[float] = None
    hospital_distance_m: Optional[float] = None
    mart_distance_m: Optional[float] = None
    seismic_grade: Optional[int] = None
    slope_percent: Optional[float] = None
    energy_efficiency_grade: Optional[int] = None
    sunshine_hours: Optional[float] = None
    long_term_rental: bool = False
    lh_certified: bool = False
    # 모듈·층수·사업성 추가 필드
    floor_count: Optional[int] = None
    recommended_units: Optional[int] = None
    lh_purchase_price: Optional[float] = None
    small_unit_ratio: Optional[float] = None
    notes: Optional[str] = None
