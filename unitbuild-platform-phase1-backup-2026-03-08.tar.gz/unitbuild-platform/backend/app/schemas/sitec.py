"""
SITE-C 평가 Pydantic 스키마
"""
from pydantic import BaseModel, Field
from typing import Dict, List, Optional


class SiteCCriteriaInput(BaseModel):
    """SITE-C 평가 입력 스키마"""
    # A. 교통 접근성
    cbd_distance_km: float = Field(..., ge=0, description="CBD까지 거리(km)")
    subway_distance_m: float = Field(..., ge=0, description="지하철역까지 거리(m)")
    bus_stop_distance_m: float = Field(..., ge=0, description="버스정류장까지 거리(m)")
    
    # B. 생활 인프라
    elementary_school_distance_m: float = Field(..., ge=0)
    hospital_distance_m: float = Field(..., ge=0)
    mart_distance_m: float = Field(..., ge=0)
    
    # C. 사업 규모
    planned_units: int = Field(..., ge=1, description="계획 세대수")
    small_unit_ratio: float = Field(..., ge=0, le=1, description="전용60㎡이하 비율")
    
    # D. 구조·안전
    seismic_grade: int = Field(..., ge=1, le=2, description="내진등급")
    slope_percent: float = Field(..., ge=0, description="경사도(%)")
    
    # E. 에너지·환경
    energy_efficiency_grade: int = Field(..., ge=1, le=5, description="에너지효율등급")
    sunshine_hours: float = Field(..., ge=0, description="일조시간(시간)")
    
    # F. 사업자 가점
    is_modular: bool = Field(True, description="모듈러 공법 여부")
    long_term_rental: bool = Field(False, description="장기임대 10년+")
    lh_certified: bool = Field(False, description="LH 우수시공사")


class SiteCResultSchema(BaseModel):
    """SITE-C 평가 결과 스키마"""
    total_score: float = Field(..., description="SITE-C 총점(0~100)")
    grade: str = Field(..., description="등급(A/B/C/탈락)")
    approval_probability: float = Field(..., description="LH 심의 통과 확률(0~1)")
    breakdown: Dict[str, float] = Field(..., description="항목별 점수")
    improvement_suggestions: List[str] = Field(..., description="개선 제안 목록")
    
    # 상세 항목 점수 (0~1)
    transportation_score: Optional[float] = None
    infrastructure_score: Optional[float] = None
    scale_score: Optional[float] = None
    structure_score: Optional[float] = None
    energy_score: Optional[float] = None
    bonus_score: Optional[float] = None


class SiteCSimulateInput(BaseModel):
    """시나리오 시뮬레이션 입력"""
    base_criteria: SiteCCriteriaInput
    changes: Dict[str, float] = Field(..., description="변경할 항목과 값")


class SiteCSimulateResult(BaseModel):
    """시뮬레이션 결과 (전/후 비교)"""
    before: SiteCResultSchema
    after: SiteCResultSchema
    score_delta: float
    grade_changed: bool
    changed_fields: Dict[str, dict]
