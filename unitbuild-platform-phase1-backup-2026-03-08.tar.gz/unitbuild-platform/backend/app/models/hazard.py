"""
위해시설 모델
"""
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime
from sqlalchemy.sql import func
from app.core.database import Base


class HazardFacility(Base):
    __tablename__ = "hazard_facilities"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    hazard_type = Column(String(50), nullable=False, comment="위해시설 유형")
    lat = Column(Float, nullable=False)
    lng = Column(Float, nullable=False)
    address = Column(String(500), nullable=True)
    min_distance_m = Column(Integer, nullable=False, comment="요구 이격거리(m)")
    data_source = Column(String(50), nullable=True, comment="데이터 출처")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
