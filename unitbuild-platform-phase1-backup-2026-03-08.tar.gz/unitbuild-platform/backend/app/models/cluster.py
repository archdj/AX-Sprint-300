"""
클러스터(Cluster) SQLAlchemy 모델
"""
from sqlalchemy import Column, Integer, String, Float, JSON, DateTime, Text
from sqlalchemy.sql import func
from app.core.database import Base


class Cluster(Base):
    __tablename__ = "clusters"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False, comment="클러스터명")
    description = Column(Text, nullable=True)
    
    # 포트폴리오 최적화 결과
    site_ids = Column(JSON, nullable=True, comment="선택된 사업지 ID 목록")
    total_modules = Column(Integer, nullable=True, comment="총 모듈 수")
    total_investment = Column(Float, nullable=True, comment="총 투자비(억원)")
    expected_roi = Column(Float, nullable=True, comment="예상 ROI(%)")
    portfolio_value = Column(Float, nullable=True, comment="포트폴리오 가치 점수")
    
    # ILP 최적화 파라미터
    max_total_investment = Column(Float, nullable=True)
    max_factory_capacity = Column(Float, nullable=True)
    min_cluster_modules = Column(Integer, default=200)
    
    # 간트 일정
    gantt_schedule = Column(JSON, nullable=True, comment="공장-현장 통합 일정")
    
    status = Column(String(20), default="draft")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
