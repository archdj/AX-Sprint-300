"""
사업지(Site) SQLAlchemy 모델
"""
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, JSON, Text, Enum
from sqlalchemy.sql import func
from app.core.database import Base
import enum


class SiteGrade(str, enum.Enum):
    A = "A"
    B = "B"
    C = "C"
    FAIL = "탈락"


class Site(Base):
    __tablename__ = "sites"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False, comment="사업지명")
    address = Column(String(500), nullable=False, comment="주소")
    lat = Column(Float, nullable=False, comment="위도")
    lng = Column(Float, nullable=False, comment="경도")
    pnu = Column(String(20), nullable=True, comment="필지 고유번호(PNU)")
    
    # 사업 기본 정보
    land_area_m2 = Column(Float, nullable=True, comment="대지면적(㎡)")
    planned_units = Column(Integer, nullable=True, comment="계획 세대수")
    small_unit_ratio = Column(Float, nullable=True, comment="전용60㎡이하 비율(0~1)")
    floor_count = Column(Integer, nullable=True, comment="층수")
    
    # SITE-C 평가 결과
    sitec_score = Column(Float, nullable=True, comment="SITE-C 점수(0~100)")
    sitec_grade = Column(Enum(SiteGrade), nullable=True, comment="SITE-C 등급")
    sitec_approval_prob = Column(Float, nullable=True, comment="LH 심의통과 확률(0~1)")
    sitec_breakdown = Column(JSON, nullable=True, comment="항목별 점수 상세")
    sitec_suggestions = Column(JSON, nullable=True, comment="개선 제안 목록")
    
    # 교통 접근성
    cbd_distance_km = Column(Float, nullable=True, comment="CBD 거리(km)")
    subway_distance_m = Column(Float, nullable=True, comment="지하철역 거리(m)")
    bus_stop_distance_m = Column(Float, nullable=True, comment="버스정류장 거리(m)")
    
    # 생활 인프라
    elementary_school_distance_m = Column(Float, nullable=True, comment="초등학교 거리(m)")
    hospital_distance_m = Column(Float, nullable=True, comment="병원 거리(m)")
    mart_distance_m = Column(Float, nullable=True, comment="마트/편의점 거리(m)")
    
    # 구조·안전
    seismic_grade = Column(Integer, nullable=True, comment="내진등급(1~2)")
    slope_percent = Column(Float, nullable=True, comment="경사도(%)")
    
    # 에너지·환경
    energy_efficiency_grade = Column(Integer, nullable=True, comment="에너지효율등급(1~5)")
    sunshine_hours = Column(Float, nullable=True, comment="일조시간(시간)")
    
    # 사업자 가점
    is_modular = Column(Boolean, default=True, comment="모듈러 공법 여부")
    long_term_rental = Column(Boolean, default=False, comment="장기임대 10년+")
    lh_certified = Column(Boolean, default=False, comment="LH 우수시공사")
    
    # 위해시설 검증
    hazard_compliant = Column(Boolean, nullable=True, comment="위해시설 기준 충족 여부")
    hazard_risk_level = Column(String(20), nullable=True, comment="위해시설 위험등급(SAFE/WARNING/DANGER)")
    hazard_report = Column(JSON, nullable=True, comment="위해시설 검증 리포트")
    
    # 수요예측
    demand_score = Column(Float, nullable=True, comment="수요 확신도(0~100)")
    recommended_units = Column(Integer, nullable=True, comment="AI 추천 세대수")
    
    # 원가/수익성
    estimated_cost = Column(Float, nullable=True, comment="예상 총원가(원)")
    lh_purchase_price = Column(Float, nullable=True, comment="LH 예상 매입가(원)")
    expected_margin = Column(Float, nullable=True, comment="예상 마진(%)")
    
    # 메타
    status = Column(String(20), default="draft", comment="상태(draft/evaluated/submitted)")
    notes = Column(Text, nullable=True, comment="메모")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
