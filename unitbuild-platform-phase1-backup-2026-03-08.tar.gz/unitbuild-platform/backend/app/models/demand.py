"""
수요예측 결과 모델
"""
from sqlalchemy import Column, Integer, String, Float, JSON, DateTime, ForeignKey
from sqlalchemy.sql import func
from app.core.database import Base


class DemandPrediction(Base):
    __tablename__ = "demand_predictions"

    id = Column(Integer, primary_key=True, index=True)
    site_id = Column(Integer, ForeignKey("sites.id"), nullable=True)
    
    lat = Column(Float, nullable=False)
    lng = Column(Float, nullable=False)
    sigungu_code = Column(String(10), nullable=True)
    emd_code = Column(String(10), nullable=True)
    
    # 예측 결과
    demand_score = Column(Float, nullable=True, comment="수요 확신도(0~100)")
    recommended_units = Column(Integer, nullable=True)
    confidence = Column(Float, nullable=True, comment="신뢰도(0~1)")
    
    # 계층적 점수
    sigungu_score = Column(Float, nullable=True)
    emd_score = Column(Float, nullable=True)
    parcel_score = Column(Float, nullable=True)
    
    # 시계열 예측 데이터
    forecast_data = Column(JSON, nullable=True, comment="12개월 수요 예측 데이터")
    risk_factors = Column(JSON, nullable=True, comment="리스크 요인 목록")
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
