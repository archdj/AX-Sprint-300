"""
클러스터 포트폴리오 최적화 API
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List
from app.core.database import get_db
from app.models.site import Site
from app.models.cluster import Cluster
from app.schemas.cluster import (
    ClusterCreate,
    ClusterResponse,
    OptimizationConstraintsSchema,
    OptimizationResultSchema,
    SiteCandidateSchema,
    GanttItemSchema,
)
from app.services.cluster_optimizer import (
    cluster_optimizer,
    SiteCandidate,
    OptimizationConstraints,
)

router = APIRouter(prefix="/api/v1/clusters", tags=["클러스터 최적화"])


@router.post("/optimize", response_model=OptimizationResultSchema, summary="포트폴리오 ILP 최적화")
async def optimize_portfolio(
    site_ids: List[int] = Query(..., description="선택한 사업지 ID 목록"),
    constraints: OptimizationConstraintsSchema = None,
    max_factory_capacity: float = Query(80.0),
    min_cluster_modules: int = Query(50),
    max_concurrent_sites: int = Query(5),
    max_total_investment: float = Query(500.0),
    db: AsyncSession = Depends(get_db),
):
    # constraints가 없으면 쿼리 파라미터로 생성
    if constraints is None:
        constraints = OptimizationConstraintsSchema(
            max_factory_capacity=max_factory_capacity,
            min_cluster_modules=min_cluster_modules,
            max_concurrent_sites=max_concurrent_sites,
            max_total_investment=max_total_investment,
        )
    """
    선택된 사업지 목록에서 ILP 최적화로 최적 포트폴리오 선택

    **제약조건 설정**:
    - max_total_investment: 최대 총 투자 자본 (억원)
    - max_factory_capacity: 공장 최대 CAPA (%)
    - min_cluster_modules: 클러스터 최소 모듈 수 (규모의 경제)
    - max_concurrent_sites: 최대 동시 진행 현장 수
    """
    if not site_ids:
        raise HTTPException(status_code=400, detail="사업지 ID가 필요합니다.")

    # DB에서 사업지 로드
    result = await db.execute(select(Site).where(Site.id.in_(site_ids)))
    sites = result.scalars().all()

    if not sites:
        raise HTTPException(status_code=404, detail="선택된 사업지를 찾을 수 없습니다.")

    # SITE-C 점수가 없는 사업지 필터링
    evaluated_sites = [s for s in sites if s.sitec_score is not None]
    if not evaluated_sites:
        raise HTTPException(
            status_code=422,
            detail="SITE-C 평가가 완료된 사업지가 없습니다. 먼저 평가를 실행하세요."
        )

    # SiteCandidate 변환
    candidates = []
    for site in evaluated_sites:
        estimated_roi = 8.0 + (site.sitec_score or 50) * 0.1  # SITE-C 기반 ROI 추정
        completion_prob = site.sitec_approval_prob or 0.5
        investment = (site.land_area_m2 or 500) * (site.planned_units or 30) * 0.001  # 가정
        modules = site.planned_units or 30

        candidates.append(SiteCandidate(
            site_id=str(site.id),
            name=site.name,
            sitec_score=site.sitec_score or 50,
            estimated_roi=estimated_roi,
            completion_prob=completion_prob,
            investment_cost=max(5.0, investment),
            module_count=modules,
            factory_capacity_usage=modules * 0.5,
            construction_months=max(4, modules // 10),
            region=site.address.split()[0] if site.address else '기타',
        ))

    opt_constraints = OptimizationConstraints(
        max_total_investment=constraints.max_total_investment,
        max_factory_capacity=constraints.max_factory_capacity,
        min_cluster_modules=constraints.min_cluster_modules,
        max_concurrent_sites=constraints.max_concurrent_sites,
    )

    opt_result = cluster_optimizer.optimize(candidates, opt_constraints)

    # 결과 직렬화
    selected_schemas = [
        SiteCandidateSchema(
            site_id=s.site_id,
            name=s.name,
            sitec_score=s.sitec_score,
            estimated_roi=s.estimated_roi,
            completion_prob=s.completion_prob,
            investment_cost=s.investment_cost,
            module_count=s.module_count,
            factory_capacity_usage=s.factory_capacity_usage,
            construction_months=s.construction_months,
            region=s.region,
        )
        for s in opt_result.selected_sites
    ]

    gantt_schemas = [
        GanttItemSchema(
            site_id=g['site_id'],
            site_name=g['site_name'],
            factory_period=g['factory_period'],
            installation_period=g['installation_period'],
            modules=g['modules'],
        )
        for g in opt_result.gantt_schedule
    ]

    return OptimizationResultSchema(
        selected_sites=selected_schemas,
        total_portfolio_value=opt_result.total_portfolio_value,
        total_investment=opt_result.total_investment,
        total_modules=opt_result.total_modules,
        expected_roi=opt_result.expected_roi,
        risk_penalty=opt_result.risk_penalty,
        gantt_schedule=gantt_schemas,
        sensitivity_analysis=opt_result.sensitivity_analysis,
        optimization_status=opt_result.optimization_status,
    )


@router.post("/", response_model=ClusterResponse, summary="클러스터 저장")
async def create_cluster(
    cluster_in: ClusterCreate,
    db: AsyncSession = Depends(get_db)
):
    """포트폴리오 최적화 결과를 클러스터로 저장"""
    cluster = Cluster(
        name=cluster_in.name,
        description=cluster_in.description,
        site_ids=cluster_in.site_ids,
        max_total_investment=cluster_in.max_total_investment,
        max_factory_capacity=cluster_in.max_factory_capacity,
        min_cluster_modules=cluster_in.min_cluster_modules,
    )
    db.add(cluster)
    await db.commit()
    await db.refresh(cluster)
    return cluster


@router.get("/", response_model=List[ClusterResponse], summary="클러스터 목록")
async def list_clusters(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Cluster))
    return result.scalars().all()


@router.get("/{cluster_id}/gantt", summary="간트 일정 조회")
async def get_gantt(cluster_id: int, db: AsyncSession = Depends(get_db)):
    """공장-현장 통합 간트 일정 반환"""
    result = await db.execute(select(Cluster).where(Cluster.id == cluster_id))
    cluster = result.scalar_one_or_none()
    if not cluster:
        raise HTTPException(status_code=404, detail="클러스터를 찾을 수 없습니다.")
    
    return {
        "cluster_id": cluster.id,
        "cluster_name": cluster.name,
        "gantt_schedule": cluster.gantt_schedule or [],
    }
