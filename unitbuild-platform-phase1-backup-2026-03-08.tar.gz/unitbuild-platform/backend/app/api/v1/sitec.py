"""
SITE-C 평가 API
"""
from fastapi import APIRouter, HTTPException
from typing import List, Dict
from app.schemas.sitec import (
    SiteCCriteriaInput,
    SiteCResultSchema,
    SiteCSimulateInput,
    SiteCSimulateResult,
)
from app.services.sitec_engine import sitec_engine, SiteCCriteria

router = APIRouter(prefix="/api/v1/sitec", tags=["SITE-C 평가"])


def _input_to_criteria(inp: SiteCCriteriaInput) -> SiteCCriteria:
    return SiteCCriteria(
        cbd_distance_km=inp.cbd_distance_km,
        subway_distance_m=inp.subway_distance_m,
        bus_stop_distance_m=inp.bus_stop_distance_m,
        elementary_school_distance_m=inp.elementary_school_distance_m,
        hospital_distance_m=inp.hospital_distance_m,
        mart_distance_m=inp.mart_distance_m,
        planned_units=inp.planned_units,
        small_unit_ratio=inp.small_unit_ratio,
        seismic_grade=inp.seismic_grade,
        slope_percent=inp.slope_percent,
        energy_efficiency_grade=inp.energy_efficiency_grade,
        sunshine_hours=inp.sunshine_hours,
        is_modular=inp.is_modular,
        long_term_rental=inp.long_term_rental,
        lh_certified=inp.lh_certified,
    )


def _result_to_schema(r) -> SiteCResultSchema:
    return SiteCResultSchema(
        total_score=r.total_score,
        grade=r.grade,
        approval_probability=r.approval_probability,
        breakdown=r.breakdown,
        improvement_suggestions=r.improvement_suggestions,
        transportation_score=r.transportation_score,
        infrastructure_score=r.infrastructure_score,
        scale_score=r.scale_score,
        structure_score=r.structure_score,
        energy_score=r.energy_score,
        bonus_score=r.bonus_score,
    )


@router.post("/evaluate", response_model=SiteCResultSchema, summary="단일 사업지 SITE-C 평가")
async def evaluate_site(criteria: SiteCCriteriaInput):
    """
    SITE-C 평가 기준 입력 → 점수·등급·개선제안 반환

    - **A등급 (≥80점)**: LH 심의 통과 확률 90%+
    - **B등급 (65~79점)**: 75%
    - **C등급 (50~64점)**: 50%
    - **탈락 (<50점)**: 10%
    """
    result = sitec_engine.calculate(_input_to_criteria(criteria))
    return _result_to_schema(result)


@router.post(
    "/batch-evaluate",
    response_model=List[SiteCResultSchema],
    summary="복수 사업지 배치 평가"
)
async def batch_evaluate(criteria_list: List[SiteCCriteriaInput]):
    """최대 50개 사업지 병렬 평가"""
    if len(criteria_list) > 50:
        raise HTTPException(status_code=400, detail="최대 50개까지 배치 평가 가능합니다.")
    
    criteria_objs = [_input_to_criteria(c) for c in criteria_list]
    results = await sitec_engine.batch_evaluate_criteria(criteria_objs)
    return [_result_to_schema(r) for r in results]


@router.post("/simulate", response_model=SiteCSimulateResult, summary="시나리오 시뮬레이션")
async def simulate_improvement(payload: SiteCSimulateInput):
    """
    변경 시나리오 적용 전/후 점수 비교

    예시: planned_units를 20→35로 늘렸을 때 점수 변화 확인
    """
    base_criteria = _input_to_criteria(payload.base_criteria)
    before, after = sitec_engine.simulate(base_criteria, payload.changes)

    changed_fields = {}
    for field, new_val in payload.changes.items():
        if hasattr(base_criteria, field):
            changed_fields[field] = {
                'before': getattr(base_criteria, field),
                'after': new_val,
            }

    return SiteCSimulateResult(
        before=_result_to_schema(before),
        after=_result_to_schema(after),
        score_delta=round(after.total_score - before.total_score, 2),
        grade_changed=(before.grade != after.grade),
        changed_fields=changed_fields,
    )


@router.get("/weights", summary="SITE-C 가중치 체계 조회")
async def get_weights():
    """SITE-C 평가 항목별 가중치 및 기준 반환"""
    return {
        "weights": sitec_engine.WEIGHTS,
        "grade_thresholds": {
            "A": {"min_score": 80, "approval_prob": 0.90, "label": "우수 — 심의 통과 확률 90%+"},
            "B": {"min_score": 65, "approval_prob": 0.75, "label": "양호 — 소규모 보완 권장"},
            "C": {"min_score": 50, "approval_prob": 0.50, "label": "검토 — 전략적 개선 필요"},
            "탈락": {"min_score": 0, "approval_prob": 0.10, "label": "재검토 — 사업지 재선정 권장"},
        },
        "criteria": {
            "A_transportation": {
                "weight": 0.25,
                "items": {
                    "A1_cbd": "CBD 접근성: ≤30km(1.0), 30~50km(0.7), >50km(0.3)",
                    "A2_subway": "지하철 역세권: ≤500m(1.0), ≤1km(0.7), ≤2km(0.4), >2km(0.0)",
                    "A3_bus": "버스정류장: ≤300m(1.0), ≤500m(0.7), >500m(0.3)",
                }
            },
            "B_infrastructure": {
                "weight": 0.20,
                "items": {
                    "B1_school": "초등학교: ≤500m(1.0), ≤1km(0.7), >1km(0.3)",
                    "B2_hospital": "병원: ≤500m(1.0), >500m(0.5)",
                    "B3_mart": "마트·편의점: ≤300m(1.0), >300m(0.5)",
                }
            },
            "C_scale": {
                "weight": 0.20,
                "items": {
                    "C1_units": "세대수: ≥30(1.0), ≥20(0.8), <20(0.5)",
                    "C2_small_ratio": "전용60㎡이하비율: ≥50%(1.0), ≥40%(0.8), <40%(0.5)",
                }
            },
            "D_structure": {
                "weight": 0.15,
                "items": {
                    "D1_seismic": "내진등급: 1등급(1.0), 2등급(0.8)",
                    "D2_slope": "경사도: ≤5%(1.0), ≤10%(0.7), >10%(0.3)",
                }
            },
            "E_energy": {
                "weight": 0.10,
                "items": {
                    "E1_efficiency": "에너지효율: 1등급(1.0), 2등급(0.8), 기타(0.5)",
                    "E2_sunshine": "일조시간: ≥4h(1.0), <4h(0.5)",
                }
            },
            "F_bonus": {
                "weight": 0.10,
                "items": {
                    "F1_modular": "모듈러 공법: 적용(1.0) ← 유닛랩 해당",
                    "F2_longterm": "장기임대10년+: 해당(0.8)",
                    "F3_certified": "LH 우수시공사: 해당(0.7)",
                }
            },
        }
    }
