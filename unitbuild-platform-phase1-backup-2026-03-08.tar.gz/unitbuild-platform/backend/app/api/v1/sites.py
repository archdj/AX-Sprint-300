"""
사업지 CRUD API
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from typing import List, Optional
from app.core.database import get_db
from app.models.site import Site
from app.schemas.site import SiteCreate, SiteUpdate, SiteResponse, SiteDetailResponse
from app.schemas.sitec import SiteCCriteriaInput
from app.services.sitec_engine import sitec_engine, SiteCCriteria

router = APIRouter(prefix="/api/v1/sites", tags=["사업지 관리"])


@router.get("/", response_model=List[SiteResponse])
async def list_sites(
    skip: int = 0,
    limit: int = 50,
    status_filter: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """사업지 목록 조회"""
    query = select(Site).offset(skip).limit(limit)
    if status_filter:
        query = query.where(Site.status == status_filter)
    result = await db.execute(query)
    return result.scalars().all()


@router.post("/", response_model=SiteDetailResponse, status_code=status.HTTP_201_CREATED)
async def create_site(
    site_in: SiteCreate,
    db: AsyncSession = Depends(get_db)
):
    """새 사업지 등록"""
    site = Site(**site_in.model_dump())
    db.add(site)
    await db.commit()
    await db.refresh(site)
    return site


@router.get("/{site_id}", response_model=SiteDetailResponse)
async def get_site(site_id: int, db: AsyncSession = Depends(get_db)):
    """사업지 상세 조회"""
    result = await db.execute(select(Site).where(Site.id == site_id))
    site = result.scalar_one_or_none()
    if not site:
        raise HTTPException(status_code=404, detail="사업지를 찾을 수 없습니다.")
    return site


@router.put("/{site_id}", response_model=SiteDetailResponse)
async def update_site(
    site_id: int,
    site_in: SiteUpdate,
    db: AsyncSession = Depends(get_db)
):
    """사업지 정보 수정"""
    result = await db.execute(select(Site).where(Site.id == site_id))
    site = result.scalar_one_or_none()
    if not site:
        raise HTTPException(status_code=404, detail="사업지를 찾을 수 없습니다.")
    
    update_data = site_in.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(site, field, value)
    
    await db.commit()
    await db.refresh(site)
    return site


@router.delete("/{site_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_site(site_id: int, db: AsyncSession = Depends(get_db)):
    """사업지 삭제"""
    result = await db.execute(select(Site).where(Site.id == site_id))
    site = result.scalar_one_or_none()
    if not site:
        raise HTTPException(status_code=404, detail="사업지를 찾을 수 없습니다.")
    await db.delete(site)
    await db.commit()


@router.post("/{site_id}/evaluate", response_model=SiteDetailResponse)
async def evaluate_and_save(site_id: int, db: AsyncSession = Depends(get_db)):
    """
    저장된 사업지 데이터로 SITE-C 평가 실행 후 결과 저장
    사업지에 교통/인프라 데이터가 입력되어 있어야 함
    """
    result = await db.execute(select(Site).where(Site.id == site_id))
    site = result.scalar_one_or_none()
    if not site:
        raise HTTPException(status_code=404, detail="사업지를 찾을 수 없습니다.")

    # 필수 데이터 체크
    required_fields = [
        'cbd_distance_km', 'subway_distance_m', 'bus_stop_distance_m',
        'elementary_school_distance_m', 'hospital_distance_m', 'mart_distance_m',
        'planned_units', 'small_unit_ratio', 'seismic_grade', 'slope_percent',
        'energy_efficiency_grade', 'sunshine_hours'
    ]
    missing = [f for f in required_fields if getattr(site, f) is None]
    if missing:
        raise HTTPException(
            status_code=422,
            detail=f"평가에 필요한 데이터 누락: {', '.join(missing)}"
        )

    criteria = SiteCCriteria(
        cbd_distance_km=site.cbd_distance_km,
        subway_distance_m=site.subway_distance_m,
        bus_stop_distance_m=site.bus_stop_distance_m,
        elementary_school_distance_m=site.elementary_school_distance_m,
        hospital_distance_m=site.hospital_distance_m,
        mart_distance_m=site.mart_distance_m,
        planned_units=site.planned_units,
        small_unit_ratio=site.small_unit_ratio,
        seismic_grade=site.seismic_grade,
        slope_percent=site.slope_percent,
        energy_efficiency_grade=site.energy_efficiency_grade,
        sunshine_hours=site.sunshine_hours,
        is_modular=site.is_modular,
        long_term_rental=site.long_term_rental,
        lh_certified=site.lh_certified,
    )

    evaluation = sitec_engine.calculate(criteria)

    site.sitec_score = evaluation.total_score
    site.sitec_grade = evaluation.grade
    site.sitec_approval_prob = evaluation.approval_probability
    site.sitec_breakdown = evaluation.breakdown
    site.sitec_suggestions = evaluation.improvement_suggestions
    site.status = "evaluated"

    await db.commit()
    await db.refresh(site)
    return site

from datetime import datetime


@router.get("/{site_id}/ai-summary", summary="AI 사업지 요약 생성")
async def get_ai_summary(
    site_id: int,
    db: AsyncSession = Depends(get_db),
):
    """사업지 데이터를 기반으로 AI 요약 생성"""
    result = await db.execute(select(Site).where(Site.id == site_id))
    site = result.scalar_one_or_none()
    if not site:
        raise HTTPException(status_code=404, detail="사업지를 찾을 수 없습니다.")

    summary = _build_ai_summary(site)
    return {"site_id": site_id, "summary": summary, "generated_at": datetime.utcnow().isoformat()}


def _build_ai_summary(site) -> dict:
    grade = site.sitec_grade.value if site.sitec_grade else "미평가"
    score = site.sitec_score or 0
    approval_prob = int((site.sitec_approval_prob or 0) * 100)

    if grade == "A" and score >= 85:
        verdict, verdict_desc, verdict_color = "최우수 사업지", "LH 신축매입약정 심의 통과 확률이 매우 높은 탁월한 사업지입니다.", "emerald"
    elif grade == "A":
        verdict, verdict_desc, verdict_color = "우수 사업지", "LH 신축매입약정 심의 기준을 충족하는 우수한 사업 조건을 갖추고 있습니다.", "green"
    elif grade == "B":
        verdict, verdict_desc, verdict_color = "양호 사업지", "전반적으로 양호한 사업 조건이나 일부 항목 보완이 필요합니다.", "blue"
    elif grade == "C":
        verdict, verdict_desc, verdict_color = "검토 필요 사업지", "사업 진행을 위해 주요 항목 보완 및 추가 검토가 필요합니다.", "yellow"
    else:
        verdict, verdict_desc, verdict_color = "미평가 사업지", "SITE-C 자동 평가를 실행하면 상세 분석 결과를 확인할 수 있습니다.", "gray"

    location_points, location_risks = [], []
    subway_m = site.subway_distance_m or 9999
    if subway_m <= 250:
        location_points.append("지하철역 {}m — 역세권 프리미엄 입지".format(int(subway_m)))
    elif subway_m <= 500:
        location_points.append("지하철역 {}m — 도보권 대중교통".format(int(subway_m)))
    else:
        location_risks.append("지하철역 {}m — 대중교통 접근성 보완 필요".format(int(subway_m)))

    school_m = site.elementary_school_distance_m or 9999
    if school_m <= 300:
        location_points.append("초등학교 {}m — 학군 우수".format(int(school_m)))
    elif school_m > 800:
        location_risks.append("초등학교 {}m — 학군 접근성 불리".format(int(school_m)))

    hospital_m = site.hospital_distance_m or 9999
    if hospital_m <= 200:
        location_points.append("의료시설 {}m — 우수한 의료 접근성".format(int(hospital_m)))

    cbd_km = site.cbd_distance_km or 0
    if cbd_km > 0 and cbd_km <= 5:
        location_points.append("도심까지 {:.0f}km — 도심 근접 입지".format(cbd_km))
    elif cbd_km >= 15:
        location_risks.append("도심 {:.0f}km — 원거리 위치".format(cbd_km))

    floor_count = site.floor_count or 0
    planned_units = site.planned_units or 0
    land_area = site.land_area_m2 or 0
    module_analysis = ""
    if floor_count > 0 and planned_units > 0:
        upf = planned_units / floor_count
        module_analysis = "{}층 {}세대 구성 (층당 약 {:.1f}세대). ".format(floor_count, planned_units, upf)
        if planned_units >= 30:
            module_analysis += "규모의 경제 달성 가능한 적정 세대수입니다. "
        elif planned_units >= 15:
            module_analysis += "기본 사업 규모를 충족합니다. 세대수 확대 시 수익성 향상 가능. "
        else:
            module_analysis += "세대수 확대를 통한 규모 최적화 검토가 필요합니다. "
    elif planned_units > 0:
        module_analysis = "계획 세대수 {}세대. ".format(planned_units)
    if land_area > 0:
        module_analysis += "대지면적 {:.0f}㎡ 기준 모듈러 공법 적용 예정.".format(land_area)

    cost_bn = (site.estimated_cost or 0) / 1e8
    lh_price_bn = (site.lh_purchase_price or 0) / 1e8
    margin = site.expected_margin or 0
    demand = site.demand_score or 0
    financial_analysis = ""
    if cost_bn > 0:
        financial_analysis += "총 공사비 {:.1f}억원".format(cost_bn)
        if lh_price_bn > 0:
            profit = lh_price_bn - cost_bn
            financial_analysis += ", LH 매입예정가 {:.1f}억원 (예상 수익 {:.1f}억원). ".format(lh_price_bn, profit)
        else:
            financial_analysis += ". "
    if margin > 0:
        if margin >= 25:
            financial_analysis += "마진율 {:.0f}% — 높은 수익성 확보. ".format(margin)
        elif margin >= 15:
            financial_analysis += "마진율 {:.0f}% — 적정 수익성. ".format(margin)
        else:
            financial_analysis += "마진율 {:.0f}% — 수익성 개선 검토 필요. ".format(margin)
    if demand > 0:
        if demand >= 75:
            financial_analysis += "수요 점수 {:.0f}점 — 해당 지역 임대 수요 우수.".format(demand)
        elif demand >= 50:
            financial_analysis += "수요 점수 {:.0f}점 — 중간 수준의 임대 수요.".format(demand)
        else:
            financial_analysis += "수요 점수 {:.0f}점 — 수요 보완 전략 필요.".format(demand)

    safety_notes = []
    seismic = site.seismic_grade or 0
    slope = site.slope_percent or 0
    energy = site.energy_efficiency_grade or 0
    if seismic == 1:
        safety_notes.append("내진 1등급 — 구조 안전성 최우수")
    if 0 < slope <= 5:
        safety_notes.append("경사도 {:.0f}% — 평탄 지형으로 시공 용이".format(slope))
    elif slope > 15:
        safety_notes.append("경사도 {:.0f}% — 지형 조건 검토 필요".format(slope))
    if 0 < energy <= 2:
        safety_notes.append("에너지효율 {}등급 — 친환경 기준 충족".format(energy))

    actions = []
    breakdown = site.sitec_breakdown or {}
    f_score = breakdown.get("F_사업자가점", 0)
    if not site.long_term_rental and f_score < 8:
        actions.append("장기임대 10년 이상 계획 설정으로 F항목 가점 확보")
    if not site.lh_certified:
        actions.append("LH 우수시공사 인증 취득으로 추가 가점 획득 가능")
    c_score = breakdown.get("C_사업규모", 0)
    if c_score < 20 and planned_units < 30:
        actions.append("세대수를 30세대 이상으로 확대하여 C항목 점수 향상")
    if grade in ("A", "B") and approval_prob >= 75:
        actions.append("현 조건으로 LH 신축매입약정 신청 진행 권장")
    if not actions:
        actions.append("현재 최적화된 사업 조건 유지")

    return {
        "verdict": verdict, "verdict_desc": verdict_desc, "verdict_color": verdict_color,
        "grade": grade, "score": score, "approval_prob": approval_prob,
        "location_points": location_points[:4], "location_risks": location_risks[:3],
        "module_analysis": module_analysis, "financial_analysis": financial_analysis,
        "safety_notes": safety_notes[:4], "recommended_actions": actions[:4],
    }

from datetime import datetime


@router.get("/{site_id}/ai-summary", summary="AI 사업지 요약 생성")
async def get_ai_summary(
    site_id: int,
    db: AsyncSession = Depends(get_db),
):
    """사업지 데이터를 기반으로 AI 요약 생성"""
    result = await db.execute(select(Site).where(Site.id == site_id))
    site = result.scalar_one_or_none()
    if not site:
        raise HTTPException(status_code=404, detail="사업지를 찾을 수 없습니다.")

    summary = _build_ai_summary(site)
    return {"site_id": site_id, "summary": summary, "generated_at": datetime.utcnow().isoformat()}


def _build_ai_summary(site) -> dict:
    grade = site.sitec_grade.value if site.sitec_grade else "미평가"
    score = site.sitec_score or 0
    approval_prob = int((site.sitec_approval_prob or 0) * 100)

    if grade == "A" and score >= 85:
        verdict, verdict_desc, verdict_color = "최우수 사업지", "LH 신축매입약정 심의 통과 확률이 매우 높은 탁월한 사업지입니다.", "emerald"
    elif grade == "A":
        verdict, verdict_desc, verdict_color = "우수 사업지", "LH 신축매입약정 심의 기준을 충족하는 우수한 사업 조건을 갖추고 있습니다.", "green"
    elif grade == "B":
        verdict, verdict_desc, verdict_color = "양호 사업지", "전반적으로 양호한 사업 조건이나 일부 항목 보완이 필요합니다.", "blue"
    elif grade == "C":
        verdict, verdict_desc, verdict_color = "검토 필요 사업지", "사업 진행을 위해 주요 항목 보완 및 추가 검토가 필요합니다.", "yellow"
    else:
        verdict, verdict_desc, verdict_color = "미평가 사업지", "SITE-C 자동 평가를 실행하면 상세 분석 결과를 확인할 수 있습니다.", "gray"

    location_points, location_risks = [], []
    subway_m = site.subway_distance_m or 9999
    if subway_m <= 250:
        location_points.append("지하철역 {}m — 역세권 프리미엄 입지".format(int(subway_m)))
    elif subway_m <= 500:
        location_points.append("지하철역 {}m — 도보권 대중교통".format(int(subway_m)))
    else:
        location_risks.append("지하철역 {}m — 대중교통 접근성 보완 필요".format(int(subway_m)))

    school_m = site.elementary_school_distance_m or 9999
    if school_m <= 300:
        location_points.append("초등학교 {}m — 학군 우수".format(int(school_m)))
    elif school_m > 800:
        location_risks.append("초등학교 {}m — 학군 접근성 불리".format(int(school_m)))

    hospital_m = site.hospital_distance_m or 9999
    if hospital_m <= 200:
        location_points.append("의료시설 {}m — 우수한 의료 접근성".format(int(hospital_m)))

    cbd_km = site.cbd_distance_km or 0
    if cbd_km > 0 and cbd_km <= 5:
        location_points.append("도심까지 {:.0f}km — 도심 근접 입지".format(cbd_km))
    elif cbd_km >= 15:
        location_risks.append("도심 {:.0f}km — 원거리 위치".format(cbd_km))

    floor_count = site.floor_count or 0
    planned_units = site.planned_units or 0
    land_area = site.land_area_m2 or 0
    module_analysis = ""
    if floor_count > 0 and planned_units > 0:
        upf = planned_units / floor_count
        module_analysis = "{}층 {}세대 구성 (층당 약 {:.1f}세대). ".format(floor_count, planned_units, upf)
        if planned_units >= 30:
            module_analysis += "규모의 경제 달성 가능한 적정 세대수입니다. "
        elif planned_units >= 15:
            module_analysis += "기본 사업 규모를 충족합니다. 세대수 확대 시 수익성 향상 가능. "
        else:
            module_analysis += "세대수 확대를 통한 규모 최적화 검토가 필요합니다. "
    elif planned_units > 0:
        module_analysis = "계획 세대수 {}세대. ".format(planned_units)
    if land_area > 0:
        module_analysis += "대지면적 {:.0f}㎡ 기준 모듈러 공법 적용 예정.".format(land_area)

    cost_bn = (site.estimated_cost or 0) / 1e8
    lh_price_bn = (site.lh_purchase_price or 0) / 1e8
    margin = site.expected_margin or 0
    demand = site.demand_score or 0
    financial_analysis = ""
    if cost_bn > 0:
        financial_analysis += "총 공사비 {:.1f}억원".format(cost_bn)
        if lh_price_bn > 0:
            profit = lh_price_bn - cost_bn
            financial_analysis += ", LH 매입예정가 {:.1f}억원 (예상 수익 {:.1f}억원). ".format(lh_price_bn, profit)
        else:
            financial_analysis += ". "
    if margin > 0:
        if margin >= 25:
            financial_analysis += "마진율 {:.0f}% — 높은 수익성 확보. ".format(margin)
        elif margin >= 15:
            financial_analysis += "마진율 {:.0f}% — 적정 수익성. ".format(margin)
        else:
            financial_analysis += "마진율 {:.0f}% — 수익성 개선 검토 필요. ".format(margin)
    if demand > 0:
        if demand >= 75:
            financial_analysis += "수요 점수 {:.0f}점 — 해당 지역 임대 수요 우수.".format(demand)
        elif demand >= 50:
            financial_analysis += "수요 점수 {:.0f}점 — 중간 수준의 임대 수요.".format(demand)
        else:
            financial_analysis += "수요 점수 {:.0f}점 — 수요 보완 전략 필요.".format(demand)

    safety_notes = []
    seismic = site.seismic_grade or 0
    slope = site.slope_percent or 0
    energy = site.energy_efficiency_grade or 0
    if seismic == 1:
        safety_notes.append("내진 1등급 — 구조 안전성 최우수")
    if 0 < slope <= 5:
        safety_notes.append("경사도 {:.0f}% — 평탄 지형으로 시공 용이".format(slope))
    elif slope > 15:
        safety_notes.append("경사도 {:.0f}% — 지형 조건 검토 필요".format(slope))
    if 0 < energy <= 2:
        safety_notes.append("에너지효율 {}등급 — 친환경 기준 충족".format(energy))

    actions = []
    breakdown = site.sitec_breakdown or {}
    f_score = breakdown.get("F_사업자가점", 0)
    if not site.long_term_rental and f_score < 8:
        actions.append("장기임대 10년 이상 계획 설정으로 F항목 가점 확보")
    if not site.lh_certified:
        actions.append("LH 우수시공사 인증 취득으로 추가 가점 획득 가능")
    c_score = breakdown.get("C_사업규모", 0)
    if c_score < 20 and planned_units < 30:
        actions.append("세대수를 30세대 이상으로 확대하여 C항목 점수 향상")
    if grade in ("A", "B") and approval_prob >= 75:
        actions.append("현 조건으로 LH 신축매입약정 신청 진행 권장")
    if not actions:
        actions.append("현재 최적화된 사업 조건 유지")

    return {
        "verdict": verdict, "verdict_desc": verdict_desc, "verdict_color": verdict_color,
        "grade": grade, "score": score, "approval_prob": approval_prob,
        "location_points": location_points[:4], "location_risks": location_risks[:3],
        "module_analysis": module_analysis, "financial_analysis": financial_analysis,
        "safety_notes": safety_notes[:4], "recommended_actions": actions[:4],
    }
