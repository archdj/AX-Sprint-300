"""
위해시설 검증 API
"""
from fastapi import APIRouter, HTTPException, Query
from typing import List, Dict, Optional
from app.services.hazard_verifier import hazard_verifier

router = APIRouter(prefix="/api/v1/hazard", tags=["위해시설 검증"])


@router.post("/verify", summary="좌표 기반 위해시설 검증")
async def verify_hazard(
    lat: float = Query(..., ge=-90, le=90, description="위도"),
    lng: float = Query(..., ge=-180, le=180, description="경도"),
    radius_m: int = Query(500, ge=100, le=2000, description="검색 반경(m)"),
):
    """
    좌표 입력 → LH 기준 위해시설 이격거리 자동 검증

    **검증 항목 (LH 신축매입약정 기준)**:
    - 주유소·LPG충전소: 25m 이상
    - 고압선 철탑: 30m 이상
    - 공장·창고: 50m 이상
    - 유해업소: 200m 이상
    - 소각장·납골당: 300m 이상

    **위험 등급**:
    - SAFE: 전 항목 충족
    - WARNING: 1개 항목 미충족
    - DANGER: 2개 이상 미충족
    """
    report = await hazard_verifier.verify(lat, lng, radius_m)
    
    return {
        "site_lat": report.site_lat,
        "site_lng": report.site_lng,
        "overall_compliant": report.overall_compliant,
        "risk_level": report.risk_level,
        "compliant_count": report.compliant_count,
        "non_compliant_count": report.non_compliant_count,
        "verification_timestamp": report.verification_timestamp,
        "data_source": report.data_source,
        "results": [
            {
                "hazard_type": r.hazard_type,
                "hazard_label": r.hazard_label,
                "is_compliant": r.is_compliant,
                "nearest_distance_m": r.nearest_distance_m if r.nearest_distance_m != float('inf') else None,
                "required_distance_m": r.required_distance_m,
                "nearest_facility_name": r.nearest_facility_name,
                "improvement": r.improvement,
            }
            for r in report.results
        ],
    }


@router.get("/rules", summary="위해시설 기준 규정 조회")
async def get_hazard_rules():
    """LH 신축매입약정 기준 위해시설 이격거리 규정 반환"""
    return {
        "source": "LH 신축매입약정 심의기준",
        "rules": hazard_verifier.get_hazard_rules_summary(),
    }


@router.get("/distance-check", summary="두 좌표간 거리 계산")
async def calculate_distance(
    lat1: float = Query(...),
    lng1: float = Query(...),
    lat2: float = Query(...),
    lng2: float = Query(...),
):
    """두 좌표 간 Haversine 직선거리 계산"""
    dist_m = hazard_verifier.haversine_distance(lat1, lng1, lat2, lng2)
    return {
        "distance_m": round(dist_m, 1),
        "distance_km": round(dist_m / 1000, 3),
    }
