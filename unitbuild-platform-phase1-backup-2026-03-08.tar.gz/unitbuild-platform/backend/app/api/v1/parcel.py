"""
필지 분석 API — /api/v1/parcel
지번 입력 → 자동 필지 분석 + 모듈 최적 배치 + 법규 검토 통합

VWorld 실데이터 통합 (서울 AWS EC2 43.201.6.67에서 직접 호출):
  - Search API    → 좌표 (위경도) + PNU
  - NED ladfrlList            → 실제 면적, 지목
  - NED getLandCharacteristics → 용도지역, 도로접면, 지형
  - NED getIndvdLandPriceAttr → 개별공시지가
"""

import os
import logging
import datetime
from fastapi import APIRouter, Query, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
import httpx

from app.services.parcel_analyzer import parcel_analyzer
from app.services.regulation_checker import regulation_checker

logger = logging.getLogger(__name__)

VWORLD_API_KEY  = os.getenv("VWORLD_API_KEY", "")
VWORLD_NED_KEY  = os.getenv("VWORLD_NED_API_KEY", "")   # NED 전용 키
VWORLD_DOMAIN   = os.getenv("VWORLD_DOMAIN", "")         # 등록 URL

router = APIRouter(prefix="/api/v1/parcel", tags=["필지 자동 분석"])


# ─────────────────────────────────────────────────────────
# 요청 스키마
# ─────────────────────────────────────────────────────────

class ParcelAnalysisRequest(BaseModel):
    parcel_number: str
    lat: Optional[float] = None
    lng: Optional[float] = None
    area_m2: Optional[float] = None
    zone_type: Optional[str] = None
    target_units: Optional[int] = None


class RegulationCheckRequest(BaseModel):
    zone_type: str = "제2종일반주거지역"
    parcel_area_m2: float = 400.0
    parcel_width_m: float = 20.0
    parcel_depth_m: float = 20.0
    road_width_m: float = 6.0
    planned_units: int = 30
    avg_unit_area_m2: float = 28.82
    total_floors: int = 5
    building_footprint_m2: float = 200.0
    total_floor_area_m2: float = 900.0
    module_type: str = "BALCONY-2"
    is_lh_purchase: bool = True


# ─────────────────────────────────────────────────────────
# VWorld NED API 내부 헬퍼 함수
# ─────────────────────────────────────────────────────────

def _ned_headers() -> dict:
    """NED API 공통 헤더"""
    return {"User-Agent": "Mozilla/5.0 (compatible; UnitBuild/1.0)"}


def _ned_params(extra: dict) -> dict:
    """NED API 공통 파라미터 (키 + 도메인)"""
    ned_key = VWORLD_NED_KEY or VWORLD_API_KEY
    params = {"format": "json", "key": ned_key}
    if VWORLD_DOMAIN:
        params["domain"] = VWORLD_DOMAIN
    params.update(extra)
    return params


async def _ned_get_land_info(pnu: str, client: httpx.AsyncClient) -> dict:
    """
    NED ladfrlList: 필지 면적, 지목, 법정동명
    반환: {area_m2, land_category, land_category_code, address_legal}
    """
    ned_key = VWORLD_NED_KEY or VWORLD_API_KEY
    if not ned_key:
        return {}
    try:
        params = _ned_params({"pnu": pnu, "numOfRows": "1"})
        resp = await client.get(
            "https://api.vworld.kr/ned/data/ladfrlList",
            params=params, headers=_ned_headers(), timeout=10.0
        )
        if resp.status_code != 200:
            logger.warning(f"NED ladfrlList HTTP {resp.status_code}")
            return {}
        data = resp.json()
        vo_root = data.get("ladfrlVOList", {})
        # "error" 키가 있어도 빈 문자열("")이면 정상 응답 — 실제 오류 코드일 때만 반환 중단
        err_code = vo_root.get("error", "")
        if err_code and str(err_code).strip():
            logger.warning(f"NED ladfrlList 오류: {err_code} - {vo_root.get('message','')}")
            return {}
        total = int(vo_root.get("totalCount", 0))
        if total == 0:
            return {}
        items = vo_root.get("ladfrlVOList", [])
        if isinstance(items, dict):
            items = [items]
        if not items:
            return {}
        item = items[0]
        result = {
            "area_m2": float(item.get("lndpclAr", 0)),
            "land_category": item.get("lndcgrCodeNm", ""),
            "land_category_code": item.get("lndcgrCode", ""),
            "address_legal": item.get("ldCodeNm", ""),
        }
        logger.info(f"NED 토지임야 ✅: 면적={result['area_m2']}㎡, 지목={result['land_category']}")
        return result
    except Exception as e:
        logger.warning(f"NED ladfrlList 오류: {e}")
        return {}


async def _ned_get_land_char(pnu: str, client: httpx.AsyncClient) -> dict:
    """
    NED getLandCharacteristics: 용도지역, 도로접면, 지형, 토지이용상황
    반환: {zone_name, zone_name2, road_side, land_use, topography}
    """
    ned_key = VWORLD_NED_KEY or VWORLD_API_KEY
    if not ned_key:
        return {}
    try:
        current_year = datetime.datetime.now().year
        params = _ned_params({
            "pnu": pnu,
            "stdrYear": str(current_year - 1),
            "numOfRows": "10",
        })
        resp = await client.get(
            "https://api.vworld.kr/ned/data/getLandCharacteristics",
            params=params, headers=_ned_headers(), timeout=10.0
        )
        if resp.status_code != 200:
            return {}
        data = resp.json()
        lc_root = data.get("landCharacteristicss", {})
        total = int(lc_root.get("totalCount", 0))
        if total == 0:
            return {}
        field_list = lc_root.get("field", [])
        if not field_list:
            return {}
        items = field_list if isinstance(field_list, list) else [field_list]
        # 최신 데이터 우선
        items_sorted = sorted(items, key=lambda x: x.get("lastUpdtDt", "0000-00-00"), reverse=True)
        item = items_sorted[0]
        result = {
            "zone_name": item.get("prposArea1Nm", item.get("prposArea1", "")),
            "zone_name2": item.get("prposArea2Nm", item.get("prposArea2", "")),
            "road_side": item.get("roadSideCodeNm", item.get("roadSideCode", "")),
            "land_use": item.get("ladUseSittnNm", item.get("ladUseSittn", "")),
            "topography": item.get("tpgrphHgCodeNm", ""),
        }
        logger.info(f"NED 토지특성 ✅: 용도지역={result['zone_name']}, 도로접면={result['road_side']}")
        return result
    except Exception as e:
        logger.warning(f"NED getLandCharacteristics 오류: {e}")
        return {}


async def _ned_get_land_price(pnu: str, client: httpx.AsyncClient) -> dict:
    """
    NED getIndvdLandPriceAttr: 개별공시지가
    반환: {price_per_m2, price_date, total_price_100m}
    """
    ned_key = VWORLD_NED_KEY or VWORLD_API_KEY
    if not ned_key:
        return {}
    try:
        current_year = datetime.datetime.now().year
        params = _ned_params({
            "pnu": pnu,
            "stdrYear": str(current_year - 1),
            "numOfRows": "1",
        })
        resp = await client.get(
            "https://api.vworld.kr/ned/data/getIndvdLandPriceAttr",
            params=params, headers=_ned_headers(), timeout=10.0
        )
        if resp.status_code != 200:
            return {}
        data = resp.json()
        # 응답 구조: {"indvdLandPrices": {"totalCount":N, "field":[...]}}
        # 주의: 루트 키가 소문자 "indvdLandPrices" (대문자 아님)
        root = data.get("indvdLandPrices") or data.get("IndvdLandPrices") or {}
        # resultCode가 빈 문자열이면 정상, 값이 있으면 오류
        result_code = root.get("resultCode", "")
        if result_code and str(result_code).strip():
            logger.warning(f"NED 공시지가 오류: {result_code} - {root.get('resultMsg','')}")
            return {}
        total = int(root.get("totalCount", 0))
        if total == 0:
            return {}
        field_list = root.get("field", [])
        if not field_list:
            return {}
        items = field_list if isinstance(field_list, list) else [field_list]
        item = items[0]
        price = float(item.get("pblntfPclnd", 0))   # 공시지가 원/㎡
        result = {
            "price_per_m2": price,
            "price_date": item.get("stdrYear", ""),
            "price_raw": item,
        }
        logger.info(f"NED 공시지가 ✅: {price:,.0f}원/㎡")
        return result
    except Exception as e:
        logger.warning(f"NED getIndvdLandPriceAttr 오류: {e}")
        return {}


# ─────────────────────────────────────────────────────────
# 엔드포인트: 필지 종합 자동 분석
# ─────────────────────────────────────────────────────────

@router.post("/analyze", summary="필지 종합 자동 분석")
async def analyze_parcel(req: ParcelAnalysisRequest):
    """
    지번 입력 → 자동 분석 원스톱 파이프라인

    **VWorld 실데이터 파이프라인 (서울 AWS 서버 43.201.6.67에서 직접 호출):**
    1. Search API       → 좌표 (위경도) + PNU
    2. NED ladfrlList   → 실제 면적, 지목
    3. NED getLandChar  → 용도지역, 도로접면
    4. NED landPrice    → 개별공시지가
    5. parcel_analyzer  → 모듈 배치 최적화 + SITE-C 평가
    """
    # ── Step 1: VWorld Search API → 좌표 + PNU ────────────────────
    vworld_lat     = req.lat
    vworld_lng     = req.lng
    vworld_pnu     = None
    vworld_address = None
    data_source_tag = "simulation"

    if VWORLD_API_KEY and not (req.lat and req.lng):
        try:
            from urllib.parse import quote as url_quote
            encoded_addr = url_quote(req.parcel_number)
            search_url = (
                f"https://api.vworld.kr/req/search"
                f"?service=search&version=2.0&request=search&format=json"
                f"&key={VWORLD_API_KEY}&query={encoded_addr}"
                f"&type=ADDRESS&category=PARCEL&crs=epsg:4326"
            )
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.get(
                    search_url,
                    headers={"User-Agent": "Mozilla/5.0 (compatible; UnitBuild/1.0)"}
                )
                if resp.status_code == 200:
                    sdata = resp.json()
                    vstatus = sdata.get("response", {}).get("status", "")
                    if vstatus == "OK":
                        items = sdata.get("response", {}).get("result", {}).get("items", [])
                        if items:
                            first = items[0]
                            point = first.get("point", {})
                            vworld_lat = float(point.get("y", 0)) or None
                            vworld_lng = float(point.get("x", 0)) or None
                            vworld_pnu = first.get("id")
                            vworld_address = first.get("address", {}).get("parcel")
                            data_source_tag = "vworld"
                            logger.info(
                                f"VWorld Search ✅: {req.parcel_number} → "
                                f"lat={vworld_lat}, lng={vworld_lng}, pnu={vworld_pnu}"
                            )
                        else:
                            logger.info(f"VWorld Search 결과 없음: {req.parcel_number}")
                    else:
                        logger.warning(f"VWorld Search 상태: {vstatus}")
        except Exception as e:
            logger.warning(f"VWorld Search 오류 (시뮬레이션으로 대체): {e}")

    # ── Step 2~4: NED API 병렬 호출 (PNU 확보 시) ─────────────────
    ned_land_info  = {}
    ned_land_char  = {}
    ned_land_price = {}
    ned_sources    = []

    pnu_to_use = vworld_pnu
    ned_key = VWORLD_NED_KEY or VWORLD_API_KEY

    if ned_key and pnu_to_use:
        try:
            import asyncio
            async with httpx.AsyncClient(timeout=12.0) as ned_client:
                ned_land_info, ned_land_char, ned_land_price = await asyncio.gather(
                    _ned_get_land_info(pnu_to_use, ned_client),
                    _ned_get_land_char(pnu_to_use, ned_client),
                    _ned_get_land_price(pnu_to_use, ned_client),
                    return_exceptions=False
                )
            if ned_land_info:
                ned_sources.append("NED 토지임야정보")
            if ned_land_char:
                ned_sources.append("NED 토지특성정보")
            if ned_land_price:
                ned_sources.append("NED 개별공시지가")
        except Exception as e:
            logger.warning(f"NED 병렬 호출 오류: {e}")

    # ── Step 5: NED 실데이터로 요청 파라미터 보완 ──────────────────
    # 면적: NED 실데이터 > 요청값 > analyzer 추정
    effective_area    = ned_land_info.get("area_m2") or req.area_m2
    # 용도지역: NED 실데이터 > 요청값
    effective_zone    = ned_land_char.get("zone_name") or req.zone_type

    # ── Step 6: parcel_analyzer 실행 ──────────────────────────────
    result = parcel_analyzer.analyze(
        parcel_number=req.parcel_number,
        lat=vworld_lat,
        lng=vworld_lng,
        area_m2=effective_area,
        zone_type=effective_zone,
        target_units=req.target_units,
    )

    # ── Step 7: VWorld + NED 실데이터로 parcel_info 덮어쓰기 ──────
    if vworld_lat and vworld_lng:
        result.parcel_info.latitude   = vworld_lat
        result.parcel_info.longitude  = vworld_lng
        result.parcel_info.data_source = data_source_tag
    if vworld_address:
        result.parcel_info.address = vworld_address
    if ned_land_info.get("area_m2"):
        result.parcel_info.area_m2 = ned_land_info["area_m2"]
    if ned_land_char.get("zone_name"):
        result.parcel_info.zone_type = ned_land_char["zone_name"]

    # ── 직렬화 ───────────────────────────────────────────────────
    parcel = result.parcel_info
    reg    = result.regulatory_limits
    best   = result.best_plan

    # 공시지가 기반 토지가치 계산
    land_value_info = {}
    if ned_land_price.get("price_per_m2") and parcel.area_m2:
        price_m2 = ned_land_price["price_per_m2"]
        total_value = price_m2 * parcel.area_m2
        land_value_info = {
            "price_per_m2": price_m2,
            "price_per_m2_formatted": f"{price_m2:,.0f}원/㎡",
            "total_land_value": total_value,
            "total_land_value_100m": round(total_value / 1_000_000),
            "total_land_value_formatted": f"{total_value/100_000_000:.1f}억원",
            "price_year": ned_land_price.get("price_date", ""),
        }

    # 데이터 소스 통합 노트
    if data_source_tag == "vworld" and ned_sources:
        data_note = f"✅ VWorld 실데이터 연동 완료 — {', '.join(ned_sources)}"
    elif data_source_tag == "vworld":
        data_note = "✅ VWorld Search API 성공 (좌표/PNU), NED 데이터 미획득"
    else:
        data_note = "⚠️ 시뮬레이션 모드 — VWorld 주소를 찾을 수 없어 추정값 사용"

    return {
        "analysis_timestamp": result.analysis_timestamp,
        "overall_feasibility": result.overall_feasibility,
        "sitec_pre_score": result.sitec_pre_score,
        "sitec_grade": result.sitec_grade,

        "parcel_info": {
            "parcel_number":  parcel.parcel_number,
            "address":        parcel.address,
            "latitude":       parcel.latitude,
            "longitude":      parcel.longitude,
            "area_m2":        parcel.area_m2,
            "width_m":        parcel.width_m,
            "depth_m":        parcel.depth_m,
            "zone_type":      parcel.zone_type,
            "road_width_m":   parcel.road_width_m,
            "slope_percent":  parcel.slope_percent,
            "data_source":    parcel.data_source,
            # NED 추가 실데이터
            "land_category":        ned_land_info.get("land_category", ""),
            "land_category_code":   ned_land_info.get("land_category_code", ""),
            "address_legal":        ned_land_info.get("address_legal", ""),
            "zone_name2":           ned_land_char.get("zone_name2", ""),
            "road_side":            ned_land_char.get("road_side", ""),
            "land_use":             ned_land_char.get("land_use", ""),
            "topography":           ned_land_char.get("topography", ""),
            "pnu":                  vworld_pnu or "",
        },

        # 공시지가 정보
        "land_value": land_value_info if land_value_info else None,

        "regulatory_limits": {
            "zone_type":                reg.zone_type,
            "coverage_ratio_max_pct":   reg.coverage_ratio_max_pct,
            "floor_area_ratio_max_pct": reg.floor_area_ratio_max_pct,
            "max_floors":               reg.max_floors,
            "height_limit_m":           reg.height_limit_m,
            "max_building_footprint_m2": reg.max_building_footprint_m2,
            "max_total_floor_area_m2":  reg.max_total_floor_area_m2,
            "parking_required":         reg.parking_required,
            "parking_area_m2":          reg.parking_area_m2,
            "notes":                    reg.notes,
        },

        "best_plan": {
            "module_type":          best.module_type.value if best else None,
            "units_per_floor":      best.units_per_floor if best else 0,
            "recommended_floors":   best.recommended_floors if best else 0,
            "total_units":          best.total_units if best else 0,
            "building_footprint_m2": best.building_footprint_m2 if best else 0,
            "total_floor_area_m2":  best.total_floor_area_m2 if best else 0,
            "coverage_ratio_pct":   best.coverage_ratio_pct if best else 0,
            "floor_area_ratio_pct": best.floor_area_ratio_pct if best else 0,
            "unit_types":           best.unit_types if best else [],
            "lh_type_breakdown":    best.lh_type_breakdown if best else {},
            "small_unit_ratio":     best.small_unit_ratio if best else 0,
            "avg_unit_area_m2":     best.avg_unit_area_m2 if best else 0,
            "estimated_construction_cost_100m": best.estimated_construction_cost_100m if best else 0,
            "estimated_lh_purchase_price_100m": best.estimated_lh_purchase_price_100m if best else 0,
            "estimated_profit_100m": best.estimated_profit_100m if best else 0,
            "roi_pct":              best.roi_pct if best else 0,
            "regulation_compliant": best.regulation_compliant if best else False,
            "compliance_notes":     best.compliance_notes if best else [],
            "warnings":             best.warnings if best else [],
        } if best else None,

        "all_plans_summary": [
            {
                "module_type":        p.module_type.value,
                "total_units":        p.total_units,
                "floors":             p.recommended_floors,
                "roi_pct":            p.roi_pct,
                "regulation_compliant": p.regulation_compliant,
                "coverage_pct":       p.coverage_ratio_pct,
                "far_pct":            p.floor_area_ratio_pct,
            }
            for p in result.placement_plans
        ],

        "key_insights": result.key_insights,
        "next_steps":   result.next_steps,
        "vworld_pnu":   vworld_pnu,
        "ned_sources":  ned_sources,
        "data_note":    data_note,
    }


@router.post("/regulation-check", summary="법규 자동 검토")
async def check_regulations(req: RegulationCheckRequest):
    """
    건축법·주차장법·국토계획법·피난방화규칙 통합 자동 검토

    **검토 항목:**
    - C01: 건폐율 (국토계획법 §78)
    - C02: 용적률 (국토계획법 §79)
    - C03: 최고 층수 (건축법 §60)
    - C04: 도로 접면 (건축법 §44)
    - C05: 정북 일조권 이격 (건축법 §61, 시행령 §86)
    - C06: 주차 대수 (주차장법 시행규칙 §6)
    - C07: 피난계단 (피난방화규칙 §8, §9)
    - C08: 복도 폭 (피난방화규칙 §15의2)
    - C09: 스프링클러 (소방시설법)
    - C10: 모듈러 공업화건축물 특례 (건축법 §23의3)
    """
    report = regulation_checker.check(
        zone_type=req.zone_type,
        parcel_area_m2=req.parcel_area_m2,
        parcel_width_m=req.parcel_width_m,
        parcel_depth_m=req.parcel_depth_m,
        road_width_m=req.road_width_m,
        planned_units=req.planned_units,
        avg_unit_area_m2=req.avg_unit_area_m2,
        total_floors=req.total_floors,
        building_footprint_m2=req.building_footprint_m2,
        total_floor_area_m2=req.total_floor_area_m2,
        module_type=req.module_type,
        is_lh_purchase=req.is_lh_purchase,
    )

    return {
        "overall_status": report.overall_status.value,
        "summary": {
            "pass":    report.pass_count,
            "warning": report.warning_count,
            "fail":    report.fail_count,
            "total":   len(report.check_items),
        },
        "modular_exemption": {
            "applied": report.modular_exemption_applied,
            "items":   report.modular_exemption_items,
        },
        "check_items": [
            {
                "item_id":        item.item_id,
                "category":       item.category,
                "name":           item.name,
                "legal_basis":    item.legal_basis,
                "required":       item.required_value,
                "actual":         item.actual_value,
                "status":         item.status.value,
                "message":        item.message,
                "recommendation": item.recommendation,
            }
            for item in report.check_items
        ],
        "required_values": {
            "coverage_ratio_max_pct": report.required_coverage_pct,
            "far_max_pct":            report.required_far_pct,
            "parking_spaces":         report.required_parking_spaces,
            "emergency_exits":        report.required_emergency_exits,
            "staircase_count":        report.required_staircase_count,
        },
        "critical_issues":  report.critical_issues,
        "recommendations":  report.recommendations,
    }


@router.get("/zones", summary="용도지역 목록 및 규제 기준")
async def list_zones():
    """국토계획법 용도지역 목록 및 건폐율/용적률 기준 반환"""
    from app.services.parcel_analyzer import ZONE_REGULATIONS_SIMPLE
    return {
        "zones": [
            {
                "zone_type":                k,
                "coverage_ratio_max_pct":   v["coverage"],
                "floor_area_ratio_max_pct": v["far"],
                "max_floors":               v["max_floors"],
                "max_floors_desc": (
                    f"{v['max_floors']}층 이하" if v["max_floors"] > 0
                    else "층수 제한 없음 (용적률로 제어)"
                ),
            }
            for k, v in ZONE_REGULATIONS_SIMPLE.items()
        ],
        "note": "국토의 계획 및 이용에 관한 법률 (법률 제21065호, 20260102) 기준",
        "lh_preferred_zones": [
            "제2종일반주거지역",
            "제3종일반주거지역",
            "준주거지역",
            "준공업지역 (LH 심의 시 추가 검토 필요)",
        ]
    }


# ─────────────────────────────────────────────────────────
# VWorld 서버사이드 프록시
# ─────────────────────────────────────────────────────────

class VWorldGeocodeRequest(BaseModel):
    address: str
    addr_type: str = "PARCEL"


class VWorldLandRequest(BaseModel):
    pnu: str


class VWorldEnrichRequest(BaseModel):
    """프론트엔드가 VWorld에서 직접 조회한 데이터를 백엔드로 전달"""
    pnu: str
    area_m2: Optional[float] = None
    land_category: Optional[str] = None
    zone_name: Optional[str] = None
    zone_name2: Optional[str] = None
    road_side: Optional[str] = None
    land_use: Optional[str] = None
    lat: Optional[float] = None
    lng: Optional[float] = None
    address_parcel: Optional[str] = None
    address_road: Optional[str] = None
    source: str = "vworld_browser"


@router.get("/vworld-proxy/geocode", summary="VWorld 주소→좌표 서버사이드 프록시")
async def vworld_proxy_geocode(
    address: str = Query(..., description="주소 문자열"),
    addr_type: str = Query("PARCEL", description="주소 유형 (PARCEL|ROAD)")
):
    """서버에서 VWorld 지오코딩 API를 Referer 헤더와 함께 호출"""
    if not VWORLD_API_KEY:
        raise HTTPException(status_code=503, detail="VWORLD_API_KEY 미설정")

    params = {
        "service": "address",
        "version": "2.0",
        "request": "GetCoord",
        "format": "json",
        "key": VWORLD_API_KEY,
        "address": address,
        "type": addr_type,
        "crs": "epsg:4326",
    }
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json, */*",
    }
    if VWORLD_DOMAIN:
        headers["Referer"] = VWORLD_DOMAIN
        params["domain"] = VWORLD_DOMAIN

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get("https://api.vworld.kr/req/address", params=params, headers=headers)
            if resp.status_code == 200:
                return resp.json()
            return {"status": "proxy_error", "http_status": resp.status_code, "detail": resp.text[:200]}
    except Exception as e:
        return {"status": "proxy_error", "detail": str(e)}


@router.get("/vworld-proxy/land-info", summary="VWorld NED 토지임야정보 프록시")
async def vworld_proxy_land_info(pnu: str = Query(..., description="19자리 PNU")):
    """VWorld NED 토지임야정보 API 서버사이드 프록시"""
    ned_key = VWORLD_NED_KEY or VWORLD_API_KEY
    if not ned_key:
        raise HTTPException(status_code=503, detail="VWORLD NED API 키 미설정")

    params = {"format": "json", "key": ned_key, "pnu": pnu, "numOfRows": "1"}
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
    if VWORLD_DOMAIN:
        headers["Referer"] = VWORLD_DOMAIN
        params["domain"] = VWORLD_DOMAIN

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get("https://api.vworld.kr/ned/data/ladfrlList", params=params, headers=headers)
            if resp.status_code == 200:
                return resp.json()
            return {"status": "proxy_error", "http_status": resp.status_code}
    except Exception as e:
        return {"status": "proxy_error", "detail": str(e)}


@router.get("/vworld-proxy/land-char", summary="VWorld NED 토지특성정보 프록시")
async def vworld_proxy_land_char(pnu: str = Query(..., description="19자리 PNU")):
    """VWorld NED 토지특성정보 API 서버사이드 프록시"""
    import datetime as dt
    ned_key = VWORLD_NED_KEY or VWORLD_API_KEY
    if not ned_key:
        raise HTTPException(status_code=503, detail="VWORLD NED API 키 미설정")

    params = {
        "format": "json", "key": ned_key, "pnu": pnu,
        "stdrYear": str(dt.datetime.now().year - 1), "numOfRows": "5",
    }
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
    if VWORLD_DOMAIN:
        headers["Referer"] = VWORLD_DOMAIN
        params["domain"] = VWORLD_DOMAIN

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get("https://api.vworld.kr/ned/data/getLandCharacteristics", params=params, headers=headers)
            if resp.status_code == 200:
                return resp.json()
            return {"status": "proxy_error", "http_status": resp.status_code}
    except Exception as e:
        return {"status": "proxy_error", "detail": str(e)}


@router.get("/vworld-proxy/land-price", summary="VWorld NED 개별공시지가 프록시")
async def vworld_proxy_land_price(pnu: str = Query(..., description="19자리 PNU")):
    """VWorld NED 개별공시지가 API 서버사이드 프록시"""
    import datetime as dt
    ned_key = VWORLD_NED_KEY or VWORLD_API_KEY
    if not ned_key:
        raise HTTPException(status_code=503, detail="VWORLD NED API 키 미설정")

    params = {
        "format": "json", "key": ned_key, "pnu": pnu,
        "stdrYear": str(dt.datetime.now().year - 1), "numOfRows": "1",
    }
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
    if VWORLD_DOMAIN:
        headers["Referer"] = VWORLD_DOMAIN
        params["domain"] = VWORLD_DOMAIN

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get("https://api.vworld.kr/ned/data/getIndvdLandPriceAttr", params=params, headers=headers)
            if resp.status_code == 200:
                return resp.json()
            return {"status": "proxy_error", "http_status": resp.status_code}
    except Exception as e:
        return {"status": "proxy_error", "detail": str(e)}


@router.post("/vworld-enrich", summary="프론트엔드 VWorld 조회결과 수신 및 평가 보완")
async def vworld_enrich(data: VWorldEnrichRequest):
    """
    브라우저에서 직접 VWorld API를 호출한 결과를 받아
    SITE-C 평가를 실제 공식 데이터로 보완합니다.
    """
    logger.info(f"VWorld enrich 수신: PNU={data.pnu}, source={data.source}")
    return {
        "status": "enriched",
        "pnu": data.pnu,
        "area_m2": data.area_m2,
        "land_category": data.land_category,
        "zone_name": data.zone_name,
        "zone_name2": data.zone_name2,
        "road_side": data.road_side,
        "lat": data.lat,
        "lng": data.lng,
        "address_parcel": data.address_parcel,
        "address_road": data.address_road,
        "source": data.source,
        "message": "VWorld 실데이터 수신 완료. 이 PNU로 SITE-C auto-evaluate를 다시 호출하면 정확한 평가가 수행됩니다.",
    }
