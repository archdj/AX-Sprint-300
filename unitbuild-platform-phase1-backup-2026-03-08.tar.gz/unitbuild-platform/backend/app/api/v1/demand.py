"""
수요 예측 API
"""
from fastapi import APIRouter, Query
from app.services.demand_predictor import demand_predictor

router = APIRouter(prefix="/api/v1/demand", tags=["수요 예측"])


@router.post("/predict", summary="좌표 기반 AI 수요 예측")
async def predict_demand(
    lat: float = Query(..., ge=-90, le=90, description="위도"),
    lng: float = Query(..., ge=-180, le=180, description="경도"),
    radius_m: int = Query(1000, ge=200, le=5000, description="분석 반경(m)"),
):
    """
    좌표 기반 주택 수요 예측

    **반환 데이터**:
    - demand_score: 수요 확신도 (0~100)
    - recommended_units: AI 추천 세대수
    - forecast_monthly: 12개월 수요 예측 시계열
    - risk_factors: 리스크 요인 목록
    
    **Phase 1**: 지역 특성 기반 시뮬레이션 예측  
    **Phase 2**: LH OpenAPI + 통계청 + 실거래가 + LSTM 모델 연동 예정
    """
    result = await demand_predictor.predict_demand(lat, lng, radius_m)
    
    return {
        "lat": result.lat,
        "lng": result.lng,
        "region_name": result.region_name,
        "demand_score": result.demand_score,
        "recommended_units": result.recommended_units,
        "confidence": result.confidence,
        "hierarchy": {
            "sigungu_score": result.sigungu_score,
            "emd_score": result.emd_score,
            "parcel_score": result.parcel_score,
        },
        "forecast_monthly": result.forecast_monthly,
        "risk_factors": result.risk_factors,
        "model_version": result.model_version,
        "predicted_at": result.predicted_at,
    }
