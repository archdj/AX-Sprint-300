"""
자동 필지 평가 API
지번/주소 입력 하나로 전체 파이프라인 자동 실행
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from dataclasses import asdict

from app.services.auto_sitec_evaluator import auto_sitec_evaluator, SiteCAutoResult
from app.services.parcel_lookup import parcel_lookup, parse_address

router = APIRouter(prefix="/api/v1/auto", tags=["자동 통합 평가"])


# ─── Pydantic 스키마 ───────────────────────────────────────────

class AutoEvaluateRequest(BaseModel):
    """자동 평가 요청"""
    address: str = Field(
        ...,
        description="지번 주소 또는 도로명 주소",
        example="서울시 강남구 역삼동 123-45",
    )
    planned_units: Optional[int] = Field(
        default=None,
        description="계획 세대수 (미입력 시 자동 추천)",
        ge=5,
        le=500,
    )
    small_unit_ratio: float = Field(
        default=0.8,
        description="전용60㎡ 이하 비율 (0~1)",
        ge=0,
        le=1,
    )
    long_term_rental: bool = Field(
        default=False,
        description="장기임대(10년+) 여부 — 가점 적용",
    )
    lh_certified: bool = Field(
        default=False,
        description="LH 우수시공사 인증 여부",
    )
    energy_grade: int = Field(
        default=2,
        description="에너지효율등급 (1~5, 낮을수록 우수)",
        ge=1,
        le=5,
    )


class ParcelBasicSchema(BaseModel):
    address: str
    lat: float
    lng: float
    area_m2: float
    land_category: str
    zone_name: str
    zone_name2: str
    coverage_ratio_max: float
    floor_area_ratio_max: float
    max_floors: int
    is_simulation: bool
    data_sources: List[str]
    # SITE-C 자동 수집 거리 (m)
    cbd_distance_km: float = 0.0
    subway_distance_m: float = 0.0
    bus_stop_distance_m: float = 0.0
    elementary_school_distance_m: float = 0.0
    hospital_distance_m: float = 0.0
    mart_distance_m: float = 0.0
    slope_percent: float = 0.0
    seismic_grade: int = 1
    sunshine_hours: float = 4.0


class ModulePlanSchema(BaseModel):
    module_type: str
    net_area_m2: float
    lh_type: str
    units_per_floor: int
    floors: int
    total_units: int
    coverage_ratio_pct: float
    floor_area_ratio_pct: float
    roi_pct: float
    is_compliant: bool


class SiteCCriteriaUsedSchema(BaseModel):
    A_transportation: Dict[str, Any]
    B_infrastructure: Dict[str, Any]
    C_scale: Dict[str, Any]
    D_structure: Dict[str, Any]
    E_energy: Dict[str, Any]
    F_bonus: Dict[str, Any]


class AutoEvaluateResponse(BaseModel):
    """자동 평가 응답"""
    address_input: str
    evaluated_at: str

    # 1. 필지
    parcel: ParcelBasicSchema

    # 2. 건축 규제
    regulations: Dict[str, Any]

    # 3. 모듈 배치
    best_module: str
    best_floor: int
    best_units: int
    coverage_ratio: float
    floor_area_ratio: float
    roi_pct: float
    module_plans: List[Dict[str, Any]]

    # 4. SITE-C
    sitec_score: float
    sitec_grade: str
    sitec_approval_prob: float
    sitec_breakdown: Dict[str, float]
    sitec_suggestions: List[str]
    sitec_criteria_used: Dict[str, Any]

    # 5. 수요 예측
    demand_score: float
    recommended_units: int
    demand_confidence: float
    demand_region: str
    demand_risk_factors: List[str]

    # 6. 사업성
    construction_cost_bn: float
    lh_purchase_bn: float
    profit_bn: float
    profit_margin_pct: float

    # 7. 종합 판정
    overall_grade: str
    overall_summary: str
    key_strengths: List[str]
    key_risks: List[str]
    next_actions: List[str]

    # 메타
    is_simulation: bool
    data_sources: List[str]
    errors: List[str]


class ParcelLookupResponse(BaseModel):
    """필지 정보만 조회 (좌표 + 면적 + 용도지역)"""
    address: str
    lat: float
    lng: float
    pnu: str
    area_m2: float
    land_category: str
    zone_name: str
    zone_name2: str
    cbd_distance_km: float
    subway_distance_m: float
    bus_stop_distance_m: float
    elementary_school_distance_m: float
    hospital_distance_m: float
    mart_distance_m: float
    slope_percent: float
    seismic_grade: int
    sunshine_hours: float
    data_sources: List[str]
    is_simulation: bool
    errors: List[str]


# ─── 엔드포인트 ────────────────────────────────────────────────

@router.post(
    "/evaluate",
    response_model=AutoEvaluateResponse,
    summary="🔑 지번 자동 통합 평가",
    description="""
    **지번 하나 입력 → 전체 자동 평가 파이프라인**

    1. 📍 VWorld API → 좌표, 필지면적, 용도지역 자동 조회
    2. 🏗️ 용도지역 → 건폐율/용적률/층수 자동 계산
    3. 🧩 Gen 2 모듈 배치 최적화 (BALCONY-2/3, BASIC 시리즈)
    4. ⭐ SITE-C A~F 항목 자동 채점 (교통/인프라거리 자동 조회)
    5. 📊 AI 수요 예측 (지역 인구·개발 특성 반영)
    6. 💰 사업성 분석 (LH 매입가 기준 ROI 계산)

    **API 키 설정 방법:**
    - `VWORLD_API_KEY`: VWorld 필지/용도지역 실데이터 조회
    - `KAKAO_REST_API_KEY`: 주변 시설(지하철/학교/병원) 정확한 거리 조회
    - 키 없이도 시뮬레이션 모드로 즉시 동작
    """,
)
async def auto_evaluate(request: AutoEvaluateRequest) -> AutoEvaluateResponse:
    """지번 자동 통합 평가 실행"""
    if not request.address or len(request.address.strip()) < 5:
        raise HTTPException(
            status_code=400,
            detail="주소를 올바르게 입력하세요. (예: 서울시 강남구 역삼동 123-45)"
        )

    try:
        result: SiteCAutoResult = await auto_sitec_evaluator.evaluate(
            address=request.address,
            planned_units=request.planned_units,
            small_unit_ratio=request.small_unit_ratio,
            long_term_rental=request.long_term_rental,
            lh_certified=request.lh_certified,
            energy_grade=request.energy_grade,
        )

        return AutoEvaluateResponse(
            address_input=result.address_input,
            evaluated_at=result.evaluated_at,
            parcel=ParcelBasicSchema(**{
                "address": result.parcel.address,
                "lat": result.parcel.lat,
                "lng": result.parcel.lng,
                "area_m2": result.parcel.area_m2,
                "land_category": result.parcel.land_category,
                "zone_name": result.parcel.zone_name,
                "zone_name2": result.parcel.zone_name2,
                "coverage_ratio_max": result.parcel.coverage_ratio_max,
                "floor_area_ratio_max": result.parcel.floor_area_ratio_max,
                "max_floors": result.parcel.max_floors,
                "is_simulation": result.parcel.is_simulation,
                "data_sources": result.parcel.data_sources,
                "cbd_distance_km": result.parcel.cbd_distance_km,
                "subway_distance_m": result.parcel.subway_distance_m,
                "bus_stop_distance_m": result.parcel.bus_stop_distance_m,
                "elementary_school_distance_m": result.parcel.elementary_school_distance_m,
                "hospital_distance_m": result.parcel.hospital_distance_m,
                "mart_distance_m": result.parcel.mart_distance_m,
                "slope_percent": result.parcel.slope_percent,
                "seismic_grade": result.parcel.seismic_grade,
                "sunshine_hours": result.parcel.sunshine_hours,
            }),
            regulations=result.regulations,
            best_module=result.best_module,
            best_floor=result.best_floor,
            best_units=result.best_units,
            coverage_ratio=result.coverage_ratio,
            floor_area_ratio=result.floor_area_ratio,
            roi_pct=result.roi_pct,
            module_plans=result.module_plans,
            sitec_score=result.sitec_score,
            sitec_grade=result.sitec_grade,
            sitec_approval_prob=result.sitec_approval_prob,
            sitec_breakdown=result.sitec_breakdown,
            sitec_suggestions=result.sitec_suggestions,
            sitec_criteria_used=result.sitec_criteria_used,
            demand_score=result.demand_score,
            recommended_units=result.recommended_units,
            demand_confidence=result.demand_confidence,
            demand_region=result.demand_region,
            demand_risk_factors=result.demand_risk_factors,
            construction_cost_bn=result.construction_cost_bn,
            lh_purchase_bn=result.lh_purchase_bn,
            profit_bn=result.profit_bn,
            profit_margin_pct=result.profit_margin_pct,
            overall_grade=result.overall_grade,
            overall_summary=result.overall_summary,
            key_strengths=result.key_strengths,
            key_risks=result.key_risks,
            next_actions=result.next_actions,
            is_simulation=result.is_simulation,
            data_sources=result.data_sources,
            errors=result.errors,
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"평가 중 오류 발생: {str(e)}")


@router.get(
    "/lookup",
    response_model=ParcelLookupResponse,
    summary="📍 필지 기본 정보 조회",
    description="주소/지번 입력 → 좌표, 면적, 용도지역, 주변 시설 거리 조회만",
)
async def lookup_parcel(
    address: str = Query(..., description="지번 또는 도로명 주소", example="서울시 강남구 역삼동 123-45"),
) -> ParcelLookupResponse:
    """주소 → 필지 기본 정보 조회 (SITE-C 평가 없이 빠른 조회)"""
    if not address or len(address.strip()) < 5:
        raise HTTPException(status_code=400, detail="주소를 올바르게 입력하세요.")

    try:
        result = await parcel_lookup.lookup(address)
        return ParcelLookupResponse(
            address=result.address_input,
            lat=result.lat,
            lng=result.lng,
            pnu=result.pnu,
            area_m2=result.area_m2,
            land_category=result.land_category,
            zone_name=result.zone_name,
            zone_name2=result.zone_name2,
            cbd_distance_km=result.cbd_distance_km,
            subway_distance_m=result.subway_distance_m,
            bus_stop_distance_m=result.bus_stop_distance_m,
            elementary_school_distance_m=result.elementary_school_distance_m,
            hospital_distance_m=result.hospital_distance_m,
            mart_distance_m=result.mart_distance_m,
            slope_percent=result.slope_percent,
            seismic_grade=result.seismic_grade,
            sunshine_hours=result.sunshine_hours,
            data_sources=result.data_sources,
            is_simulation=result.is_simulation,
            errors=result.lookup_errors,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"필지 조회 오류: {str(e)}")


@router.get(
    "/parse-address",
    summary="주소 파싱 테스트",
    description="입력 주소를 시도/시군구/읍면동/지번으로 분리합니다",
)
async def parse_address_endpoint(
    address: str = Query(..., description="주소 문자열"),
):
    """주소 파싱 결과 반환 (개발/테스트용)"""
    return parse_address(address)


@router.get(
    "/api-status",
    summary="외부 API 연결 상태 확인",
)
async def check_api_status():
    """VWorld/카카오 API 키 설정 여부 및 연결 상태 반환"""
    import os
    vworld_key = os.getenv("VWORLD_API_KEY", "")
    kakao_key = os.getenv("KAKAO_REST_API_KEY", "")

    status = {
        "vworld": {
            "configured": bool(vworld_key),
            "description": "VWorld 지오코딩, 토지임야정보, 토지특성정보, 토지이용계획 API",
            "signup_url": "https://www.vworld.kr/dev/v4dv_2ddrjguide2_s001.do",
            "data_available": ["좌표변환", "필지면적", "용도지역", "토지특성", "공시지가"],
        },
        "kakao": {
            "configured": bool(kakao_key),
            "description": "카카오 로컬 API — 주변 시설 거리 검색 (지하철/학교/병원/마트)",
            "signup_url": "https://developers.kakao.com/",
            "data_available": ["지하철역거리", "버스정류장거리", "학교거리", "병원거리", "마트거리"],
        },
        "simulation_mode": not (bool(vworld_key) and bool(kakao_key)),
        "note": (
            "시뮬레이션 모드 동작 중 — 실제 데이터 조회를 위해 API 키를 환경변수에 설정하세요."
            if not (bool(vworld_key) and bool(kakao_key))
            else "실제 API 연동 모드 동작 중"
        ),
        "env_vars": {
            "VWORLD_API_KEY": "VWorld Open API 인증키",
            "KAKAO_REST_API_KEY": "카카오 REST API 키",
        },
    }
    return status



# ─── 사업지 등록 ──────────────────────────────────────────────

class SaveSiteRequest(BaseModel):
    address: str = Field(..., description="지번 주소")
    site_name: str = Field("", description="사업지명 (미입력시 주소 자동 사용)")
    planned_units: int = Field(0, description="계획 세대수 (0=자동)")
    small_unit_ratio: float = Field(0.8, description="전용60이하 비율")
    long_term_rental: bool = False
    lh_certified: bool = False
    energy_grade: int = Field(2, ge=1, le=5)
    notes: str = Field("", description="메모")


class SaveSiteResponse(BaseModel):
    site_id: int
    site_name: str
    address: str
    sitec_score: float
    sitec_grade: str
    overall_grade: str
    message: str


@router.post(
    "/save-site",
    response_model=SaveSiteResponse,
    summary="평가 결과 사업지 등록",
    description="자동 평가 결과를 사업지 DB에 저장하여 클러스터 최적화에 활용합니다.",
)
async def save_site_from_evaluation(request: SaveSiteRequest):
    from app.core.database import get_db as _get_db
    from app.models.site import Site

    gen = _get_db()
    db_session = await gen.__anext__()

    try:
        result: SiteCAutoResult = await auto_sitec_evaluator.evaluate(
            address=request.address,
            planned_units=request.planned_units if request.planned_units > 0 else None,
            small_unit_ratio=request.small_unit_ratio,
            long_term_rental=request.long_term_rental,
            lh_certified=request.lh_certified,
            energy_grade=request.energy_grade,
        )

        site_name = request.site_name.strip() or result.address_input
        grade_val = result.sitec_grade if result.sitec_grade in ("A", "B", "C") else None

        site = Site(
            name=site_name,
            address=result.address_input,
            lat=result.parcel.lat,
            lng=result.parcel.lng,
            pnu=getattr(result.parcel, "pnu", None),
            land_area_m2=result.parcel.area_m2,
            planned_units=result.best_units or request.planned_units or None,
            small_unit_ratio=request.small_unit_ratio,
            floor_count=result.best_floor,
            cbd_distance_km=result.parcel.cbd_distance_km,
            subway_distance_m=result.parcel.subway_distance_m,
            bus_stop_distance_m=result.parcel.bus_stop_distance_m,
            elementary_school_distance_m=result.parcel.elementary_school_distance_m,
            hospital_distance_m=result.parcel.hospital_distance_m,
            mart_distance_m=result.parcel.mart_distance_m,
            seismic_grade=result.parcel.seismic_grade,
            slope_percent=result.parcel.slope_percent,
            energy_efficiency_grade=request.energy_grade,
            sunshine_hours=result.parcel.sunshine_hours,
            is_modular=True,
            long_term_rental=request.long_term_rental,
            lh_certified=request.lh_certified,
            sitec_score=result.sitec_score,
            sitec_grade=grade_val,
            sitec_approval_prob=result.sitec_approval_prob,
            sitec_breakdown=result.sitec_breakdown,
            sitec_suggestions=result.sitec_suggestions,
            demand_score=result.demand_score,
            recommended_units=result.recommended_units,
            estimated_cost=result.construction_cost_bn * 1e8 if result.construction_cost_bn else None,
            lh_purchase_price=result.lh_purchase_bn * 1e8 if result.lh_purchase_bn else None,
            expected_margin=result.profit_margin_pct,
            status="evaluated",
            notes=request.notes or None,
        )

        db_session.add(site)
        await db_session.commit()
        await db_session.refresh(site)

        grade_str = site.sitec_grade.value if site.sitec_grade else "N/A"
        msg = "사업지 등록 완료 (ID: " + str(site.id) + "). 포트폴리오 탭에서 클러스터 검토 가능합니다."

        return SaveSiteResponse(
            site_id=site.id,
            site_name=site.name,
            address=site.address,
            sitec_score=site.sitec_score or 0,
            sitec_grade=grade_str,
            overall_grade=result.overall_grade,
            message=msg,
        )

    except Exception as e:
        await db_session.rollback()
        raise HTTPException(status_code=500, detail="사업지 등록 오류: " + str(e))
    finally:
        try:
            await gen.aclose()
        except Exception:
            pass
