"""
모듈 카탈로그 API — /api/v1/modules
UnitBuild Gen 2 모듈 사양 조회 및 배치 계획
"""

from fastapi import APIRouter, Query
from typing import Optional, List
from pydantic import BaseModel

from app.services.module_catalog import (
    ModuleType, LHUnitType, CorridorType,
    module_catalog, GEN2_MODULE_CATALOG, STANDARD_SHAFT,
    TOTAL_CONSTRUCTION_COST_PER_M2, LH_PURCHASE_PRICE_PER_M2
)

router = APIRouter(prefix="/api/v1/modules", tags=["모듈 카탈로그 (Gen 2)"])


# ─────────────────────────────────────────────────────────
# 요청/응답 스키마
# ─────────────────────────────────────────────────────────

class FloorPlanRequest(BaseModel):
    parcel_width_m: float
    parcel_depth_m: float
    module_type: str = "BALCONY-2"
    corridor_shared: bool = True


class CostEstimateRequest(BaseModel):
    total_units: int
    module_type: str = "BALCONY-2"
    region: str = "수도권"


class MixRecommendRequest(BaseModel):
    target_units: int
    preferred_lh_type: Optional[str] = None
    require_balcony: bool = False
    require_wide_corridor: bool = False


# ─────────────────────────────────────────────────────────
# 엔드포인트
# ─────────────────────────────────────────────────────────

@router.get("/", summary="전체 모듈 목록 조회")
async def list_modules(
    transportable_only: bool = Query(False, description="운송 가능(≤9600mm) 모듈만")
):
    """
    Gen 2 전체 모듈 카탈로그 반환
    - 모듈 사양, 면적, LH 대응 타입, 사업성 정보 포함
    """
    if transportable_only:
        modules = module_catalog.get_transportable_modules()
    else:
        modules = module_catalog.get_all_modules()

    return {
        "count": len(modules),
        "transport_limit_mm": 9600,
        "column_size": "SQ-Pipe 150×150mm",
        "module_width_fixed_mm": 3200,
        "centerline_width_mm": 3050,
        "modules": [
            {
                "module_type": m.module_type.value,
                "width_mm": m.width_mm,
                "length_mm": m.length_mm,
                "bath_length_mm": m.bath_length_mm,
                "room_length_mm": m.room_length_mm,
                "balcony_length_mm": m.balcony_length_mm,
                "corridor_length_mm": m.corridor_length_mm,
                "corridor_type": m.corridor_type.value if m.corridor_type else None,
                "building_area_m2": m.building_area_m2,
                "net_area_m2": m.net_area_m2,
                "gross_area_m2": m.gross_area_m2,
                "lh_type_match": m.lh_type_match.value if m.lh_type_match else None,
                "lh_area_m2": m.lh_area_m2,
                "area_advantage_m2": m.area_advantage_m2,
                "factory_assembly": m.factory_assembly,
                "transport_feasible": m.transport_feasible,
                "wet_joint_required": m.wet_joint_required,
                "cost_index": m.cost_index,
                "description": m.description,
                "notes": m.notes,
            }
            for m in modules
        ],
        "shaft_spec": {
            "width_mm": STANDARD_SHAFT.width_mm,
            "depth_mm": STANDARD_SHAFT.depth_mm,
            "location": STANDARD_SHAFT.location,
            "includes": STANDARD_SHAFT.includes,
            "note": STANDARD_SHAFT.note,
        }
    }


@router.get("/lh-comparison", summary="Gen 2 vs LH 기준 면적 비교")
async def lh_comparison():
    """
    Gen 2 모듈과 LH 주택유형별 면적 비교
    - 19㎡형 / 26㎡형 / 29㎡형 대응 분석
    """
    comparison = module_catalog.compare_with_lh_standard()
    return {
        "comparison": comparison,
        "summary": {
            "19㎡형": {
                "lh_standard_m2": 19.0,
                "gen2_match": "BASIC-1-C1 (전용 21.81㎡) — LH 대비 +2.81㎡ 우수",
            },
            "26㎡형": {
                "lh_standard_m2": 26.0,
                "gen2_match": "BASIC-4-C1 (전용 26.69㎡) — LH 기준 충족",
            },
            "29㎡형": {
                "lh_standard_m2": 29.0,
                "gen2_match": "BALCONY-2/3 (전용 28.82㎡) — LH 대비 -0.18㎡ 근접",
            },
        },
        "gen2_advantages": [
            "기둥 150×150mm → LH 기준 대비 전용면적 0.5~0.9평 추가 확보",
            "9600mm 운송한도로 발코니 완전공장조립 가능 (현장습식조인트 불필요)",
            "3200mm 균일 그리드 → BIM 자동화 속도·정확도 향상",
        ]
    }


@router.get("/{module_type}", summary="특정 모듈 상세 조회")
async def get_module_detail(module_type: str):
    """특정 모듈 타입의 상세 사양 반환"""
    # ModuleType 변환
    try:
        mt = ModuleType(module_type)
    except ValueError:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail=f"모듈 타입 '{module_type}' 없음")

    spec = module_catalog.get_module(mt)
    if not spec:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail=f"모듈 '{module_type}' 정보 없음")

    return {
        "module_type": spec.module_type.value,
        "dimensions": {
            "width_mm": spec.width_mm,
            "length_mm": spec.length_mm,
            "centerline_width_mm": spec.centerline_width_mm,
            "column_size": spec.column_size_mm,
        },
        "block_composition": {
            "bath_length_mm": spec.bath_length_mm,
            "room_length_mm": spec.room_length_mm,
            "balcony_length_mm": spec.balcony_length_mm,
            "corridor_length_mm": spec.corridor_length_mm,
            "corridor_type": spec.corridor_type.value if spec.corridor_type else None,
            "description": spec.description,
        },
        "areas": {
            "building_area_m2": spec.building_area_m2,
            "net_area_m2": spec.net_area_m2,
            "gross_area_m2": spec.gross_area_m2,
            "area_formula": f"3.05 × ({spec.length_mm/1000:.3f}m - 0.15m) = {spec.building_area_m2}㎡",
        },
        "lh_matching": {
            "lh_type": spec.lh_type_match.value if spec.lh_type_match else None,
            "lh_standard_area_m2": spec.lh_area_m2,
            "area_advantage_m2": spec.area_advantage_m2,
            "assessment": (
                "우수" if spec.net_area_m2 > spec.lh_area_m2 else
                "근접" if abs(spec.net_area_m2 - spec.lh_area_m2) < 2 else "부족"
            ),
        },
        "production": {
            "factory_assembly": spec.factory_assembly,
            "transport_feasible": spec.transport_feasible,
            "transport_limit_mm": 9600,
            "wet_joint_required": spec.wet_joint_required,
            "cost_index": spec.cost_index,
        },
        "notes": spec.notes,
    }


@router.post("/floor-plan", summary="층별 배치 계획 계산")
async def calculate_floor_plan(req: FloorPlanRequest):
    """
    필지 크기와 모듈 타입으로 층별 배치 계획 계산
    """
    try:
        mt = ModuleType(req.module_type)
    except ValueError:
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail=f"잘못된 모듈 타입: {req.module_type}")

    result = module_catalog.calculate_floor_plan(
        req.parcel_width_m,
        req.parcel_depth_m,
        mt,
        req.corridor_shared,
    )
    return result


@router.post("/cost-estimate", summary="사업비 개산 견적")
async def estimate_cost(req: CostEstimateRequest):
    """
    세대수 및 모듈 타입 기준 사업비 개산 견적
    (LH 매입가 기준, 토지비 미포함)
    """
    try:
        mt = ModuleType(req.module_type)
    except ValueError:
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail=f"잘못된 모듈 타입: {req.module_type}")

    result = module_catalog.estimate_project_cost(
        req.total_units, mt, req.region
    )
    return result


@router.post("/recommend-mix", summary="최적 모듈 조합 추천")
async def recommend_module_mix(req: MixRecommendRequest):
    """
    세대수와 조건에 따른 Gen 2 최적 모듈 조합 추천
    """
    lh_type = None
    if req.preferred_lh_type:
        try:
            lh_type = LHUnitType(req.preferred_lh_type)
        except ValueError:
            pass

    recommendations = module_catalog.recommend_module_mix(
        req.target_units,
        lh_type,
        req.require_balcony,
        req.require_wide_corridor,
    )

    return {
        "target_units": req.target_units,
        "recommendations": [
            {
                "module_type": spec.module_type.value,
                "unit_count": count,
                "unit_ratio_pct": round(count / req.target_units * 100, 1),
                "net_area_m2": spec.net_area_m2,
                "lh_type_match": spec.lh_type_match.value if spec.lh_type_match else None,
                "transport_feasible": spec.transport_feasible,
                "notes": spec.notes,
            }
            for spec, count in recommendations
        ],
        "gen2_strategy": (
            "BALCONY-2를 40% 이상 편성하여 고품질 LH 29㎡형 세대 구성 권장. "
            "잔여 세대는 BASIC-1-C1(19㎡형)으로 소형 채움"
        ),
    }
