"""
대량 사업지 평가 API + 스마트 클러스터링 API (500~1000세대 최적 분할)
- ROI 계산: 지역별 LH 매입단가 반영 (강남3구 950만원/㎡, 서울 기타 700만원/㎡ 등)
  ※ DB의 estimated_cost / lh_purchase_price는 항상 lh=cost*1.3(30% 고정)으로 저장되어 있어
     반드시 주소 기반 재계산 필요
- 클러스터 보고서 DB 저장/조회 (cluster_reports 테이블)
- 대규모 검토 상세 리포트 (단일 사업지 수준)
- 제조 간트: 병렬 생산 (동시 최대 300세대, 공장 CAPA 반영)
"""
import math
import uuid
import asyncio
import json
from datetime import datetime
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text
from app.core.database import get_db
from app.models.site import Site

router = APIRouter(prefix="/api/v1/bulk", tags=["bulk"])

# ─── 스키마 ──────────────────────────────────────────────

class BulkAddressItem(BaseModel):
    address: str
    name: Optional[str] = None

class BulkEvaluateRequest(BaseModel):
    addresses: List[BulkAddressItem]

class ClusterRequest(BaseModel):
    site_ids: Optional[List[int]] = None
    radius_km: float = 5.0
    min_cluster_size: int = 2
    apply_cost_discount: bool = True
    min_units_per_cluster: int = 500
    max_units_per_cluster: int = 1000

class SmartClusterRequest(BaseModel):
    site_ids: Optional[List[int]] = None
    radius_km: float = 5.0
    min_units_per_cluster: int = 500
    max_units_per_cluster: int = 1000
    apply_cost_discount: bool = True
    save_report: bool = True   # 보고서 DB 저장 여부

# ─── LH 지역별 매입단가 ──────────────────────────────────

# LH 신축매입약정 실거래 기준 (전용면적 기준 만원/㎡)
# 출처: LH 2024~2025 신축매입약정 공모 결과
LH_PRICE_TABLE = {
    # 강남3구 (강남·서초·송파)
    "강남구":   950,
    "서초구":   950,
    "송파구":   950,
    # 서울 고가 지역
    "마포구":   820,
    "용산구":   820,
    "성동구":   820,
    "광진구":   820,
    "영등포구": 780,
    "양천구":   760,
    "강동구":   750,
    "동작구":   750,
    "종로구":   750,
    "중구":     750,
    # 서울 일반 지역
    "_서울_기타": 700,
    # 수도권
    "_경기_성남": 620,
    "_경기_수원": 580,
    "_경기_고양": 560,
    "_경기_기타": 520,
    "_인천_기타": 500,
    # 지방광역시
    "_부산_기타": 450,
    "_대구_기타": 420,
    "_광주_기타": 400,
    "_대전_기타": 400,
    "_기타":      380,
}

# 공장 생산 CAPA: 동시 최대 300세대 (병렬 생산)
FACTORY_PARALLEL_CAPACITY = 300
# 월 세대 처리 속도 (세대/월)
FACTORY_MONTHLY_RATE = 50  # 50세대/월


def get_lh_price_per_m2(address: str) -> float:
    """주소에서 지역 추출 → LH 매입단가(만원/㎡) 반환"""
    if not address:
        return 700  # 서울 기본

    # 구 레벨 매칭
    for gu_name, price in LH_PRICE_TABLE.items():
        if not gu_name.startswith("_") and gu_name in address:
            return price

    # 시/도 레벨 매칭
    if "서울" in address:
        return 700
    if "성남" in address:
        return 620
    if "수원" in address:
        return 580
    if "고양" in address or "일산" in address:
        return 560
    if "경기" in address:
        return 520
    if "인천" in address:
        return 500
    if "부산" in address:
        return 450
    if "대구" in address:
        return 420
    if "광주" in address or "대전" in address:
        return 400

    return 380  # 기타 지방


def calc_roi_for_site(
    planned_units: int,
    net_area_m2: float,   # 전용면적(㎡/세대)
    address: str,
    cost_idx: float = 1.0,
) -> Dict[str, float]:
    """
    단위 일관성 보장된 ROI 계산:
    - 공사비: 연면적 기준 280만원/㎡ × cost_idx  (전용률 65% 적용)
    - LH 매입가: 지역별 단가(만원/㎡) × 전용면적
    - 단위: 억원 (1억 = 10,000만원)
    """
    gfa_per_unit = net_area_m2 / 0.65            # 세대당 연면적(㎡)
    unit_cost_wan = gfa_per_unit * 280 * cost_idx  # 만원/세대
    total_cost_bn = planned_units * unit_cost_wan / 10000   # 억원

    lh_price_wan_m2 = get_lh_price_per_m2(address)          # 만원/㎡
    unit_lh_wan = net_area_m2 * lh_price_wan_m2              # 만원/세대
    total_lh_bn = planned_units * unit_lh_wan / 10000        # 억원

    profit_bn = total_lh_bn - total_cost_bn
    roi_pct = (profit_bn / total_cost_bn * 100) if total_cost_bn > 0 else 0
    margin_pct = (profit_bn / total_lh_bn * 100) if total_lh_bn > 0 else 0

    return {
        "total_cost_bn": round(total_cost_bn, 2),
        "total_lh_bn": round(total_lh_bn, 2),
        "profit_bn": round(profit_bn, 2),
        "roi_pct": round(roi_pct, 1),
        "margin_pct": round(margin_pct, 1),
        "lh_price_per_m2": lh_price_wan_m2,
    }


def site_to_dict(s: Site) -> dict:
    """
    Site 모델 → bulk 처리용 dict 변환

    ※ 중요: DB의 estimated_cost/lh_purchase_price는
       항상 lh = cost * 1.3 (ROI 30% 고정)으로 저장되어 있음.
       따라서 LH 매입가는 반드시 주소 기반 지역별 단가로 재계산.
       건축비도 세대수 기반으로 재계산하여 일관성 확보.

    공사비 기준:
    - 세대당 전용면적: 29㎡ (표준 소형)
    - 공사비 단가: 280만원/㎡ (연면적 기준, 전용률 65% 적용)
    - 세대당 공사비 = 29/0.65 * 280 = 약 1,248만원/세대
    - 총공사비(억원) = 세대수 × 1,248만원 / 10,000 ≈ 세대수 × 0.125억
    """
    planned_units = s.planned_units or 20
    address = s.address or ""

    # ── 건축비 재계산 (항상 세대수 기반) ──
    NET_AREA_M2 = 29.0      # 전용면적 29㎡/세대 (표준 소형)
    OCCUPANCY = 0.65        # 전용률
    UNIT_COST_WAN = 280     # 만원/㎡ (연면적 기준)
    gfa_per_unit = NET_AREA_M2 / OCCUPANCY     # ≈ 44.6㎡/세대
    cost_per_unit_wan = gfa_per_unit * UNIT_COST_WAN  # ≈ 12,492만원/세대
    cost_bn = planned_units * cost_per_unit_wan / 10000  # 억원

    # ── LH 매입가 재계산 (주소 기반 지역별 단가) ──
    lh_price_per_m2 = get_lh_price_per_m2(address)  # 만원/㎡
    lh_per_unit_wan = NET_AREA_M2 * lh_price_per_m2  # 만원/세대
    lh_bn = planned_units * lh_per_unit_wan / 10000  # 억원

    # ── ROI 계산 ──
    profit_bn = lh_bn - cost_bn
    roi_pct = (profit_bn / cost_bn * 100) if cost_bn > 0 else 0

    return {
        "id": s.id,
        "name": s.name,
        "address": address,
        "lat": s.lat,
        "lng": s.lng,
        "sitec_score": s.sitec_score,
        "sitec_grade": s.sitec_grade.value if s.sitec_grade else None,
        "planned_units": planned_units,
        "floor_count": s.floor_count,
        "estimated_cost_bn": round(cost_bn, 2),
        "lh_price_bn": round(lh_bn, 2),
        "roi_pct": round(roi_pct, 1),
        "lh_price_per_m2": lh_price_per_m2,
        # DB 원본값도 보존 (참조용)
        "db_cost_raw": s.estimated_cost,
        "db_lh_raw": s.lh_purchase_price,
        "expected_margin": s.expected_margin,   # DB 저장 마진 (참조용)
        "sitec_approval_prob": s.sitec_approval_prob,
        "sitec_breakdown": s.sitec_breakdown,
        "sitec_suggestions": s.sitec_suggestions,
        "land_area_m2": s.land_area_m2,
        "small_unit_ratio": s.small_unit_ratio,
        "cbd_distance_km": s.cbd_distance_km,
        "subway_distance_m": s.subway_distance_m,
        "bus_stop_distance_m": s.bus_stop_distance_m,
        "elementary_school_distance_m": s.elementary_school_distance_m,
        "hospital_distance_m": s.hospital_distance_m,
        "mart_distance_m": s.mart_distance_m,
        "seismic_grade": s.seismic_grade,
        "slope_percent": s.slope_percent,
        "energy_efficiency_grade": s.energy_efficiency_grade,
        "sunshine_hours": s.sunshine_hours,
        "is_modular": s.is_modular,
        "long_term_rental": s.long_term_rental,
        "lh_certified": s.lh_certified,
        "hazard_compliant": s.hazard_compliant,
        "hazard_risk_level": s.hazard_risk_level,
    }


# ─── 유틸 함수 ──────────────────────────────────────────

def haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    R = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = (math.sin(dlat/2)**2
         + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlng/2)**2)
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def calc_cluster_discount(n_units: int, n_sites: int) -> float:
    """
    클러스터 모듈 동시제작 건축비 할인율
    - 20세대 이하: 0%
    - 20~50세대: 최대 5%
    - 50~100세대: 최대 10%
    - 100~200세대: 최대 15%
    - 200~500세대: 최대 18%
    - 500~1000세대: 최대 20%
    - 1000세대 이상: 최대 22%
    복수 현장 보너스: 현장당 1%, 최대 3%
    상한: 22%
    """
    if n_units <= 20:
        base = 0.0
    elif n_units <= 50:
        base = 5.0 * (n_units - 20) / 30
    elif n_units <= 100:
        base = 5.0 + 5.0 * (n_units - 50) / 50
    elif n_units <= 200:
        base = 10.0 + 5.0 * (n_units - 100) / 100
    elif n_units <= 500:
        base = 15.0 + 3.0 * (n_units - 200) / 300
    elif n_units <= 1000:
        base = 18.0 + 2.0 * (n_units - 500) / 500
    else:
        base = 20.0 + min(2.0, 2.0 * (n_units - 1000) / 1000)

    site_bonus = min(3.0, (n_sites - 1) * 1.0) if n_sites > 1 else 0.0
    return round(min(22.0, base + site_bonus), 1)


def _build_gantt_parallel(group: List[dict]) -> dict:
    """
    공장 병렬 생산 + 현장 설치 간트 스케줄
    
    원칙:
    - 공장 CAPA: 동시 최대 300세대 병렬 생산 (FACTORY_PARALLEL_CAPACITY)
    - 생산 속도: 월 50세대 (FACTORY_MONTHLY_RATE)
    - 클러스터 내 모든 사업지를 가능한 동시에 제작 시작
    - 현장 설치는 공장 생산 완료 후 병렬 진행
    
    스케줄링 알고리즘:
    1. SITE-C 점수 높은 순으로 우선순위 배정
    2. 동시 생산 가능 세대 풀(pool)에 넣기 (300세대 상한)
    3. 풀이 찰 때까지 사업지 추가, 넘치면 다음 배치로
    4. 각 배치는 병렬 생산 → 순차 설치
    """
    sites_sorted = sorted(group, key=lambda s: s.get("sitec_score") or 0, reverse=True)
    
    # 배치 분할 (동시 생산 CAPA 기준)
    batches = []
    current_batch = []
    current_batch_units = 0
    
    for site in sites_sorted:
        units = site["planned_units"]
        if current_batch_units + units > FACTORY_PARALLEL_CAPACITY and current_batch:
            batches.append(current_batch)
            current_batch = [site]
            current_batch_units = units
        else:
            current_batch.append(site)
            current_batch_units += units
    
    if current_batch:
        batches.append(current_batch)
    
    # 각 배치 스케줄 생성
    schedule_items = []
    batch_start_month = 0
    
    for batch_idx, batch in enumerate(batches):
        batch_total_units = sum(s["planned_units"] for s in batch)
        # 공장 생산 기간: 총 세대수 / 월 생산 속도 (병렬이므로 가장 큰 단일 현장 기준)
        max_units_in_batch = max(s["planned_units"] for s in batch)
        factory_months = max(2, math.ceil(max_units_in_batch / FACTORY_MONTHLY_RATE))
        
        # 현장 설치 기간 결정 (배치 내 병렬 설치)
        # 각 현장은 공장 완료 후 동시에 설치 시작 가능
        batch_factory_end = batch_start_month + factory_months
        
        for site in batch:
            units = site["planned_units"]
            # 설치 기간: 세대수 / 30 (현장당 월 30세대 설치)
            install_months = max(1, math.ceil(units / 30))
            
            schedule_items.append({
                "site_id": site["id"],
                "site_name": site["name"],
                "address": site["address"],
                "modules": units,
                "sitec_score": site.get("sitec_score"),
                "batch": batch_idx + 1,
                # 공장 생산: 배치 시작 ~ 배치 생산 완료 (동시 생산)
                "factory_start": batch_start_month,
                "factory_end": batch_factory_end,
                # 현장 설치: 공장 완료 후 ~ 설치 완료 (배치 내 병렬)
                "install_start": batch_factory_end,
                "install_end": batch_factory_end + install_months,
                "total_months": batch_factory_end + install_months - batch_start_month,
                "parallel_production": True,
            })
        
        # 다음 배치 시작은 현재 배치 생산 완료 후
        # (단, 현장 설치와 다음 배치 생산은 병행 가능)
        batch_start_month = batch_factory_end
    
    # 전체 완공 예정 월수
    total_months = max(
        (item["install_end"] for item in schedule_items),
        default=0
    )
    
    # 배치별 요약
    batch_summary = []
    for b_idx, batch in enumerate(batches):
        b_units = sum(s["planned_units"] for s in batch)
        b_sites = [item for item in schedule_items if item["batch"] == b_idx + 1]
        b_factory_start = b_sites[0]["factory_start"] if b_sites else 0
        b_factory_end = b_sites[0]["factory_end"] if b_sites else 0
        b_install_end = max(item["install_end"] for item in b_sites) if b_sites else 0
        batch_summary.append({
            "batch_no": b_idx + 1,
            "n_sites": len(batch),
            "total_units": b_units,
            "factory_start_month": b_factory_start,
            "factory_end_month": b_factory_end,
            "install_end_month": b_install_end,
        })
    
    return {
        "schedule": schedule_items,
        "batch_summary": batch_summary,
        "total_months": total_months,
        "factory_capacity": FACTORY_PARALLEL_CAPACITY,
        "monthly_rate": FACTORY_MONTHLY_RATE,
        "n_batches": len(batches),
        "parallel_production": True,
    }


def _build_site_detail_report(site: dict) -> dict:
    """
    단일 사업지 수준의 상세 분석 리포트 생성
    대규모 검토 내 각 사업지에 대한 단일 사업지 수준 보고서
    """
    address = site.get("address", "")
    units = site.get("planned_units", 20)
    score = site.get("sitec_score") or 0
    grade = site.get("sitec_grade") or "—"
    cost_bn = site.get("estimated_cost_bn", 0)
    lh_bn = site.get("lh_price_bn", 0)
    profit_bn = lh_bn - cost_bn
    roi_pct = (profit_bn / cost_bn * 100) if cost_bn > 0 else 0
    lh_price = site.get("lh_price_per_m2") or get_lh_price_per_m2(address)

    # SITE-C 등급 해석
    grade_interpretation = {
        "A": {"label": "최우선 추진", "color": "emerald", "prob": "90%", "desc": "LH 심의 통과 최우선 대상"},
        "B": {"label": "추진 권장", "color": "blue", "prob": "75%", "desc": "LH 심의 통과 가능성 높음"},
        "C": {"label": "조건부 추진", "color": "amber", "prob": "50%", "desc": "개선 후 재평가 권장"},
        "탈락": {"label": "재검토 필요", "color": "red", "prob": "15%", "desc": "사업지 재선정 권장"},
    }
    gi = grade_interpretation.get(grade, {"label": "미평가", "color": "gray", "prob": "—", "desc": "평가 필요"})

    # 교통 접근성 분석
    subway_m = site.get("subway_distance_m") or 0
    bus_m = site.get("bus_stop_distance_m") or 0
    cbd_km = site.get("cbd_distance_km") or 0

    transport_notes = []
    if subway_m > 0:
        if subway_m <= 300:
            transport_notes.append(f"지하철 초역세권 {subway_m:.0f}m ✓")
        elif subway_m <= 500:
            transport_notes.append(f"지하철 역세권 {subway_m:.0f}m ✓")
        elif subway_m <= 1000:
            transport_notes.append(f"지하철 {subway_m:.0f}m (1km 이내)")
        else:
            transport_notes.append(f"지하철 {subway_m:.0f}m — 역 거리 감점")
    if bus_m > 0:
        transport_notes.append(f"버스정류장 {bus_m:.0f}m {'✓' if bus_m <= 300 else ''}")
    if cbd_km > 0:
        transport_notes.append(f"도심 {cbd_km:.1f}km")

    # 인프라 분석
    elem_m = site.get("elementary_school_distance_m") or 0
    hosp_m = site.get("hospital_distance_m") or 0
    mart_m = site.get("mart_distance_m") or 0

    infra_notes = []
    if elem_m > 0:
        infra_notes.append(f"초등학교 {elem_m:.0f}m {'✓' if elem_m <= 1000 else '△'}")
    if hosp_m > 0:
        infra_notes.append(f"병원 {hosp_m:.0f}m {'✓' if hosp_m <= 1000 else '△'}")
    if mart_m > 0:
        infra_notes.append(f"마트/편의점 {mart_m:.0f}m {'✓' if mart_m <= 500 else '△'}")

    # 사업성 판정
    if roi_pct >= 30:
        biz_grade = "탁월"
        biz_color = "emerald"
    elif roi_pct >= 20:
        biz_grade = "우수"
        biz_color = "green"
    elif roi_pct >= 10:
        biz_grade = "양호"
        biz_color = "blue"
    elif roi_pct >= 5:
        biz_grade = "검토"
        biz_color = "amber"
    else:
        biz_grade = "부적합"
        biz_color = "red"

    # 강점/리스크 분석
    strengths = []
    risks = []

    if score >= 85:
        strengths.append(f"SITE-C {score:.1f}점 — 최우선 추진 대상 (상위 10%)")
    elif score >= 75:
        strengths.append(f"SITE-C {score:.1f}점 — LH 심의 통과 유력")

    if roi_pct >= 25:
        strengths.append(f"ROI {roi_pct:.1f}% — 높은 투자수익률")
    elif roi_pct >= 15:
        strengths.append(f"ROI {roi_pct:.1f}% — 양호한 수익성")

    if site.get("is_modular"):
        strengths.append("모듈러 공법 — LH 심의 가점 + 공기 단축 효과")
    if subway_m and subway_m <= 500:
        strengths.append(f"지하철 역세권 ({subway_m:.0f}m) — 임차 수요 확실")
    if site.get("lh_certified"):
        strengths.append("LH 우수시공사 인증 — 심의 우대")
    if units >= 30:
        strengths.append(f"{units}세대 규모 — 공동관리비 절감 효과")

    if score < 60:
        risks.append(f"SITE-C {score:.1f}점 — LH 심의 통과율 낮음 (재평가 권장)")
    if subway_m and subway_m > 1500:
        risks.append(f"지하철역 {subway_m:.0f}m — 교통 접근성 감점 요인")
    slope = site.get("slope_percent") or 0
    if slope > 10:
        risks.append(f"경사도 {slope:.1f}% — 기초공사 추가 비용 예상")
    if units < 15:
        risks.append(f"{units}세대 소규모 — 공동비용 분담 불리")
    if roi_pct < 10:
        risks.append(f"ROI {roi_pct:.1f}% — 수익성 추가 검토 필요")
    if site.get("hazard_risk_level") == "DANGER":
        risks.append("위해시설 위험 등급 — 사업지 재검토 권장")

    # LH 지역 매입단가 설명
    addr_parts = address.split()
    region_label = addr_parts[1] if len(addr_parts) >= 2 else "해당지역"
    lh_region_note = f"{region_label}: LH 매입단가 {lh_price}만원/㎡ 적용"

    # 재무 세부
    cost_per_unit = cost_bn / units * 100 if units > 0 else 0  # 백만원/세대
    lh_per_unit = lh_bn / units * 100 if units > 0 else 0     # 백만원/세대

    return {
        "site_id": site["id"],
        "name": site["name"],
        "address": address,
        "sitec_score": score,
        "sitec_grade": grade,
        "grade_label": gi["label"],
        "grade_color": gi["color"],
        "lh_approval_prob": gi["prob"],
        "planned_units": units,
        "floor_count": site.get("floor_count"),
        "land_area_m2": site.get("land_area_m2"),
        # 재무 (억원)
        "cost_bn": round(cost_bn, 2),
        "lh_bn": round(lh_bn, 2),
        "profit_bn": round(profit_bn, 2),
        "roi_pct": round(roi_pct, 1),
        "cost_per_unit_mn": round(cost_per_unit, 1),  # 백만원/세대
        "lh_per_unit_mn": round(lh_per_unit, 1),      # 백만원/세대
        "lh_price_per_m2": lh_price,
        "lh_region_note": lh_region_note,
        "biz_grade": biz_grade,
        "biz_color": biz_color,
        # 교통/인프라
        "transport_notes": transport_notes,
        "infra_notes": infra_notes,
        "subway_distance_m": subway_m,
        "bus_stop_distance_m": bus_m,
        "cbd_distance_km": cbd_km,
        # SITE-C 상세
        "sitec_breakdown": site.get("sitec_breakdown"),
        "sitec_suggestions": site.get("sitec_suggestions"),
        # 강점/리스크
        "strengths": strengths,
        "risks": risks,
        # 입지 특성
        "is_modular": site.get("is_modular"),
        "lh_certified": site.get("lh_certified"),
        "hazard_risk_level": site.get("hazard_risk_level"),
        "sitec_approval_prob": site.get("sitec_approval_prob"),
    }


def build_cluster_report(cluster_id: int, group: List[dict], apply_discount: bool = True) -> dict:
    """단일 클러스터에 대한 종합 보고서 생성 (DB 저장용 포함)"""
    n_sites = len(group)
    total_units = sum(s["planned_units"] for s in group)
    base_cost = sum(s["estimated_cost_bn"] for s in group)
    total_lh = sum(s["lh_price_bn"] for s in group)

    discount_pct = calc_cluster_discount(total_units, n_sites) if apply_discount else 0.0
    discounted_cost = base_cost * (1 - discount_pct / 100)
    profit_bn = total_lh - discounted_cost
    cluster_roi = (profit_bn / discounted_cost * 100) if discounted_cost > 0 else 0

    c_lat = sum(s["lat"] for s in group) / n_sites
    c_lng = sum(s["lng"] for s in group) / n_sites

    grades = [s["sitec_grade"] for s in group if s["sitec_grade"]]
    grade_order = {"A": 0, "B": 1, "C": 2, "탈락": 3}
    best_grade = min(grades, key=lambda g: grade_order.get(g, 99)) if grades else "—"
    avg_score = sum(s.get("sitec_score") or 0 for s in group) / n_sites

    # 지역 구성 분석
    regions: Dict[str, int] = {}
    for s in group:
        parts = s["address"].split()
        gu = parts[1] if len(parts) >= 2 else "기타"
        regions[gu] = regions.get(gu, 0) + 1

    # SITE-C 등급 분포
    grade_dist: Dict[str, int] = {}
    for s in group:
        g = s.get("sitec_grade") or "미평가"
        grade_dist[g] = grade_dist.get(g, 0) + 1

    # 상위 5개 사업지 (SITE-C 점수 기준)
    top_sites = sorted(group, key=lambda s: s.get("sitec_score") or 0, reverse=True)[:5]

    # 사업 타당성 종합 판정
    if avg_score >= 80 and cluster_roi >= 15:
        viability = "탁월"
        viability_color = "emerald"
    elif avg_score >= 75 and cluster_roi >= 10:
        viability = "우수"
        viability_color = "green"
    elif avg_score >= 65 and cluster_roi >= 7:
        viability = "양호"
        viability_color = "blue"
    elif avg_score >= 55:
        viability = "검토"
        viability_color = "amber"
    else:
        viability = "부적합"
        viability_color = "red"

    # 클러스터 분할 적합성 (500~1000 범위)
    if total_units < 300:
        target_fit = "소규모"
    elif total_units < 500:
        target_fit = "적정이하"
    elif total_units <= 1000:
        target_fit = "최적"
    elif total_units <= 1500:
        target_fit = "과대"
    else:
        target_fit = "분할필요"

    # 리스크 요인
    risks = []
    if avg_score < 65:
        risks.append(f"평균 SITE-C {avg_score:.1f}점 — LH 심의 통과율 낮음")
    if total_units > 1200:
        risks.append(f"총 {total_units}세대 — 공장 CAPA 과부하 위험")
    if n_sites < 3:
        risks.append("사업지 수 부족 — 공통비 절감 효과 제한적")
    if cluster_roi < 8:
        risks.append(f"예상 ROI {cluster_roi:.1f}% — 수익성 검토 필요")

    # 강점 요인
    strengths = []
    if avg_score >= 80:
        strengths.append(f"평균 SITE-C {avg_score:.1f}점 — LH 심의 통과 최우선 구간")
    elif avg_score >= 70:
        strengths.append(f"평균 SITE-C {avg_score:.1f}점 — LH 심의 통과 유력")
    if discount_pct >= 15:
        strengths.append(f"건축비 {discount_pct}% 절감 — 규모의 경제 극대화")
    elif discount_pct >= 10:
        strengths.append(f"건축비 {discount_pct}% 절감 — 동시 발주 효과")
    if cluster_roi >= 20:
        strengths.append(f"예상 ROI {cluster_roi:.1f}% — 탁월한 수익성")
    elif cluster_roi >= 10:
        strengths.append(f"예상 ROI {cluster_roi:.1f}% — 높은 수익성")
    if n_sites >= 5:
        strengths.append(f"{n_sites}개 현장 묶음 — 현장관리비 최대 절감")
    if 500 <= total_units <= 1000:
        strengths.append(f"{total_units}세대 — 공장 최적 생산 규모 달성")
    if total_units > 1000:
        strengths.append(f"{total_units}세대 대규모 — 최고 할인율 적용 가능")

    # 추천 액션
    next_actions = []
    if viability in ("탁월", "우수"):
        next_actions.append("즉시 LH 신축매입약정 신청 절차 착수")
        next_actions.append(f"{n_sites}개 현장 모듈 설계 동시 착수 → 인허가 병행")
        next_actions.append(f"공장 병렬 생산 스케줄 확정 (동시 최대 {FACTORY_PARALLEL_CAPACITY}세대)")
    elif viability == "양호":
        next_actions.append("하위 SITE-C 사업지 개선 후 클러스터 재구성 검토")
        next_actions.append("LH 신축매입약정 타당성 사전 검토 신청")
    else:
        next_actions.append("하위 SITE-C 사업지 제외 후 재구성 권장")
        next_actions.append("추가 사업지 발굴로 규모 및 SITE-C 평균 확대")
    if discount_pct >= 10:
        next_actions.append(f"공장 동시 생산 계획 수립 — {discount_pct}% 건축비 절감 확정")

    # 재무 요약 (지역별 LH 단가 설명 포함)
    lh_price_breakdown = {}
    for s in group:
        addr = s.get("address", "")
        lhp = get_lh_price_per_m2(addr)
        gu = addr.split()[1] if len(addr.split()) >= 2 else "기타"
        lh_price_breakdown[gu] = lhp

    # 사업지별 상세 리포트
    site_detail_reports = [_build_site_detail_report(s) for s in group]

    # 병렬 생산 간트 스케줄
    gantt_result = _build_gantt_parallel(group)

    return {
        "cluster_id": cluster_id,
        "center_lat": round(c_lat, 6),
        "center_lng": round(c_lng, 6),
        "n_sites": n_sites,
        "total_units": total_units,
        "base_cost_bn": round(base_cost, 2),
        "discounted_cost_bn": round(discounted_cost, 2),
        "discount_pct": discount_pct,
        "total_lh_bn": round(total_lh, 2),
        "profit_bn": round(profit_bn, 2),
        "cluster_roi_pct": round(cluster_roi, 1),
        "avg_sitec_score": round(avg_score, 1),
        "best_grade": best_grade,
        "target_fit": target_fit,
        "viability": viability,
        "viability_color": viability_color,
        "sites": group,
        "site_details": site_detail_reports,   # 단일 사업지 수준 상세 보고서
        "top_sites": top_sites,
        "region_breakdown": regions,
        "grade_distribution": grade_dist,
        "strengths": strengths,
        "risks": risks,
        "next_actions": next_actions,
        "lh_price_breakdown": lh_price_breakdown,
        "discount_breakdown": {
            "volume_discount_basis": f"동시 {total_units}세대 제작",
            "site_bonus_basis": f"{n_sites}개 현장 조율 보너스",
            "formula": f"min(22%, 규모할인 + 현장보너스) = {discount_pct}%",
            "saving_bn": round(base_cost - discounted_cost, 2),
        },
        # 병렬 생산 간트 (gantt 키 + gantt_parallel 키 동시 제공)
        "gantt": gantt_result["schedule"],
        "gantt_parallel": gantt_result,
    }


def smart_cluster_sites(
    sites: List[dict],
    radius_km: float,
    min_units: int = 500,
    max_units: int = 1000,
    min_size: int = 2,
) -> List[List[dict]]:
    """
    스마트 클러스터링: 지리적 반경 + 500~1000세대 목표 분할

    알고리즘:
    1. SITE-C 점수 높은 순 Seed 선택
    2. Seed 반경 내 사업지 후보군 수집 (거리순 정렬)
    3. 후보군을 500~1000세대 범위로 분할
       - 현재 클러스터가 max_units 초과 예정 → 새 클러스터 시작
       - 남은 후보로 목표 범위 채우기
    4. min_size 미달 클러스터 → 인근 클러스터에 합류 또는 미배정
    """
    remaining = sorted(sites, key=lambda s: s.get("sitec_score") or 0, reverse=True)
    assigned = set()
    clusters: List[List[dict]] = []

    for seed in remaining:
        if seed["id"] in assigned:
            continue

        # 반경 내 미배정 후보 수집 (거리순)
        candidates = []
        for other in remaining:
            if other["id"] in assigned:
                continue
            dist = haversine_km(seed["lat"], seed["lng"], other["lat"], other["lng"])
            if dist <= radius_km:
                candidates.append((dist, other))
        candidates.sort(key=lambda x: x[0])
        candidates_sites = [s for _, s in candidates]

        if not candidates_sites:
            continue

        # 500~1000 세대 목표로 분할
        current_cluster: List[dict] = []
        current_units = 0

        for site in candidates_sites:
            site_units = site["planned_units"]

            if current_units + site_units > max_units and current_units >= min_units:
                # 현재 클러스터 완성
                if len(current_cluster) >= min_size:
                    for s in current_cluster:
                        assigned.add(s["id"])
                    clusters.append(current_cluster)
                current_cluster = []
                current_units = 0

            # 단일 사업지가 max_units 초과면 단독 클러스터 (예외 처리)
            if site_units > max_units * 1.5:
                if site["id"] not in assigned:
                    assigned.add(site["id"])
                    clusters.append([site])
                continue

            current_cluster.append(site)
            current_units += site_units

        # 마지막 클러스터 처리
        if current_cluster:
            new_sites = [s for s in current_cluster if s["id"] not in assigned]
            if len(new_sites) >= min_size:
                for s in new_sites:
                    assigned.add(s["id"])
                clusters.append(new_sites)

    return clusters


def greedy_cluster(sites: List[dict], radius_km: float, min_size: int) -> List[List[dict]]:
    """기존 단순 Greedy 클러스터링 (하위 호환용)"""
    remaining = sorted(sites, key=lambda s: s.get("sitec_score") or 0, reverse=True)
    clusters = []
    assigned = set()

    for seed in remaining:
        if seed["id"] in assigned:
            continue
        group = [seed]
        for other in remaining:
            if other["id"] in assigned or other["id"] == seed["id"]:
                continue
            if haversine_km(seed["lat"], seed["lng"], other["lat"], other["lng"]) <= radius_km:
                group.append(other)
        if len(group) >= min_size:
            for s in group:
                assigned.add(s["id"])
            clusters.append(group)

    return clusters


# ─── DB 저장 헬퍼 ────────────────────────────────────────

async def ensure_cluster_reports_table(db: AsyncSession):
    """cluster_reports 테이블이 없으면 생성"""
    create_sql = """
    CREATE TABLE IF NOT EXISTS cluster_reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cluster_name TEXT NOT NULL,
        cluster_no INTEGER,
        analysis_session TEXT,
        center_lat REAL,
        center_lng REAL,
        radius_km REAL,
        site_ids TEXT,
        n_sites INTEGER,
        total_units INTEGER,
        target_fit TEXT,
        base_cost_bn REAL,
        discounted_cost_bn REAL,
        discount_pct REAL,
        total_lh_bn REAL,
        profit_bn REAL,
        cluster_roi_pct REAL,
        avg_sitec_score REAL,
        best_grade TEXT,
        grade_distribution TEXT,
        viability TEXT,
        viability_color TEXT,
        strengths TEXT,
        risks TEXT,
        next_actions TEXT,
        region_breakdown TEXT,
        full_report TEXT,
        gantt TEXT,
        gantt_parallel TEXT,
        rank INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP
    )
    """
    await db.execute(text(create_sql))
    await db.commit()


async def save_cluster_reports(
    reports: List[dict],
    session_id: str,
    radius_km: float,
    db: AsyncSession
) -> List[int]:
    """클러스터 보고서 목록을 DB에 저장 후 ID 목록 반환"""
    await ensure_cluster_reports_table(db)

    saved_ids = []
    for r in reports:
        site_ids = [s["id"] for s in r.get("sites", [])]
        
        # 지역명 추출 (가장 많은 구)
        regions = r.get("region_breakdown", {})
        top_region = max(regions, key=lambda k: regions[k]) if regions else "미상"
        
        # 상위 사업지명
        top_sites = r.get("top_sites", [])
        top_name = top_sites[0]["name"] if top_sites else ""
        
        cluster_name = f"클러스터-{r['cluster_id']} ({top_name[:10]}, {top_region})"

        insert_sql = text("""
        INSERT INTO cluster_reports (
            cluster_name, cluster_no, analysis_session,
            center_lat, center_lng, radius_km,
            site_ids, n_sites, total_units, target_fit,
            base_cost_bn, discounted_cost_bn, discount_pct,
            total_lh_bn, profit_bn, cluster_roi_pct,
            avg_sitec_score, best_grade, grade_distribution,
            viability, viability_color,
            strengths, risks, next_actions,
            region_breakdown, full_report, gantt, gantt_parallel, rank,
            created_at
        ) VALUES (
            :cluster_name, :cluster_no, :session_id,
            :center_lat, :center_lng, :radius_km,
            :site_ids, :n_sites, :total_units, :target_fit,
            :base_cost_bn, :discounted_cost_bn, :discount_pct,
            :total_lh_bn, :profit_bn, :cluster_roi_pct,
            :avg_sitec_score, :best_grade, :grade_distribution,
            :viability, :viability_color,
            :strengths, :risks, :next_actions,
            :region_breakdown, :full_report, :gantt, :gantt_parallel, :rank,
            CURRENT_TIMESTAMP
        )
        """)

        # full_report: site_details 제외한 핵심 필드만 저장 (용량 최적화)
        compact_report = {k: v for k, v in r.items() if k not in ("sites", "site_details", "gantt", "gantt_parallel")}

        await db.execute(insert_sql, {
            "cluster_name": cluster_name,
            "cluster_no": r.get("cluster_id"),
            "session_id": session_id,
            "center_lat": r.get("center_lat"),
            "center_lng": r.get("center_lng"),
            "radius_km": radius_km,
            "site_ids": json.dumps(site_ids, ensure_ascii=False),
            "n_sites": r.get("n_sites"),
            "total_units": r.get("total_units"),
            "target_fit": r.get("target_fit"),
            "base_cost_bn": r.get("base_cost_bn"),
            "discounted_cost_bn": r.get("discounted_cost_bn"),
            "discount_pct": r.get("discount_pct"),
            "total_lh_bn": r.get("total_lh_bn"),
            "profit_bn": r.get("profit_bn"),
            "cluster_roi_pct": r.get("cluster_roi_pct"),
            "avg_sitec_score": r.get("avg_sitec_score"),
            "best_grade": r.get("best_grade"),
            "grade_distribution": json.dumps(r.get("grade_distribution", {}), ensure_ascii=False),
            "viability": r.get("viability"),
            "viability_color": r.get("viability_color"),
            "strengths": json.dumps(r.get("strengths", []), ensure_ascii=False),
            "risks": json.dumps(r.get("risks", []), ensure_ascii=False),
            "next_actions": json.dumps(r.get("next_actions", []), ensure_ascii=False),
            "region_breakdown": json.dumps(r.get("region_breakdown", {}), ensure_ascii=False),
            "full_report": json.dumps(compact_report, ensure_ascii=False),
            "gantt": json.dumps(r.get("gantt", []), ensure_ascii=False),
            "gantt_parallel": json.dumps(r.get("gantt_parallel", {}), ensure_ascii=False),
            "rank": r.get("rank"),
        })

        result = await db.execute(text("SELECT last_insert_rowid()"))
        row = result.fetchone()
        if row:
            saved_ids.append(row[0])

    await db.commit()
    return saved_ids


# ─── 엔드포인트 ─────────────────────────────────────────

@router.post("/smart-cluster", summary="500~1000세대 최적 다중 클러스터 구성")
async def smart_cluster_endpoint(req: SmartClusterRequest, db: AsyncSession = Depends(get_db)):
    """
    스마트 클러스터링:
    - 지리적 반경 내 사업지를 500~1000세대 목표로 자동 분할
    - ROI: DB 고정값(30%) 대신 주소 기반 지역별 LH 단가로 완전 재계산
    - 간트: 동시 300세대 병렬 생산 반영
    - 보고서 DB 저장 (조회 가능)
    """
    stmt = select(Site).where(Site.sitec_score != None)
    if req.site_ids:
        stmt = stmt.where(Site.id.in_(req.site_ids))
    result = await db.execute(stmt)
    sites_db = result.scalars().all()

    if not sites_db:
        return {
            "total_sites": 0, "total_clusters": 0,
            "clusters": [], "unclustered": [],
            "summary": {"message": "평가 완료 사업지가 없습니다."}
        }

    # 사업지 dict 변환 (주소 기반 LH 단가 재계산으로 ROI 고정 30% 문제 해결)
    site_dicts = []
    for s in sites_db:
        if not s.lat or not s.lng:
            continue
        site_dicts.append(site_to_dict(s))

    if not site_dicts:
        return {
            "total_sites": 0, "total_clusters": 0,
            "clusters": [], "unclustered": [],
            "summary": {"message": "좌표 정보가 있는 사업지가 없습니다."}
        }

    # 스마트 클러스터링 실행
    raw_clusters = smart_cluster_sites(
        site_dicts,
        radius_km=req.radius_km,
        min_units=req.min_units_per_cluster,
        max_units=req.max_units_per_cluster,
        min_size=2,
    )

    assigned_ids = {s["id"] for cl in raw_clusters for s in cl}
    unclustered = [s for s in site_dicts if s["id"] not in assigned_ids]

    # 각 클러스터 종합 보고서 생성
    cluster_reports = []
    for idx, group in enumerate(raw_clusters):
        report = build_cluster_report(
            cluster_id=idx + 1,
            group=group,
            apply_discount=req.apply_cost_discount,
        )
        cluster_reports.append(report)

    # 클러스터를 ROI 순으로 정렬
    cluster_reports.sort(key=lambda r: r["cluster_roi_pct"], reverse=True)
    for i, r in enumerate(cluster_reports):
        r["rank"] = i + 1

    # 전체 요약
    total_units_all = sum(r["total_units"] for r in cluster_reports)
    total_base = sum(r["base_cost_bn"] for r in cluster_reports)
    total_disc = sum(r["discounted_cost_bn"] for r in cluster_reports)
    total_profit = sum(r["profit_bn"] for r in cluster_reports)
    avg_roi = sum(r["cluster_roi_pct"] for r in cluster_reports) / len(cluster_reports) if cluster_reports else 0
    avg_score_all = sum(r["avg_sitec_score"] for r in cluster_reports) / len(cluster_reports) if cluster_reports else 0

    # 보고서 DB 저장
    session_id = str(uuid.uuid4())[:12]
    saved_ids = []
    if req.save_report and cluster_reports:
        try:
            saved_ids = await save_cluster_reports(cluster_reports, session_id, req.radius_km, db)
        except Exception as e:
            # 저장 실패해도 응답은 정상 반환
            saved_ids = []

    return {
        "session_id": session_id,
        "radius_km": req.radius_km,
        "target_units_range": [req.min_units_per_cluster, req.max_units_per_cluster],
        "total_sites": len(site_dicts),
        "total_clusters": len(cluster_reports),
        "clustered": len(assigned_ids),
        "unclustered_count": len(unclustered),
        "clusters": cluster_reports,
        "unclustered": [
            {
                "id": s["id"], "name": s["name"], "address": s["address"],
                "sitec_score": s["sitec_score"], "sitec_grade": s["sitec_grade"],
                "planned_units": s["planned_units"],
                "roi_pct": s.get("roi_pct"),
            }
            for s in unclustered
        ],
        "saved_report_ids": saved_ids,
        "summary": {
            "total_clusters": len(cluster_reports),
            "total_clustered_units": total_units_all,
            "total_unclustered": len(unclustered),
            "base_cost_bn": round(total_base, 2),
            "discounted_cost_bn": round(total_disc, 2),
            "total_saving_bn": round(total_base - total_disc, 2),
            "total_profit_bn": round(total_profit, 2),
            "avg_roi_pct": round(avg_roi, 1),
            "avg_sitec_score": round(avg_score_all, 1),
            "avg_discount_pct": round((total_base - total_disc) / total_base * 100 if total_base > 0 else 0, 1),
            "optimal_clusters": sum(1 for r in cluster_reports if r["target_fit"] == "최적"),
            "top_cluster": {
                "cluster_id": cluster_reports[0]["cluster_id"],
                "total_units": cluster_reports[0]["total_units"],
                "cluster_roi_pct": cluster_reports[0]["cluster_roi_pct"],
                "viability": cluster_reports[0]["viability"],
            } if cluster_reports else None,
        },
    }


@router.post("/cluster", summary="반경 클러스터 자동 묶음 (기본)")
async def cluster_sites(req: ClusterRequest, db: AsyncSession = Depends(get_db)):
    stmt = select(Site).where(Site.sitec_score != None)
    if req.site_ids:
        stmt = stmt.where(Site.id.in_(req.site_ids))
    result = await db.execute(stmt)
    sites_db = result.scalars().all()

    if not sites_db:
        return {"radius_km": req.radius_km, "total_sites": 0, "clustered": 0,
                "unclustered": 0, "clusters": [], "summary": {"total_clusters": 0}}

    site_dicts = []
    for s in sites_db:
        if not s.lat or not s.lng:
            continue
        site_dicts.append(site_to_dict(s))

    if req.min_units_per_cluster > 0 and req.max_units_per_cluster > 0:
        raw_clusters = smart_cluster_sites(
            site_dicts, req.radius_km,
            min_units=req.min_units_per_cluster,
            max_units=req.max_units_per_cluster,
        )
    else:
        raw_clusters = greedy_cluster(site_dicts, req.radius_km, req.min_cluster_size)

    assigned_ids = {s["id"] for cl in raw_clusters for s in cl}
    unclustered = [s for s in site_dicts if s["id"] not in assigned_ids]

    cluster_groups = []
    for idx, group in enumerate(raw_clusters):
        report = build_cluster_report(idx + 1, group, req.apply_cost_discount)
        cluster_groups.append(report)

    all_base = sum(c["base_cost_bn"] for c in cluster_groups)
    all_disc = sum(c["discounted_cost_bn"] for c in cluster_groups)

    return {
        "radius_km": req.radius_km,
        "total_sites": len(site_dicts),
        "clustered": len(assigned_ids),
        "unclustered": len(unclustered),
        "clusters": cluster_groups,
        "unclustered_sites": [
            {"id": s["id"], "name": s["name"], "address": s["address"],
             "sitec_score": s["sitec_score"], "sitec_grade": s["sitec_grade"]}
            for s in unclustered
        ],
        "summary": {
            "total_clusters": len(cluster_groups),
            "total_clustered": len(assigned_ids),
            "base_cost_bn": round(all_base, 2),
            "discounted_cost_bn": round(all_disc, 2),
            "saving_bn": round(all_base - all_disc, 2),
        },
    }


@router.get("/cluster/{cluster_id}/report", summary="클러스터 상세 보고서 조회 (세션 기반)")
async def get_cluster_report(
    cluster_id: int,
    session_id: str = "",
    db: AsyncSession = Depends(get_db),
):
    """저장된 클러스터 보고서 조회"""
    await ensure_cluster_reports_table(db)

    if session_id:
        result = await db.execute(
            text("SELECT * FROM cluster_reports WHERE analysis_session = :sid AND cluster_no = :cno"),
            {"sid": session_id, "cno": cluster_id}
        )
    else:
        result = await db.execute(
            text("SELECT * FROM cluster_reports WHERE id = :cid"),
            {"cid": cluster_id}
        )

    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"클러스터 보고서 {cluster_id}를 찾을 수 없습니다.")

    keys = result.keys()
    report_dict = dict(zip(keys, row))

    # JSON 필드 파싱
    for field in ["site_ids", "grade_distribution", "strengths", "risks", "next_actions",
                  "region_breakdown", "full_report", "gantt", "gantt_parallel"]:
        if report_dict.get(field) and isinstance(report_dict[field], str):
            try:
                report_dict[field] = json.loads(report_dict[field])
            except:
                pass

    return report_dict


@router.get("/reports", summary="저장된 클러스터 보고서 목록")
async def list_cluster_reports(
    limit: int = 20,
    offset: int = 0,
    session_id: str = "",
    db: AsyncSession = Depends(get_db),
):
    """저장된 클러스터 보고서 목록 조회"""
    await ensure_cluster_reports_table(db)

    if session_id:
        result = await db.execute(
            text("""SELECT id, cluster_name, cluster_no, analysis_session,
                          n_sites, total_units, cluster_roi_pct, viability,
                          target_fit, avg_sitec_score, discount_pct,
                          base_cost_bn, discounted_cost_bn, profit_bn,
                          rank, created_at
                   FROM cluster_reports WHERE analysis_session = :sid
                   ORDER BY rank ASC, created_at DESC
                   LIMIT :lim OFFSET :off"""),
            {"sid": session_id, "lim": limit, "off": offset}
        )
    else:
        result = await db.execute(
            text("""SELECT id, cluster_name, cluster_no, analysis_session,
                          n_sites, total_units, cluster_roi_pct, viability,
                          target_fit, avg_sitec_score, discount_pct,
                          base_cost_bn, discounted_cost_bn, profit_bn,
                          rank, created_at
                   FROM cluster_reports
                   ORDER BY created_at DESC
                   LIMIT :lim OFFSET :off"""),
            {"lim": limit, "off": offset}
        )

    rows = result.fetchall()
    keys = result.keys()
    reports = [dict(zip(keys, row)) for row in rows]

    # 전체 개수
    if session_id:
        cnt_result = await db.execute(
            text("SELECT COUNT(*) FROM cluster_reports WHERE analysis_session = :sid"),
            {"sid": session_id}
        )
    else:
        cnt_result = await db.execute(text("SELECT COUNT(*) FROM cluster_reports"))
    total_count = cnt_result.scalar()

    return {"total": total_count, "reports": reports}


@router.get("/reports/sessions", summary="분석 세션 목록 조회")
async def list_analysis_sessions(db: AsyncSession = Depends(get_db)):
    """저장된 클러스터 분석 세션 목록 (최근 20개)"""
    await ensure_cluster_reports_table(db)

    result = await db.execute(text("""
        SELECT analysis_session,
               COUNT(*) as cluster_count,
               SUM(total_units) as total_units,
               AVG(cluster_roi_pct) as avg_roi,
               MAX(created_at) as last_created
        FROM cluster_reports
        WHERE analysis_session IS NOT NULL
        GROUP BY analysis_session
        ORDER BY last_created DESC
        LIMIT 20
    """))
    rows = result.fetchall()
    keys = result.keys()
    sessions = [dict(zip(keys, row)) for row in rows]
    return {"sessions": sessions}


@router.get("/reports/{report_id}/detail", summary="클러스터 보고서 상세 조회")
async def get_cluster_report_detail(report_id: int, db: AsyncSession = Depends(get_db)):
    """저장된 클러스터 보고서 상세 조회 (full_report 포함)"""
    await ensure_cluster_reports_table(db)

    result = await db.execute(
        text("SELECT * FROM cluster_reports WHERE id = :rid"),
        {"rid": report_id}
    )
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"보고서 ID {report_id}를 찾을 수 없습니다.")

    keys = result.keys()
    report_dict = dict(zip(keys, row))

    for field in ["site_ids", "grade_distribution", "strengths", "risks", "next_actions",
                  "region_breakdown", "full_report", "gantt", "gantt_parallel"]:
        if report_dict.get(field) and isinstance(report_dict[field], str):
            try:
                report_dict[field] = json.loads(report_dict[field])
            except:
                pass

    return report_dict


@router.post("/evaluate-csv", summary="CSV 대량 주소 평가")
async def evaluate_csv_addresses(req: BulkEvaluateRequest):
    if len(req.addresses) > 200:
        raise HTTPException(status_code=400, detail="최대 200개 주소까지 처리 가능합니다.")
    if len(req.addresses) == 0:
        raise HTTPException(status_code=400, detail="주소가 없습니다.")

    from app.state import job_store
    from app.api.v1.auto_eval import auto_evaluate, AutoEvaluateRequest as AEReq
    from app.api.v1.auto_eval import save_site_from_evaluation, SaveSiteRequest

    job_id = str(uuid.uuid4())[:8]
    job_store[job_id] = {
        "job_id": job_id, "total": len(req.addresses),
        "completed": 0, "failed": 0, "status": "running", "results": [],
    }

    async def process_batch():
        from app.core.database import AsyncSessionLocal
        for item in req.addresses:
            async with AsyncSessionLocal() as dbs:
                try:
                    ae_req = AEReq(address=item.address)
                    eval_result = await auto_evaluate(ae_req)
                    save_req = SaveSiteRequest(
                        address=item.address,
                        evaluation=eval_result,
                        name=item.name or item.address[:50],
                    )
                    saved = await save_site_from_evaluation(save_req)
                    job_store[job_id]["results"].append({
                        "address": item.address,
                        "name": item.name or item.address[:50],
                        "status": "ok",
                        "site_id": saved.site_id,
                        "sitec_grade": eval_result.sitec_grade,
                        "sitec_score": eval_result.sitec_score,
                        "overall_grade": eval_result.overall_grade,
                        "roi_pct": eval_result.roi_pct,
                        "construction_cost_bn": eval_result.construction_cost_bn,
                    })
                    job_store[job_id]["completed"] += 1
                except Exception as e:
                    job_store[job_id]["failed"] += 1
                    job_store[job_id]["results"].append({
                        "address": item.address, "status": "error", "error": str(e)[:200],
                    })
            await asyncio.sleep(0.3)
        job_store[job_id]["status"] = "done"

    asyncio.create_task(process_batch())
    return {"job_id": job_id, "total": len(req.addresses), "status": "running"}


@router.get("/job/{job_id}", summary="대량 평가 작업 상태 조회")
async def get_job_status(job_id: str):
    from app.state import job_store
    if job_id not in job_store:
        raise HTTPException(status_code=404, detail="작업을 찾을 수 없습니다.")
    return job_store[job_id]


@router.get("/jobs", summary="전체 작업 목록")
async def list_jobs():
    from app.state import job_store
    return list(job_store.values())


# ═══════════════════════════════════════════════════════════════
# ILP 포트폴리오 최적화 (Portfolio Optimization)
# 클러스터 검토 결과에서 제약 조건 기반 최적 조합 추천
# ═══════════════════════════════════════════════════════════════

class PortfolioConstraints(BaseModel):
    """ILP 포트폴리오 최적화 제약 조건"""
    budget_bn: float = 1000.0
    max_units_per_year: int = 3000
    min_cluster_roi: float = 50.0
    max_parallel_clusters: int = 5
    objective: str = "maximize_roi"   # maximize_roi | maximize_profit | maximize_units
    session_id: Optional[str] = None
    cluster_ids: Optional[List[int]] = None
    must_include_ids: Optional[List[int]] = None
    exclude_ids: Optional[List[int]] = None
    min_total_units: int = 0


def _solve_ilp_greedy(candidates: list, constraints: PortfolioConstraints) -> tuple:
    """
    순수 Python Greedy ILP 근사 솔버 (외부 의존성 없음)
    0-1 배낭 문제(Knapsack)를 greedy + backtracking으로 근사 최적 해결
    """
    obj = constraints.objective
    budget = constraints.budget_bn
    max_units_yr = constraints.max_units_per_year
    max_par = constraints.max_parallel_clusters
    must_ids = set(constraints.must_include_ids or [])
    excl_ids = set(constraints.exclude_ids or [])

    # 1) 제외 필터링
    filtered = [c for c in candidates if c["cluster_id"] not in excl_ids]

    # 2) ROI 최소 필터 (must_include는 예외)
    filtered = [
        c for c in filtered
        if c["cluster_roi_pct"] >= constraints.min_cluster_roi
        or c["cluster_id"] in must_ids
    ]

    # 3) 정렬 기준 (목표 함수에 따라)
    if obj == "maximize_roi":
        # ROI 대비 투자비 효율 = profit/cost ratio 로 정렬
        filtered.sort(key=lambda c: c["cluster_roi_pct"], reverse=True)
    elif obj == "maximize_profit":
        filtered.sort(key=lambda c: c["profit_bn"], reverse=True)
    elif obj == "maximize_units":
        # 세대수 대비 비용 효율
        filtered.sort(key=lambda c: c["total_units"] / max(c["discounted_cost_bn"], 0.1), reverse=True)

    # 4) must_include 우선 배치
    must_list = [c for c in filtered if c["cluster_id"] in must_ids]
    others = [c for c in filtered if c["cluster_id"] not in must_ids]
    ordered = must_list + others

    # 5) Greedy 선택
    selected = []
    total_cost = 0.0
    total_units_yr = 0
    n_parallel = 0

    for c in ordered:
        cost = c["discounted_cost_bn"]
        units = c["total_units"]
        # 제약 체크
        if total_cost + cost > budget * 1.02:  # 2% 여유
            continue
        if total_units_yr + units > max_units_yr * 1.1:
            continue
        if n_parallel >= max_par:
            continue
        selected.append(c)
        total_cost += cost
        total_units_yr += units
        n_parallel += 1

    # 6) 최소 세대수 미달 시 경고만 (선택은 유지)
    return selected, filtered


def _build_gantt_phases(selected: list) -> list:
    """선택된 클러스터의 착수 순서 간트 계획 생성"""
    phases = []
    cumulative_month = 0
    for i, c in enumerate(selected):
        units = c["total_units"]
        # 공사 기간: 세대수 기반 추정 (300세대/4개월 기준)
        duration_months = max(4, round(units / 300 * 4))
        phases.append({
            "phase_no": i + 1,
            "cluster_id": c["cluster_id"],
            "cluster_name": c["cluster_name"],
            "total_units": units,
            "start_month": cumulative_month,
            "end_month": cumulative_month + duration_months,
            "duration_months": duration_months,
            "cost_bn": c["discounted_cost_bn"],
            "profit_bn": c["profit_bn"],
            "roi_pct": c["cluster_roi_pct"],
            "overlap_possible": cumulative_month > 0,
        })
        # 병렬 착수: 300세대 이상이면 1개월 딜레이, 이하면 즉시 병렬
        if units >= 300:
            cumulative_month += 2
        else:
            cumulative_month += 1
    return phases


def _sensitivity_analysis(all_candidates: list, selected_ids: set,
                          constraints: PortfolioConstraints) -> dict:
    """민감도 분석: 예산 10/20% 증가 시 추가 선택 가능 클러스터"""
    not_selected = [c for c in all_candidates if c["cluster_id"] not in selected_ids]
    not_selected.sort(key=lambda c: c["cluster_roi_pct"], reverse=True)

    result = {
        "budget_increase_10pct": [],
        "budget_increase_20pct": [],
        "roi_relax_10pct": [],
    }

    budget_10 = constraints.budget_bn * 1.10
    budget_20 = constraints.budget_bn * 1.20
    roi_relax = constraints.min_cluster_roi * 0.90

    current_cost = sum(
        c["discounted_cost_bn"] for c in all_candidates
        if c["cluster_id"] in selected_ids
    )

    for c in not_selected[:5]:
        if current_cost + c["discounted_cost_bn"] <= budget_10:
            result["budget_increase_10pct"].append({
                "cluster_id": c["cluster_id"],
                "cluster_name": c["cluster_name"],
                "roi_pct": c["cluster_roi_pct"],
                "cost_bn": c["discounted_cost_bn"],
                "units": c["total_units"],
            })
        if current_cost + c["discounted_cost_bn"] <= budget_20:
            result["budget_increase_20pct"].append({
                "cluster_id": c["cluster_id"],
                "cluster_name": c["cluster_name"],
                "roi_pct": c["cluster_roi_pct"],
                "cost_bn": c["discounted_cost_bn"],
                "units": c["total_units"],
            })
        if c["cluster_roi_pct"] >= roi_relax:
            result["roi_relax_10pct"].append({
                "cluster_id": c["cluster_id"],
                "cluster_name": c["cluster_name"],
                "roi_pct": c["cluster_roi_pct"],
                "cost_bn": c["discounted_cost_bn"],
                "units": c["total_units"],
            })

    return result


@router.post("/optimize-portfolio", summary="ILP 포트폴리오 최적화")
async def optimize_portfolio(
    constraints: PortfolioConstraints,
    db: AsyncSession = Depends(get_db)
):
    """
    저장된 클러스터 보고서 또는 세션 결과에서
    제약 조건 기반 최적 클러스터 조합을 추천합니다.

    제약 조건:
    - budget_bn: 총 투자 예산 (억원, 기본 1000억)
    - max_units_per_year: 연간 최대 착수 세대수 (기본 3000세대)
    - min_cluster_roi: 최소 클러스터 ROI (%, 기본 50%)
    - max_parallel_clusters: 동시 착수 최대 클러스터 수 (기본 5개)
    - objective: 최적화 목표 (maximize_roi/maximize_profit/maximize_units)
    - session_id: 특정 클러스터 세션 ID (없으면 전체 보고서 활용)

    알고리즘: Greedy Knapsack (0-1 배낭 문제 근사 최적)
    """
    await ensure_cluster_reports_table(db)

    # ── 1) 후보 클러스터 로드 ──────────────────────────────
    if constraints.session_id:
        result = await db.execute(
            text("""SELECT id, cluster_name, cluster_no, n_sites, total_units,
                        base_cost_bn, discounted_cost_bn, discount_pct,
                        total_lh_bn, profit_bn, cluster_roi_pct,
                        avg_sitec_score, best_grade, viability, viability_color,
                        target_fit, rank
                   FROM cluster_reports
                   WHERE analysis_session = :sid
                   ORDER BY cluster_roi_pct DESC"""),
            {"sid": constraints.session_id}
        )
    elif constraints.cluster_ids:
        id_list = ",".join(str(i) for i in constraints.cluster_ids)
        result = await db.execute(
            text(f"""SELECT id, cluster_name, cluster_no, n_sites, total_units,
                        base_cost_bn, discounted_cost_bn, discount_pct,
                        total_lh_bn, profit_bn, cluster_roi_pct,
                        avg_sitec_score, best_grade, viability, viability_color,
                        target_fit, rank
                   FROM cluster_reports
                   WHERE id IN ({id_list})
                   ORDER BY cluster_roi_pct DESC""")
        )
    else:
        # 최근 200개 보고서
        result = await db.execute(
            text("""SELECT id, cluster_name, cluster_no, n_sites, total_units,
                        base_cost_bn, discounted_cost_bn, discount_pct,
                        total_lh_bn, profit_bn, cluster_roi_pct,
                        avg_sitec_score, best_grade, viability, viability_color,
                        target_fit, rank
                   FROM cluster_reports
                   ORDER BY cluster_roi_pct DESC
                   LIMIT 200""")
        )

    rows = result.fetchall()
    keys = result.keys()
    if not rows:
        raise HTTPException(
            status_code=404,
            detail="최적화할 클러스터 보고서가 없습니다. 먼저 스마트 클러스터 분석을 실행하세요."
        )

    # dict 변환
    candidates = []
    for row in rows:
        d = dict(zip(keys, row))
        candidates.append({
            "cluster_id":       d["id"],
            "cluster_name":     d["cluster_name"] or f"클러스터 {d['cluster_no']}",
            "n_sites":          d["n_sites"] or 0,
            "total_units":      d["total_units"] or 0,
            "base_cost_bn":     float(d["base_cost_bn"] or 0),
            "discounted_cost_bn": float(d["discounted_cost_bn"] or 0),
            "discount_pct":     float(d["discount_pct"] or 0),
            "total_lh_bn":      float(d["total_lh_bn"] or 0),
            "profit_bn":        float(d["profit_bn"] or 0),
            "cluster_roi_pct":  float(d["cluster_roi_pct"] or 0),
            "avg_sitec_score":  float(d["avg_sitec_score"] or 0),
            "best_grade":       d["best_grade"] or "-",
            "viability":        d["viability"] or "검토필요",
            "viability_color":  d["viability_color"] or "gray",
            "target_fit":       d["target_fit"] or "-",
            "rank":             d["rank"] or 0,
        })

    # ── 2) ILP 솔버 실행 ────────────────────────────────────
    selected, filtered = _solve_ilp_greedy(candidates, constraints)

    # ── 3) 선택 이유 생성 ───────────────────────────────────
    def _reason(c: dict, rank: int, obj: str) -> str:
        reasons = []
        if c["cluster_roi_pct"] >= 120:
            reasons.append(f"최고 ROI {c['cluster_roi_pct']:.1f}%")
        elif c["cluster_roi_pct"] >= 80:
            reasons.append(f"우수 ROI {c['cluster_roi_pct']:.1f}%")
        else:
            reasons.append(f"ROI {c['cluster_roi_pct']:.1f}%")

        if c["best_grade"] in ["A+", "A"]:
            reasons.append(f"최우수 등급 {c['best_grade']}")
        if c["discount_pct"] >= 15:
            reasons.append(f"공사비 {c['discount_pct']:.1f}% 절감")
        if c["total_units"] >= 800:
            reasons.append(f"대규모 {c['total_units']}세대")
        if obj == "maximize_units" and c["total_units"] >= 500:
            reasons.append("세대수 최대화 선택")
        if obj == "maximize_profit" and c["profit_bn"] >= 100:
            reasons.append(f"수익 {c['profit_bn']:.0f}억")
        return " · ".join(reasons) if reasons else "제약 조건 충족"

    selected_ids = {c["cluster_id"] for c in selected}
    result_clusters = []
    for rank_i, c in enumerate(selected, 1):
        result_clusters.append({
            **c,
            "selected": True,
            "selection_reason": _reason(c, rank_i, constraints.objective),
            "rank": rank_i,
        })

    # 미선택 클러스터도 포함 (selected=False)
    not_selected_result = []
    for c in filtered:
        if c["cluster_id"] not in selected_ids:
            not_selected_result.append({
                **c,
                "selected": False,
                "selection_reason": _unselect_reason(c, constraints, selected),
                "rank": 0,
            })

    # ── 4) 포트폴리오 집계 ─────────────────────────────────
    total_inv = sum(c["discounted_cost_bn"] for c in selected)
    total_lh  = sum(c["total_lh_bn"] for c in selected)
    total_pft = sum(c["profit_bn"] for c in selected)
    total_units_sel = sum(c["total_units"] for c in selected)
    total_sites_sel = sum(c["n_sites"] for c in selected)
    portfolio_roi = (total_pft / total_inv * 100) if total_inv > 0 else 0

    # ── 5) 간트 착수 계획 ──────────────────────────────────
    gantt_phases = _build_gantt_phases(selected)

    # ── 6) 민감도 분석 ─────────────────────────────────────
    sensitivity = _sensitivity_analysis(filtered, selected_ids, constraints)

    # ── 7) 실행 요약 문장 ──────────────────────────────────
    obj_label = {
        "maximize_roi": "ROI 최대화",
        "maximize_profit": "수익 최대화",
        "maximize_units": "세대수 최대화"
    }.get(constraints.objective, constraints.objective)

    exec_summary = (
        f"예산 {constraints.budget_bn:.0f}억원 내에서 {obj_label} 목표로 "
        f"전체 {len(filtered)}개 후보 클러스터 중 {len(selected)}개를 최적 선택했습니다. "
        f"총 투자 {total_inv:.0f}억원 / 예상 수익 {total_pft:.0f}억원 / "
        f"포트폴리오 ROI {portfolio_roi:.1f}%"
    )

    return {
        "selected_clusters": result_clusters,
        "not_selected_clusters": not_selected_result[:20],  # 미선택 상위 20개
        "total_investment_bn": round(total_inv, 2),
        "total_lh_bn": round(total_lh, 2),
        "total_profit_bn": round(total_pft, 2),
        "portfolio_roi_pct": round(portfolio_roi, 2),
        "total_units": total_units_sel,
        "total_sites": total_sites_sel,
        "n_clusters_selected": len(selected),
        "n_clusters_total": len(filtered),
        "budget_utilization_pct": round(total_inv / constraints.budget_bn * 100, 1) if constraints.budget_bn > 0 else 0,
        "objective": constraints.objective,
        "optimization_method": "Greedy Knapsack (0-1 ILP Approximation)",
        "constraints_summary": {
            "budget_bn": constraints.budget_bn,
            "max_units_per_year": constraints.max_units_per_year,
            "min_cluster_roi": constraints.min_cluster_roi,
            "max_parallel_clusters": constraints.max_parallel_clusters,
            "objective": constraints.objective,
        },
        "execution_summary": exec_summary,
        "gantt_phases": gantt_phases,
        "sensitivity": sensitivity,
    }


def _unselect_reason(c: dict, constraints: PortfolioConstraints, selected: list) -> str:
    """미선택 클러스터의 제외 사유"""
    if c["cluster_roi_pct"] < constraints.min_cluster_roi:
        return f"ROI {c['cluster_roi_pct']:.1f}% < 최소 기준 {constraints.min_cluster_roi:.0f}%"
    total_cost = sum(s["discounted_cost_bn"] for s in selected)
    if total_cost + c["discounted_cost_bn"] > constraints.budget_bn:
        return f"예산 초과 (추가 필요 {c['discounted_cost_bn']:.0f}억, 잔여 예산 {constraints.budget_bn - total_cost:.0f}억)"
    total_units = sum(s["total_units"] for s in selected)
    if total_units + c["total_units"] > constraints.max_units_per_year * 1.1:
        return f"연간 세대 한도 초과 ({total_units + c['total_units']}세대 > {constraints.max_units_per_year}세대)"
    if len(selected) >= constraints.max_parallel_clusters:
        return f"동시 착수 한도 초과 (최대 {constraints.max_parallel_clusters}개 클러스터)"
    return "낮은 우선순위 (상위 클러스터 선택 후 예산/용량 소진)"


@router.get("/portfolio/sessions", summary="포트폴리오 최적화에 사용 가능한 세션 목록")
async def list_portfolio_sessions(db: AsyncSession = Depends(get_db)):
    """저장된 클러스터 세션 목록 조회 (포트폴리오 최적화 입력용)"""
    await ensure_cluster_reports_table(db)
    result = await db.execute(text("""
        SELECT analysis_session,
               COUNT(*) as n_clusters,
               SUM(total_units) as total_units,
               AVG(cluster_roi_pct) as avg_roi,
               MAX(created_at) as last_created
        FROM cluster_reports
        WHERE analysis_session IS NOT NULL
        GROUP BY analysis_session
        ORDER BY last_created DESC
        LIMIT 50
    """))
    rows = result.fetchall()
    keys = result.keys()
    return {"sessions": [dict(zip(keys, row)) for row in rows]}
