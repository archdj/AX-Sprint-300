"""
환경변수 및 설정 관리
"""
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # App
    APP_NAME: str = "UnitBuild Platform"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True
    
    # Database
    DATABASE_URL: str = "sqlite+aiosqlite:///./unitbuild.db"
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379"
    
    # Security
    JWT_SECRET: str = "unitbuild-secret-key-change-in-production"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 1440  # 24시간
    
    # External APIs
    LH_OPEN_API_KEY: Optional[str] = None
    VWORLD_API_KEY: Optional[str] = None
    VWORLD_DOMAIN: Optional[str] = None           # VWorld 등록 도메인 (서버사이드 Referer용)
    KAKAO_MAP_API_KEY: Optional[str] = None       # JavaScript SDK용
    KAKAO_REST_API_KEY: Optional[str] = None      # REST API용 (Local API 등)
    MAPBOX_TOKEN: Optional[str] = None
    DATA_GO_KR_API_KEY: Optional[str] = None      # 공공데이터포털 - 토지이용계획정보 (7층이하 감지용)
    
    # CORS
    ALLOWED_ORIGINS: list = [
        "http://localhost:3000",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
    ]
    
    class Config:
        env_file = ".env"
        case_sensitive = True
        extra = "ignore"


settings = Settings()
