module.exports = {
  apps: [
    {
      name: 'unitbuild-backend',
      script: '/home/user/webapp/unitbuild-platform/backend/venv/bin/uvicorn',
      args: 'app.main:app --host 0.0.0.0 --port 8000',
      cwd: '/home/user/webapp/unitbuild-platform/backend',
      interpreter: 'none',
      env: {
        PYTHONPATH: '/home/user/webapp/unitbuild-platform/backend',
        PATH: '/home/user/webapp/unitbuild-platform/backend/venv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
        // 외부 API 키
        KAKAO_REST_API_KEY: 'ee62ca79a661e7f82394e5c570f86209',
        KAKAO_MAP_API_KEY:  'ee62ca79a661e7f82394e5c570f86209',
        VWORLD_API_KEY:     '0F9773C6-F395-3084-ADDE-5BD59A71D4C1',
      },
      watch: false,
      instances: 1,
      exec_mode: 'fork',
    }
  ]
}
