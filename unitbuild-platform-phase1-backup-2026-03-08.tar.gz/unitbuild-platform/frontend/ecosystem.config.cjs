module.exports = {
  apps: [
    {
      name: 'unitbuild-frontend',
      script: 'server.cjs',
      cwd: '/home/user/webapp/unitbuild-platform/frontend',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      watch: false,
      instances: 1,
      exec_mode: 'fork',
    }
  ]
}
