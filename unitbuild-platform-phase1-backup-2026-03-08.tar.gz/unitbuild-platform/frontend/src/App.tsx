import { useState, useRef } from 'react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import Dashboard from './pages/Dashboard'
import BulkDashboard from './pages/BulkDashboard'
import BulkUpload from './pages/BulkUpload'
import BulkCluster from './pages/BulkCluster'
import ClusterReview from './pages/ClusterReview'
import PortfolioOptimizer from './pages/PortfolioOptimizer'
import ModuleCatalog from './pages/ModuleCatalog'
import AutoEvaluator from './pages/AutoEvaluator'
import LandingPage from './pages/LandingPage'
import {
  Building2, Package, Zap, Menu, X,
  ChevronRight, Info, ChevronDown, FileText, BarChart2,
  Map, Upload, Layers, LayoutDashboard
} from 'lucide-react'
import './index.css'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 30000 },
  },
})

type Tab =
  | 'landing'
  | 'dashboard'
  | 'bulk-dashboard'
  | 'auto'
  | 'bulk-upload'
  | 'cluster'
  | 'bulk-cluster'
  | 'portfolio'
  | 'units'
  | 'solution'

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('landing')
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [portfolioDropOpen, setPortfolioDropOpen] = useState(false)
  const portfolioTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const handleNavigate = (tab: string) => {
    setActiveTab(tab as Tab)
    setMobileMenuOpen(false)
    setPortfolioDropOpen(false)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  // ── 호버 헬퍼 ─────────────────────────────────────────────
  const makeHover = (
    _open: boolean,
    setOpen: (v: boolean) => void,
    timer: React.MutableRefObject<ReturnType<typeof setTimeout> | null>
  ) => ({
    onMouseEnter: () => {
      if (timer.current) clearTimeout(timer.current)
      setOpen(true)
    },
    onMouseLeave: () => {
      timer.current = setTimeout(() => setOpen(false), 150)
    },
  })

  const portfolioHover = makeHover(portfolioDropOpen, setPortfolioDropOpen, portfolioTimer)

  const isPortfolioActive =
    activeTab === 'dashboard' || activeTab === 'bulk-dashboard' ||
    activeTab === 'auto' || activeTab === 'bulk-upload' ||
    activeTab === 'cluster' || activeTab === 'bulk-cluster' || activeTab === 'portfolio'

  // ── 탭 라벨 매핑 ─────────────────────────────────────────
  const tabLabel: Record<Tab, string> = {
    landing: '홈',
    auto: '사업지 평가',
    'bulk-upload': '대규모 검토',
    dashboard: '사업지 대시보드',
    'bulk-dashboard': '대규모 검토 대시보드',
    cluster: '클러스터 검토',
    'bulk-cluster': '대규모 클러스터',
    portfolio: '포트폴리오 최적화',
    units: '유닛 제품',
    solution: '솔루션 소개',
  }

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-slate-50">

        {/* ══════════════════════════════════════════════════
            탑 네비게이션
        ══════════════════════════════════════════════════ */}
        <nav className="topnav px-4 md:px-8" style={{ position: 'relative', zIndex: 50 }}>
          <div className="max-w-6xl mx-auto w-full flex items-center justify-between">

            {/* 로고 */}
            <button
              className="flex items-center gap-2.5 hover:opacity-80 transition-opacity"
              onClick={() => handleNavigate('landing')}
            >
              <div className="w-8 h-8 bg-blue-600 rounded-xl flex items-center justify-center shadow-sm">
                <Building2 size={17} className="text-white" />
              </div>
              <div className="leading-tight">
                <span className="font-black text-gray-900 text-base">UnitBuild</span>
                <span className="hidden md:block text-[10px] text-gray-400 leading-none">모듈러 사업지 자동평가</span>
              </div>
            </button>

            {/* PC 네비 */}
            <div className="hidden md:flex items-center gap-1">

              {/* ① 포트폴리오 드롭다운 (평가 + 대시보드 + 클러스터 모두 포함) */}
              <div className="relative" {...portfolioHover}>
                <button
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                    isPortfolioActive
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-200'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                  }`}
                >
                  <Layers size={15} />
                  포트폴리오
                  <ChevronDown size={13} className={`transition-transform ${portfolioDropOpen ? 'rotate-180' : ''}`} />
                </button>
                {portfolioDropOpen && (
                  <div className="absolute left-0 top-full mt-1.5 w-64 bg-white border border-gray-200 rounded-2xl shadow-xl py-2 z-50">

                    {/* 평가 섹션 */}
                    <div className="px-4 pt-1 pb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">사업지 평가</div>
                    <DropItem
                      icon={<FileText size={14} />}
                      label="단일 사업지 평가"
                      desc="지번 입력 → 10초 자동 분석"
                      active={activeTab === 'auto'}
                      onClick={() => handleNavigate('auto')}
                    />
                    <DropItem
                      icon={<Upload size={14} />}
                      label="대규모 검토"
                      desc="CSV 최대 200개 일괄 평가"
                      active={activeTab === 'bulk-upload'}
                      onClick={() => handleNavigate('bulk-upload')}
                    />

                    <div className="mx-3 my-1.5 border-t border-gray-100" />

                    {/* 대시보드 섹션 */}
                    <div className="px-4 pt-1 pb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">대시보드</div>
                    <DropItem
                      icon={<LayoutDashboard size={14} />}
                      label="사업지 대시보드"
                      desc="평가 완료 사업지 종합 리포트"
                      active={activeTab === 'dashboard'}
                      onClick={() => handleNavigate('dashboard')}
                    />
                    <DropItem
                      icon={<BarChart2 size={14} />}
                      label="대규모 검토 대시보드"
                      desc="CSV 평가 현황 · 필터 · 내보내기"
                      active={activeTab === 'bulk-dashboard'}
                      onClick={() => handleNavigate('bulk-dashboard')}
                    />

                    <div className="mx-3 my-1.5 border-t border-gray-100" />

                    {/* 클러스터 최적화 섹션 */}
                    <div className="px-4 pt-1 pb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">클러스터 · 포트폴리오</div>
                    <DropItem
                      icon={<Map size={14} />}
                      label="클러스터 검토"
                      desc="사업지 선택 · 건축비 절감 시뮬"
                      active={activeTab === 'cluster'}
                      onClick={() => handleNavigate('cluster')}
                    />
                    <DropItem
                      icon={<Layers size={14} />}
                      label="대규모 클러스터 자동 묶음"
                      desc="반경 3/5/10km 자동 클러스터링"
                      active={activeTab === 'bulk-cluster'}
                      onClick={() => handleNavigate('bulk-cluster')}
                    />
                    <DropItem
                      icon={<BarChart2 size={14} />}
                      label="포트폴리오 최적화"
                      desc="ILP 기반 최적 포트폴리오 구성"
                      active={activeTab === 'portfolio'}
                      onClick={() => handleNavigate('portfolio')}
                    />
                  </div>
                )}
              </div>

              {/* ② 유닛 제품 */}
              <button
                onClick={() => handleNavigate('units')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                  activeTab === 'units'
                    ? 'bg-blue-600 text-white shadow-sm shadow-blue-200'
                    : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                <Package size={15} /> 유닛 제품
              </button>

              {/* ③ 솔루션 소개 */}
              <button
                onClick={() => handleNavigate('solution')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                  activeTab === 'solution'
                    ? 'bg-blue-600 text-white shadow-sm shadow-blue-200'
                    : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                <Info size={15} /> 솔루션 소개
              </button>
            </div>

            {/* CTA 버튼 */}
            <div className="hidden md:flex items-center gap-2">
              <button
                onClick={() => handleNavigate('auto')}
                className="flex items-center gap-1.5 px-5 py-2 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors shadow-sm"
              >
                <Zap size={14} /> 무료 사업지 평가
              </button>
            </div>

            {/* 모바일 햄버거 */}
            <button
              className="md:hidden p-2 rounded-xl hover:bg-gray-100 transition-colors"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </nav>

        {/* ══ 모바일 메뉴 드롭다운 ══════════════════════════ */}
        {mobileMenuOpen && (
          <div className="md:hidden fixed inset-x-0 top-[60px] z-40 bg-white border-b border-gray-200 shadow-xl overflow-y-auto max-h-[80vh]">
            <div className="p-4 space-y-1">
              {/* 사업지 평가 섹션 */}
              <div className="px-4 py-1.5 text-[10px] font-bold text-gray-400 uppercase tracking-widest">사업지 평가</div>
              <MobileItem icon={<FileText size={15} />} label="단일 사업지 평가" desc="지번 입력 → 10초 자동 분석" active={activeTab === 'auto'} onClick={() => handleNavigate('auto')} />
              <MobileItem icon={<Upload size={15} />} label="대규모 검토" desc="CSV 최대 200개 일괄 평가" active={activeTab === 'bulk-upload'} onClick={() => handleNavigate('bulk-upload')} />

              {/* 대시보드 섹션 */}
              <div className="px-4 py-1.5 text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-2">대시보드</div>
              <MobileItem icon={<LayoutDashboard size={15} />} label="사업지 대시보드" desc="평가 완료 사업지 종합 리포트" active={activeTab === 'dashboard'} onClick={() => handleNavigate('dashboard')} />
              <MobileItem icon={<BarChart2 size={15} />} label="대규모 검토 대시보드" desc="CSV 평가 현황 · 필터 · 내보내기" active={activeTab === 'bulk-dashboard'} onClick={() => handleNavigate('bulk-dashboard')} />

              {/* 포트폴리오 섹션 */}
              <div className="px-4 py-1.5 text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-2">포트폴리오</div>
              <MobileItem icon={<Map size={15} />} label="클러스터 검토" desc="사업지 선택 · 건축비 절감 시뮬" active={activeTab === 'cluster'} onClick={() => handleNavigate('cluster')} />
              <MobileItem icon={<Layers size={15} />} label="대규모 클러스터 자동 묶음" desc="반경 3/5/10km 자동 클러스터링" active={activeTab === 'bulk-cluster'} onClick={() => handleNavigate('bulk-cluster')} />
              <MobileItem icon={<BarChart2 size={15} />} label="포트폴리오 최적화" desc="ILP 기반 최적 포트폴리오 구성" active={activeTab === 'portfolio'} onClick={() => handleNavigate('portfolio')} />

              {/* 제품 & 소개 */}
              <div className="px-4 py-1.5 text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-2">제품 & 소개</div>
              <MobileItem icon={<Package size={15} />} label="유닛 제품" desc="모듈러 유닛 제품군 6종" active={activeTab === 'units'} onClick={() => handleNavigate('units')} />
              <MobileItem icon={<Info size={15} />} label="솔루션 소개" desc="UnitBuild 솔루션 안내" active={activeTab === 'solution'} onClick={() => handleNavigate('solution')} />
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════
            메인 컨텐츠
        ══════════════════════════════════════════════════ */}
        <main>
          {activeTab === 'landing' && (
            <LandingPage onNavigate={handleNavigate} />
          )}

          {activeTab !== 'landing' && (
            <div className="max-w-6xl mx-auto px-4 md:px-6 py-8">
              {/* Breadcrumb */}
              <div className="flex items-center gap-2 text-xs text-gray-400 mb-6">
                <button onClick={() => handleNavigate('landing')} className="hover:text-blue-600 transition-colors">홈</button>
                <ChevronRight size={12} />
                <span className="text-gray-700 font-medium">{tabLabel[activeTab] ?? activeTab}</span>
              </div>

              {activeTab === 'auto'           && <AutoEvaluator />}
              {activeTab === 'bulk-upload'    && <BulkUpload />}
              {activeTab === 'dashboard'      && <Dashboard onNavigate={handleNavigate} />}
              {activeTab === 'bulk-dashboard' && <BulkDashboard />}
              {activeTab === 'cluster'        && <ClusterReview />}
              {activeTab === 'bulk-cluster'   && <BulkCluster />}
              {activeTab === 'portfolio'      && <PortfolioOptimizer />}
              {activeTab === 'units'          && <ModuleCatalog />}
              {activeTab === 'solution'       && <SolutionPage onNavigate={handleNavigate} />}
            </div>
          )}
        </main>

      </div>
    </QueryClientProvider>
  )
}

/* ── 드롭다운 아이템 ─────────────────────────────────────── */
function DropItem({
  icon, label, desc, active, onClick,
}: { icon: React.ReactNode; label: string; desc?: string; active?: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-start gap-3 px-4 py-2.5 hover:bg-blue-50 transition-colors text-left ${active ? 'bg-blue-50' : ''}`}
    >
      <span className={`mt-0.5 shrink-0 ${active ? 'text-blue-600' : 'text-gray-400'}`}>{icon}</span>
      <div>
        <div className={`text-sm font-semibold leading-tight ${active ? 'text-blue-700' : 'text-gray-800'}`}>{label}</div>
        {desc && <div className="text-[11px] text-gray-400 mt-0.5 leading-tight">{desc}</div>}
      </div>
    </button>
  )
}

/* ── 모바일 메뉴 아이템 ──────────────────────────────────── */
function MobileItem({
  icon, label, desc, active, onClick,
}: { icon: React.ReactNode; label: string; desc?: string; active?: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
        active ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-50'
      }`}
    >
      <div className="flex items-center gap-3">
        <span className={active ? 'text-blue-600' : 'text-gray-400'}>{icon}</span>
        <div className="text-left">
          <div>{label}</div>
          {desc && <div className="text-xs text-gray-400">{desc}</div>}
        </div>
      </div>
      <ChevronRight size={14} className="text-gray-300" />
    </button>
  )
}

/* ══════════════════════════════════════════════════════════
   솔루션 소개 페이지
══════════════════════════════════════════════════════════ */
function SolutionPage({ onNavigate }: { onNavigate: (tab: string) => void }) {
  return (
    <div className="space-y-12">

      {/* 솔루션 개요 */}
      <div className="text-center py-8">
        <div className="section-tag">About UnitBuild</div>
        <h1 className="text-3xl md:text-4xl font-black text-gray-900 mt-3 mb-4">
          모듈러 건축 기반<br />
          <span style={{ color: 'var(--ub-blue)' }}>LH 사업 자동화 솔루션</span>
        </h1>
        <p className="text-gray-500 text-lg max-w-2xl mx-auto leading-relaxed">
          유닛빌드는 LH 신축매입약정 사업의 사업성 검토부터 모듈 설계·제조·시공까지<br />
          원스톱으로 지원하는 스마트 건설 플랫폼입니다.
        </p>
      </div>

      {/* 핵심 가치 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          {
            num: '01', color: 'bg-blue-600',
            title: '사업지 자동 분석',
            desc: '지번 하나로 즉시 분석하거나, CSV로 수백 개 사업지를 일괄 평가. VWorld·카카오 API 실데이터 기반 SITE-C 자동 채점.',
            items: ['단일 지번 즉시 분석', 'CSV 대량 일괄 평가', 'SITE-C 자동 채점 · ROI 산출'],
          },
          {
            num: '02', color: 'bg-teal-600',
            title: '클러스터 건축비 최적화',
            desc: '반경 3/5/10km 기준 자동 클러스터링으로 인접 사업지를 묶어 모듈 동시제작. 최대 22% 건축비 절감 수식 자동 적용.',
            items: ['반경별 자동 클러스터링', '규모의 경제 건축비 할인', '포트폴리오 ILP 최적화'],
          },
          {
            num: '03', color: 'bg-purple-600',
            title: '유닛 제품 시스템',
            desc: '공장 제조·현장 조립 방식의 모듈러 유닛 6종. LH 주택유형 대응, 품질 표준화, 공기 단축.',
            items: ['6종 표준 유닛', 'LH 주택유형 매칭', '공장 품질 관리'],
          },
        ].map((v, i) => (
          <div key={i} className="card">
            <div className={`w-10 h-10 ${v.color} rounded-xl flex items-center justify-center text-white font-black text-lg mb-4`}>
              {v.num}
            </div>
            <h3 className="font-bold text-gray-900 text-lg mb-2">{v.title}</h3>
            <p className="text-gray-500 text-sm leading-relaxed mb-4">{v.desc}</p>
            <ul className="space-y-1.5">
              {v.items.map((item, j) => (
                <li key={j} className="flex items-center gap-2 text-xs text-gray-600">
                  <div className={`w-1.5 h-1.5 rounded-full ${v.color}`} />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* 플랫폼 기능 구조 */}
      <div className="bg-slate-900 rounded-2xl p-8 text-white">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-black mb-2">플랫폼 기능 구조</h2>
          <p className="text-slate-400 text-sm">사업지 발굴부터 최적 포트폴리오 구성까지</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[
            { label: '단일 사업지 평가', desc: '지번 입력→SITE-C→ROI\n10초 내 완성', color: 'border-blue-500', tab: 'auto' },
            { label: '대규모 검토', desc: 'CSV 최대 200개\n일괄 평가 & 진행 추적', color: 'border-sky-400', tab: 'bulk-upload' },
            { label: '사업지 대시보드', desc: '평가 완료 사업지\n종합 리포트 클릭 조회', color: 'border-teal-500', tab: 'dashboard' },
            { label: '대규모 검토 대시보드', desc: '전체 평가 현황\n필터·정렬·CSV 내보내기', color: 'border-cyan-400', tab: 'bulk-dashboard' },
            { label: '클러스터 검토', desc: '수동 선택 클러스터\n건축비 절감 시뮬', color: 'border-purple-500', tab: 'cluster' },
            { label: '포트폴리오 최적화', desc: '반경 3/5/10km\n자동 클러스터링 + ILP 최적화', color: 'border-pink-400', tab: 'portfolio' },
          ].map((w, i) => (
            <button
              key={i}
              onClick={() => onNavigate(w.tab)}
              className={`bg-white/5 border ${w.color} rounded-xl p-4 text-left hover:bg-white/10 transition-colors`}
            >
              <div className="font-bold text-white text-sm mb-1">{w.label}</div>
              <div className="text-xs text-slate-400 whitespace-pre-line leading-relaxed">{w.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* 사업 추진 워크플로우 */}
      <div>
        <div className="text-center mb-8">
          <div className="section-tag">워크플로우</div>
          <h2 className="text-2xl font-black text-gray-900">사업 추진 단계</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { step: '1단계', title: '사업지 발굴', desc: '단일 또는 CSV 대량\n자동 평가', color: 'border-blue-500 bg-blue-50' },
            { step: '2단계', title: '클러스터 구성', desc: '반경 기준 자동 묶음\n건축비 최적화', color: 'border-teal-500 bg-teal-50' },
            { step: '3단계', title: '설계·인허가', desc: '유닛 제품 기반\n빠른 설계', color: 'border-purple-500 bg-purple-50' },
            { step: '4단계', title: '제조·시공', desc: '공장 제조·현장 조립\n품질·공기 달성', color: 'border-green-500 bg-green-50' },
          ].map((w, i) => (
            <div key={i} className={`border-2 ${w.color} rounded-xl p-4`}>
              <div className="text-xs font-semibold text-gray-400 mb-1">{w.step}</div>
              <div className="font-bold text-gray-900 mb-2">{w.title}</div>
              <div className="text-xs text-gray-500 whitespace-pre-line leading-relaxed">{w.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* 수치 경쟁력 */}
      <div>
        <div className="text-center mb-8">
          <div className="section-tag">경쟁력</div>
          <h2 className="text-2xl font-black text-gray-900">수치로 증명하는 UnitBuild</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { num: '10초', label: '사업지 자동 분석 시간', sub: '지번 입력 → 리포트 완성' },
            { num: '22%', label: '최대 건축비 절감', sub: '클러스터 동시 모듈 제작' },
            { num: '6종', label: '표준 유닛 제품', sub: 'LH 주택유형 완전 대응' },
            { num: '200개', label: 'CSV 일괄 처리', sub: '대규모 사업지 검토 한 번에' },
          ].map(s => (
            <div key={s.label} className="card text-center">
              <div className="text-3xl font-black text-blue-600 mb-1">{s.num}</div>
              <div className="font-semibold text-gray-900 text-sm mb-1">{s.label}</div>
              <div className="text-xs text-gray-400">{s.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl p-8 text-center text-white">
        <h2 className="text-2xl font-black mb-3">지금 바로 사업지를 분석해보세요</h2>
        <p className="text-blue-200 mb-6">회원가입 없이, 지번 주소만으로 즉시 시작 · 무료 제공</p>
        <div className="flex flex-wrap gap-3 justify-center">
          <button
            onClick={() => onNavigate('auto')}
            className="flex items-center gap-2 px-8 py-3.5 bg-white text-blue-700 rounded-xl font-bold hover:bg-blue-50 transition-colors shadow-lg"
          >
            <Zap size={18} /> 사업지 평가 시작
          </button>
          <button
            onClick={() => onNavigate('units')}
            className="flex items-center gap-2 px-8 py-3.5 border-2 border-white/30 text-white rounded-xl font-bold hover:bg-white/10 transition-colors"
          >
            <Package size={18} /> 유닛 제품 보기
          </button>
        </div>
      </div>

    </div>
  )
}
