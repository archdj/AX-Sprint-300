import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { sitesAPI } from '../api'
import {
  Building2, MapPin, TrendingUp, CheckCircle, Clock,
  X, ChevronRight, BarChart3, Star, Layers, Home,
  AlertCircle, Award, Zap, ArrowRight, Brain, DollarSign,
  ShieldCheck, Ruler, Train, Bus, GraduationCap, Activity,
  ShoppingCart, Sun, FlameKindling, Leaf, RefreshCw
} from 'lucide-react'

const GRADE_COLOR: Record<string, string> = {
  'A':  'text-green-700 bg-green-50 border-green-200',
  'B':  'text-blue-700 bg-blue-50 border-blue-200',
  'C':  'text-yellow-700 bg-yellow-50 border-yellow-200',
  '탈락': 'text-red-700 bg-red-50 border-red-200',
}
const OVERALL_STYLE: Record<string, { bg: string; text: string; border: string; label: string; badge: string }> = {
  'A+': { bg: 'bg-emerald-950', text: 'text-emerald-300', border: 'border-emerald-700', label: '탁월', badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-600' },
  'A':  { bg: 'bg-green-950',   text: 'text-green-300',   border: 'border-green-700',   label: '우수', badge: 'bg-green-500/20 text-green-300 border-green-600' },
  'B':  { bg: 'bg-blue-950',    text: 'text-blue-300',    border: 'border-blue-700',    label: '양호', badge: 'bg-blue-500/20 text-blue-300 border-blue-600' },
  'C':  { bg: 'bg-amber-950',   text: 'text-amber-300',   border: 'border-amber-700',   label: '검토', badge: 'bg-amber-500/20 text-amber-300 border-amber-600' },
  '검토요': { bg: 'bg-red-950', text: 'text-red-300',     border: 'border-red-700',     label: '재검토', badge: 'bg-red-500/20 text-red-300 border-red-600' },
}

const BREAKDOWN_LABELS: Record<string, { label: string; color: string; max: number }> = {
  A_교통접근성: { label: 'A. 교통 접근성', color: '#3b82f6', max: 30 },
  B_생활인프라:  { label: 'B. 생활 인프라',  color: '#10b981', max: 25 },
  C_사업규모:    { label: 'C. 사업 규모',    color: '#8b5cf6', max: 25 },
  D_구조안전:    { label: 'D. 구조·안전',   color: '#f59e0b', max: 10 },
  E_에너지환경:  { label: 'E. 에너지·환경', color: '#06b6d4', max: 5  },
  F_사업자가점:  { label: 'F. 사업자 가점', color: '#ec4899', max: 5  },
}

const VERDICT_COLOR: Record<string, string> = {
  emerald: 'from-emerald-950 to-emerald-900 border-emerald-700',
  green:   'from-green-950 to-green-900 border-green-700',
  blue:    'from-blue-950 to-blue-900 border-blue-700',
  yellow:  'from-amber-950 to-amber-900 border-amber-700',
  red:     'from-red-950 to-red-900 border-red-700',
}

interface ReportModalProps {
  siteId: number
  onClose: () => void
}

function ReportModal({ siteId, onClose }: ReportModalProps) {
  const { data: site, isLoading: siteLoading } = useQuery({
    queryKey: ['site', siteId],
    queryFn: () => sitesAPI.get(siteId),
  })
  const { data: aiData, isLoading: aiLoading } = useQuery({
    queryKey: ['aiSummary', siteId],
    queryFn: () => sitesAPI.aiSummary(siteId),
  })

  if (siteLoading) {
    return (
      <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
        <div className="modal-content flex items-center justify-center min-h-[400px]">
          <div className="text-center text-gray-400">
            <RefreshCw size={32} className="animate-spin mx-auto mb-3" />
            <p>리포트 불러오는 중...</p>
          </div>
        </div>
      </div>
    )
  }

  if (!site) return null

  const overall = site.sitec_grade ? OVERALL_STYLE[site.sitec_grade] || OVERALL_STYLE['검토요'] : null
  const ai = aiData?.summary
  const verdictBg = ai ? (VERDICT_COLOR[ai.verdict_color] || VERDICT_COLOR['blue']) : ''

  const totalSitecScore = site.sitec_breakdown
    ? Object.values(site.sitec_breakdown as Record<string, number>).reduce((a, b) => a + b, 0)
    : site.sitec_score

  const constructionCost = site.estimated_cost ? site.estimated_cost / 1e8 : null
  const lhPrice = site.lh_purchase_price ? site.lh_purchase_price / 1e8 : null
  const profit = (constructionCost && lhPrice) ? lhPrice - constructionCost : null

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-content">

        {/* ── 헤더 ── */}
        <div className={`p-6 rounded-t-2xl border-b ${overall?.bg || 'bg-gray-900'} ${overall?.border || 'border-gray-700'}`}>
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-4">
              <div className={`text-6xl font-black ${overall?.text || 'text-gray-400'} leading-none`}>
                {site.sitec_grade || '—'}
              </div>
              <div>
                <h2 className="font-black text-white text-xl leading-tight">{site.name}</h2>
                <p className="text-sm text-gray-400 mt-0.5 flex items-center gap-1">
                  <MapPin size={12} /> {site.address}
                </p>
                <div className="flex flex-wrap gap-2 mt-2">
                  <span className={`text-xs font-bold border rounded-full px-2.5 py-0.5 ${overall?.badge || ''}`}>
                    SITE-C {site.sitec_grade}등급
                  </span>
                  {site.sitec_approval_prob != null && (
                    <span className="text-xs bg-white/10 text-gray-300 border border-white/20 rounded-full px-2.5 py-0.5">
                      LH 심의 통과 {(site.sitec_approval_prob * 100).toFixed(0)}%
                    </span>
                  )}
                  <span className={`text-xs rounded-full px-2.5 py-0.5 ${
                    site.status === 'evaluated' ? 'bg-green-500/20 text-green-400 border border-green-600' : 'bg-gray-700 text-gray-400'
                  }`}>
                    {site.status === 'evaluated' ? '✓ 평가완료' : site.status}
                  </span>
                </div>
              </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-xl transition-colors text-gray-400 hover:text-white">
              <X size={20} />
            </button>
          </div>
        </div>

        {/* ── 본문 ── */}
        <div className="p-6 space-y-5 overflow-y-auto bg-gray-950">

          {/* AI 사업지 요약 */}
          {ai && (
            <div className={`rounded-2xl border bg-gradient-to-br ${verdictBg} p-5`}>
              <div className="flex items-center gap-2 mb-3">
                <Brain size={16} className="text-purple-400" />
                <span className="text-xs font-bold text-purple-400 uppercase tracking-wider">AI 사업지 분석</span>
              </div>
              <div className="flex items-start gap-4 mb-4">
                <div>
                  <div className="text-white font-black text-2xl">{ai.verdict}</div>
                  <div className="text-gray-300 text-sm mt-1">{ai.verdict_desc}</div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-3">
                {/* 입지 강점 */}
                {ai.location_points.length > 0 && (
                  <div className="bg-white/5 rounded-xl p-3">
                    <div className="text-xs text-gray-400 font-semibold mb-2 flex items-center gap-1">
                      <CheckCircle size={12} className="text-green-400" /> 입지 강점
                    </div>
                    {ai.location_points.map((pt, i) => (
                      <div key={i} className="text-xs text-gray-300 py-0.5 flex items-start gap-1.5">
                        <span className="text-green-400 mt-0.5">•</span> {pt}
                      </div>
                    ))}
                  </div>
                )}
                {/* 입지 리스크 */}
                {ai.location_risks.length > 0 && (
                  <div className="bg-white/5 rounded-xl p-3">
                    <div className="text-xs text-gray-400 font-semibold mb-2 flex items-center gap-1">
                      <AlertCircle size={12} className="text-amber-400" /> 리스크 요인
                    </div>
                    {ai.location_risks.map((r, i) => (
                      <div key={i} className="text-xs text-gray-300 py-0.5 flex items-start gap-1.5">
                        <span className="text-amber-400 mt-0.5">▲</span> {r}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* 모듈 분석 */}
              <div className="mt-3 bg-white/5 rounded-xl p-3">
                <div className="text-xs text-gray-400 font-semibold mb-1 flex items-center gap-1">
                  <Building2 size={12} className="text-blue-400" /> 모듈 분석
                </div>
                <p className="text-xs text-gray-300">{ai.module_analysis}</p>
              </div>

              {/* 재무 분석 */}
              <div className="mt-3 bg-white/5 rounded-xl p-3">
                <div className="text-xs text-gray-400 font-semibold mb-1 flex items-center gap-1">
                  <DollarSign size={12} className="text-yellow-400" /> 재무 분석
                </div>
                <p className="text-xs text-gray-300">{ai.financial_analysis}</p>
              </div>

              {/* 권고 액션 */}
              {ai.recommended_actions.length > 0 && (
                <div className="mt-3 bg-white/5 rounded-xl p-3">
                  <div className="text-xs text-gray-400 font-semibold mb-2 flex items-center gap-1">
                    <Zap size={12} className="text-cyan-400" /> 권고 액션
                  </div>
                  <div className="space-y-1.5">
                    {ai.recommended_actions.map((a, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-gray-300">
                        <span className="text-cyan-400 font-bold shrink-0">{i + 1}.</span> {a}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {aiLoading && (
            <div className="rounded-2xl border border-gray-700 bg-gray-900 p-5 flex items-center gap-3 text-gray-400">
              <RefreshCw size={16} className="animate-spin text-purple-400" />
              <span className="text-sm">AI 분석 중...</span>
            </div>
          )}

          {/* KPI 요약 카드 4개 */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: 'SITE-C', value: site.sitec_score ? `${site.sitec_score.toFixed(1)}점` : '—', sub: site.sitec_grade ? `${site.sitec_grade}등급` : '', icon: <Star size={16} className="text-yellow-400" />, bg: 'bg-yellow-950 border-yellow-800' },
              { label: '필지 면적', value: site.land_area_m2 ? `${site.land_area_m2.toLocaleString()}㎡` : '—', sub: '', icon: <Ruler size={16} className="text-blue-400" />, bg: 'bg-blue-950 border-blue-800' },
              { label: '계획 세대', value: site.planned_units ? `${site.planned_units}세대` : '—', sub: site.floor_count ? `${site.floor_count}층` : '', icon: <Home size={16} className="text-purple-400" />, bg: 'bg-purple-950 border-purple-800' },
              { label: '예상 마진', value: site.expected_margin ? `${site.expected_margin.toFixed(1)}%` : '—', sub: profit ? `+${profit.toFixed(1)}억원` : '', icon: <TrendingUp size={16} className="text-green-400" />, bg: 'bg-green-950 border-green-800' },
            ].map(k => (
              <div key={k.label} className={`${k.bg} border rounded-xl p-4`}>
                <div className="flex items-center gap-1.5 mb-2">{k.icon}<span className="text-xs text-gray-400">{k.label}</span></div>
                <div className="font-black text-white text-lg">{k.value}</div>
                {k.sub && <div className="text-xs text-gray-500 mt-0.5">{k.sub}</div>}
              </div>
            ))}
          </div>

          {/* 층/세대/모듈 배치 상세 */}
          <div className="bg-gray-900 border border-gray-700 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <Building2 size={16} className="text-blue-400" />
              <span className="font-bold text-white text-sm">모듈 배치 계획</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {[
                { label: '건물 층수', value: site.floor_count ? `${site.floor_count}층` : '—', icon: <Building2 size={14} className="text-blue-400" /> },
                { label: '총 세대수', value: site.planned_units ? `${site.planned_units}세대` : '—', icon: <Home size={14} className="text-purple-400" /> },
                { label: '권장 세대', value: site.recommended_units ? `${site.recommended_units}세대` : '—', icon: <Star size={14} className="text-yellow-400" /> },
                { label: '소형 세대 비율', value: site.small_unit_ratio ? `${(site.small_unit_ratio * 100).toFixed(0)}%` : '—', icon: <Layers size={14} className="text-cyan-400" /> },
                { label: '용지 면적', value: site.land_area_m2 ? `${site.land_area_m2.toLocaleString()}㎡` : '—', icon: <Ruler size={14} className="text-green-400" /> },
                { label: '모듈러 공법', value: site.is_modular ? '적용' : '미적용', icon: <ShieldCheck size={14} className="text-emerald-400" /> },
              ].map(item => (
                <div key={item.label} className="bg-gray-800 rounded-xl p-3">
                  <div className="flex items-center gap-1.5 mb-1">{item.icon}<span className="text-xs text-gray-400">{item.label}</span></div>
                  <div className="font-bold text-white text-sm">{item.value}</div>
                </div>
              ))}
            </div>

            {/* 층별 시각화 */}
            {site.floor_count && site.planned_units && (
              <div className="mt-4">
                <div className="text-xs text-gray-400 mb-2">층별 세대 배치 (추정)</div>
                <div className="space-y-1.5">
                  {Array.from({ length: Math.min(site.floor_count, 8) }, (_, i) => {
                    const floorNum = site.floor_count! - i
                    const unitsPerFloor = Math.round(site.planned_units! / site.floor_count!)
                    return (
                      <div key={floorNum} className="flex items-center gap-2">
                        <span className="text-xs text-gray-500 w-8 text-right">{floorNum}F</span>
                        <div className="flex-1 bg-gray-800 rounded-full h-5 overflow-hidden">
                          <div
                            className="h-full bg-blue-600/60 rounded-full flex items-center px-2"
                            style={{ width: `${Math.min((unitsPerFloor / 10) * 100, 100)}%` }}
                          >
                            <span className="text-xs text-white/70">{unitsPerFloor}세대</span>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                  {site.floor_count > 8 && (
                    <div className="text-xs text-gray-500 text-center">... 외 {site.floor_count - 8}개 층</div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* 투입 비용 상세 */}
          <div className="bg-gray-900 border border-gray-700 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <DollarSign size={16} className="text-yellow-400" />
              <span className="font-bold text-white text-sm">사업 수지 분석</span>
            </div>
            <div className="space-y-3">
              {/* 공사비 */}
              <div className="flex items-center justify-between py-2 border-b border-gray-800">
                <div>
                  <div className="text-sm font-semibold text-white">총 공사비 (투입 비용)</div>
                  <div className="text-xs text-gray-500">모듈러 제작 + 현장 설치 + 부대비용</div>
                </div>
                <div className="text-right">
                  <div className="font-black text-red-400 text-xl">
                    {constructionCost ? `${constructionCost.toFixed(1)}억원` : site.estimated_cost ? `${(site.estimated_cost / 1e8).toFixed(1)}억원` : '—'}
                  </div>
                  {site.planned_units && constructionCost && (
                    <div className="text-xs text-gray-500">세대당 {(constructionCost / site.planned_units * 100).toFixed(0)}백만원</div>
                  )}
                </div>
              </div>

              {/* LH 매입 예정가 */}
              <div className="flex items-center justify-between py-2 border-b border-gray-800">
                <div>
                  <div className="text-sm font-semibold text-white">LH 매입 예정가</div>
                  <div className="text-xs text-gray-500">LH 신축매입약정 기준가</div>
                </div>
                <div className="text-right">
                  <div className="font-black text-blue-400 text-xl">
                    {lhPrice ? `${lhPrice.toFixed(1)}억원` : '—'}
                  </div>
                </div>
              </div>

              {/* 예상 수익 */}
              <div className="flex items-center justify-between py-2">
                <div>
                  <div className="text-sm font-semibold text-white">예상 수익 (세전)</div>
                  <div className="text-xs text-gray-500">LH 매입가 - 총 공사비</div>
                </div>
                <div className="text-right">
                  <div className={`font-black text-2xl ${profit && profit > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {profit ? `${profit > 0 ? '+' : ''}${profit.toFixed(1)}억원` : '—'}
                  </div>
                  {site.expected_margin && (
                    <div className="text-xs text-gray-400">마진율 {site.expected_margin.toFixed(1)}%</div>
                  )}
                </div>
              </div>

              {/* 수익 게이지 */}
              {site.expected_margin != null && (
                <div className="pt-2">
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span>수익성 지표</span>
                    <span>{site.expected_margin.toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-gray-800 rounded-full h-3">
                    <div
                      className={`h-3 rounded-full transition-all duration-700 ${
                        site.expected_margin >= 25 ? 'bg-green-500' :
                        site.expected_margin >= 15 ? 'bg-blue-500' :
                        site.expected_margin >= 5  ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                      style={{ width: `${Math.min(site.expected_margin, 50)}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-gray-600 mt-0.5">
                    <span>0%</span><span>25%</span><span>50%</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {/* 필지 상세 정보 */}
            <div className="bg-gray-900 border border-gray-700 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <MapPin size={15} className="text-cyan-400" />
                <span className="font-bold text-white text-sm">필지 접근성</span>
              </div>
              <div className="space-y-2">
                {[
                  { label: '지하철역', value: site.subway_distance_m, unit: 'm', icon: <Train size={12} className="text-blue-400" />, good: 500 },
                  { label: '버스 정류장', value: site.bus_stop_distance_m, unit: 'm', icon: <Bus size={12} className="text-green-400" />, good: 300 },
                  { label: '초등학교', value: site.elementary_school_distance_m, unit: 'm', icon: <GraduationCap size={12} className="text-purple-400" />, good: 500 },
                  { label: '의료시설', value: site.hospital_distance_m, unit: 'm', icon: <Activity size={12} className="text-red-400" />, good: 500 },
                  { label: '마트/편의시설', value: site.mart_distance_m, unit: 'm', icon: <ShoppingCart size={12} className="text-orange-400" />, good: 500 },
                  { label: '도심(CBD)', value: site.cbd_distance_km, unit: 'km', icon: <Building2 size={12} className="text-gray-400" />, good: 10 },
                ].map(row => {
                  const good = row.value != null && row.value <= row.good
                  return (
                    <div key={row.label} className="flex items-center justify-between py-1.5 border-b border-gray-800 last:border-0">
                      <div className="flex items-center gap-2">
                        {row.icon}
                        <span className="text-xs text-gray-400">{row.label}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className={`text-xs font-semibold ${good ? 'text-green-400' : 'text-gray-300'}`}>
                          {row.value != null ? `${row.value}${row.unit}` : '—'}
                        </span>
                        {row.value != null && (
                          <span className={`text-xs px-1.5 py-0.5 rounded-full ${good ? 'bg-green-900/50 text-green-400' : 'bg-gray-800 text-gray-500'}`}>
                            {good ? '양호' : '보통'}
                          </span>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* 안전·환경 */}
            <div className="bg-gray-900 border border-gray-700 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <ShieldCheck size={15} className="text-emerald-400" />
                <span className="font-bold text-white text-sm">구조·환경 안전</span>
              </div>
              <div className="space-y-2">
                {[
                  { label: '내진 등급', value: site.seismic_grade ? `${site.seismic_grade}등급` : '—', icon: <ShieldCheck size={12} className="text-emerald-400" />, good: site.seismic_grade === 1 },
                  { label: '경사도', value: site.slope_percent != null ? `${site.slope_percent}%` : '—', icon: <Activity size={12} className="text-yellow-400" />, good: (site.slope_percent ?? 99) <= 5 },
                  { label: '에너지 효율', value: site.energy_efficiency_grade ? `${site.energy_efficiency_grade}등급` : '—', icon: <Leaf size={12} className="text-green-400" />, good: (site.energy_efficiency_grade ?? 99) <= 2 },
                  { label: '일조 시간', value: site.sunshine_hours ? `${site.sunshine_hours}시간/일` : '—', icon: <Sun size={12} className="text-orange-400" />, good: (site.sunshine_hours ?? 0) >= 4 },
                  { label: '수요 점수', value: site.demand_score ? `${site.demand_score.toFixed(1)}점` : '—', icon: <TrendingUp size={12} className="text-cyan-400" />, good: (site.demand_score ?? 0) >= 70 },
                  { label: '재해 위험', value: site.hazard_compliant ? '적합' : site.hazard_compliant === false ? '검토필요' : '—', icon: <FlameKindling size={12} className="text-red-400" />, good: site.hazard_compliant === true },
                ].map(row => (
                  <div key={row.label} className="flex items-center justify-between py-1.5 border-b border-gray-800 last:border-0">
                    <div className="flex items-center gap-2">
                      {row.icon}
                      <span className="text-xs text-gray-400">{row.label}</span>
                    </div>
                    <span className={`text-xs font-semibold ${row.good ? 'text-green-400' : 'text-gray-300'}`}>
                      {row.value}
                    </span>
                  </div>
                ))}
              </div>

              {/* 안전 노트 (AI) */}
              {ai && ai.safety_notes.length > 0 && (
                <div className="mt-3 pt-3 border-t border-gray-800">
                  <div className="text-xs text-gray-500 mb-2">AI 안전 평가</div>
                  {ai.safety_notes.map((n, i) => (
                    <div key={i} className="text-xs text-emerald-400 flex items-start gap-1.5 py-0.5">
                      <CheckCircle size={11} className="mt-0.5 shrink-0" /> {n}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* SITE-C 항목별 점수 */}
          {site.sitec_breakdown && Object.keys(site.sitec_breakdown).length > 0 && (
            <div className="bg-gray-900 border border-gray-700 rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <BarChart3 size={15} className="text-purple-400" />
                  <span className="font-bold text-white text-sm">SITE-C 항목별 점수</span>
                </div>
                <div className="text-right">
                  <span className={`text-3xl font-black ${overall?.text || 'text-gray-400'}`}>
                    {totalSitecScore?.toFixed ? totalSitecScore.toFixed(1) : totalSitecScore}
                  </span>
                  <span className="text-sm text-gray-500 ml-1">/ 100점</span>
                </div>
              </div>
              <div className="space-y-3">
                {Object.entries(BREAKDOWN_LABELS).map(([key, meta]) => {
                  const raw = (site.sitec_breakdown as Record<string, number>)[key] ?? 0
                  const score = raw <= 1 ? raw * 100 : raw
                  const pct = (score / meta.max) * 100
                  return (
                    <div key={key}>
                      <div className="flex justify-between text-xs mb-1.5">
                        <span className="font-medium text-gray-300">{meta.label}</span>
                        <span className="text-gray-400">{score.toFixed(0)} / {meta.max}점</span>
                      </div>
                      <div className="w-full bg-gray-800 rounded-full h-2.5">
                        <div
                          className="h-2.5 rounded-full transition-all duration-700"
                          style={{ width: `${Math.min(pct, 100)}%`, backgroundColor: meta.color }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* 개선 제안 */}
          {site.sitec_suggestions && site.sitec_suggestions.length > 0 && (
            <div className="bg-gray-900 border border-amber-800/50 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <Zap size={15} className="text-amber-400" />
                <span className="font-bold text-white text-sm">점수 향상 제안</span>
              </div>
              <div className="space-y-2">
                {(site.sitec_suggestions as string[]).map((s, i) => (
                  <div key={i} className="flex items-start gap-2 text-sm text-amber-300 bg-amber-950/50 border border-amber-800/30 rounded-xl px-3 py-2.5">
                    <AlertCircle size={13} className="mt-0.5 shrink-0" /> {s}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 사업 조건 */}
          <div className="bg-gray-900 border border-gray-700 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <Award size={15} className="text-cyan-400" />
              <span className="font-bold text-white text-sm">사업 조건</span>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: '모듈러 공법', value: site.is_modular, desc: '공기 단축' },
                { label: '장기임대 10년+', value: site.long_term_rental, desc: 'F항목 가점' },
                { label: 'LH 우수시공사', value: site.lh_certified, desc: '추가 가점' },
              ].map(item => (
                <div key={item.label} className={`rounded-xl p-3 text-center border ${
                  item.value
                    ? 'bg-emerald-950/50 border-emerald-700 text-emerald-300'
                    : 'bg-gray-800 border-gray-700 text-gray-500'
                }`}>
                  <div className="text-2xl mb-1">{item.value ? '✓' : '—'}</div>
                  <div className="text-xs font-semibold">{item.label}</div>
                  <div className="text-xs opacity-60 mt-0.5">{item.desc}</div>
                </div>
              ))}
            </div>
          </div>

          {/* 하단 */}
          <div className="flex items-center justify-between pt-2 border-t border-gray-800">
            <span className="text-xs text-gray-500 flex items-center gap-1">
              <Clock size={11} /> 등록: {site.created_at ? new Date(site.created_at).toLocaleDateString('ko-KR') : '—'}
            </span>
            <button onClick={onClose} className="text-xs text-gray-400 hover:text-white px-4 py-2 rounded-xl border border-gray-700 hover:border-gray-500 transition-colors">
              닫기
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

interface DashboardProps {
  onNavigate: (tab: string) => void
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const { data: sites = [], isLoading } = useQuery({
    queryKey: ['sites'],
    queryFn: sitesAPI.list,
    refetchInterval: 30000,
  })

  const [selectedSiteId, setSelectedSiteId] = useState<number | null>(null)

  const evaluated = sites.filter(s => s.sitec_score !== null)
  const gradeA = evaluated.filter(s => s.sitec_grade === 'A').length
  const avgScore = evaluated.length > 0
    ? Math.round(evaluated.reduce((acc, s) => acc + (s.sitec_score || 0), 0) / evaluated.length * 10) / 10
    : 0

  return (
    <div className="space-y-6">

      {/* 헤더 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-gray-900">사업지 대시보드</h1>
          <p className="text-sm text-gray-400 mt-0.5">LH 신축매입약정 사업지 관리 · 클러스터 최적화</p>
        </div>
        <button onClick={() => onNavigate('auto')} className="btn-primary text-sm">
          <Zap size={15} /> 새 사업지 평가
        </button>
      </div>

      {/* KPI 카드 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { icon: <Building2 size={18} className="text-blue-600" />, label: '등록 사업지', value: sites.length, unit: '개소', bg: 'bg-blue-50' },
          { icon: <TrendingUp size={18} className="text-green-600" />, label: '평가 완료', value: evaluated.length, unit: '개소', bg: 'bg-green-50' },
          { icon: <CheckCircle size={18} className="text-emerald-600" />, label: 'A등급 사업지', value: gradeA, unit: '개소', bg: 'bg-emerald-50' },
          { icon: <Star size={18} className="text-purple-600" />, label: '평균 SITE-C', value: avgScore, unit: '점', bg: 'bg-purple-50' },
        ].map(k => (
          <div key={k.label} className="card flex items-center gap-3">
            <div className={`p-2.5 rounded-xl ${k.bg}`}>{k.icon}</div>
            <div>
              <p className="text-xs text-gray-400">{k.label}</p>
              <p className="text-2xl font-black text-gray-900">
                {k.value}<span className="text-sm font-normal text-gray-400 ml-1">{k.unit}</span>
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* 사업지 카드 목록 */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-gray-900 flex items-center gap-2">
            <Building2 size={16} /> 등록 사업지
            <span className="text-gray-400 text-sm font-normal">({sites.length}개)</span>
          </h2>
          <span className="text-xs text-gray-400">클릭하면 종합 리포트를 볼 수 있습니다</span>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center h-32 text-gray-400 text-sm">로딩 중...</div>
        ) : sites.length === 0 ? (
          <div className="card flex flex-col items-center justify-center py-16 text-gray-400">
            <Building2 size={40} className="mb-3 opacity-20" />
            <p className="font-medium">등록된 사업지가 없습니다</p>
            <p className="text-sm mt-1">자동 통합 평가 탭에서 사업지를 추가하세요</p>
            <button onClick={() => onNavigate('auto')} className="btn-primary mt-4 text-sm">
              <Zap size={14} /> 사업지 평가하기
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sites.map(site => {
              const gradeStyle = GRADE_COLOR[site.sitec_grade ?? ''] || 'text-gray-500 bg-gray-100 border-gray-200'
              const hasEval = site.sitec_score !== null
              return (
                <div
                  key={site.id}
                  className="site-card cursor-pointer"
                  onClick={() => setSelectedSiteId(site.id)}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-gray-900 text-sm truncate">{site.name}</h3>
                      <p className="text-xs text-gray-400 flex items-center gap-1 mt-0.5 truncate">
                        <MapPin size={10} /> {site.address}
                      </p>
                    </div>
                    {hasEval && (
                      <span className={`ml-2 text-xs font-bold border rounded-full px-2 py-0.5 shrink-0 ${gradeStyle}`}>
                        {site.sitec_grade}
                      </span>
                    )}
                  </div>

                  {hasEval ? (
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-400">SITE-C</span>
                        <span className="font-bold text-gray-800">{site.sitec_score?.toFixed(1)}점</span>
                      </div>
                      <div className="score-bar">
                        <div
                          className="score-fill"
                          style={{
                            width: `${site.sitec_score}%`,
                            backgroundColor: site.sitec_grade === 'A' ? '#10b981'
                              : site.sitec_grade === 'B' ? '#3b82f6'
                              : site.sitec_grade === 'C' ? '#f59e0b' : '#ef4444'
                          }}
                        />
                      </div>
                      <div className="flex gap-3 text-xs text-gray-500 pt-1">
                        {site.planned_units && (
                          <span className="flex items-center gap-0.5">
                            <Home size={10} /> {site.planned_units}세대
                          </span>
                        )}
                        {site.demand_score && (
                          <span className="flex items-center gap-0.5">
                            <TrendingUp size={10} /> 수요 {site.demand_score.toFixed(0)}점
                          </span>
                        )}
                        {site.expected_margin && (
                          <span className="flex items-center gap-0.5">
                            <DollarSign size={10} /> {site.expected_margin.toFixed(0)}%
                          </span>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="text-xs text-gray-400 bg-gray-50 rounded-lg px-3 py-2 text-center">
                      평가 대기 중
                    </div>
                  )}

                  <div className="flex items-center justify-between mt-3 pt-2 border-t border-gray-50">
                    <span className={`text-xs rounded-full px-2 py-0.5 ${
                      site.status === 'evaluated' ? 'bg-green-50 text-green-700' : 'bg-gray-100 text-gray-500'
                    }`}>
                      {site.status === 'evaluated' ? '평가완료' : site.status === 'draft' ? '초안' : site.status}
                    </span>
                    <span className="text-xs text-blue-600 flex items-center gap-0.5 font-medium">
                      리포트 보기 <ChevronRight size={11} />
                    </span>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* 등급 분포 + 시스템 상태 */}
      {evaluated.length > 0 && (
        <div className="grid md:grid-cols-2 gap-4">
          <div className="card">
            <div className="card-header"><BarChart3 size={14} /> SITE-C 등급 분포</div>
            <div className="space-y-3">
              {[
                { grade: 'A', label: 'A등급 (≥80점)', color: 'bg-green-500' },
                { grade: 'B', label: 'B등급 (65~79점)', color: 'bg-blue-500' },
                { grade: 'C', label: 'C등급 (50~64점)', color: 'bg-yellow-500' },
                { grade: '탈락', label: '탈락 (<50점)', color: 'bg-red-400' },
              ].map(({ grade, label, color }) => {
                const count = evaluated.filter(s => s.sitec_grade === grade).length
                const pct = evaluated.length > 0 ? Math.round(count / evaluated.length * 100) : 0
                return (
                  <div key={grade}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-gray-600">{label}</span>
                      <span className="font-semibold text-gray-900">{count}개 ({pct}%)</span>
                    </div>
                    <div className="score-bar">
                      <div className={`score-fill ${color}`} style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                )
              })}
            </div>
            <button
              onClick={() => onNavigate('portfolio')}
              className="w-full mt-4 flex items-center justify-center gap-2 text-sm text-indigo-600 hover:text-indigo-800 font-medium py-2 border border-indigo-100 hover:border-indigo-200 rounded-xl bg-indigo-50 hover:bg-indigo-100 transition-colors"
            >
              <Layers size={14} /> 클러스터 최적화 검토 <ArrowRight size={13} />
            </button>
          </div>

          <div className="card">
            <div className="card-header"><Clock size={14} /> 시스템 상태</div>
            <div className="space-y-2.5">
              {[
                { name: 'SITE-C 평가 엔진', status: 'ready', desc: 'LH 심의기준 자동 정량화' },
                { name: 'VWorld 필지 API', status: 'ready', desc: '실데이터 조회 활성' },
                { name: 'AI 사업지 요약', status: 'ready', desc: 'AI 기반 종합 분석' },
                { name: 'ILP 최적화', status: 'ready', desc: '클러스터 포트폴리오 최적화' },
              ].map(m => (
                <div key={m.name} className="flex items-center justify-between py-1.5 border-b border-gray-50 last:border-0">
                  <div>
                    <span className="font-medium text-sm text-gray-800">{m.name}</span>
                    <p className="text-xs text-gray-400">{m.desc}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${
                    m.status === 'ready' ? 'bg-green-50 text-green-700 border-green-200'
                    : m.status === 'simulation' ? 'bg-blue-50 text-blue-700 border-blue-200'
                    : 'bg-gray-100 text-gray-500 border-gray-200'
                  }`}>
                    {m.status === 'ready' ? '운영중' : m.status === 'simulation' ? '시뮬레이션' : '예정'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 종합 리포트 모달 */}
      {selectedSiteId !== null && (
        <ReportModal siteId={selectedSiteId} onClose={() => setSelectedSiteId(null)} />
      )}
    </div>
  )
}
