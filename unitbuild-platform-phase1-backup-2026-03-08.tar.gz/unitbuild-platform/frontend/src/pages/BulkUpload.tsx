/**
 * BulkUpload.tsx – 대규모 CSV 사업지 업로드 & 배치 평가 페이지
 * 최대 200개 주소 일괄 업로드 → 비동기 평가 → 진행 추적
 */
import { useState, useRef, useCallback } from 'react'
import {
  Upload, Download, FileText, Play, RefreshCw, CheckCircle,
  XCircle, Clock, AlertCircle, ChevronDown, ChevronUp, Info,
  Loader2, BarChart2, Building, TrendingUp, DollarSign
} from 'lucide-react'

const API = '/api/v1'

interface AddressRow { address: string; name: string }
interface ParseError { row: number; message: string }
interface EvalResult {
  address: string
  name?: string
  status: 'ok' | 'error' | 'pending'
  sitec_score?: number
  sitec_grade?: string
  overall_grade?: string
  roi_pct?: number
  construction_cost_bn?: number
  error?: string
  site_id?: number
}
interface JobStatus {
  job_id: string
  status: 'pending' | 'running' | 'done' | 'error'
  total: number
  completed: number
  results: EvalResult[]
  created_at: string
}

const CSV_TEMPLATE = `address,name
서울특별시 강남구 역삼동 123,역삼 사업지
경기도 성남시 분당구 정자동 456,정자 사업지
인천광역시 연수구 송도동 789,송도 사업지`

const GRADE_COLOR: Record<string, string> = {
  'A+': 'bg-emerald-100 text-emerald-700',
  'A': 'bg-green-100 text-green-700',
  'B+': 'bg-blue-100 text-blue-700',
  'B': 'bg-sky-100 text-sky-700',
  'C': 'bg-yellow-100 text-yellow-700',
  'D': 'bg-red-100 text-red-700',
}

export default function BulkUpload() {
  const [rows, setRows] = useState<AddressRow[]>([])
  const [parseErrors, setParseErrors] = useState<ParseError[]>([])
  const [rawText, setRawText] = useState('')
  const [dragOver, setDragOver] = useState(false)
  const [_jobId, setJobId] = useState<string | null>(null)
  const [job, setJob] = useState<JobStatus | null>(null)
  const [polling, setPolling] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [showPreview, setShowPreview] = useState(true)
  const [showErrors, setShowErrors] = useState(false)
  const [tab, setTab] = useState<'upload' | 'results'>('upload')
  const fileRef = useRef<HTMLInputElement>(null)
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // ── CSV 파싱 ────────────────────────────────────────────
  const parseCSV = useCallback((text: string) => {
    const lines = text.trim().split('\n').map(l => l.trim()).filter(Boolean)
    if (lines.length === 0) return
    const errors: ParseError[] = []
    const parsed: AddressRow[] = []

    // 헤더 감지
    const firstLine = lines[0].toLowerCase()
    const hasHeader = firstLine.includes('address') || firstLine.includes('주소')
    const dataLines = hasHeader ? lines.slice(1) : lines

    dataLines.forEach((line, idx) => {
      const rowNum = hasHeader ? idx + 2 : idx + 1
      const cols = line.split(',').map(c => c.trim().replace(/^"|"$/g, ''))
      const address = cols[0] || ''
      const name = cols[1] || `사업지 ${rowNum}`
      if (!address) {
        errors.push({ row: rowNum, message: '주소가 비어 있습니다' })
        return
      }
      if (address.length < 5) {
        errors.push({ row: rowNum, message: `주소가 너무 짧습니다: "${address}"` })
        return
      }
      parsed.push({ address, name })
    })

    if (parsed.length > 200) {
      errors.push({ row: 0, message: `최대 200개까지 처리 가능합니다. 현재 ${parsed.length}개 → 앞에서 200개만 사용됩니다.` })
      parsed.splice(200)
    }

    setRows(parsed)
    setParseErrors(errors)
    setTab('upload')
  }, [])

  const handleFile = (file: File) => {
    const reader = new FileReader()
    reader.onload = e => {
      const text = e.target?.result as string
      setRawText(text)
      parseCSV(text)
    }
    reader.readAsText(file, 'utf-8')
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    const file = e.dataTransfer.files[0]
    if (file) handleFile(file)
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) handleFile(file)
  }

  const handleTextPaste = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setRawText(e.target.value)
    parseCSV(e.target.value)
  }

  // ── CSV 템플릿 다운로드 ─────────────────────────────────
  const downloadTemplate = () => {
    const blob = new Blob(['\uFEFF' + CSV_TEMPLATE], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'unitbuild_bulk_template.csv'; a.click()
    URL.revokeObjectURL(url)
  }

  // ── 결과 CSV 다운로드 ────────────────────────────────────
  const downloadResults = () => {
    if (!job) return
    const header = 'name,address,status,sitec_score,sitec_grade,roi_pct,construction_cost_억\n'
    const rows = job.results.map(r =>
      `"${r.name ?? ''}","${r.address}",${r.status},${r.sitec_score?.toFixed(1) ?? ''},${r.sitec_grade ?? ''},${r.roi_pct?.toFixed(1) ?? ''},${r.construction_cost_bn?.toFixed(0) ?? ''}`
    ).join('\n')
    const blob = new Blob(['\uFEFF' + header + rows], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'unitbuild_bulk_results.csv'; a.click()
    URL.revokeObjectURL(url)
  }

  // ── 폴링 ────────────────────────────────────────────────
  const startPolling = (id: string) => {
    setPolling(true)
    pollRef.current = setInterval(async () => {
      try {
        const res = await fetch(`${API}/bulk/job/${id}`)
        if (!res.ok) return
        const data: JobStatus = await res.json()
        setJob(data)
        if (data.status === 'done' || data.status === 'error') {
          clearInterval(pollRef.current!)
          setPolling(false)
          setTab('results')
        }
      } catch { /* 무시 */ }
    }, 2000)
  }

  // ── 평가 시작 ────────────────────────────────────────────
  const startEval = async () => {
    if (rows.length === 0) return
    setSubmitting(true)
    try {
      const res = await fetch(`${API}/bulk/evaluate-csv`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ addresses: rows.map(r => ({ address: r.address, name: r.name })) }),
      })
      if (!res.ok) throw new Error(`서버 오류 ${res.status}`)
      const data = await res.json()
      setJobId(data.job_id)
      setJob({
        job_id: data.job_id,
        status: 'pending',
        total: rows.length,
        completed: 0,
        results: [],
        created_at: new Date().toISOString(),
      })
      startPolling(data.job_id)
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : '알 수 없는 오류'
      alert('평가 시작 실패: ' + msg)
    } finally {
      setSubmitting(false)
    }
  }

  const reset = () => {
    if (pollRef.current) clearInterval(pollRef.current)
    setRows([]); setParseErrors([]); setRawText(''); setJobId(null)
    setJob(null); setPolling(false); setTab('upload')
  }

  // ── KPI 계산 ─────────────────────────────────────────────
  const kpi = (() => {
    if (!job?.results?.length) return null
    const done = job.results.filter(r => r.status === 'ok')
    const aGrade = done.filter(r => r.sitec_grade && ['A', 'B'].includes(r.sitec_grade))
    const rois = done.filter(r => r.roi_pct !== undefined).map(r => r.roi_pct!)
    const costs = done.filter(r => r.construction_cost_bn).map(r => r.construction_cost_bn!)
    return {
      total: job.total,
      done: done.length,
      aGrade: aGrade.length,
      avgMargin: rois.length ? rois.reduce((a, b) => a + b, 0) / rois.length : null,
      totalCost: costs.length ? costs.reduce((a, b) => a + b, 0) : null,
    }
  })()

  const progress = job ? Math.round((job.completed / Math.max(job.total, 1)) * 100) : 0

  return (
    <div className="space-y-6">

      {/* ── 헤더 */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-black text-gray-900">대규모 사업지 검토</h1>
          <p className="text-gray-500 text-sm mt-1">CSV 파일로 최대 200개 주소를 업로드하여 일괄 SITE-C 평가</p>
        </div>
        <button
          onClick={downloadTemplate}
          className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-sm font-medium hover:bg-slate-200 transition-colors"
        >
          <Download size={15} /> CSV 템플릿 다운로드
        </button>
      </div>

      {/* ── 탭 */}
      <div className="flex gap-1 bg-slate-100 rounded-xl p-1 w-fit">
        {(['upload', 'results'] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-5 py-2 rounded-lg text-sm font-semibold transition-all ${
              tab === t ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            {t === 'upload' ? '📁 업로드' : '📊 평가 결과'}
            {t === 'results' && job && (
              <span className="ml-1.5 px-1.5 py-0.5 text-xs rounded-full bg-blue-600 text-white">
                {job.completed}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* ════ UPLOAD TAB ════════════════════════════════════ */}
      {tab === 'upload' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {/* 파일 드롭존 */}
          <div className="space-y-4">
            <div
              onDragOver={e => { e.preventDefault(); setDragOver(true) }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
              onClick={() => fileRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all ${
                dragOver ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50/50'
              }`}
            >
              <Upload size={36} className={`mx-auto mb-3 ${dragOver ? 'text-blue-500' : 'text-gray-400'}`} />
              <p className="font-semibold text-gray-700">CSV 파일을 드래그하거나 클릭</p>
              <p className="text-xs text-gray-400 mt-1">address, name 두 컬럼 · 최대 200행 · UTF-8</p>
              <input ref={fileRef} type="file" accept=".csv,.txt" className="hidden" onChange={handleFileInput} />
            </div>

            {/* CSV 포맷 안내 */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
              <div className="flex items-center gap-2 text-amber-700 font-semibold text-sm mb-2">
                <Info size={15} /> CSV 포맷 안내
              </div>
              <pre className="text-xs text-amber-800 bg-amber-100 rounded-lg p-3 overflow-x-auto">
{`address,name
서울특별시 강남구 역삼동 123,역삼 사업지
경기도 성남시 분당구 정자동 456,정자 사업지`}
              </pre>
              <ul className="text-xs text-amber-700 mt-2 space-y-1">
                <li>• 첫 번째 컬럼: 주소 (필수)</li>
                <li>• 두 번째 컬럼: 사업지명 (선택)</li>
                <li>• 헤더 행은 있어도 없어도 됩니다</li>
              </ul>
            </div>
          </div>

          {/* 텍스트 직접 입력 */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                또는 주소 직접 붙여넣기
              </label>
              <textarea
                className="w-full h-48 p-3 border border-gray-300 rounded-xl text-sm font-mono resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder={`address,name\n서울특별시 강남구 역삼동 123,역삼 사업지\n경기도 성남시 분당구 정자동 456,정자 사업지`}
                value={rawText}
                onChange={handleTextPaste}
              />
              {rows.length > 0 && (
                <p className="text-xs text-green-600 mt-1">✓ {rows.length}개 주소 파싱 완료</p>
              )}
            </div>

            {/* 파싱 에러 */}
            {parseErrors.length > 0 && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-4">
                <button
                  className="flex items-center justify-between w-full text-sm font-semibold text-red-700"
                  onClick={() => setShowErrors(!showErrors)}
                >
                  <span><XCircle size={14} className="inline mr-1" />파싱 오류 {parseErrors.length}건</span>
                  {showErrors ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                </button>
                {showErrors && (
                  <ul className="mt-2 space-y-1">
                    {parseErrors.map((e, i) => (
                      <li key={i} className="text-xs text-red-600">
                        {e.row > 0 ? `행 ${e.row}: ` : ''}{e.message}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── 미리보기 패널 (업로드 탭) */}
      {tab === 'upload' && rows.length > 0 && (
        <div className="card">
          <button
            className="flex items-center justify-between w-full text-sm font-semibold text-gray-800 mb-3"
            onClick={() => setShowPreview(!showPreview)}
          >
            <span><FileText size={15} className="inline mr-1.5" />주소 미리보기 ({rows.length}개)</span>
            {showPreview ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>
          {showPreview && (
            <div className="overflow-x-auto max-h-64 overflow-y-auto">
              <table className="w-full text-xs">
                <thead className="sticky top-0 bg-slate-50">
                  <tr>
                    <th className="text-left py-2 px-3 text-gray-500 font-semibold">#</th>
                    <th className="text-left py-2 px-3 text-gray-500 font-semibold">사업지명</th>
                    <th className="text-left py-2 px-3 text-gray-500 font-semibold">주소</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r, i) => (
                    <tr key={i} className="border-t border-gray-100 hover:bg-gray-50">
                      <td className="py-1.5 px-3 text-gray-400">{i + 1}</td>
                      <td className="py-1.5 px-3 font-medium text-gray-700">{r.name}</td>
                      <td className="py-1.5 px-3 text-gray-600">{r.address}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ── 실행 버튼 (업로드 탭) */}
      {tab === 'upload' && (
        <div className="flex items-center gap-3">
          <button
            disabled={rows.length === 0 || submitting || polling}
            onClick={startEval}
            className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors shadow-sm"
          >
            {submitting ? <Loader2 size={16} className="animate-spin" /> : <Play size={16} />}
            {submitting ? '평가 시작 중...' : `${rows.length}개 일괄 평가 시작`}
          </button>
          {rows.length > 0 && (
            <button onClick={reset} className="flex items-center gap-2 px-4 py-3 bg-slate-100 text-slate-600 rounded-xl text-sm font-medium hover:bg-slate-200 transition-colors">
              <RefreshCw size={15} /> 초기화
            </button>
          )}
          {rows.length === 0 && (
            <p className="text-sm text-gray-400">CSV 파일을 업로드하거나 주소를 입력하세요</p>
          )}
        </div>
      )}

      {/* ── 진행 상태 바 */}
      {job && (
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              {polling ? (
                <Loader2 size={16} className="animate-spin text-blue-500" />
              ) : job.status === 'done' ? (
                <CheckCircle size={16} className="text-green-500" />
              ) : (
                <AlertCircle size={16} className="text-red-500" />
              )}
              <span className="font-semibold text-gray-800">
                {polling ? '평가 진행 중...' : job.status === 'done' ? '평가 완료' : '오류 발생'}
              </span>
            </div>
            <span className="text-sm text-gray-500">
              {job.completed} / {job.total} 완료 ({progress}%)
            </span>
          </div>
          <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                job.status === 'done' ? 'bg-green-500' : 'bg-blue-500'
              }`}
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      )}

      {/* ════ RESULTS TAB ════════════════════════════════════ */}
      {tab === 'results' && (
        <div className="space-y-6">

          {/* KPI */}
          {kpi && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="card text-center">
                <Building size={20} className="mx-auto text-blue-500 mb-2" />
                <div className="text-2xl font-black text-gray-900">{kpi.done}</div>
                <div className="text-xs text-gray-500 mt-0.5">평가 완료</div>
              </div>
              <div className="card text-center">
                <CheckCircle size={20} className="mx-auto text-emerald-500 mb-2" />
                <div className="text-2xl font-black text-gray-900">{kpi.aGrade}</div>
                <div className="text-xs text-gray-500 mt-0.5">A등급 이상</div>
              </div>
              <div className="card text-center">
                <TrendingUp size={20} className="mx-auto text-purple-500 mb-2" />
                <div className="text-2xl font-black text-gray-900">
                  {kpi.avgMargin !== null ? `${kpi.avgMargin.toFixed(1)}%` : '-'}
                </div>
                <div className="text-xs text-gray-500 mt-0.5">평균 ROI</div>
              </div>
              <div className="card text-center">
                <DollarSign size={20} className="mx-auto text-amber-500 mb-2" />
                <div className="text-2xl font-black text-gray-900">
                  {kpi.totalCost !== null ? `${kpi.totalCost.toFixed(0)}억` : '-'}
                </div>
                <div className="text-xs text-gray-500 mt-0.5">총 예상 건축비(억)</div>
              </div>
            </div>
          )}

          {/* 결과 테이블 */}
          {job && job.results.length > 0 ? (
            <div className="card overflow-hidden p-0">
              <div className="flex items-center justify-between p-4 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <BarChart2 size={16} className="text-blue-500" />
                  <span className="font-semibold text-gray-800">평가 결과 ({job.results.length}건)</span>
                </div>
                <button
                  onClick={downloadResults}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg text-xs font-medium hover:bg-slate-200 transition-colors"
                >
                  <Download size={13} /> CSV 다운로드
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="text-left py-3 px-4 text-gray-500 font-semibold text-xs">#</th>
                      <th className="text-left py-3 px-4 text-gray-500 font-semibold text-xs">사업지명</th>
                      <th className="text-left py-3 px-4 text-gray-500 font-semibold text-xs">주소</th>
                      <th className="text-center py-3 px-4 text-gray-500 font-semibold text-xs">상태</th>
                      <th className="text-center py-3 px-4 text-gray-500 font-semibold text-xs">SITE-C</th>
                      <th className="text-center py-3 px-4 text-gray-500 font-semibold text-xs">등급</th>
                      <th className="text-right py-3 px-4 text-gray-500 font-semibold text-xs">수익률</th>
                      <th className="text-right py-3 px-4 text-gray-500 font-semibold text-xs">건축비(억)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {job.results.map((r, i) => (
                      <tr key={i} className="border-t border-gray-100 hover:bg-gray-50">
                        <td className="py-2.5 px-4 text-gray-400 text-xs">{i + 1}</td>
                        <td className="py-2.5 px-4 font-medium text-gray-800">{r.name}</td>
                        <td className="py-2.5 px-4 text-gray-500 text-xs max-w-[200px] truncate">{r.address}</td>
                        <td className="py-2.5 px-4 text-center">
                          {r.status === 'ok' ? (
                            <span className="inline-flex items-center gap-1 text-xs text-green-700 bg-green-100 px-2 py-0.5 rounded-full">
                              <CheckCircle size={11} /> 완료
                            </span>
                          ) : r.status === 'error' ? (
                            <span className="inline-flex items-center gap-1 text-xs text-red-700 bg-red-100 px-2 py-0.5 rounded-full" title={r.error}>
                              <XCircle size={11} /> 오류
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">
                              <Clock size={11} /> 대기
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-4 text-center font-bold text-blue-700">
                          {r.sitec_score?.toFixed(1) ?? '-'}
                        </td>
                        <td className="py-2.5 px-4 text-center">
                          {r.sitec_grade ? (
                            <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${GRADE_COLOR[r.sitec_grade] ?? 'bg-gray-100 text-gray-600'}`}>
                              {r.sitec_grade}
                            </span>
                          ) : '-'}
                        </td>
                        <td className="py-2.5 px-4 text-right text-sm">
                          {r.roi_pct !== undefined
                            ? <span className="font-semibold text-purple-700">{r.roi_pct.toFixed(1)}%</span>
                            : '-'}
                        </td>
                        <td className="py-2.5 px-4 text-right text-sm">
                          {r.construction_cost_bn !== undefined
                            ? <span className="font-medium text-gray-700">{r.construction_cost_bn.toFixed(0)}억</span>
                            : '-'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="card text-center py-16 text-gray-400">
              <BarChart2 size={40} className="mx-auto mb-3 opacity-30" />
              <p className="font-medium">아직 평가 결과가 없습니다</p>
              <p className="text-sm mt-1">업로드 탭에서 CSV를 업로드하고 평가를 시작하세요</p>
              <button
                onClick={() => setTab('upload')}
                className="mt-4 px-5 py-2 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors"
              >
                업로드로 이동
              </button>
            </div>
          )}

          {/* 오류 목록 */}
          {job && job.results.filter(r => r.status === 'error').length > 0 && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4">
              <p className="font-semibold text-red-700 text-sm mb-2">
                <XCircle size={14} className="inline mr-1" />
                평가 실패 {job.results.filter(r => r.status === 'error').length}건
              </p>
              <ul className="space-y-1">
                {job.results.filter(r => r.status === 'error').map((r, i) => (
                  <li key={i} className="text-xs text-red-600">• {r.name} ({r.address}): {r.error}</li>
                ))}
              </ul>
            </div>
          )}

          <div className="flex gap-3">
            <button onClick={reset} className="flex items-center gap-2 px-5 py-2.5 bg-slate-100 text-slate-700 rounded-xl text-sm font-semibold hover:bg-slate-200 transition-colors">
              <RefreshCw size={15} /> 새 업로드
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
