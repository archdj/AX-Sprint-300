/**
 * ClusterReview.tsx – 기본 클러스터 검토 (소규모 수동 클러스터링)
 * 등록된 사업지에서 직접 선택 → 클러스터 구성 → 비용 최적화
 */
import { useState, useEffect } from 'react'
import {
  Layers, RefreshCw, X, Info,
  CheckCircle, AlertCircle, Building, DollarSign,
  Map
} from 'lucide-react'

const API = '/api/v1'

interface SiteRow {
  id: number
  name: string
  address: string
  lat?: number
  lng?: number
  planned_units?: number
  sitec_score?: number
  sitec_grade?: string
  expected_margin?: number
  estimated_cost?: number
}

interface ClusterCalc {
  sites: SiteRow[]
  total_units: number
  n_sites: number
  base_cost: number
  discount_pct: number
  discounted_cost: number
  savings: number
  avg_sitec: number
  avg_margin: number
}

const GRADE_COLOR: Record<string, string> = {
  'A+': 'bg-emerald-100 text-emerald-700',
  'A':  'bg-green-100 text-green-700',
  'B+': 'bg-blue-100 text-blue-700',
  'B':  'bg-sky-100 text-sky-700',
  'C':  'bg-yellow-100 text-yellow-700',
  'D':  'bg-red-100 text-red-700',
}

function calcDiscount(nUnits: number, nSites: number): number {
  let base = 0
  if (nUnits <= 20) base = 0
  else if (nUnits <= 50) base = (nUnits - 20) / 30 * 5
  else if (nUnits <= 100) base = 5 + (nUnits - 50) / 50 * 5
  else if (nUnits <= 200) base = 10 + (nUnits - 100) / 100 * 6
  else if (nUnits <= 400) base = 16 + (nUnits - 200) / 200 * 2
  else base = 18 + Math.min((nUnits - 400) / 400 * 4, 4)

  const siteBonus = nSites >= 5 ? 4 : nSites >= 3 ? 2 : nSites >= 2 ? 1 : 0
  return Math.min(base + siteBonus, 22)
}

function computeCluster(sites: SiteRow[]): ClusterCalc {
  const totalUnits = sites.reduce((a, s) => a + (s.planned_units ?? 0), 0)
  const baseCost = sites.reduce((a, s) => a + (s.estimated_cost ?? 0), 0)
  const discPct = sites.length >= 2 ? calcDiscount(totalUnits, sites.length) : 0
  const discounted = baseCost * (1 - discPct / 100)
  const avgSitec = sites.filter(s => s.sitec_score).reduce((a, s, _, arr) => a + (s.sitec_score! / arr.length), 0)
  const margins = sites.filter(s => s.expected_margin).map(s => s.expected_margin!)
  const avgMargin = margins.length ? margins.reduce((a, b) => a + b, 0) / margins.length : 0
  return {
    sites,
    total_units: totalUnits,
    n_sites: sites.length,
    base_cost: baseCost,
    discount_pct: discPct,
    discounted_cost: discounted,
    savings: baseCost - discounted,
    avg_sitec: avgSitec,
    avg_margin: avgMargin,
  }
}

export default function ClusterReview() {
  const [allSites, setAllSites] = useState<SiteRow[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set())
  const [search, setSearch] = useState('')
  const [showGuide, setShowGuide] = useState(true)

  useEffect(() => {
    fetch(`${API}/sites/?limit=200`)
      .then(r => r.json())
      .then(d => { setAllSites(d.items || d); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  const toggle = (id: number) => {
    const next = new Set(selectedIds)
    next.has(id) ? next.delete(id) : next.add(id)
    setSelectedIds(next)
  }

  const filtered = allSites.filter(s => {
    const q = search.toLowerCase()
    return !q || s.name.toLowerCase().includes(q) || s.address.toLowerCase().includes(q)
  })

  const selectedSites = allSites.filter(s => selectedIds.has(s.id))
  const cluster = selectedSites.length >= 1 ? computeCluster(selectedSites) : null

  return (
    <div className="space-y-6">

      {/* ── 헤더 */}
      <div>
        <h1 className="text-2xl font-black text-gray-900">클러스터 검토</h1>
        <p className="text-gray-500 text-sm mt-1">
          사업지를 직접 선택하여 클러스터를 구성하고 모듈 동시제작 건축비 절감을 시뮬레이션
        </p>
      </div>

      {/* 가이드 */}
      {showGuide && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 relative">
          <button
            onClick={() => setShowGuide(false)}
            className="absolute top-3 right-3 text-blue-400 hover:text-blue-600"
          >
            <X size={15} />
          </button>
          <div className="flex items-center gap-2 text-blue-700 font-semibold text-sm mb-2">
            <Info size={14} /> 클러스터 검토 사용법
          </div>
          <ol className="text-xs text-blue-700 space-y-1 list-decimal list-inside">
            <li>아래 목록에서 함께 묶을 사업지를 클릭하여 선택하세요</li>
            <li>2개 이상 선택하면 모듈 동시제작 건축비 할인이 자동 계산됩니다</li>
            <li>오른쪽 클러스터 패널에서 절감 효과를 확인하세요</li>
            <li>더 많은 사업지와 큰 클러스터일수록 할인율이 높아집니다 (최대 22%)</li>
          </ol>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">

        {/* ── 왼쪽: 사업지 목록 (3/5) */}
        <div className="lg:col-span-3 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-gray-800">사업지 선택</h2>
            <span className="text-xs text-gray-400">{selectedIds.size}개 선택</span>
          </div>

          {/* 검색 */}
          <input
            className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="사업지명 또는 주소 검색..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />

          {loading ? (
            <div className="text-center py-12 text-gray-400">
              <RefreshCw size={28} className="mx-auto mb-2 animate-spin opacity-40" />
              <p className="text-sm">사업지 불러오는 중...</p>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <Building size={32} className="mx-auto mb-2 opacity-30" />
              <p className="text-sm font-medium">등록된 사업지가 없습니다</p>
              <p className="text-xs mt-1">먼저 단일 평가 또는 대규모 검토에서 사업지를 등록하세요</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[560px] overflow-y-auto pr-1">
              {filtered.map(s => {
                const isSelected = selectedIds.has(s.id)
                return (
                  <button
                    key={s.id}
                    onClick={() => toggle(s.id)}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                      isSelected
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-blue-300 bg-white'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3 flex-1">
                        <div className={`w-5 h-5 mt-0.5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                          isSelected ? 'bg-blue-600 border-blue-600' : 'border-gray-300'
                        }`}>
                          {isSelected && <CheckCircle size={12} className="text-white" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-gray-800 text-sm">{s.name}</div>
                          <div className="text-xs text-gray-500 mt-0.5 truncate">{s.address}</div>
                          <div className="flex items-center gap-2 mt-1.5">
                            {s.sitec_grade && (
                              <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${GRADE_COLOR[s.sitec_grade] ?? 'bg-gray-100 text-gray-600'}`}>
                                {s.sitec_grade}
                              </span>
                            )}
                            {s.sitec_score && (
                              <span className="text-xs text-blue-700 font-semibold">{s.sitec_score.toFixed(1)}점</span>
                            )}
                            {s.planned_units && (
                              <span className="text-xs text-gray-500">{s.planned_units}세대</span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        {s.expected_margin !== undefined && (
                          <div className="text-xs font-bold text-purple-700">
                            {(s.expected_margin * 100).toFixed(1)}%
                          </div>
                        )}
                        {s.estimated_cost && (
                          <div className="text-xs text-gray-500 mt-0.5">
                            {(s.estimated_cost / 1e8).toFixed(0)}억
                          </div>
                        )}
                      </div>
                    </div>
                  </button>
                )
              })}
            </div>
          )}
        </div>

        {/* ── 오른쪽: 클러스터 패널 (2/5) */}
        <div className="lg:col-span-2 space-y-4">
          <h2 className="font-bold text-gray-800">클러스터 분석</h2>

          {cluster && cluster.n_sites >= 1 ? (
            <div className="space-y-4">
              {/* 선택된 사업지 요약 */}
              <div className="card">
                <div className="flex items-center gap-2 text-gray-800 font-semibold text-sm mb-3">
                  <Layers size={15} className="text-blue-500" />
                  선택 사업지 ({cluster.n_sites}개)
                </div>
                <div className="space-y-2">
                  {cluster.sites.map(s => (
                    <div key={s.id} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => toggle(s.id)}
                          className="w-4 h-4 text-red-400 hover:text-red-600 transition-colors"
                        >
                          <X size={14} />
                        </button>
                        <span className="font-medium text-gray-700 truncate max-w-[110px]">{s.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {s.sitec_grade && (
                          <span className={`px-1.5 py-0.5 rounded-full font-bold text-[10px] ${GRADE_COLOR[s.sitec_grade] ?? ''}`}>
                            {s.sitec_grade}
                          </span>
                        )}
                        <span className="text-gray-500">{s.planned_units ?? 0}세대</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 건축비 절감 */}
              <div className={`card ${cluster.n_sites >= 2 && cluster.discount_pct > 0 ? 'bg-emerald-50 border-emerald-200' : 'bg-gray-50'}`}>
                <div className="flex items-center gap-2 font-semibold text-sm mb-4">
                  <DollarSign size={15} className="text-emerald-600" />
                  <span className="text-gray-800">건축비 절감 분석</span>
                </div>

                {cluster.n_sites < 2 ? (
                  <div className="text-center py-4 text-gray-400">
                    <AlertCircle size={24} className="mx-auto mb-2 opacity-40" />
                    <p className="text-sm">2개 이상 선택 시 할인 적용</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">기준 건축비</span>
                      <span className="font-semibold text-gray-700">{(cluster.base_cost / 1e8).toFixed(0)}억원</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">모듈 동시제작 할인</span>
                      <span className="font-bold text-emerald-600">-{cluster.discount_pct.toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between text-sm border-t border-gray-200 pt-2">
                      <span className="font-semibold text-gray-700">적용 후 건축비</span>
                      <span className="font-black text-blue-700">{(cluster.discounted_cost / 1e8).toFixed(0)}억원</span>
                    </div>
                    <div className="bg-emerald-100 rounded-xl p-3 text-center">
                      <div className="text-lg font-black text-emerald-700">
                        -{(cluster.savings / 1e8).toFixed(0)}억원 절감
                      </div>
                      <div className="text-xs text-emerald-600 mt-0.5">
                        {cluster.total_units}세대 동시제작 규모의 경제
                      </div>
                    </div>

                    {/* 게이지 */}
                    <div>
                      <div className="flex justify-between text-xs text-gray-400 mb-1">
                        <span>절감 {cluster.discount_pct.toFixed(1)}%</span>
                        <span>최대 22%</span>
                      </div>
                      <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-emerald-500 rounded-full transition-all"
                          style={{ width: `${(cluster.discount_pct / 22) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* 클러스터 지표 */}
              <div className="card">
                <div className="font-semibold text-sm text-gray-800 mb-3">클러스터 종합 지표</div>
                <div className="space-y-2.5">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">총 계획 세대수</span>
                    <span className="font-bold text-gray-800">{cluster.total_units}세대</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">SITE-C 평균</span>
                    <span className="font-bold text-blue-700">{cluster.avg_sitec.toFixed(1)}점</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">평균 기대수익률</span>
                    <span className="font-bold text-purple-700">{(cluster.avg_margin * 100).toFixed(1)}%</span>
                  </div>
                </div>
              </div>

              {/* 초기화 */}
              <button
                onClick={() => setSelectedIds(new Set())}
                className="w-full flex items-center justify-center gap-2 py-2.5 bg-slate-100 text-slate-600 rounded-xl text-sm font-medium hover:bg-slate-200 transition-colors"
              >
                <RefreshCw size={14} /> 선택 초기화
              </button>
            </div>
          ) : (
            <div className="card text-center py-12 text-gray-400">
              <Map size={36} className="mx-auto mb-3 opacity-30" />
              <p className="font-medium text-sm">사업지를 선택하세요</p>
              <p className="text-xs mt-1">2개 이상 선택 시<br />건축비 할인이 자동 계산됩니다</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
