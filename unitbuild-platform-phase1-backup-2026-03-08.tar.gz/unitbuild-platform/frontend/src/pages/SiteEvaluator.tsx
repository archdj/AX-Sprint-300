import { useState } from 'react'
import { useMutation as _useMutation, useQueryClient } from '@tanstack/react-query'
import type { SiteCInput, SiteCResult, HazardReport, DemandResult } from '../api'
import { sitecAPI, hazardAPI, demandAPI, sitesAPI } from '../api'
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine
} from 'recharts'
import { Search, MapPin, Zap, ShieldCheck, TrendingUp, AlertCircle, CheckCircle2, XCircle, Loader2, Save } from 'lucide-react'

interface EvalState {
  sitec: SiteCResult | null
  hazard: HazardReport | null
  demand: DemandResult | null
  loading: boolean
  error: string | null
}

const defaultInput: SiteCInput & { name: string; address: string; lat: number; lng: number } = {
  name: '',
  address: '',
  lat: 37.4979,
  lng: 127.0276,
  cbd_distance_km: 15,
  subway_distance_m: 800,
  bus_stop_distance_m: 300,
  elementary_school_distance_m: 600,
  hospital_distance_m: 500,
  mart_distance_m: 200,
  planned_units: 30,
  small_unit_ratio: 0.5,
  seismic_grade: 1,
  slope_percent: 5,
  energy_efficiency_grade: 2,
  sunshine_hours: 4.5,
  is_modular: true,
  long_term_rental: false,
  lh_certified: false,
}

const gradeStyle: Record<string, { bg: string; text: string; ring: string }> = {
  'A': { bg: 'bg-green-50', text: 'text-green-700', ring: 'ring-green-300' },
  'B': { bg: 'bg-blue-50', text: 'text-blue-700', ring: 'ring-blue-300' },
  'C': { bg: 'bg-yellow-50', text: 'text-yellow-700', ring: 'ring-yellow-300' },
  '탈락': { bg: 'bg-red-50', text: 'text-red-700', ring: 'ring-red-300' },
}

export default function SiteEvaluator() {
  const [form, setForm] = useState(defaultInput)
  const [state, setState] = useState<EvalState>({ sitec: null, hazard: null, demand: null, loading: false, error: null })
  const [saved, setSaved] = useState(false)
  const queryClient = useQueryClient()

  const handleChange = (key: string, value: string | number | boolean) => {
    setForm(prev => ({ ...prev, [key]: value }))
  }

  const handleEvaluate = async () => {
    if (!form.name || !form.address) {
      setState(p => ({ ...p, error: '사업지명과 주소를 입력하세요.' }))
      return
    }
    setState({ sitec: null, hazard: null, demand: null, loading: true, error: null })
    setSaved(false)
    try {
      const [sitec, hazard, demand] = await Promise.all([
        sitecAPI.evaluate(form),
        hazardAPI.verify(form.lat, form.lng),
        demandAPI.predict(form.lat, form.lng),
      ])
      setState({ sitec, hazard, demand, loading: false, error: null })
    } catch (e: any) {
      setState(p => ({ ...p, loading: false, error: '평가 중 오류가 발생했습니다: ' + (e.message || '') }))
    }
  }

  const handleSave = async () => {
    if (!state.sitec || !state.hazard || !state.demand) return
    try {
      const siteData = {
        name: form.name,
        address: form.address,
        lat: form.lat,
        lng: form.lng,
        planned_units: form.planned_units,
        small_unit_ratio: form.small_unit_ratio,
        is_modular: form.is_modular,
        cbd_distance_km: form.cbd_distance_km,
        subway_distance_m: form.subway_distance_m,
        bus_stop_distance_m: form.bus_stop_distance_m,
        elementary_school_distance_m: form.elementary_school_distance_m,
        hospital_distance_m: form.hospital_distance_m,
        mart_distance_m: form.mart_distance_m,
        seismic_grade: form.seismic_grade,
        slope_percent: form.slope_percent,
        energy_efficiency_grade: form.energy_efficiency_grade,
        sunshine_hours: form.sunshine_hours,
        long_term_rental: form.long_term_rental,
        lh_certified: form.lh_certified,
      }
      await sitesAPI.create(siteData)
      queryClient.invalidateQueries({ queryKey: ['sites'] })
      setSaved(true)
    } catch (e) {
      console.error(e)
    }
  }

  // 레이더 차트 데이터
  const radarData = state.sitec ? [
    { subject: '교통\n접근성', value: state.sitec.transportation_score * 100, fullMark: 100 },
    { subject: '생활\n인프라', value: state.sitec.infrastructure_score * 100, fullMark: 100 },
    { subject: '사업\n규모', value: state.sitec.scale_score * 100, fullMark: 100 },
    { subject: '구조\n안전', value: state.sitec.structure_score * 100, fullMark: 100 },
    { subject: '에너지\n환경', value: state.sitec.energy_score * 100, fullMark: 100 },
    { subject: '사업자\n가점', value: state.sitec.bonus_score * 100, fullMark: 100 },
  ] : []

  const grade = state.sitec?.grade || ''
  const gStyle = gradeStyle[grade] || { bg: 'bg-gray-50', text: 'text-gray-600', ring: 'ring-gray-200' }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Search size={20} className="text-blue-600" />
        <h2 className="text-xl font-bold text-gray-900">사업지 평가</h2>
        <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">
          SITE-C + 위해시설 + AI 수요예측
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* 입력 폼 */}
        <div className="space-y-4">
          {/* 기본 정보 */}
          <div className="card">
            <div className="card-header"><MapPin size={15} /> 기본 정보</div>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="form-label">사업지명 *</label>
                <input className="form-input" value={form.name} onChange={e => handleChange('name', e.target.value)} placeholder="예: 강남구 역삼동 모듈러 임대" />
              </div>
              <div className="col-span-2">
                <label className="form-label">주소 *</label>
                <input className="form-input" value={form.address} onChange={e => handleChange('address', e.target.value)} placeholder="예: 서울시 강남구 역삼동 000-0" />
              </div>
              <div>
                <label className="form-label">위도 (Lat)</label>
                <input className="form-input" type="number" step="0.0001" value={form.lat} onChange={e => handleChange('lat', parseFloat(e.target.value))} />
              </div>
              <div>
                <label className="form-label">경도 (Lng)</label>
                <input className="form-input" type="number" step="0.0001" value={form.lng} onChange={e => handleChange('lng', parseFloat(e.target.value))} />
              </div>
            </div>
          </div>

          {/* A. 교통 접근성 */}
          <div className="card">
            <div className="card-header">
              <span className="bg-blue-100 text-blue-700 text-xs px-1.5 py-0.5 rounded font-bold">A</span>
              교통 접근성 <span className="text-gray-400 font-normal text-xs">(25%)</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <NumberInput label="CBD 거리 (km)" value={form.cbd_distance_km} onChange={v => handleChange('cbd_distance_km', v)} step={1} />
              <NumberInput label="지하철역 거리 (m)" value={form.subway_distance_m} onChange={v => handleChange('subway_distance_m', v)} step={50} />
              <NumberInput label="버스정류장 거리 (m)" value={form.bus_stop_distance_m} onChange={v => handleChange('bus_stop_distance_m', v)} step={50} />
            </div>
          </div>

          {/* B. 생활 인프라 */}
          <div className="card">
            <div className="card-header">
              <span className="bg-green-100 text-green-700 text-xs px-1.5 py-0.5 rounded font-bold">B</span>
              생활 인프라 <span className="text-gray-400 font-normal text-xs">(20%)</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <NumberInput label="초등학교 거리 (m)" value={form.elementary_school_distance_m} onChange={v => handleChange('elementary_school_distance_m', v)} step={50} />
              <NumberInput label="병원 거리 (m)" value={form.hospital_distance_m} onChange={v => handleChange('hospital_distance_m', v)} step={50} />
              <NumberInput label="마트/편의점 거리 (m)" value={form.mart_distance_m} onChange={v => handleChange('mart_distance_m', v)} step={50} />
            </div>
          </div>

          {/* C. 사업 규모 */}
          <div className="card">
            <div className="card-header">
              <span className="bg-purple-100 text-purple-700 text-xs px-1.5 py-0.5 rounded font-bold">C</span>
              사업 규모 <span className="text-gray-400 font-normal text-xs">(20%)</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <NumberInput label="계획 세대수" value={form.planned_units} onChange={v => handleChange('planned_units', v)} step={1} />
              <div>
                <label className="form-label">전용60㎡이하 비율 ({Math.round(form.small_unit_ratio * 100)}%)</label>
                <input type="range" min={0} max={1} step={0.05} value={form.small_unit_ratio}
                  onChange={e => handleChange('small_unit_ratio', parseFloat(e.target.value))}
                  className="w-full accent-purple-600 mt-2" />
              </div>
            </div>
          </div>

          {/* D+E. 구조/에너지 */}
          <div className="card">
            <div className="card-header">
              <span className="bg-orange-100 text-orange-700 text-xs px-1.5 py-0.5 rounded font-bold">D·E</span>
              구조·안전 / 에너지·환경 <span className="text-gray-400 font-normal text-xs">(15%+10%)</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <SelectInput label="내진등급" value={form.seismic_grade} onChange={v => handleChange('seismic_grade', v)}
                options={[{ value: 1, label: '1등급 (최우수)' }, { value: 2, label: '2등급' }]} />
              <NumberInput label="경사도 (%)" value={form.slope_percent} onChange={v => handleChange('slope_percent', v)} step={0.5} />
              <SelectInput label="에너지효율등급" value={form.energy_efficiency_grade} onChange={v => handleChange('energy_efficiency_grade', v)}
                options={[1,2,3,4,5].map(n => ({ value: n, label: `${n}등급` }))} />
              <NumberInput label="일조시간 (h)" value={form.sunshine_hours} onChange={v => handleChange('sunshine_hours', v)} step={0.5} />
            </div>
          </div>

          {/* F. 사업자 가점 */}
          <div className="card">
            <div className="card-header">
              <span className="bg-yellow-100 text-yellow-700 text-xs px-1.5 py-0.5 rounded font-bold">F</span>
              사업자 가점 <span className="text-gray-400 font-normal text-xs">(10%)</span>
            </div>
            <div className="space-y-2">
              {[
                { key: 'is_modular', label: '모듈러 공법 적용 (+1.0) — 유닛랩 해당', val: form.is_modular },
                { key: 'long_term_rental', label: '장기임대 10년 이상 (+0.8)', val: form.long_term_rental },
                { key: 'lh_certified', label: 'LH 우수시공사 인증 (+0.7)', val: form.lh_certified },
              ].map(({ key, label, val }) => (
                <label key={key} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 rounded p-1.5">
                  <input type="checkbox" checked={val} onChange={e => handleChange(key, e.target.checked)}
                    className="w-4 h-4 accent-yellow-600" />
                  <span className="text-sm">{label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* 평가 버튼 */}
          <button
            onClick={handleEvaluate}
            disabled={state.loading}
            className="w-full py-3 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700 disabled:opacity-60 flex items-center justify-center gap-2 transition-colors"
          >
            {state.loading ? (
              <><Loader2 size={18} className="animate-spin" /> 평가 진행 중...</>
            ) : (
              <><Zap size={18} /> SITE-C 자동 평가 실행</>
            )}
          </button>

          {state.error && (
            <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-3 text-sm flex items-center gap-2">
              <AlertCircle size={16} /> {state.error}
            </div>
          )}
        </div>

        {/* 결과 패널 */}
        <div className="space-y-4">
          {!state.sitec && !state.loading && (
            <div className="card flex flex-col items-center justify-center h-64 text-gray-400">
              <Zap size={48} className="mb-3 opacity-20" />
              <p className="font-medium">평가를 실행하면 결과가 표시됩니다</p>
              <p className="text-xs mt-1">SITE-C 점수 · 위해시설 · AI 수요예측을 동시에 분석합니다</p>
            </div>
          )}

          {state.sitec && (
            <>
              {/* SITE-C 결과 카드 */}
              <div className={`card ${gStyle.bg} ring-2 ${gStyle.ring}`}>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-xs text-gray-500 font-medium">SITE-C 총점</p>
                    <p className="text-4xl font-black text-gray-900">{state.sitec.total_score.toFixed(1)}</p>
                    <p className="text-xs text-gray-500">/ 100점</p>
                  </div>
                  <div className="text-center">
                    <div className={`grade-badge grade-${grade} text-3xl w-16 h-16`}>{grade}</div>
                    <p className={`text-xs mt-1 font-bold ${gStyle.text}`}>
                      심의통과 {Math.round(state.sitec.approval_probability * 100)}%
                    </p>
                  </div>
                </div>

                {/* 항목별 점수 바 */}
                <div className="space-y-2">
                  {Object.entries(state.sitec.breakdown).map(([key, val]) => (
                    <div key={key}>
                      <div className="flex justify-between text-xs mb-0.5">
                        <span className="text-gray-600">{key}</span>
                        <span className="font-semibold">{val.toFixed(1)}점</span>
                      </div>
                      <div className="score-bar">
                        <div className="score-fill bg-blue-500"
                          style={{ width: `${(val / 25) * 100}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 레이더 차트 */}
              <div className="card">
                <div className="card-header"><Zap size={15} /> SITE-C 항목별 분포</div>
                <ResponsiveContainer width="100%" height={220}>
                  <RadarChart data={radarData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11 }} />
                    <PolarRadiusAxis domain={[0, 100]} tick={{ fontSize: 10 }} />
                    <Radar name="점수" dataKey="value" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.3} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>

              {/* 개선 제안 */}
              {state.sitec.improvement_suggestions.length > 0 && (
                <div className="card">
                  <div className="card-header"><AlertCircle size={15} className="text-amber-500" /> 개선 제안</div>
                  <ul className="space-y-2">
                    {state.sitec.improvement_suggestions.map((s, i) => (
                      <li key={i} className="text-sm flex items-start gap-2">
                        <span className="text-amber-500 mt-0.5">→</span>
                        <span>{s}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}

          {/* 위해시설 검증 결과 */}
          {state.hazard && (
            <div className="card">
              <div className="card-header justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck size={15} className="text-gray-500" />
                  <span>위해시설 검증</span>
                </div>
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full border
                  ${state.hazard.risk_level === 'SAFE' ? 'bg-green-50 text-green-700 border-green-200' :
                    state.hazard.risk_level === 'WARNING' ? 'bg-yellow-50 text-yellow-700 border-yellow-200' :
                    'bg-red-50 text-red-700 border-red-200'}`}>
                  {state.hazard.risk_level === 'SAFE' ? '✅ SAFE' :
                   state.hazard.risk_level === 'WARNING' ? '⚠️ WARNING' : '🔴 DANGER'}
                </span>
              </div>
              <div className="space-y-2">
                {state.hazard.results.map(r => (
                  <div key={r.hazard_type} className={`flex items-center justify-between text-sm p-2 rounded-lg ${r.is_compliant ? 'bg-green-50' : 'bg-red-50'}`}>
                    <div className="flex items-center gap-2">
                      {r.is_compliant ? <CheckCircle2 size={15} className="text-green-600" /> : <XCircle size={15} className="text-red-600" />}
                      <span className="font-medium">{r.hazard_label}</span>
                    </div>
                    <div className="text-right text-xs">
                      <span className={r.is_compliant ? 'text-green-600' : 'text-red-600'}>
                        {r.nearest_distance_m != null ? `${r.nearest_distance_m.toFixed(0)}m` : '해당없음'}
                      </span>
                      <span className="text-gray-400 ml-1">/ {r.required_distance_m}m</span>
                    </div>
                  </div>
                ))}
              </div>
              {state.hazard.results.filter(r => !r.is_compliant).length > 0 && (
                <div className="mt-3 text-xs text-red-600 bg-red-50 rounded-lg p-2 border border-red-100">
                  {state.hazard.results.filter(r => !r.is_compliant).map(r => r.improvement).join(' | ')}
                </div>
              )}
            </div>
          )}

          {/* 수요 예측 결과 */}
          {state.demand && (
            <div className="card">
              <div className="card-header justify-between">
                <div className="flex items-center gap-2">
                  <TrendingUp size={15} className="text-gray-500" />
                  <span>AI 수요 예측</span>
                  <span className="text-xs text-gray-400">({state.demand.region_name})</span>
                </div>
                <span className="text-lg font-black text-purple-600">
                  {state.demand.demand_score.toFixed(1)}점
                </span>
              </div>
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="text-center bg-purple-50 rounded-lg p-2">
                  <p className="text-xs text-gray-500">추천 세대수</p>
                  <p className="text-xl font-bold text-purple-700">{state.demand.recommended_units}</p>
                </div>
                <div className="text-center bg-purple-50 rounded-lg p-2">
                  <p className="text-xs text-gray-500">예측 신뢰도</p>
                  <p className="text-xl font-bold text-purple-700">{Math.round(state.demand.confidence * 100)}%</p>
                </div>
                <div className="text-center bg-purple-50 rounded-lg p-2">
                  <p className="text-xs text-gray-500">필지 점수</p>
                  <p className="text-xl font-bold text-purple-700">{state.demand.hierarchy.parcel_score.toFixed(1)}</p>
                </div>
              </div>

              {/* 12개월 예측 차트 */}
              <ResponsiveContainer width="100%" height={130}>
                <AreaChart data={state.demand.forecast_monthly}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="month" tick={{ fontSize: 9 }} interval={2} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 10 }} />
                  <Tooltip formatter={(v: unknown) => [`${Number(v).toFixed(1)}점`, '수요점수']} />
                  <ReferenceLine y={65} stroke="#f59e0b" strokeDasharray="4 4" label={{ value: 'B등급', fontSize: 10 }} />
                  <Area type="monotone" dataKey="demand_score" stroke="#8b5cf6" fill="#ede9fe" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>

              {state.demand.risk_factors.length > 0 && (
                <div className="mt-3">
                  <p className="text-xs font-semibold text-gray-500 mb-1">리스크 요인</p>
                  <ul className="space-y-1">
                    {state.demand.risk_factors.map((r, i) => (
                      <li key={i} className="text-xs text-amber-700 flex items-start gap-1">
                        <span>•</span><span>{r}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* 저장 버튼 */}
          {state.sitec && (
            <button
              onClick={handleSave}
              disabled={saved}
              className={`w-full py-3 font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors ${
                saved
                  ? 'bg-green-100 text-green-700 cursor-default'
                  : 'bg-gray-800 text-white hover:bg-gray-900'
              }`}
            >
              {saved ? (
                <><CheckCircle2 size={18} /> 저장 완료</>
              ) : (
                <><Save size={18} /> 사업지 DB 저장</>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

function NumberInput({ label, value, onChange, step }: {
  label: string; value: number; onChange: (v: number) => void; step: number
}) {
  return (
    <div>
      <label className="form-label">{label}</label>
      <input type="number" step={step} value={value}
        onChange={e => onChange(parseFloat(e.target.value) || 0)}
        className="form-input" />
    </div>
  )
}

function SelectInput({ label, value, onChange, options }: {
  label: string; value: number; onChange: (v: number) => void;
  options: { value: number; label: string }[]
}) {
  return (
    <div>
      <label className="form-label">{label}</label>
      <select value={value} onChange={e => onChange(parseInt(e.target.value))} className="form-input">
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  )
}
