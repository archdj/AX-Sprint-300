import { useState, useRef } from 'react'
import axios from 'axios'
import {
  Search, Loader2, CheckCircle2, MapPin, Building2,
  TrendingUp, Zap, Shield, BarChart3,
  Star, ChevronRight, Package, Layers, Clock,
  XCircle, Award, Home, AlertCircle,
} from 'lucide-react'

interface AutoEvalResult {
  address_input: string
  parcel: {
    address: string; lat: number; lng: number; area_m2: number
    zone_name: string; coverage_ratio_max: number; floor_area_ratio_max: number; max_floors: number
  }
  best_module: string; best_floor: number; best_units: number
  roi_pct: number; coverage_ratio: number; floor_area_ratio: number
  sitec_score: number; sitec_grade: string; sitec_approval_prob: number
  sitec_breakdown: Record<string, number>; sitec_suggestions: string[]
  demand_score: number; recommended_units: number; demand_region: string
  construction_cost_bn: number; lh_purchase_bn: number; profit_bn: number
  overall_grade: string; overall_summary: string
  key_strengths: string[]; key_risks: string[]; next_actions: string[]
  is_simulation: boolean; data_sources: string[]; errors: string[]
}

const GRADE_STYLE: Record<string, { bg: string; text: string; border: string; label: string }> = {
  'A+': { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-300', label: '탁월' },
  'A':  { bg: 'bg-green-50',   text: 'text-green-700',   border: 'border-green-300',   label: '우수' },
  'B':  { bg: 'bg-blue-50',    text: 'text-blue-700',    border: 'border-blue-300',    label: '양호' },
  'C':  { bg: 'bg-yellow-50',  text: 'text-yellow-700',  border: 'border-yellow-300',  label: '검토' },
  '검토요': { bg: 'bg-red-50', text: 'text-red-700',     border: 'border-red-300',     label: '재검토' },
}

const FEATURES = [
  {
    icon: <MapPin size={24} className="text-blue-400" />,
    iconBg: 'bg-blue-900/40',
    title: '필지 자동 조회',
    desc: '지번 하나로 면적·용도지역·건폐율·용적률·층수 제한까지 VWorld·카카오 API 실데이터로 즉시 확인',
  },
  {
    icon: <Building2 size={24} className="text-teal-400" />,
    iconBg: 'bg-teal-900/40',
    title: '유닛 제품 최적 배치',
    desc: '유닛빌드 유닛 제품을 해당 필지에 최적 배치·세대수·층수·건폐율 자동 산출',
  },
  {
    icon: <Star size={24} className="text-yellow-400" />,
    iconBg: 'bg-yellow-900/40',
    title: 'SITE-C 자동 채점',
    desc: 'LH 신축매입약정 심의기준 6개 항목을 자동 정량화. A·B·C·탈락 등급과 심의 통과 확률 제공',
  },
  {
    icon: <TrendingUp size={24} className="text-purple-400" />,
    iconBg: 'bg-purple-900/40',
    title: '수요·사업성 분석',
    desc: '지역 수요 점수, 권장 세대수, 공사비·LH 매입가·예상 수익·ROI까지 원스톱 사업성 분석',
  },
  {
    icon: <Layers size={24} className="text-indigo-400" />,
    iconBg: 'bg-indigo-900/40',
    title: '포트폴리오 최적화',
    desc: 'ILP 알고리즘으로 여러 사업지를 클러스터화·공장 CAPA 배분·동시 현장 수 최적 조합 산출',
  },
  {
    icon: <Shield size={24} className="text-green-400" />,
    iconBg: 'bg-green-900/40',
    title: '실데이터 기반 신뢰성',
    desc: 'VWorld 국토 API, 카카오맵 API 연동으로 공시 데이터 기반 정확한 분석 결과 제공',
  },
]

const PROCESS_STEPS = [
  { num: '01', title: '지번 입력', desc: '법정동 지번 주소\n(예: 강남구 역삼동 123-45)', icon: <MapPin size={20} /> },
  { num: '02', title: '필지 분석', desc: 'VWorld·카카오 API\n실데이터 자동 조회', icon: <Search size={20} /> },
  { num: '03', title: '모듈 배치', desc: '유닛 제품군\n최적 세대·층수 계산', icon: <Building2 size={20} /> },
  { num: '04', title: 'SITE-C 채점', desc: 'LH 심의기준\n6개 항목 자동 점수화', icon: <Star size={20} /> },
  { num: '05', title: '사업성 리포트', desc: 'ROI·수익·등급\n종합 판정 완료', icon: <BarChart3 size={20} /> },
]

const EVAL_CRITERIA = [
  { label: 'A. 교통 접근성', weight: '25%', items: ['지하철 도보 거리', '버스 정류장', '도심 접근성'], color: 'bg-blue-500' },
  { label: 'B. 생활 인프라', weight: '20%', items: ['초등학교 거리', '의료시설', '생활편의시설'], color: 'bg-emerald-500' },
  { label: 'C. 사업 규모', weight: '20%', items: ['필지 면적', '계획 세대수', '소형주택 비율'], color: 'bg-purple-500' },
  { label: 'D. 구조·안전', weight: '15%', items: ['내진 등급', '경사도', '위해시설 거리'], color: 'bg-amber-500' },
  { label: 'E. 에너지·환경', weight: '10%', items: ['에너지효율 등급', '일조시간', '환경 기준'], color: 'bg-cyan-500' },
  { label: 'F. 사업자 가점', weight: '10%', items: ['모듈러 공법', '장기임대 계획', 'LH 인증'], color: 'bg-pink-500' },
]

interface LandingPageProps {
  onNavigate: (tab: string) => void
}

export default function LandingPage({ onNavigate }: LandingPageProps) {
  const [address, setAddress] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<AutoEvalResult | null>(null)
  const [error, setError] = useState('')
  const resultRef = useRef<HTMLDivElement>(null)

  const handleEvaluate = async () => {
    const trimmed = address.trim()
    if (!trimmed || trimmed.length < 5) {
      setError('지번 주소를 입력하세요. 예) 서울시 강남구 역삼동 123-45')
      return
    }
    setLoading(true)
    setError('')
    setResult(null)
    try {
      const res = await axios.post<AutoEvalResult>('/api/v1/auto/evaluate', {
        address: trimmed,
        planned_units: null,
        long_term_rental: false,
        lh_certified: false,
        energy_grade: 2,
        small_unit_ratio: 0.8,
      })
      setResult(res.data)
      setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 150)
    } catch (e: unknown) {
      const err = e as { response?: { data?: { detail?: string } }; message?: string }
      setError(err.response?.data?.detail || err.message || '평가 중 오류가 발생했습니다.')
    } finally {
      setLoading(false)
    }
  }

  const overallStyle = result ? (GRADE_STYLE[result.overall_grade] || GRADE_STYLE['검토요']) : null

  return (
    <div className="min-h-screen bg-slate-50">

      {/* ── 히어로 섹션 ─────────────────────────────────────── */}
      <section className="hero-section py-20 px-4">
        <div className="hero-grid" />
        <div className="relative max-w-5xl mx-auto text-center">

          {/* 배지 */}
          <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-1.5 text-xs text-blue-200 font-medium mb-6">
            <Zap size={12} className="text-yellow-400" />
            LH 신축매입약정 × 모듈러 건축 자동 분석 플랫폼
          </div>

          {/* 헤드라인 */}
          <h1 className="text-4xl md:text-6xl font-black text-white leading-tight mb-5">
            LH 사업지,<br />
            <span className="gradient-text">지번 하나면 충분합니다</span>
          </h1>
          <p className="text-blue-200 text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
            모듈러 건축 기반 사업성 검토부터 SITE-C 채점·ROI 산출까지<br className="hidden md:block" />
            10초 안에 완성하는 LH 신축매입약정 자동화 플랫폼
          </p>

          {/* 인라인 평가 입력 */}
          <div className="hero-input-box max-w-2xl mx-auto">
            <p className="text-white/70 text-sm font-medium mb-3 text-left">📍 사업지 지번 주소를 입력하세요</p>
            <div className="flex gap-2">
              <input
                className="flex-1 px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/40 text-sm focus:outline-none focus:border-blue-400 focus:bg-white/15 transition-all"
                value={address}
                onChange={e => setAddress(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleEvaluate()}
                placeholder="예: 서울특별시 강남구 역삼동 702-10"
              />
              <button
                onClick={handleEvaluate}
                disabled={loading}
                className="flex items-center gap-2 px-6 py-3 bg-blue-500 hover:bg-blue-400 text-white rounded-xl font-semibold text-sm transition-all disabled:opacity-50 whitespace-nowrap shadow-lg"
              >
                {loading ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />}
                {loading ? '분석 중...' : '자동 평가'}
              </button>
            </div>

            {/* 오류 */}
            {error && (
              <div className="flex items-center gap-2 mt-3 text-red-300 text-xs">
                <XCircle size={13} /> {error}
              </div>
            )}

            {/* 샘플 주소 */}
            {!result && !loading && (
              <div className="flex flex-wrap gap-2 mt-3">
                <span className="text-white/40 text-xs">예시:</span>
                {[
                  '서울특별시 중랑구 면목동 612-6',
                  '서울특별시 양천구 신월동 104-26',
                ].map(addr => (
                  <button
                    key={addr}
                    onClick={() => setAddress(addr)}
                    className="text-xs text-blue-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-full px-2.5 py-0.5 transition-colors"
                  >
                    {addr}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* 결과 미리보기 (히어로 내) */}
          {loading && (
            <div className="hero-input-box max-w-2xl mx-auto mt-4">
              <div className="flex items-center gap-3 text-blue-200 text-sm">
                <Loader2 size={18} className="animate-spin text-blue-400" />
                <span>VWorld·카카오 API 실데이터 조회 중...</span>
              </div>
              <div className="flex flex-wrap gap-2 mt-3">
                {['📍 좌표 조회', '🗺️ 용도지역', '🏗️ 모듈 배치', '⭐ SITE-C', '💰 사업성'].map((s, i) => (
                  <span key={i} className="text-xs bg-white/5 border border-white/10 text-white/50 rounded-full px-2 py-0.5">{s}</span>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* ── 평가 결과 섹션 ──────────────────────────────────── */}
      {result && (
        <section ref={resultRef} className="max-w-5xl mx-auto px-4 py-10">
          <div className={`rounded-2xl border-2 ${overallStyle?.border} ${overallStyle?.bg} p-6 mb-6`}>
            <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
              <div className="flex items-center gap-4">
                <span className={`text-5xl font-black ${overallStyle?.text}`}>{result.overall_grade}</span>
                <div>
                  <div className={`font-bold text-lg ${overallStyle?.text}`}>{overallStyle?.label} 사업지</div>
                  <div className="text-sm text-gray-500">{result.parcel.address} · {result.is_simulation ? '시뮬레이션' : '실데이터'}</div>
                </div>
              </div>
              <div className="flex gap-6 flex-wrap">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-700">{result.sitec_score.toFixed(1)}점</div>
                  <div className="text-xs text-gray-500">SITE-C</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-700">{result.best_units}세대</div>
                  <div className="text-xs text-gray-500">추천 세대수</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-700">{result.roi_pct.toFixed(1)}%</div>
                  <div className="text-xs text-gray-500">예상 ROI</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">{result.profit_bn.toFixed(1)}억</div>
                  <div className="text-xs text-gray-500">예상 수익</div>
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-700 mb-4">{result.overall_summary}</p>

            {/* 핵심 수치 */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              {[
                { label: '필지 면적', value: `${result.parcel.area_m2.toLocaleString()}㎡` },
                { label: '용도지역', value: result.parcel.zone_name },
                { label: '최적 모듈', value: result.best_module },
                { label: '승인 확률', value: `${(result.sitec_approval_prob * 100).toFixed(0)}%` },
              ].map(item => (
                <div key={item.label} className="bg-white/60 rounded-xl p-3 text-center">
                  <div className="text-xs text-gray-500 mb-0.5">{item.label}</div>
                  <div className="font-bold text-gray-900 text-sm">{item.value}</div>
                </div>
              ))}
            </div>

            {/* 강점 & 제안 */}
            {result.key_strengths.length > 0 && (
              <div className="grid md:grid-cols-2 gap-3 mb-4">
                <div>
                  <div className="text-xs font-semibold text-green-700 mb-2 flex items-center gap-1">
                    <CheckCircle2 size={12} /> 사업 강점
                  </div>
                  {result.key_strengths.slice(0, 3).map((s, i) => (
                    <div key={i} className="text-xs text-green-800 bg-green-50 rounded-lg px-3 py-1.5 mb-1.5 flex items-start gap-1.5">
                      <CheckCircle2 size={11} className="mt-0.5 shrink-0" /> {s}
                    </div>
                  ))}
                </div>
                {result.sitec_suggestions.length > 0 && (
                  <div>
                    <div className="text-xs font-semibold text-amber-700 mb-2 flex items-center gap-1">
                      <AlertCircle size={12} /> 개선 제안
                    </div>
                    {result.sitec_suggestions.slice(0, 3).map((s, i) => (
                      <div key={i} className="text-xs text-amber-800 bg-amber-50 rounded-lg px-3 py-1.5 mb-1.5 flex items-start gap-1.5">
                        <AlertCircle size={11} className="mt-0.5 shrink-0" /> {s}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 액션 버튼 */}
            <div className="flex flex-wrap gap-3 pt-3 border-t border-gray-200">
              <button
                onClick={() => onNavigate('auto')}
                className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors"
              >
                <BarChart3 size={15} /> 상세 분석 보기
              </button>
              <button
                onClick={() => onNavigate('portfolio')}
                className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-semibold hover:bg-indigo-700 transition-colors"
              >
                <Layers size={15} /> 포트폴리오 검토
              </button>
              <button
                onClick={() => { setResult(null); setAddress('') }}
                className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 text-gray-600 rounded-xl text-sm hover:bg-gray-50 transition-colors"
              >
                다른 주소 평가
              </button>
            </div>
          </div>
        </section>
      )}

      {/* ── 진행 방식 ────────────────────────────────────────── */}
      <section className="max-w-5xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <div className="section-tag">평가 프로세스</div>
          <h2 className="text-3xl font-black text-gray-900">입력부터 리포트까지, 자동으로</h2>
          <p className="text-gray-500 mt-2">5단계 자동 파이프라인이 10초 안에 사업지를 완전 분석합니다</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {PROCESS_STEPS.map((step, i) => (
            <div key={i} className="relative">
              {i < PROCESS_STEPS.length - 1 && (
                <div className="hidden md:block absolute top-8 left-[60%] right-[-40%] h-0.5 bg-gradient-to-r from-blue-300 to-blue-100 z-0" />
              )}
              <div className="relative z-10 text-center">
                <div className="w-16 h-16 rounded-2xl bg-blue-600 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-blue-200">
                  <div className="text-white">{step.icon}</div>
                </div>
                <div className="text-xs font-bold text-blue-600 mb-1">{step.num}</div>
                <div className="font-bold text-gray-900 text-sm mb-1">{step.title}</div>
                <div className="text-xs text-gray-500 leading-relaxed whitespace-pre-line">{step.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── 주요 기능 ─────────────────────────────────────────── */}
      <section className="bg-slate-900 py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-block section-tag bg-white/10 text-blue-300 border-0">핵심 기능</div>
            <h2 className="text-3xl font-black text-white mt-2">스마트 사업지 분석의 모든 것</h2>
            <p className="text-slate-400 mt-2">데이터 기반 의사결정으로 LH 사업 성공률을 높입니다</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {FEATURES.map((f, i) => (
              <div key={i} className="bg-slate-800 border border-slate-700 rounded-2xl p-5 hover:border-blue-500/50 hover:bg-slate-800/80 transition-all">
                <div className={`w-12 h-12 ${f.iconBg} rounded-xl flex items-center justify-center mb-4`}>
                  {f.icon}
                </div>
                <h3 className="font-bold text-white mb-2">{f.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── SITE-C 평가 기준 ──────────────────────────────────── */}
      <section className="max-w-5xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <div className="section-tag">SITE-C 평가 기준</div>
          <h2 className="text-3xl font-black text-gray-900">LH 심의 기준 6개 항목 자동 채점</h2>
          <p className="text-gray-500 mt-2">국토교통부·LH 신축매입약정 기준을 정량화하여 자동으로 점수화합니다</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {EVAL_CRITERIA.map((c, i) => (
            <div key={i} className="card">
              <div className="flex items-center justify-between mb-3">
                <span className="font-bold text-gray-900 text-sm">{c.label}</span>
                <span className={`text-xs font-bold text-white px-2.5 py-1 rounded-full ${c.color}`}>
                  가중치 {c.weight}
                </span>
              </div>
              <div className="space-y-1.5">
                {c.items.map((item, j) => (
                  <div key={j} className="flex items-center gap-2 text-xs text-gray-600">
                    <div className={`w-1.5 h-1.5 rounded-full ${c.color}`} />
                    {item}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* 등급 기준 */}
        <div className="mt-8 bg-white rounded-2xl border border-gray-200 p-6">
          <h3 className="font-bold text-gray-900 mb-4 text-center">SITE-C 등급 기준</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { grade: 'A', range: '80점 이상', prob: '심의 통과 90%+', color: 'bg-green-50 border-green-200 text-green-700' },
              { grade: 'B', range: '65~79점', prob: '심의 통과 75%', color: 'bg-blue-50 border-blue-200 text-blue-700' },
              { grade: 'C', range: '50~64점', prob: '심의 통과 50%', color: 'bg-yellow-50 border-yellow-200 text-yellow-700' },
              { grade: '탈락', range: '50점 미만', prob: '심의 통과 10%', color: 'bg-red-50 border-red-200 text-red-700' },
            ].map(g => (
              <div key={g.grade} className={`border rounded-xl p-3 text-center ${g.color}`}>
                <div className="text-2xl font-black mb-1">{g.grade}</div>
                <div className="text-xs font-semibold">{g.range}</div>
                <div className="text-xs mt-1 opacity-80">{g.prob}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 유닛빌드 소개 ─────────────────────────────────────── */}
      <section className="bg-gradient-to-br from-blue-600 to-blue-800 py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div>
              <div className="inline-block bg-white/10 text-white text-xs font-semibold px-3 py-1 rounded-full mb-4 border border-white/20">
                About UnitBuild
              </div>
              <h2 className="text-3xl font-black text-white mb-4">
                맞춤형 모듈러 건축으로<br />LH 사업을 혁신합니다
              </h2>
              <p className="text-blue-200 leading-relaxed mb-6">
                유닛빌드는 모듈러 건축 기반 LH 신축매입약정 사업의 사업성 검토부터
                모듈 설계·제조·시공까지 원스톱으로 지원하는 스타트업입니다.
                유닛 제품군을 통해 건설 기간 단축·품질 표준화·원가 절감을 실현합니다.
              </p>
              <div className="grid grid-cols-3 gap-4">
                {[
                  { num: '10초', label: '자동 평가 시간' },
                  { num: '90%', label: 'A등급 심의 통과율' },
                  { num: '6종', label: '유닛 모듈 제품' },
                ].map(s => (
                  <div key={s.label} className="text-center">
                    <div className="text-2xl font-black text-white">{s.num}</div>
                    <div className="text-xs text-blue-200 mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-3">
              {[
                { icon: <Package size={18} />, title: '유닛 제품', desc: '6종의 표준화된 모듈러 유닛 제품. 공장 제조·현장 조립으로 품질과 속도를 동시에' },
                { icon: <Clock size={18} />, title: '빠른 사업 진행', desc: '사업지 분석부터 설계·인허가·시공까지 기존 대비 30% 단축된 사업 일정' },
                { icon: <Award size={18} />, title: 'LH 심의 최적화', desc: 'SITE-C 채점 시스템으로 LH 신축매입약정 심의 기준에 최적화된 사업 계획 수립' },
                { icon: <Home size={18} />, title: '투명한 사업성', desc: '공사비·매입가·ROI를 데이터 기반으로 산출. 리스크 없는 사업 의사결정' },
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-3 bg-white/10 rounded-xl p-4 border border-white/10">
                  <div className="w-9 h-9 bg-white/15 rounded-lg flex items-center justify-center shrink-0 text-white">
                    {item.icon}
                  </div>
                  <div>
                    <div className="font-semibold text-white text-sm">{item.title}</div>
                    <div className="text-blue-200 text-xs leading-relaxed mt-0.5">{item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────── */}
      <section className="max-w-5xl mx-auto px-4 py-16 text-center">
        <h2 className="text-3xl font-black text-gray-900 mb-3">지금 바로 사업지를 분석해보세요</h2>
        <p className="text-gray-500 mb-8">회원가입 없이, 지번 주소만으로 즉시 시작</p>
        <div className="flex flex-wrap gap-3 justify-center">
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-2 px-8 py-3.5 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200"
          >
            <Search size={18} /> 무료 사업지 평가 시작
          </button>
          <button
            onClick={() => onNavigate('portfolio')}
            className="flex items-center gap-2 px-8 py-3.5 border-2 border-gray-200 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-colors"
          >
            <ChevronRight size={18} /> 포트폴리오 최적화
          </button>
        </div>
      </section>

      {/* ── 푸터 ─────────────────────────────────────────────── */}
      <footer className="border-t border-gray-200 bg-white py-8 px-4">
        <div className="max-w-5xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center">
              <Building2 size={14} className="text-white" />
            </div>
            <span className="font-black text-gray-900">UnitBuild</span>
            <span className="text-xs text-gray-400">유닛 제품 · LH 자동평가 플랫폼</span>
          </div>
          <div className="text-xs text-gray-400">
            © 2025 UnitBuild. Powered by VWorld · Kakao Map API
          </div>
        </div>
      </footer>
    </div>
  )
}
