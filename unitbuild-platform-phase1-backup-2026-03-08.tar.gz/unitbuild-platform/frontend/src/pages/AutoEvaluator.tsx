import { useState, useRef } from 'react'
import axios from 'axios'
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, Cell,
} from 'recharts'
import {
  Search, MapPin, Building2, TrendingUp, Zap,
  CheckCircle2, AlertCircle, XCircle, Loader2, ChevronRight,
  RotateCcw, Info, Star, Award, Building, Home, Layers,
  BookmarkPlus, CheckCheck, X,
} from 'lucide-react'
import { vworldAPI } from '../api'

// ─── 타입 정의 ────────────────────────────────────────────────

interface ParcelBasic {
  address: string
  lat: number
  lng: number
  area_m2: number
  land_category: string
  zone_name: string
  zone_name2: string
  coverage_ratio_max: number
  floor_area_ratio_max: number
  max_floors: number
  is_simulation: boolean
  data_sources: string[]
}

interface ModulePlan {
  module_type: string
  net_area_m2: number
  lh_type: string
  units_per_floor: number
  floors: number
  total_units: number
  coverage_ratio_pct: number
  floor_area_ratio_pct: number
  roi_pct: number
  is_compliant: boolean
}

interface AutoEvalResult {
  address_input: string
  evaluated_at: string
  parcel: ParcelBasic
  regulations: Record<string, number | string>
  best_module: string
  best_floor: number
  best_units: number
  coverage_ratio: number
  floor_area_ratio: number
  roi_pct: number
  module_plans: ModulePlan[]
  sitec_score: number
  sitec_grade: 'A' | 'B' | 'C' | '탈락'
  sitec_approval_prob: number
  sitec_breakdown: Record<string, number>
  sitec_suggestions: string[]
  sitec_criteria_used: Record<string, Record<string, unknown>>
  demand_score: number
  recommended_units: number
  demand_confidence: number
  demand_region: string
  demand_risk_factors: string[]
  construction_cost_bn: number
  lh_purchase_bn: number
  profit_bn: number
  profit_margin_pct: number
  overall_grade: string
  overall_summary: string
  key_strengths: string[]
  key_risks: string[]
  next_actions: string[]
  is_simulation: boolean
  data_sources: string[]
  errors: string[]
}

// ─── 스타일 상수 ─────────────────────────────────────────────

const GRADE_STYLE: Record<string, { bg: string; text: string; border: string; label: string }> = {
  'A+': { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-300', label: '탁월' },
  'A':  { bg: 'bg-green-50',   text: 'text-green-700',   border: 'border-green-300',   label: '우수' },
  'B':  { bg: 'bg-blue-50',    text: 'text-blue-700',    border: 'border-blue-300',    label: '양호' },
  'C':  { bg: 'bg-yellow-50',  text: 'text-yellow-700',  border: 'border-yellow-300',  label: '검토' },
  '검토요': { bg: 'bg-red-50', text: 'text-red-700',     border: 'border-red-300',     label: '재검토' },
}

const SITEC_STYLE: Record<string, { color: string; label: string; prob: string }> = {
  'A': { color: 'text-green-700',  label: 'A등급 — 우수', prob: '심의 통과 90%+' },
  'B': { color: 'text-blue-700',   label: 'B등급 — 양호', prob: '심의 통과 75%'  },
  'C': { color: 'text-yellow-700', label: 'C등급 — 검토', prob: '심의 통과 50%'  },
  '탈락': { color: 'text-red-700', label: '탈락',          prob: '심의 통과 10%'  },
}

const BREAKDOWN_LABELS: Record<string, { label: string; color: string; weight: string }> = {
  A_교통접근성: { label: 'A. 교통 접근성', color: '#3b82f6', weight: '25%' },
  B_생활인프라:  { label: 'B. 생활 인프라',  color: '#10b981', weight: '20%' },
  C_사업규모:    { label: 'C. 사업 규모',    color: '#8b5cf6', weight: '20%' },
  D_구조안전:    { label: 'D. 구조·안전',   color: '#f59e0b', weight: '15%' },
  E_에너지환경:  { label: 'E. 에너지·환경', color: '#06b6d4', weight: '10%' },
  F_사업자가점:  { label: 'F. 사업자 가점', color: '#ec4899', weight: '10%' },
}

// ─── 워크플로우 단계 컴포넌트 ─────────────────────────────────

function StepBadge({ step, label, done }: { step: number; label: string; done: boolean }) {
  return (
    <div className={`flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium ${
      done ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
    }`}>
      {done
        ? <CheckCircle2 size={12} />
        : <span className="w-3 h-3 rounded-full bg-gray-300 flex items-center justify-center text-[9px] text-white">{step}</span>
      }
      {label}
    </div>
  )
}

// ─── 메인 컴포넌트 ────────────────────────────────────────────

export default function AutoEvaluator() {
  const [address, setAddress] = useState('')
  const [plannedUnits, setPlannedUnits] = useState<number | ''>('')
  const [longTermRental, setLongTermRental] = useState(false)
  const [lhCertified, setLhCertified] = useState(false)
  const [energyGrade, setEnergyGrade] = useState(2)

  const [result, setResult] = useState<AutoEvalResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [activeSection, setActiveSection] = useState<string>('parcel')
  const resultRef = useRef<HTMLDivElement>(null)

  const [vworldStatus, setVworldStatus] = useState<'idle' | 'loading' | 'success' | 'failed'>('idle')
  const [vworldData, setVworldData] = useState<{ area_m2?: number; zone_name?: string; land_category?: string } | null>(null)

  // ── 사업지 등록 상태 ──
  const [saveModal, setSaveModal] = useState(false)
  const [siteName, setSiteName] = useState('')
  const [saveLoading, setSaveLoading] = useState(false)
  const [saveResult, setSaveResult] = useState<{ site_id: number; site_name: string; message: string } | null>(null)
  const [saveError, setSaveError] = useState('')

  const handleEvaluate = async () => {
    const trimmed = address.trim()
    if (!trimmed || trimmed.length < 6) {
      setError('지번 주소를 입력하세요. (예: 서울시 강남구 역삼동 123-45)')
      return
    }
    setLoading(true)
    setError('')
    setResult(null)
    setVworldStatus('idle')
    setVworldData(null)
    setSaveResult(null)

    // ── Step 1: 백엔드 기본 평가 (Kakao 기반) ──
    let backendResult: AutoEvalResult | null = null
    try {
      const res = await axios.post<AutoEvalResult>('/api/v1/auto/evaluate', {
        address: trimmed,
        planned_units: plannedUnits || null,
        long_term_rental: longTermRental,
        lh_certified: lhCertified,
        energy_grade: energyGrade,
        small_unit_ratio: 0.8,
      })
      backendResult = res.data
      setResult(res.data)
      setActiveSection('parcel')
      setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100)
    } catch (e: unknown) {
      const err = e as { response?: { data?: { detail?: string } }; message?: string }
      setError(err.response?.data?.detail || err.message || '평가 중 오류가 발생했습니다.')
      setLoading(false)
      return
    } finally {
      setLoading(false)
    }

    // ── Step 2: 브라우저에서 VWorld 직접 호출 (백엔드 평가와 병행) ──
    if (backendResult?.parcel?.lat && backendResult?.parcel?.lng) {
      setVworldStatus('loading')
      try {
        const pnu = (backendResult as any).pnu || ''
        const { geo, landInfo, landChar } = await vworldAPI.enrichParcel(trimmed, pnu)

        if (landInfo || landChar || geo) {
          const enriched = {
            area_m2: landInfo?.area_m2,
            zone_name: landChar?.zone_name,
            land_category: landInfo?.land_category,
          }
          setVworldData(enriched)
          setVworldStatus('success')

          // VWorld 데이터를 백엔드로 전달 (향후 재평가에 활용)
          if (pnu) {
            await vworldAPI.sendEnrichToBackend({
              pnu,
              area_m2: landInfo?.area_m2,
              land_category: landInfo?.land_category,
              zone_name: landChar?.zone_name,
              zone_name2: landChar?.zone_name2,
              road_side: landChar?.road_side,
              lat: geo?.lat,
              lng: geo?.lng,
              address_parcel: geo?.address_parcel,
            })
          }
        } else {
          setVworldStatus('failed')
        }
      } catch {
        setVworldStatus('failed')
      }
    }
  }

  const handleReset = () => {
    setAddress('')
    setPlannedUnits('')
    setResult(null)
    setError('')
    setSaveResult(null)
  }

  // ── 사업지 등록 핸들러 ──
  const handleSaveSite = async () => {
    if (!result) return
    setSaveLoading(true)
    setSaveError('')
    try {
      const res = await axios.post('/api/v1/auto/save-site', {
        address: result.address_input || address,
        site_name: siteName.trim() || undefined,
        planned_units: result.best_units,
        long_term_rental: longTermRental,
        lh_certified: lhCertified,
        energy_grade: energyGrade,
        small_unit_ratio: 0.8,
      })
      setSaveResult(res.data)
    } catch (e: unknown) {
      const err = e as { response?: { data?: { detail?: string } }; message?: string }
      setSaveError(err.response?.data?.detail || err.message || '사업지 등록 중 오류가 발생했습니다.')
    } finally {
      setSaveLoading(false)
    }
  }

  // 레이더 차트 데이터
  const radarData = result ? Object.entries(BREAKDOWN_LABELS).map(([key, meta]) => ({
    subject: meta.label.split(' ')[1],
    value: Math.round((result.sitec_breakdown[key] ?? 0) * 100),
    fullMark: 100,
  })) : []

  // 모듈 비교 차트
  const moduleChartData = result?.module_plans.slice(0, 5).map(p => ({
    name: p.module_type.replace('BASIC-', 'B-').replace('BALCONY-', 'BAL-'),
    세대수: p.total_units,
    ROI: p.roi_pct,
    적합: p.is_compliant ? 1 : 0,
  })) ?? []

  const overallStyle = result ? (GRADE_STYLE[result.overall_grade] || GRADE_STYLE['검토요']) : null

  return (
    <div className="space-y-5">

      {/* ─── 헤더 ─────────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-600 rounded-lg">
            <Search size={18} className="text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900">지번 자동 통합 평가</h2>
            <p className="text-xs text-gray-500">지번 하나 입력 → 필지·모듈·SITE-C·수요·사업성 자동 분석</p>
          </div>
        </div>
        {result && (
          <button onClick={handleReset} className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-gray-700 border border-gray-200 rounded-lg px-3 py-1.5">
            <RotateCcw size={12} /> 초기화
          </button>
        )}
      </div>

      {/* ─── 입력 폼 ──────────────────────────────────────── */}
      <div className="card">
        <div className="space-y-4">
          {/* 주소 입력 */}
          <div>
            <label className="form-label flex items-center gap-1.5">
              <MapPin size={13} className="text-blue-500" />
              지번 주소 <span className="text-red-500">*</span>
            </label>
            <div className="flex gap-2">
              <input
                className="form-input flex-1"
                value={address}
                onChange={e => setAddress(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleEvaluate()}
                placeholder="예: 서울시 강남구 역삼동 123-45 또는 경기도 성남시 분당구 정자동 1-1"
              />
              <button
                onClick={handleEvaluate}
                disabled={loading}
                className="flex items-center gap-2 px-5 py-2 bg-blue-600 text-white rounded-lg font-medium text-sm hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? <Loader2 size={15} className="animate-spin" /> : <Search size={15} />}
                {loading ? '분석 중...' : '자동 평가'}
              </button>
            </div>
          </div>

          {/* 옵션 */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-1 border-t border-gray-100">
            <div>
              <label className="form-label text-xs">계획 세대수 (미입력 시 자동)</label>
              <input
                type="number" min={5} max={500}
                className="form-input text-sm"
                value={plannedUnits}
                onChange={e => setPlannedUnits(e.target.value ? parseInt(e.target.value) : '')}
                placeholder="자동 추천"
              />
            </div>
            <div>
              <label className="form-label text-xs">에너지효율등급</label>
              <select className="form-input text-sm" value={energyGrade} onChange={e => setEnergyGrade(parseInt(e.target.value))}>
                {[1,2,3,4,5].map(n => <option key={n} value={n}>{n}등급{n===1?' (최우수)':n===2?' (우수)':''}</option>)}
              </select>
            </div>
            <div className="flex flex-col gap-1.5 pt-5">
              <label className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer hover:text-gray-800">
                <input type="checkbox" checked={longTermRental} onChange={e => setLongTermRental(e.target.checked)} className="rounded" />
                장기임대 10년+ 가점 (+0.8)
              </label>
              <label className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer hover:text-gray-800">
                <input type="checkbox" checked={lhCertified} onChange={e => setLhCertified(e.target.checked)} className="rounded" />
                LH 우수시공사 인증 (+0.7)
              </label>
            </div>
            <div className="pt-3">
              <div className="bg-blue-50 border border-blue-100 rounded-lg p-2.5 text-xs text-blue-700 space-y-1">
                <div className="font-medium flex items-center gap-1"><Info size={11} /> 자동 조회 항목</div>
                <div>📍 위도·경도, 필지면적, 용도지역</div>
                <div>🏫 지하철·학교·병원 거리</div>
                <div>🏗️ Gen 2 모듈 최적 배치</div>
                <div>⭐ SITE-C A~F 자동 채점</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ─── 오류 메시지 ──────────────────────────────────── */}
      {error && (
        <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
          <XCircle size={15} className="mt-0.5 shrink-0" />
          {error}
        </div>
      )}

      {/* ─── 로딩 ─────────────────────────────────────────── */}
      {loading && (
        <div className="card">
          <div className="space-y-3 py-4">
            <div className="flex items-center justify-center gap-3 text-blue-600 font-medium">
              <Loader2 size={20} className="animate-spin" />
              자동 분석 파이프라인 실행 중...
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              {[
                '📍 좌표 조회',
                '🗺️ 용도지역 확인',
                '🏗️ 모듈 배치 계산',
                '⭐ SITE-C 채점',
                '📊 수요 예측',
                '💰 사업성 분석',
              ].map((s, i) => (
                <StepBadge key={i} step={i+1} label={s} done={false} />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ─── 결과 영역 ────────────────────────────────────── */}
      {result && (
        <div ref={resultRef} className="space-y-5">

          {/* 종합 판정 배너 */}
          <div className={`rounded-xl border-2 ${overallStyle?.border} ${overallStyle?.bg} p-5`}>
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <span className={`text-4xl font-black ${overallStyle?.text}`}>{result.overall_grade}</span>
                  <div>
                    <div className={`text-sm font-bold ${overallStyle?.text}`}>{overallStyle?.label} 사업지</div>
                    <div className="text-xs text-gray-500">{result.demand_region} · {result.is_simulation ? '시뮬레이션' : '실데이터'}</div>
                  </div>
                </div>
                <p className="text-sm text-gray-700 max-w-xl">{result.overall_summary}</p>
              </div>
              <div className="flex flex-wrap gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-700">{result.sitec_score.toFixed(1)}점</div>
                  <div className="text-xs text-gray-500">SITE-C 점수</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-700">{result.best_units}세대</div>
                  <div className="text-xs text-gray-500">추천 세대수</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-700">{result.roi_pct.toFixed(1)}%</div>
                  <div className="text-xs text-gray-500">예상 ROI</div>
                </div>
              </div>
            </div>

            {/* 진행 단계 + 사업지 등록 버튼 */}
            <div className="flex flex-wrap items-center gap-2 mt-4 pt-3 border-t border-gray-200">
              {[
                '📍 필지조회', '🗺️ 용도지역', '🏗️ 모듈배치',
                '⭐ SITE-C', '📊 수요예측', '💰 사업성',
              ].map((s, i) => (
                <StepBadge key={i} step={i+1} label={s} done={true} />
              ))}
              {result.is_simulation && (
                <span className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-full px-2 py-0.5">
                  ⚠️ 시뮬레이션 모드 (API 키 미설정)
                </span>
              )}
              {/* 사업지 등록 버튼 */}
              <div className="ml-auto">
                {saveResult ? (
                  <span className="flex items-center gap-1.5 text-xs font-medium text-green-700 bg-green-100 border border-green-300 rounded-lg px-3 py-1.5">
                    <CheckCheck size={13} /> 사업지 등록 완료 (#{saveResult.site_id})
                  </span>
                ) : (
                  <button
                    onClick={() => { setSaveModal(true); setSaveError(''); setSiteName('') }}
                    className="flex items-center gap-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg px-3 py-1.5 transition-colors shadow-sm"
                  >
                    <BookmarkPlus size={13} /> 사업지 등록 → 클러스터 검토
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* ─── 사업지 등록 모달 ─────────────────────────── */}
          {saveModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 p-6 space-y-4">
                {/* 모달 헤더 */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-indigo-100 rounded-lg">
                      <BookmarkPlus size={16} className="text-indigo-600" />
                    </div>
                    <h3 className="font-bold text-gray-900">사업지 등록</h3>
                  </div>
                  <button onClick={() => setSaveModal(false)} className="text-gray-400 hover:text-gray-600">
                    <X size={18} />
                  </button>
                </div>

                {/* 요약 정보 */}
                <div className="bg-gray-50 rounded-xl p-4 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">주소</span>
                    <span className="font-medium text-gray-800 text-right max-w-[200px]">{result.address_input || address}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">종합 등급</span>
                    <span className={`font-bold ${overallStyle?.text}`}>{result.overall_grade} ({overallStyle?.label})</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">SITE-C</span>
                    <span className="font-medium">{result.sitec_score.toFixed(1)}점 / {result.sitec_grade}등급</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">추천 세대수</span>
                    <span className="font-medium">{result.best_units}세대</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">예상 ROI</span>
                    <span className="font-medium text-green-700">{result.roi_pct.toFixed(1)}%</span>
                  </div>
                </div>

                {/* 사업지명 입력 */}
                <div>
                  <label className="text-xs font-medium text-gray-600 mb-1 block">
                    사업지 이름 <span className="text-gray-400">(미입력 시 주소로 자동 생성)</span>
                  </label>
                  <input
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300"
                    value={siteName}
                    onChange={e => setSiteName(e.target.value)}
                    placeholder={`예: ${(result.address_input || address).split(' ').slice(-2).join(' ')} 사업지`}
                  />
                </div>

                {/* 오류 메시지 */}
                {saveError && (
                  <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700">
                    <XCircle size={13} className="mt-0.5 shrink-0" />
                    {saveError}
                  </div>
                )}

                {/* 성공 메시지 */}
                {saveResult && (
                  <div className="flex items-start gap-2 p-3 bg-green-50 border border-green-200 rounded-lg text-xs text-green-700">
                    <CheckCheck size={13} className="mt-0.5 shrink-0" />
                    <div>
                      <div className="font-bold">{saveResult.message}</div>
                      <div className="mt-0.5 text-green-600">등록된 사업지: {saveResult.site_name} (ID: #{saveResult.site_id})</div>
                      <div className="mt-1 text-green-600">포트폴리오 탭에서 클러스터 최적화 검토가 가능합니다.</div>
                    </div>
                  </div>
                )}

                {/* 버튼 */}
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={() => setSaveModal(false)}
                    className="flex-1 px-4 py-2 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50"
                  >
                    취소
                  </button>
                  {saveResult ? (
                    <button
                      onClick={() => setSaveModal(false)}
                      className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700"
                    >
                      <CheckCheck size={14} /> 확인
                    </button>
                  ) : (
                    <button
                      onClick={handleSaveSite}
                      disabled={saveLoading}
                      className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 disabled:opacity-50"
                    >
                      {saveLoading
                        ? <><Loader2 size={14} className="animate-spin" /> 등록 중...</>
                        : <><BookmarkPlus size={14} /> 사업지 등록</>
                      }
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 섹션 탭 */}
          <div className="flex gap-1 bg-gray-100 p-1 rounded-xl overflow-x-auto">
            {[
              { key: 'parcel',   icon: <MapPin size={13}/>,     label: '필지정보' },
              { key: 'module',   icon: <Building2 size={13}/>,  label: '모듈배치' },
              { key: 'sitec',    icon: <Star size={13}/>,       label: 'SITE-C' },
              { key: 'demand',   icon: <TrendingUp size={13}/>, label: '수요예측' },
              { key: 'business', icon: <Award size={13}/>,      label: '사업성' },
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveSection(tab.key)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                  activeSection === tab.key
                    ? 'bg-white text-blue-700 shadow-sm'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {tab.icon} {tab.label}
              </button>
            ))}
          </div>

          {/* ── 섹션 1: 필지 정보 ─────────────────────────── */}
          {activeSection === 'parcel' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="card">
                <div className="card-header"><MapPin size={14}/> 필지 기본 정보</div>
                <div className="space-y-2 text-sm">
                  {[
                    { label: '입력 주소', value: result.parcel.address },
                    { label: '좌표', value: `${result.parcel.lat.toFixed(5)}, ${result.parcel.lng.toFixed(5)}` },
                    { label: '필지 면적', value: `${result.parcel.area_m2.toLocaleString()}㎡` },
                    { label: '지목', value: result.parcel.land_category },
                    { label: '용도지역', value: result.parcel.zone_name, highlight: true },
                    { label: '용도지구', value: result.parcel.zone_name2 || '-' },
                  ].map(r => (
                    <div key={r.label} className="flex justify-between items-baseline border-b border-gray-50 pb-1.5">
                      <span className="text-gray-500 text-xs">{r.label}</span>
                      <span className={`font-medium ${r.highlight ? 'text-blue-700' : 'text-gray-800'}`}>{r.value}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="card">
                <div className="card-header"><Layers size={14}/> 건축 규제 한도</div>
                <div className="space-y-2 text-sm">
                  {[
                    { label: '건폐율 한도', value: `${result.parcel.coverage_ratio_max}%`, sub: `최대 건축 면적 ${(result.parcel.area_m2 * result.parcel.coverage_ratio_max / 100).toFixed(0)}㎡` },
                    { label: '용적률 한도', value: `${result.parcel.floor_area_ratio_max}%`, sub: `최대 연면적 ${(result.parcel.area_m2 * result.parcel.floor_area_ratio_max / 100).toFixed(0)}㎡` },
                    { label: '최고 층수', value: result.parcel.max_floors > 0 ? `${result.parcel.max_floors}층 이하` : '제한 없음', sub: (result.regulations as any).floor_limit_note ? '⚠️ 실제 층수 제한 확인 필요' : undefined },
                    { label: '필요 주차', value: `${result.regulations.parking_required ?? '-'}대` },
                  ].map(r => (
                    <div key={r.label} className="flex justify-between items-start border-b border-gray-50 pb-2">
                      <span className="text-gray-500 text-xs">{r.label}</span>
                      <div className="text-right">
                        <div className="font-bold text-blue-700">{r.value}</div>
                        {r.sub && <div className="text-xs text-gray-400">{r.sub}</div>}
                      </div>
                    </div>
                  ))}
                </div>
                {result.regulations.floor_limit_note && (
                  <div className="mt-3 p-2 bg-amber-50 border border-amber-200 rounded text-xs text-amber-800">
                    <span className="font-bold">⚠️ 층수 확인 필요</span><br/>
                    {result.regulations.floor_limit_note}
                  </div>
                )}
                <div className="mt-3 pt-3 border-t border-gray-100">
                  <div className="text-xs text-gray-400 mb-1">데이터 소스</div>
                  <div className="flex flex-wrap gap-1">
                    {result.data_sources.map(s => (
                      <span key={s} className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded">{s}</span>
                    ))}
                    {/* VWorld 브라우저 직접 호출 상태 */}
                    {vworldStatus === 'loading' && (
                      <span className="text-xs bg-blue-100 text-blue-600 px-2 py-0.5 rounded flex items-center gap-1">
                        <Loader2 size={10} className="animate-spin" /> NED 데이터 조회 중...
                      </span>
                    )}
                    {vworldStatus === 'success' && (
                      <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded flex items-center gap-1">
                        <CheckCircle2 size={10} /> NED 실데이터 (VWorld)
                      </span>
                    )}
                    {vworldStatus === 'failed' && (
                      <span className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded" title="VWorld NED 조회 추가 시도 필요">
                        NED 보조조회 미적용
                      </span>
                    )}
                  </div>
                  {/* VWorld 실데이터 보정 결과 표시 */}
                  {vworldData && (
                    <div className="mt-2 p-2 bg-green-50 border border-green-200 rounded-lg">
                      <div className="text-xs font-semibold text-green-700 mb-1">📡 VWorld 실데이터 (브라우저 직접 조회)</div>
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        {vworldData.area_m2 && (
                          <div>
                            <span className="text-gray-500">면적</span>
                            <span className="font-bold ml-1 text-green-800">{vworldData.area_m2} ㎡</span>
                          </div>
                        )}
                        {vworldData.zone_name && (
                          <div>
                            <span className="text-gray-500">용도지역</span>
                            <span className="font-bold ml-1 text-green-800">{vworldData.zone_name}</span>
                          </div>
                        )}
                        {vworldData.land_category && (
                          <div>
                            <span className="text-gray-500">지목</span>
                            <span className="font-bold ml-1 text-green-800">{vworldData.land_category}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* SITE-C 자동 채워진 값 */}
              <div className="card md:col-span-2">
                <div className="card-header"><Info size={14}/> SITE-C 자동 채워진 입력값</div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                  {Object.entries(result.sitec_criteria_used).map(([key, vals]) => (
                    <div key={key} className="bg-gray-50 rounded-lg p-2.5">
                      <div className="font-semibold text-gray-700 mb-1.5">{key.replace('_', ' ')}</div>
                      {Object.entries(vals as Record<string, unknown>).filter(([k]) => k !== 'source').map(([k, v]) => (
                        <div key={k} className="flex justify-between text-gray-600">
                          <span className="text-gray-400">{k.replace(/_/g, ' ')}</span>
                          <span className="font-medium">
                            {typeof v === 'boolean' ? (v ? '✓' : '✗') :
                             typeof v === 'number' ? v.toLocaleString() : String(v)}
                          </span>
                        </div>
                      ))}
                      <div className="mt-1.5 text-gray-400 text-[10px]">{(vals as Record<string, unknown>).source as string}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ── 섹션 2: 모듈 배치 ─────────────────────────── */}
          {activeSection === 'module' && (
            <div className="space-y-4">
              {/* 최적 플랜 */}
              <div className="card border-2 border-blue-200 bg-blue-50">
                <div className="flex items-center gap-2 mb-3">
                  <Award size={16} className="text-blue-600" />
                  <span className="font-bold text-blue-800">최적 모듈 배치안</span>
                  <span className="bg-blue-600 text-white text-xs px-2 py-0.5 rounded-full">추천</span>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { label: '모듈 타입', value: result.best_module, icon: <Building2 size={14}/> },
                    { label: '층수 × 세대/층', value: `${result.best_floor}층 × ${Math.round(result.best_units / result.best_floor)}세대`, icon: <Layers size={14}/> },
                    { label: '총 세대수', value: `${result.best_units}세대`, icon: <Home size={14}/> },
                    { label: 'ROI', value: `${result.roi_pct.toFixed(1)}%`, icon: <TrendingUp size={14}/> },
                    { label: '건폐율', value: `${result.coverage_ratio.toFixed(1)}%`, icon: <Building size={14}/> },
                    { label: '용적률', value: `${result.floor_area_ratio.toFixed(1)}%`, icon: <Layers size={14}/> },
                  ].map(item => (
                    <div key={item.label} className="bg-white rounded-lg p-3">
                      <div className="flex items-center gap-1 text-xs text-gray-500 mb-1">{item.icon}{item.label}</div>
                      <div className="font-bold text-blue-800">{item.value}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 모듈 비교 차트 */}
              <div className="card">
                <div className="card-header"><BarChart className="w-4 h-4" /> 모듈별 세대수 비교</div>
                <div className="w-full overflow-hidden" style={{ height: 180 }}>
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={moduleChartData} margin={{ top: 5, right: 10, left: -15, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <Tooltip />
                    <Bar dataKey="세대수" radius={[4,4,0,0]}>
                      {moduleChartData.map((_, i) => (
                        <Cell key={i} fill={i === 0 ? '#2563eb' : '#94a3b8'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
                </div>
              </div>

              {/* 모듈 플랜 테이블 */}
              <div className="card overflow-x-auto">
                <div className="card-header"><Building2 size={14}/> 전체 모듈 배치 비교</div>
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-gray-200 text-gray-500">
                      <th className="text-left py-2 pr-3">모듈</th>
                      <th className="text-right py-2 px-2">전용(㎡)</th>
                      <th className="text-right py-2 px-2">층/세대</th>
                      <th className="text-right py-2 px-2">총세대</th>
                      <th className="text-right py-2 px-2">건폐율</th>
                      <th className="text-right py-2 px-2">용적률</th>
                      <th className="text-right py-2 px-2">ROI</th>
                      <th className="text-center py-2 pl-2">적합</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.module_plans.map((p, i) => (
                      <tr key={i} className={`border-b border-gray-50 ${i === 0 ? 'bg-blue-50 font-medium' : ''}`}>
                        <td className="py-2 pr-3 font-medium text-gray-800">{p.module_type}</td>
                        <td className="text-right py-2 px-2 text-gray-600">{p.net_area_m2}<span className="text-gray-400 text-[10px] ml-0.5">㎡ ({(p.net_area_m2 * 0.3025).toFixed(1)}평)</span></td>
                        <td className="text-right py-2 px-2 text-gray-600">{p.floors}F × {p.units_per_floor}</td>
                        <td className="text-right py-2 px-2 font-bold text-blue-700">{p.total_units}</td>
                        <td className="text-right py-2 px-2 text-gray-600">{p.coverage_ratio_pct}%</td>
                        <td className="text-right py-2 px-2 text-gray-600">{p.floor_area_ratio_pct}%</td>
                        <td className="text-right py-2 px-2 font-bold text-green-700">{p.roi_pct.toFixed(1)}%</td>
                        <td className="text-center py-2 pl-2">
                          {p.is_compliant
                            ? <CheckCircle2 size={13} className="text-green-500 mx-auto" />
                            : <XCircle size={13} className="text-red-400 mx-auto" />
                          }
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ── 섹션 3: SITE-C ────────────────────────────── */}
          {activeSection === 'sitec' && (
            <div className="space-y-4">
              {/* 점수 헤더 */}
              <div className="grid grid-cols-3 gap-3">
                <div className="card text-center col-span-1">
                  <div className={`text-5xl font-black mb-1 ${SITEC_STYLE[result.sitec_grade]?.color}`}>
                    {result.sitec_grade}
                  </div>
                  <div className="text-xs text-gray-500">{SITEC_STYLE[result.sitec_grade]?.label}</div>
                  <div className="text-xs text-gray-400 mt-1">{SITEC_STYLE[result.sitec_grade]?.prob}</div>
                </div>
                <div className="card col-span-2">
                  <div className="flex items-end gap-2 mb-3">
                    <span className="text-3xl font-bold text-gray-800">{result.sitec_score.toFixed(1)}</span>
                    <span className="text-sm text-gray-400 mb-1">/ 100점</span>
                    <span className="ml-auto text-sm font-medium text-blue-600">
                      승인확률 {(result.sitec_approval_prob * 100).toFixed(0)}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div
                      className="h-2.5 rounded-full bg-gradient-to-r from-blue-400 to-blue-600 transition-all"
                      style={{ width: `${result.sitec_score}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-gray-400 mt-1">
                    <span>탈락 &lt;50</span><span>C: 50~64</span><span>B: 65~79</span><span>A: 80+</span>
                  </div>
                </div>
              </div>

              {/* 레이더 + 항목별 점수 */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="card">
                  <div className="card-header">SITE-C 항목별 점수</div>
                  <div className="w-full overflow-hidden" style={{ height: 240 }}>
                    <ResponsiveContainer width="100%" height={240}>
                      <RadarChart data={radarData} outerRadius={75} margin={{ top: 10, right: 30, bottom: 10, left: 30 }}>
                        <PolarGrid />
                        <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10 }} />
                        <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fontSize: 9 }} tickCount={4} />
                        <Radar name="점수" dataKey="value" stroke="#2563eb" fill="#2563eb" fillOpacity={0.2} />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                <div className="card">
                  <div className="card-header">항목별 세부 점수</div>
                  <div className="space-y-2.5">
                    {Object.entries(BREAKDOWN_LABELS).map(([key, meta]) => {
                      const score = (result.sitec_breakdown[key] ?? 0) * 100
                      return (
                        <div key={key}>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-gray-700 font-medium">{meta.label}</span>
                            <span className="text-gray-500">{meta.weight} 가중치 · {score.toFixed(0)}점</span>
                          </div>
                          <div className="w-full bg-gray-100 rounded-full h-2">
                            <div
                              className="h-2 rounded-full transition-all"
                              style={{ width: `${score}%`, backgroundColor: meta.color }}
                            />
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>

              {/* 개선 제안 */}
              {result.sitec_suggestions.length > 0 && (
                <div className="card">
                  <div className="card-header"><Zap size={14}/> 개선 제안</div>
                  <div className="space-y-1.5">
                    {result.sitec_suggestions.map((s, i) => (
                      <div key={i} className="flex items-start gap-2 text-sm text-amber-700 bg-amber-50 rounded-lg px-3 py-2">
                        <AlertCircle size={13} className="mt-0.5 shrink-0" />
                        {s}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── 섹션 4: 수요 예측 ─────────────────────────── */}
          {activeSection === 'demand' && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="card text-center">
                  <div className="text-3xl font-bold text-purple-700">{result.demand_score.toFixed(1)}</div>
                  <div className="text-xs text-gray-500 mt-1">수요 확신도 점수</div>
                  <div className="w-full bg-gray-100 rounded-full h-1.5 mt-2">
                    <div className="h-1.5 rounded-full bg-purple-500" style={{ width: `${result.demand_score}%` }} />
                  </div>
                </div>
                <div className="card text-center">
                  <div className="text-3xl font-bold text-blue-700">{result.recommended_units}</div>
                  <div className="text-xs text-gray-500 mt-1">추천 세대수</div>
                  <div className="text-xs text-gray-400 mt-1">수요 기반 산정</div>
                </div>
                <div className="card text-center">
                  <div className="text-3xl font-bold text-green-700">{(result.demand_confidence * 100).toFixed(0)}%</div>
                  <div className="text-xs text-gray-500 mt-1">예측 신뢰도</div>
                  <div className="text-xs text-gray-400 mt-1">{result.demand_region}</div>
                </div>
              </div>
              {result.demand_risk_factors.length > 0 && (
                <div className="card">
                  <div className="card-header"><AlertCircle size={14}/> 수요 리스크 요인</div>
                  <div className="space-y-1.5">
                    {result.demand_risk_factors.map((r, i) => (
                      <div key={i} className="flex items-start gap-2 text-sm text-gray-700 bg-gray-50 rounded-lg px-3 py-2">
                        <AlertCircle size={13} className="mt-0.5 text-amber-500 shrink-0" />
                        {r}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── 섹션 5: 사업성 ────────────────────────────── */}
          {activeSection === 'business' && (
            <div className="space-y-4">
              {/* 사업비 요약 */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { label: '공사비', value: `${result.construction_cost_bn.toFixed(1)}억`, color: 'text-gray-700', bg: 'bg-gray-50' },
                  { label: 'LH 매입가', value: `${result.lh_purchase_bn.toFixed(1)}억`, color: 'text-blue-700', bg: 'bg-blue-50' },
                  { label: '예상 수익', value: `${result.profit_bn.toFixed(1)}억`, color: 'text-green-700', bg: 'bg-green-50' },
                  { label: 'ROI', value: `${result.roi_pct.toFixed(1)}%`, color: 'text-purple-700', bg: 'bg-purple-50' },
                ].map(item => (
                  <div key={item.label} className={`${item.bg} rounded-xl p-4 text-center`}>
                    <div className={`text-2xl font-bold ${item.color}`}>{item.value}</div>
                    <div className="text-xs text-gray-500 mt-1">{item.label}</div>
                  </div>
                ))}
              </div>

              {/* 강점 & 리스크 */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="card">
                  <div className="card-header text-green-700"><CheckCircle2 size={14}/> 사업 강점</div>
                  {result.key_strengths.length > 0 ? (
                    <div className="space-y-2">
                      {result.key_strengths.map((s, i) => (
                        <div key={i} className="flex items-start gap-2 text-sm text-green-700 bg-green-50 rounded-lg px-3 py-2">
                          <CheckCircle2 size={13} className="mt-0.5 shrink-0" />
                          {s}
                        </div>
                      ))}
                    </div>
                  ) : <p className="text-xs text-gray-400">강점 분석 중...</p>}
                </div>
                <div className="card">
                  <div className="card-header text-red-600"><AlertCircle size={14}/> 주요 리스크</div>
                  {result.key_risks.length > 0 ? (
                    <div className="space-y-2">
                      {result.key_risks.map((r, i) => (
                        <div key={i} className="flex items-start gap-2 text-sm text-red-700 bg-red-50 rounded-lg px-3 py-2">
                          <AlertCircle size={13} className="mt-0.5 shrink-0" />
                          {r}
                        </div>
                      ))}
                    </div>
                  ) : <p className="text-xs text-gray-400 p-2">특이 리스크 없음</p>}
                </div>
              </div>

              {/* 다음 단계 */}
              <div className="card">
                <div className="card-header"><ChevronRight size={14}/> 권장 다음 단계</div>
                <div className="space-y-2">
                  {result.next_actions.map((a, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm text-gray-700">
                      <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      {a}
                    </div>
                  ))}
                </div>
              </div>

              {/* API 연동 안내 */}
              {result.is_simulation && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                  <div className="flex items-start gap-2">
                    <Info size={15} className="text-amber-600 mt-0.5 shrink-0" />
                    <div>
                      <div className="font-medium text-amber-800 text-sm mb-1">더 정확한 분석을 위해</div>
                      <p className="text-xs text-amber-700 mb-2">현재 시뮬레이션 모드입니다. 아래 API 키를 설정하면 실제 데이터로 정밀 분석이 가능합니다.</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                        <div className="bg-white rounded-lg p-2.5 border border-amber-200">
                          <div className="font-medium text-amber-800 mb-1">VWORLD_API_KEY</div>
                          <div className="text-amber-600">• 필지면적, 용도지역 실데이터</div>
                          <div className="text-amber-600">• 토지이용계획, 공시지가</div>
                          <a href="https://www.vworld.kr" target="_blank" rel="noopener noreferrer"
                             className="text-blue-600 underline mt-1 inline-block">vworld.kr 신청 →</a>
                        </div>
                        <div className="bg-white rounded-lg p-2.5 border border-amber-200">
                          <div className="font-medium text-amber-800 mb-1">KAKAO_REST_API_KEY</div>
                          <div className="text-amber-600">• 지하철/버스/학교 실거리 조회</div>
                          <div className="text-amber-600">• 병원/마트/편의점 거리</div>
                          <a href="https://developers.kakao.com" target="_blank" rel="noopener noreferrer"
                             className="text-blue-600 underline mt-1 inline-block">developers.kakao.com →</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>
      )}
    </div>
  )
}
