import { useState } from 'react'
import { useMutation as _useMutation, useQuery } from '@tanstack/react-query'
import { sitesAPI } from '../api'
import axios from 'axios'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Cell
} from 'recharts'
import { Layers, Play, CheckCircle, TrendingUp, Factory, BarChart2, Loader2 } from 'lucide-react'

interface Constraints {
  max_total_investment: number
  max_factory_capacity: number
  min_cluster_modules: number
  max_concurrent_sites: number
}

interface OptResult {
  selected_sites: any[]
  total_portfolio_value: number
  total_investment: number
  total_modules: number
  expected_roi: number
  optimization_status: string
  gantt_schedule: any[]
  sensitivity_analysis: any
}

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6']

export default function PortfolioOptimizer() {
  const [selectedIds, setSelectedIds] = useState<number[]>([])
  const [constraints, setConstraints] = useState<Constraints>({
    max_total_investment: 500,
    max_factory_capacity: 80,
    min_cluster_modules: 50,
    max_concurrent_sites: 5,
  })
  const [result, setResult] = useState<OptResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const { data: sites = [] } = useQuery({
    queryKey: ['sites'],
    queryFn: sitesAPI.list,
  })

  const evaluatedSites = sites.filter(s => s.sitec_score !== null)

  const toggleSite = (id: number) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    )
  }

  const handleOptimize = async () => {
    if (selectedIds.length < 2) {
      setError('최소 2개 이상의 사업지를 선택하세요.')
      return
    }
    setLoading(true)
    setError(null)
    try {
      // site_ids + constraints 모두 쿼리 파라미터로 전송
      const params = new URLSearchParams()
      selectedIds.forEach(id => params.append('site_ids', id.toString()))
      params.set('max_total_investment', constraints.max_total_investment.toString())
      params.set('max_factory_capacity', constraints.max_factory_capacity.toString())
      params.set('min_cluster_modules', constraints.min_cluster_modules.toString())
      params.set('max_concurrent_sites', constraints.max_concurrent_sites.toString())
      const url = '/api/v1/clusters/optimize?' + params.toString()
      const response = await axios.post(url)
      setResult(response.data)
    } catch (e: any) {
      const detail = e.response?.data?.detail
      let msg: string = e.message
      if (Array.isArray(detail)) {
        msg = detail.map((d: any) => d.msg || JSON.stringify(d)).join(', ')
      } else if (typeof detail === 'string') {
        msg = detail
      }
      setError('최적화 중 오류: ' + msg)
    } finally {
      setLoading(false)
    }
  }

  const roiData = result?.selected_sites.map(s => ({
    name: s.name.slice(0, 8),
    roi: s.estimated_roi.toFixed(1),
    sitec: s.sitec_score.toFixed(0),
    modules: s.module_count,
  })) || []

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Layers size={20} className="text-purple-600" />
        <h2 className="text-xl font-bold text-gray-900">포트폴리오 최적화</h2>
        <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">ILP 클러스터 최적화</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* 사업지 선택 */}
        <div className="card lg:col-span-1">
          <div className="card-header justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle size={15} /> 후보 사업지 선택
            </div>
            <span className="text-xs text-gray-400">{selectedIds.length}/{evaluatedSites.length}</span>
          </div>
          {evaluatedSites.length === 0 ? (
            <div className="text-center py-8 text-gray-400 text-sm">
              <p>평가된 사업지가 없습니다</p>
              <p className="text-xs mt-1">사업지 평가 탭에서 먼저 평가하세요</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {evaluatedSites.map(site => (
                <label key={site.id}
                  className={`flex items-center gap-3 p-2.5 rounded-lg cursor-pointer border transition-colors ${
                    selectedIds.includes(site.id)
                      ? 'bg-purple-50 border-purple-200'
                      : 'bg-gray-50 border-gray-100 hover:bg-gray-100'
                  }`}>
                  <input type="checkbox"
                    checked={selectedIds.includes(site.id)}
                    onChange={() => toggleSite(site.id)}
                    className="w-4 h-4 accent-purple-600" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{site.name}</p>
                    <p className="text-xs text-gray-500">
                      SITE-C {site.sitec_score?.toFixed(1)}점 · {site.sitec_grade}등급
                    </p>
                  </div>
                </label>
              ))}
            </div>
          )}

          {/* 제약조건 */}
          <div className="mt-4 pt-4 border-t border-gray-100 space-y-3">
            <p className="text-xs font-semibold text-gray-500">최적화 제약조건</p>
            {[
              { key: 'max_total_investment', label: '최대 투자자본 (억원)', step: 50, max: 2000 },
              { key: 'max_factory_capacity', label: '공장 최대 CAPA (%)', step: 5, max: 200 },
              { key: 'min_cluster_modules', label: '최소 클러스터 모듈 수', step: 10, max: 500 },
              { key: 'max_concurrent_sites', label: '최대 동시 현장 수', step: 1, max: 20 },
            ].map(c => (
              <div key={c.key}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-gray-600">{c.label}</span>
                  <span className="font-semibold text-purple-700">{constraints[c.key as keyof Constraints]}</span>
                </div>
                <input type="range" min={c.step} max={c.max} step={c.step}
                  value={constraints[c.key as keyof Constraints]}
                  onChange={e => setConstraints(prev => ({ ...prev, [c.key]: parseFloat(e.target.value) }))}
                  className="w-full accent-purple-600" />
              </div>
            ))}
          </div>

          <button
            onClick={handleOptimize}
            disabled={loading || selectedIds.length < 2}
            className="w-full mt-4 py-2.5 bg-purple-600 text-white font-semibold rounded-xl hover:bg-purple-700 disabled:opacity-50 flex items-center justify-center gap-2 transition-colors text-sm"
          >
            {loading ? <><Loader2 size={16} className="animate-spin" /> 최적화 중...</> : <><Play size={16} /> ILP 최적화 실행</>}
          </button>
          {error && <p className="mt-2 text-xs text-red-600">{error}</p>}
        </div>

        {/* 결과 영역 */}
        <div className="lg:col-span-2 space-y-4">
          {!result ? (
            <div className="card flex flex-col items-center justify-center h-64 text-gray-400">
              <BarChart2 size={48} className="mb-3 opacity-20" />
              <p>2개 이상 사업지를 선택 후 최적화를 실행하세요</p>
              <p className="text-xs mt-1">ILP로 최적 포트폴리오를 자동 선택합니다</p>
            </div>
          ) : (
            <>
              {/* KPI */}
              <div className="grid grid-cols-4 gap-3">
                {[
                  { label: '선택 사업지', value: result.selected_sites.length, unit: '개', color: 'blue' },
                  { label: '총 투자액', value: result.total_investment.toFixed(0), unit: '억원', color: 'green' },
                  { label: '총 모듈 수', value: result.total_modules, unit: '개', color: 'purple' },
                  { label: '예상 ROI', value: result.expected_roi.toFixed(1), unit: '%', color: 'amber' },
                ].map(k => (
                  <div key={k.label} className="card text-center py-3">
                    <p className="text-xs text-gray-500">{k.label}</p>
                    <p className="text-2xl font-black text-gray-900">
                      {k.value}<span className="text-sm font-normal text-gray-500"> {k.unit}</span>
                    </p>
                  </div>
                ))}
              </div>

              {/* 선택 사업지 목록 */}
              <div className="card">
                <div className="card-header"><CheckCircle size={15} className="text-green-600" /> 선택된 최적 사업지 ({result.optimization_status})</div>
                <div className="space-y-2">
                  {result.selected_sites.map((s, i) => (
                    <div key={s.site_id} className="flex items-center justify-between p-2.5 bg-green-50 rounded-lg border border-green-100">
                      <div className="flex items-center gap-3">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white"
                          style={{ backgroundColor: COLORS[i % COLORS.length] }}>
                          {i + 1}
                        </div>
                        <div>
                          <p className="text-sm font-medium">{s.name}</p>
                          <p className="text-xs text-gray-500">SITE-C {s.sitec_score.toFixed(1)}점 · {s.module_count}개 모듈</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-bold text-green-700">ROI {s.estimated_roi.toFixed(1)}%</p>
                        <p className="text-xs text-gray-500">{s.investment_cost.toFixed(0)}억원</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* ROI 차트 */}
              {roiData.length > 0 && (
                <div className="card">
                  <div className="card-header"><TrendingUp size={15} /> 사업지별 ROI 비교</div>
                  <ResponsiveContainer width="100%" height={180}>
                    <BarChart data={roiData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Bar dataKey="roi" name="예상ROI(%)" fill="#3b82f6" radius={[4, 4, 0, 0]}>
                        {roiData.map((_entry, idx) => <Cell key={idx} fill={COLORS[idx % COLORS.length]} />)}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}

              {/* 간트 차트 */}
              {result.gantt_schedule.length > 0 && (
                <div className="card">
                  <div className="card-header"><Factory size={15} /> 공장-현장 통합 간트 일정</div>
                  <div className="space-y-3">
                    {result.gantt_schedule.map((g) => (
                      <div key={g.site_id}>
                        <p className="text-xs font-medium text-gray-600 mb-1">{g.site_name} ({g.modules}모듈)</p>
                        <div className="relative h-6 bg-gray-100 rounded overflow-hidden">
                          <div
                            className="absolute h-full bg-blue-400 flex items-center justify-center text-xs text-white"
                            style={{
                              left: `${(g.factory_period[0] / 24) * 100}%`,
                              width: `${((g.factory_period[1] - g.factory_period[0]) / 24) * 100}%`,
                            }}>
                            공장
                          </div>
                          <div
                            className="absolute h-full bg-green-400 flex items-center justify-center text-xs text-white"
                            style={{
                              left: `${(g.installation_period[0] / 24) * 100}%`,
                              width: `${((g.installation_period[1] - g.installation_period[0]) / 24) * 100}%`,
                            }}>
                            설치
                          </div>
                        </div>
                      </div>
                    ))}
                    <div className="flex gap-4 text-xs text-gray-500 mt-2">
                      <span className="flex items-center gap-1"><span className="w-3 h-3 bg-blue-400 rounded"></span>공장 생산</span>
                      <span className="flex items-center gap-1"><span className="w-3 h-3 bg-green-400 rounded"></span>현장 설치</span>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
