import { useState, useEffect } from 'react'
import axios from 'axios'
import {
  Package, Ruler, CheckCircle,
  AlertTriangle, ChevronDown, ChevronUp, BarChart3
} from 'lucide-react'

const API = '/api/v1/modules'

interface ModuleSpec {
  module_type: string
  width_mm: number
  length_mm: number
  bath_length_mm: number
  room_length_mm: number
  balcony_length_mm: number
  corridor_length_mm: number
  corridor_type: string | null
  building_area_m2: number
  net_area_m2: number
  gross_area_m2: number
  lh_type_match: string | null
  lh_area_m2: number
  area_advantage_m2: number
  factory_assembly: boolean
  transport_feasible: boolean
  wet_joint_required: boolean
  cost_index: number
  description: string
  notes: string
}

interface LHComparison {
  lh_type: string
  lh_area_m2: number
  module_type: string
  module_net_area_m2: number
  module_building_area_m2: number
  area_difference_m2: number
  area_advantage: string
  transport_feasible: boolean
  factory_assembly: boolean
  notes: string
}

const MODULE_COLORS: Record<string, string> = {
  'BALCONY-2': 'bg-blue-600',
  'BALCONY-3': 'bg-blue-500',
  'BASIC-1-C1': 'bg-green-600',
  'BASIC-1-C2': 'bg-green-500',
  'BASIC-2-C1': 'bg-purple-600',
  'BASIC-2-C2': 'bg-purple-500',
  'BASIC-4-C1': 'bg-amber-600',
  'CORRIDOR': 'bg-gray-400',
}

const BLOCK_COLORS: Record<string, string> = {
  bath: 'bg-cyan-400',
  room: 'bg-blue-500',
  balcony: 'bg-green-400',
  corridor: 'bg-amber-400',
}

// 단순 모듈 단면 시각화
function ModuleDiagram({ spec }: { spec: ModuleSpec }) {
  const SCALE = 0.018  // mm → px 스케일
  const height = 30

  const blocks = []
  if (spec.bath_length_mm) blocks.push({ type: 'bath', label: '욕', w: spec.bath_length_mm * SCALE })
  if (spec.room_length_mm) blocks.push({ type: 'room', label: '주거', w: spec.room_length_mm * SCALE })
  if (spec.balcony_length_mm) blocks.push({ type: 'balcony', label: '발', w: spec.balcony_length_mm * SCALE })
  if (spec.corridor_length_mm) blocks.push({ type: 'corridor', label: '복', w: spec.corridor_length_mm * SCALE })

  return (
    <div className="flex items-end gap-0.5 py-2">
      {blocks.map((b, i) => (
        <div
          key={i}
          className={`${BLOCK_COLORS[b.type]} rounded-sm flex items-center justify-center text-white text-[9px] font-bold transition-all`}
          style={{ width: `${b.w}px`, height: `${height}px` }}
          title={`${b.type} ${spec[`${b.type}_length_mm` as keyof ModuleSpec]}mm`}
        >
          {b.label}
        </div>
      ))}
      <div className="ml-1 text-[9px] text-gray-400 self-center">
        ={spec.length_mm}mm
      </div>
    </div>
  )
}

export default function ModuleCatalog() {
  const [modules, setModules] = useState<ModuleSpec[]>([])
  const [lhComparison, setLhComparison] = useState<LHComparison[]>([])
  const [shaftSpec, setShaftSpec] = useState<Record<string, unknown> | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'catalog' | 'lhCompare' | 'cso'>('catalog')
  const [expandedModule, setExpandedModule] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      try {
        const [catRes, lhRes] = await Promise.all([
          axios.get(`${API}/`),
          axios.get(`${API}/lh-comparison`),
        ])
        setModules(catRes.data.modules)
        setShaftSpec(catRes.data.shaft_spec)
        setLhComparison(lhRes.data.comparison)
      } catch (e) {
        console.error(e)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full" />
      </div>
    )
  }

  const balconyModules = modules.filter(m => m.balcony_length_mm > 0)
  const basicModules = modules.filter(m => m.balcony_length_mm === 0 && m.module_type !== 'CORRIDOR')

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <Package size={24} className="text-blue-600" />
          UnitBuild 유닛 제품 카탈로그
        </h1>
        <p className="text-gray-500 text-sm mt-1">
          모듈 폭 3,200mm 고정 · 운송한도 9,600mm · SQ-Pipe 150×150mm
        </p>
      </div>

      {/* Gen 2 핵심 스펙 배너 */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-xl p-5 text-white">
        <p className="text-sm font-semibold opacity-80 mb-3">유닛 제품 주요 사양 (2026 기준)</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: '모듈 폭', value: '3,200 mm', sub: '고정' },
            { label: '운송 한도', value: '9,600 mm', sub: '완전 공장조립' },
            { label: '기둥 규격', value: '150×150 mm', sub: 'SQ-Pipe' },
            { label: '중심선 폭', value: '3,050 mm', sub: '3200-150(기둥)' },
          ].map(item => (
            <div key={item.label} className="text-center">
              <p className="text-2xl font-black">{item.value}</p>
              <p className="text-xs opacity-70">{item.label}</p>
              <p className="text-xs opacity-50">{item.sub}</p>
            </div>
          ))}
        </div>
      </div>

      {/* 탭 */}
      <div className="flex gap-1 bg-gray-100 rounded-lg p-1 w-fit">
        {[
          { id: 'catalog', label: '카탈로그' },
          { id: 'lhCompare', label: 'LH 면적 비교' },
          { id: 'cso', label: 'CSO 요약' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
              activeTab === tab.id
                ? 'bg-white text-blue-700 shadow-sm'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 카탈로그 탭 */}
      {activeTab === 'catalog' && (
        <div className="space-y-6">
          {/* BALCONY 시리즈 (Gen 2 핵심) */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="h-4 w-1 bg-blue-600 rounded" />
              <h2 className="text-sm font-bold text-gray-800">BALCONY 시리즈 — 유닛 핵심 신제품</h2>
              <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">9600mm 정확·완전공장조립</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {balconyModules.map(m => (
                <ModuleCard
                  key={m.module_type}
                  spec={m}
                  expanded={expandedModule === m.module_type}
                  onToggle={() => setExpandedModule(expandedModule === m.module_type ? null : m.module_type)}
                  highlight
                />
              ))}
            </div>
          </div>

          {/* BASIC 시리즈 */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="h-4 w-1 bg-green-600 rounded" />
              <h2 className="text-sm font-bold text-gray-800">BASIC 시리즈 — 표준형</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {basicModules.map(m => (
                <ModuleCard
                  key={m.module_type}
                  spec={m}
                  expanded={expandedModule === m.module_type}
                  onToggle={() => setExpandedModule(expandedModule === m.module_type ? null : m.module_type)}
                />
              ))}
            </div>
          </div>

          {/* 샤프트 스펙 */}
          {shaftSpec && (
            <div className="bg-gray-50 rounded-xl border border-gray-200 p-5">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">🔧 MEP 샤프트 표준 규격</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-xs text-gray-500">규격</p>
                  <p className="font-bold text-gray-800">
                    {shaftSpec.width_mm as number} × {shaftSpec.depth_mm as number} mm
                  </p>
                </div>
                <div className="md:col-span-2">
                  <p className="text-xs text-gray-500">배치</p>
                  <p className="text-sm text-gray-700">{shaftSpec.location as string}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">특이사항</p>
                  <p className="text-sm text-gray-700">{shaftSpec.note as string}</p>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-1">
                {(shaftSpec.includes as string[]).map(item => (
                  <span key={item} className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* LH 면적 비교 탭 */}
      {activeTab === 'lhCompare' && (
        <div className="space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <p className="text-sm font-semibold text-blue-800 mb-1">유닛빌드 vs LH 주택유형 면적 비교</p>
            <p className="text-xs text-blue-600">
              기둥 150×150mm → LH 기준 대비 전용면적 0.5~0.9평 추가 확보 · 3,200mm 균일 그리드 BIM 자동화
            </p>
          </div>

          {/* LH 타입별 요약 */}
          {['19㎡형', '26㎡형', '29㎡형'].map(lhType => {
            const typeItems = lhComparison.filter(c => c.lh_type === lhType)
            if (typeItems.length === 0) return null
            const lhArea = typeItems[0].lh_area_m2

            return (
              <div key={lhType} className="bg-white rounded-xl border border-gray-200 p-5">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-bold text-gray-800">LH {lhType}</h3>
                    <p className="text-xs text-gray-500">LH 기준: {lhArea} ㎡</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-500">유닛 대응 모듈</p>
                    <p className="font-bold text-blue-600">{typeItems.length}종</p>
                  </div>
                </div>

                {/* 면적 바 차트 (단순) */}
                <div className="space-y-3">
                  {typeItems.map(item => (
                    <div key={item.module_type}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-mono text-gray-700">{item.module_type}</span>
                        <span className={`text-xs font-bold ${
                          item.area_advantage === '우수' ? 'text-green-600' :
                          item.area_advantage === '근접' ? 'text-blue-600' : 'text-amber-600'
                        }`}>
                          {item.module_net_area_m2} ㎡
                          ({item.area_difference_m2 >= 0 ? '+' : ''}{item.area_difference_m2} ㎡)
                        </span>
                      </div>
                      <div className="flex gap-1 h-3 rounded overflow-hidden">
                        <div
                          className="bg-gray-200 rounded-l"
                          style={{ width: `${(lhArea / 35) * 100}%` }}
                          title={`LH 기준: ${lhArea}㎡`}
                        />
                        <div
                          className={`rounded-r ${
                            item.area_difference_m2 >= 0 ? 'bg-green-400' : 'bg-amber-400'
                          }`}
                          style={{ width: `${(Math.abs(item.area_difference_m2) / 35) * 100}%` }}
                          title={`차이: ${item.area_difference_m2}㎡`}
                        />
                      </div>
                      <div className="flex justify-between text-[10px] text-gray-400 mt-0.5">
                        <span>LH 기준 {lhArea}㎡</span>
                        <div className="flex gap-2">
                          {item.transport_feasible && (
                            <span className="text-blue-500">✓ 운송가능</span>
                          )}
                          {item.factory_assembly && (
                            <span className="text-green-500">✓ 공장조립</span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* CSO 요약 탭 */}
      {activeTab === 'cso' && (
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
              <BarChart3 size={20} className="text-blue-600" />
              유닛빌드 사업전략 개요 (CSO Summary)
            </h3>

            <div className="space-y-4">
              {[
                {
                  num: '1',
                  title: '운송한도 9,600mm → 발코니 완전공장조립',
                  color: 'blue',
                  content: '9,600mm 운송한도 달성으로 BALCONY-2·3 모듈의 발코니까지 완전히 공장에서 조립 가능. 현장 습식 조인트 완전 제거 → 시공 품질 균일화, 공기 단축, 현장 인력 최소화.',
                  badge: '핵심 혁신'
                },
                {
                  num: '2',
                  title: '기둥 150mm → 전용면적 0.5~0.9평 추가',
                  color: 'green',
                  content: '기존 180mm 기둥 대비 SQ-Pipe 150×150mm 적용으로 중심선 폭 3,050mm 확보. LH 기준 19㎡형 대비 BASIC-1-C1은 전용 21.81㎡ 제공 → 입주자 만족도 향상, LH 심의 경쟁력 강화.',
                  badge: '면적 우위'
                },
                {
                  num: '3',
                  title: '3,200mm 균일 그리드 → BIM 자동화',
                  color: 'purple',
                  content: '전 모듈 폭 3,200mm 통일 → BIM 파라메트릭 모델링 자동화. 부재 표준화로 공장 생산성 향상, 설계 변경 최소화, 원가 예측 정확도 향상.',
                  badge: 'BIM 효율'
                },
              ].map(item => (
                <div key={item.num} className={`rounded-xl border p-5 ${
                  item.color === 'blue' ? 'border-blue-200 bg-blue-50' :
                  item.color === 'green' ? 'border-green-200 bg-green-50' :
                  'border-purple-200 bg-purple-50'
                }`}>
                  <div className="flex items-start gap-3">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center text-white font-black text-sm flex-shrink-0 ${
                      item.color === 'blue' ? 'bg-blue-600' :
                      item.color === 'green' ? 'bg-green-600' : 'bg-purple-600'
                    }`}>
                      {item.num}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-bold text-gray-800">{item.title}</h4>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                          item.color === 'blue' ? 'bg-blue-200 text-blue-800' :
                          item.color === 'green' ? 'bg-green-200 text-green-800' :
                          'bg-purple-200 text-purple-800'
                        }`}>{item.badge}</span>
                      </div>
                      <p className="text-sm text-gray-600">{item.content}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* 블록 치수 옵션 */}
            <div className="mt-6 pt-6 border-t border-gray-100">
              <h4 className="text-sm font-bold text-gray-700 mb-3">블록 치수 옵션 (mm)</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { name: '욕실', values: '2,400 / 3,200', color: 'bg-cyan-100 text-cyan-700' },
                  { name: '주거실', values: '4,900 / 5,700', color: 'bg-blue-100 text-blue-700' },
                  { name: '발코니', values: '1,500 (선택)', color: 'bg-green-100 text-green-700' },
                  { name: '복도', values: '1,400 / 2,000', color: 'bg-amber-100 text-amber-700' },
                ].map(b => (
                  <div key={b.name} className={`rounded-lg px-3 py-2 ${b.color}`}>
                    <p className="text-xs font-medium">{b.name}</p>
                    <p className="text-sm font-bold mt-0.5">{b.values}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* 건축면적 공식 */}
            <div className="mt-4 bg-gray-900 rounded-xl p-4 text-white">
              <p className="text-xs font-medium text-gray-300 mb-2">건축면적 산정 공식</p>
              <code className="text-sm font-mono text-green-400">
                건축면적 = 3.05m × (전체 길이 - 0.15m)
              </code>
              <p className="text-xs text-gray-400 mt-1">
                예시: BALCONY-2 (9,600mm) → 3.05 × (9.6 - 0.15) = <strong className="text-white">28.82 ㎡</strong>
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// 모듈 카드 컴포넌트
function ModuleCard({
  spec, expanded, onToggle, highlight = false
}: {
  spec: ModuleSpec
  expanded: boolean
  onToggle: () => void
  highlight?: boolean
}) {
  const colorClass = MODULE_COLORS[spec.module_type] || 'bg-gray-500'

  return (
    <div className={`bg-white rounded-xl border ${highlight ? 'border-blue-300' : 'border-gray-200'} overflow-hidden transition-all`}>
      <div
        className="p-4 cursor-pointer hover:bg-gray-50"
        onClick={onToggle}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 ${colorClass} rounded-lg flex items-center justify-center text-white text-xs font-bold`}>
              {spec.module_type.split('-').slice(0, 2).join('')}
            </div>
            <div>
              <p className="font-bold text-gray-800">{spec.module_type}</p>
              <p className="text-xs text-gray-500 mt-0.5">{spec.description}</p>
            </div>
          </div>
          <div className="text-right flex-shrink-0">
            <p className="text-lg font-black text-gray-900">{spec.net_area_m2}
              <span className="text-xs text-gray-400 ml-0.5">㎡</span>
            </p>
            <p className="text-xs text-gray-400">{spec.length_mm}mm</p>
          </div>
        </div>

        {/* 모듈 단면도 */}
        <ModuleDiagram spec={spec} />

        <div className="flex items-center justify-between mt-2">
          <div className="flex gap-1">
            {spec.transport_feasible && (
              <span className="text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded-full font-medium">
                ✓ 운송가능
              </span>
            )}
            {spec.factory_assembly && (
              <span className="text-[10px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded-full font-medium">
                ✓ 공장조립
              </span>
            )}
            {spec.balcony_length_mm > 0 && (
              <span className="text-[10px] bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded-full font-medium">
                발코니
              </span>
            )}
            {spec.lh_type_match && (
              <span className="text-[10px] bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full font-medium">
                LH {spec.lh_type_match}
              </span>
            )}
          </div>
          <button className="text-gray-400 hover:text-gray-600">
            {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </button>
        </div>
      </div>

      {/* 상세 정보 */}
      {expanded && (
        <div className="border-t border-gray-100 p-4 bg-gray-50">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="text-xs font-medium text-gray-500 mb-2">치수 구성</p>
              <dl className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <dt className="text-gray-400">전체 길이</dt>
                  <dd className="font-bold">{spec.length_mm} mm</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-400">욕실</dt>
                  <dd>{spec.bath_length_mm || '-'} mm</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-400">주거실</dt>
                  <dd>{spec.room_length_mm || '-'} mm</dd>
                </div>
                {spec.balcony_length_mm > 0 && (
                  <div className="flex justify-between">
                    <dt className="text-gray-400">발코니</dt>
                    <dd className="text-green-600 font-medium">{spec.balcony_length_mm} mm</dd>
                  </div>
                )}
                {spec.corridor_length_mm > 0 && (
                  <div className="flex justify-between">
                    <dt className="text-gray-400">복도 ({spec.corridor_type})</dt>
                    <dd>{spec.corridor_length_mm} mm</dd>
                  </div>
                )}
              </dl>
            </div>
            <div>
              <p className="text-xs font-medium text-gray-500 mb-2">면적</p>
              <dl className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <dt className="text-gray-400">건축면적</dt>
                  <dd className="font-bold">{spec.building_area_m2} ㎡</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-400">전용면적</dt>
                  <dd className="font-bold text-blue-600">{spec.net_area_m2} ㎡</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-400">공급면적</dt>
                  <dd>{spec.gross_area_m2} ㎡</dd>
                </div>
                {spec.lh_type_match && (
                  <>
                    <div className="flex justify-between border-t border-gray-100 pt-1">
                      <dt className="text-gray-400">LH 기준</dt>
                      <dd>{spec.lh_area_m2} ㎡</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-gray-400">vs LH</dt>
                      <dd className={spec.net_area_m2 > spec.lh_area_m2 ? 'text-green-600 font-bold' : 'text-amber-600'}>
                        {spec.net_area_m2 > spec.lh_area_m2 ? '+' : ''}
                        {(spec.net_area_m2 - spec.lh_area_m2).toFixed(2)} ㎡
                      </dd>
                    </div>
                  </>
                )}
              </dl>
            </div>
          </div>

          {/* 면적 공식 */}
          <div className="mt-3 bg-gray-100 rounded-lg px-3 py-2">
            <p className="text-[10px] text-gray-400">건축면적 산식</p>
            <code className="text-xs text-gray-700">
              3.05 × ({(spec.length_mm / 1000).toFixed(3)} - 0.15) = {spec.building_area_m2} ㎡
            </code>
          </div>

          <p className="text-[11px] text-gray-500 mt-3 leading-relaxed">{spec.notes}</p>

          <div className="flex justify-between items-center mt-3">
            <div className="flex items-center gap-2">
              <Ruler size={12} className="text-gray-400" />
              <span className="text-xs text-gray-400">상대 원가지수: {spec.cost_index}</span>
            </div>
            {spec.wet_joint_required ? (
              <span className="text-xs text-amber-600 flex items-center gap-1">
                <AlertTriangle size={12} />습식 조인트 필요
              </span>
            ) : (
              <span className="text-xs text-green-600 flex items-center gap-1">
                <CheckCircle size={12} />건식 조립
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
