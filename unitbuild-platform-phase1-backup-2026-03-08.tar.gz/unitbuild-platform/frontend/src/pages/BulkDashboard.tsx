/**
 * BulkDashboard.tsx – 대규모 검토 대시보드
 * 대량 평가된 사업지 목록을 KPI·필터·정렬로 조회
 */
import { useState, useEffect } from 'react'
import {
  BarChart2, RefreshCw, Search, Filter, SortAsc, SortDesc,
  CheckCircle, TrendingUp, Building, DollarSign,
  ChevronDown, ChevronUp, Download, AlertTriangle
} from 'lucide-react'

const API = '/api/v1'

interface SiteRow {
  id: number
  name: string
  address: string
  lat?: number
  lng?: number
  planned_units?: number
  sitec_score?: number
  sitec_grade?: string
  sitec_approval_prob?: number
  demand_score?: number
  expected_margin?: number
  estimated_cost?: number
  status: string
  created_at: string
}

const GRADE_COLOR: Record<string, string> = {
  'A+': 'bg-emerald-100 text-emerald-700 border-emerald-200',
  'A':  'bg-green-100 text-green-700 border-green-200',
  'B+': 'bg-blue-100 text-blue-700 border-blue-200',
  'B':  'bg-sky-100 text-sky-700 border-sky-200',
  'C':  'bg-yellow-100 text-yellow-700 border-yellow-200',
  'D':  'bg-red-100 text-red-700 border-red-200',
}

// grade order not needed here

type SortKey = 'sitec_score' | 'expected_margin' | 'estimated_cost' | 'created_at' | 'demand_score'

export default function BulkDashboard() {
  const [sites, setSites] = useState<SiteRow[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [gradeFilter, setGradeFilter] = useState<string>('all')
  const [sortKey, setSortKey] = useState<SortKey>('sitec_score')
  const [sortAsc, setSortAsc] = useState(false)
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [expandKpi, setExpandKpi] = useState(true)

  const fetchSites = async () => {
    setLoading(true)
    try {
      const res = await fetch(`${API}/sites/?limit=500`)
      if (!res.ok) return
      const data = await res.json()
      setSites(data.items || data)
    } catch { /* 무시 */ }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchSites() }, [])

  // ── 필터 + 정렬 ──────────────────────────────────────────
  const filtered = sites
    .filter(s => {
      const q = search.toLowerCase()
      if (q && !s.name.toLowerCase().includes(q) && !s.address.toLowerCase().includes(q)) return false
      if (gradeFilter !== 'all' && s.sitec_grade !== gradeFilter) return false
      return true
    })
    .sort((a, b) => {
      let av: number
      let bv: number
      if (sortKey === 'sitec_score') {
        av = a.sitec_score ?? -1; bv = b.sitec_score ?? -1
      } else if (sortKey === 'expected_margin') {
        av = a.expected_margin ?? -1; bv = b.expected_margin ?? -1
      } else if (sortKey === 'estimated_cost') {
        av = a.estimated_cost ?? 0; bv = b.estimated_cost ?? 0
      } else if (sortKey === 'demand_score') {
        av = a.demand_score ?? -1; bv = b.demand_score ?? -1
      } else {
        av = new Date(a.created_at).getTime()
        bv = new Date(b.created_at).getTime()
      }
      return sortAsc ? av - bv : bv - av
    })

  // ── KPI ──────────────────────────────────────────────────
  const evaluated = sites.filter(s => s.sitec_score !== null && s.sitec_score !== undefined)
  const aGrade = evaluated.filter(s => s.sitec_grade && ['A+', 'A'].includes(s.sitec_grade))
  const margins = evaluated.filter(s => s.expected_margin).map(s => s.expected_margin!)
  const avgMargin = margins.length ? margins.reduce((a, b) => a + b, 0) / margins.length : null
  const totalCost = evaluated.filter(s => s.estimated_cost).map(s => s.estimated_cost!).reduce((a, b) => a + b, 0)

  // ── 등급별 분포 ──────────────────────────────────────────
  const gradeDist = ['A+', 'A', 'B+', 'B', 'C', 'D'].map(g => ({
    grade: g,
    count: evaluated.filter(s => s.sitec_grade === g).length,
  }))

  // ── CSV 다운로드 ─────────────────────────────────────────
  const downloadCSV = () => {
    const header = 'id,name,address,sitec_score,sitec_grade,approval_prob,expected_margin_pct,estimated_cost_억,demand_score\n'
    const rows = filtered.map(s =>
      `${s.id},"${s.name}","${s.address}",${s.sitec_score?.toFixed(1) ?? ''},${s.sitec_grade ?? ''},${
        s.sitec_approval_prob ? (s.sitec_approval_prob * 100).toFixed(0) : ''
      }%,${s.expected_margin ? s.expected_margin.toFixed(1) : ''}%,${
        s.estimated_cost ? (s.estimated_cost / 1e8).toFixed(1) : ''
      },${s.demand_score?.toFixed(1) ?? ''}`
    ).join('\n')
    const blob = new Blob(['\uFEFF' + header + rows], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = 'bulk_dashboard.csv'; a.click()
    URL.revokeObjectURL(url)
  }

  const toggleSelect = (id: number) => {
    const next = new Set(selected)
    next.has(id) ? next.delete(id) : next.add(id)
    setSelected(next)
  }

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortAsc(!sortAsc)
    else { setSortKey(key); setSortAsc(false) }
  }

  const SortIcon = ({ k }: { k: SortKey }) =>
    sortKey === k
      ? (sortAsc ? <SortAsc size={13} className="text-blue-600" /> : <SortDesc size={13} className="text-blue-600" />)
      : <SortAsc size={13} className="text-gray-300" />

  return (
    <div className="space-y-6">

      {/* ── 헤더 */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-black text-gray-900">대규모 검토 대시보드</h1>
          <p className="text-gray-500 text-sm mt-1">전체 평가 사업지 현황 · 필터링 · 다운로드</p>
        </div>
        <div className="flex gap-2">
          <button onClick={fetchSites} className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-sm font-medium hover:bg-slate-200 transition-colors">
            <RefreshCw size={14} /> 새로고침
          </button>
          <button onClick={downloadCSV} className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors shadow-sm">
            <Download size={14} /> CSV 내보내기
          </button>
        </div>
      </div>

      {/* ── KPI 패널 */}
      <div className="card">
        <button
          className="flex items-center justify-between w-full mb-4"
          onClick={() => setExpandKpi(!expandKpi)}
        >
          <span className="font-bold text-gray-800 flex items-center gap-2">
            <BarChart2 size={16} className="text-blue-500" /> 전체 KPI 요약
          </span>
          {expandKpi ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
        </button>
        {expandKpi && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-blue-50 rounded-xl p-4 text-center">
                <Building size={20} className="mx-auto text-blue-500 mb-2" />
                <div className="text-2xl font-black text-blue-900">{sites.length}</div>
                <div className="text-xs text-blue-600 mt-0.5">전체 등록 사업지</div>
              </div>
              <div className="bg-emerald-50 rounded-xl p-4 text-center">
                <CheckCircle size={20} className="mx-auto text-emerald-500 mb-2" />
                <div className="text-2xl font-black text-emerald-900">{aGrade.length}</div>
                <div className="text-xs text-emerald-600 mt-0.5">A등급 이상</div>
              </div>
              <div className="bg-purple-50 rounded-xl p-4 text-center">
                <TrendingUp size={20} className="mx-auto text-purple-500 mb-2" />
                <div className="text-2xl font-black text-purple-900">
                  {avgMargin !== null ? `${avgMargin.toFixed(1)}%` : '-'}
                </div>
                <div className="text-xs text-purple-600 mt-0.5">평균 기대수익률</div>
              </div>
              <div className="bg-amber-50 rounded-xl p-4 text-center">
                <DollarSign size={20} className="mx-auto text-amber-500 mb-2" />
                <div className="text-2xl font-black text-amber-900">
                  {totalCost > 0 ? `${(totalCost / 1e9).toFixed(0)}억` : '-'}
                </div>
                <div className="text-xs text-amber-600 mt-0.5">총 예상 건축비</div>
              </div>
            </div>

            {/* 등급 분포 바 */}
            {evaluated.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-gray-500 mb-2">등급 분포</p>
                <div className="flex gap-2 flex-wrap">
                  {gradeDist.filter(g => g.count > 0).map(g => (
                    <div
                      key={g.grade}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-bold cursor-pointer transition-all ${
                        gradeFilter === g.grade ? 'ring-2 ring-offset-1 ring-blue-400 ' : ''
                      }${GRADE_COLOR[g.grade] ?? 'bg-gray-100 text-gray-700 border-gray-200'}`}
                      onClick={() => setGradeFilter(gradeFilter === g.grade ? 'all' : g.grade)}
                    >
                      {g.grade} <span className="opacity-70">({g.count})</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── 필터 바 */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-[180px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            className="w-full pl-8 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="사업지명 또는 주소 검색..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <select
          className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={gradeFilter}
          onChange={e => setGradeFilter(e.target.value)}
        >
          <option value="all">전체 등급</option>
          {['A+', 'A', 'B+', 'B', 'C', 'D'].map(g => (
            <option key={g} value={g}>{g}등급</option>
          ))}
        </select>
        <span className="text-xs text-gray-400 flex items-center gap-1">
          <Filter size={12} /> {filtered.length}건 표시
        </span>
      </div>

      {/* ── 테이블 */}
      {loading ? (
        <div className="card text-center py-16 text-gray-400">
          <RefreshCw size={32} className="mx-auto mb-3 animate-spin opacity-40" />
          <p>데이터 불러오는 중...</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="card text-center py-16 text-gray-400">
          <AlertTriangle size={32} className="mx-auto mb-3 opacity-30" />
          <p className="font-medium">조건에 맞는 사업지가 없습니다</p>
          <p className="text-sm mt-1">필터를 변경하거나 대규모 검토에서 CSV를 업로드해 평가를 먼저 수행하세요</p>
        </div>
      ) : (
        <div className="card overflow-hidden p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-gray-100">
                <tr>
                  <th className="py-3 px-4 text-left">
                    <input
                      type="checkbox"
                      onChange={e => {
                        if (e.target.checked) setSelected(new Set(filtered.map(s => s.id)))
                        else setSelected(new Set())
                      }}
                      checked={selected.size === filtered.length && filtered.length > 0}
                    />
                  </th>
                  <th className="py-3 px-4 text-left text-xs font-semibold text-gray-500">사업지명</th>
                  <th className="py-3 px-4 text-left text-xs font-semibold text-gray-500">주소</th>
                  <th className="py-3 px-4 text-center text-xs font-semibold text-gray-500 cursor-pointer hover:text-blue-600"
                    onClick={() => handleSort('sitec_score')}>
                    <span className="flex items-center justify-center gap-1">SITE-C <SortIcon k="sitec_score" /></span>
                  </th>
                  <th className="py-3 px-4 text-center text-xs font-semibold text-gray-500">등급</th>
                  <th className="py-3 px-4 text-center text-xs font-semibold text-gray-500">통과확률</th>
                  <th className="py-3 px-4 text-right text-xs font-semibold text-gray-500 cursor-pointer hover:text-blue-600"
                    onClick={() => handleSort('expected_margin')}>
                    <span className="flex items-center justify-end gap-1">수익률 <SortIcon k="expected_margin" /></span>
                  </th>
                  <th className="py-3 px-4 text-right text-xs font-semibold text-gray-500 cursor-pointer hover:text-blue-600"
                    onClick={() => handleSort('estimated_cost')}>
                    <span className="flex items-center justify-end gap-1">건축비 <SortIcon k="estimated_cost" /></span>
                  </th>
                  <th className="py-3 px-4 text-center text-xs font-semibold text-gray-500 cursor-pointer hover:text-blue-600"
                    onClick={() => handleSort('demand_score')}>
                    <span className="flex items-center justify-center gap-1">수요 <SortIcon k="demand_score" /></span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((s) => (
                  <tr key={s.id} className={`border-t border-gray-100 hover:bg-blue-50/30 transition-colors ${selected.has(s.id) ? 'bg-blue-50' : ''}`}>
                    <td className="py-2.5 px-4">
                      <input type="checkbox" checked={selected.has(s.id)} onChange={() => toggleSelect(s.id)} />
                    </td>
                    <td className="py-2.5 px-4">
                      <div className="font-semibold text-gray-800">{s.name}</div>
                      <div className="text-[10px] text-gray-400 mt-0.5">ID #{s.id}</div>
                    </td>
                    <td className="py-2.5 px-4 text-gray-500 text-xs max-w-[180px] truncate">{s.address}</td>
                    <td className="py-2.5 px-4 text-center font-bold text-blue-700">
                      {s.sitec_score?.toFixed(1) ?? <span className="text-gray-300">-</span>}
                    </td>
                    <td className="py-2.5 px-4 text-center">
                      {s.sitec_grade ? (
                        <span className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-bold border ${GRADE_COLOR[s.sitec_grade] ?? 'bg-gray-100 text-gray-600 border-gray-200'}`}>
                          {s.sitec_grade}
                        </span>
                      ) : <span className="text-gray-300">-</span>}
                    </td>
                    <td className="py-2.5 px-4 text-center text-xs">
                      {s.sitec_approval_prob
                        ? <span className={`font-semibold ${s.sitec_approval_prob >= 0.8 ? 'text-emerald-600' : s.sitec_approval_prob >= 0.6 ? 'text-yellow-600' : 'text-red-500'}`}>
                            {(s.sitec_approval_prob * 100).toFixed(0)}%
                          </span>
                        : <span className="text-gray-300">-</span>}
                    </td>
                    <td className="py-2.5 px-4 text-right">
                      {s.expected_margin !== undefined && s.expected_margin !== null
                        ? <span className="font-semibold text-purple-700">{s.expected_margin.toFixed(1)}%</span>
                        : <span className="text-gray-300">-</span>}
                    </td>
                    <td className="py-2.5 px-4 text-right text-gray-700">
                      {s.estimated_cost
                        ? `${(s.estimated_cost / 1e8).toFixed(0)}억`
                        : <span className="text-gray-300">-</span>}
                    </td>
                    <td className="py-2.5 px-4 text-center">
                      {s.demand_score !== undefined && s.demand_score !== null ? (
                        <div className="flex items-center justify-center gap-1">
                          <div className="w-16 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${s.demand_score >= 80 ? 'bg-emerald-500' : s.demand_score >= 60 ? 'bg-blue-500' : 'bg-yellow-500'}`}
                              style={{ width: `${Math.min(s.demand_score, 100)}%` }}
                            />
                          </div>
                          <span className="text-xs text-gray-600">{s.demand_score.toFixed(0)}</span>
                        </div>
                      ) : <span className="text-gray-300">-</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="p-3 border-t border-gray-100 text-xs text-gray-400 flex justify-between">
            <span>{filtered.length}건 표시 / 전체 {sites.length}건</span>
            {selected.size > 0 && (
              <span className="text-blue-600 font-semibold">{selected.size}개 선택됨</span>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
