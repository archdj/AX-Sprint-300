import { useState } from 'react'
import axios from 'axios'
import {
  MapPin, Building2, AlertTriangle, CheckCircle, XCircle,
  Info, TrendingUp, Layers, DollarSign, ChevronRight,
  RefreshCw, FileText, Home, Search, Zap, Star,
} from 'lucide-react'

const API = '/api/v1'

// ─── 타입 (AutoEvaluator와 동일) ───────────────────────────────

interface ParcelBasic {
  address: string
  lat: number
  lng: number
  area_m2: number
  land_category: string
  zone_name: string
  zone_name2: string
  coverage_ratio_max: number
  floor_area_ratio_max: number
  max_floors: number
  is_simulation: boolean
  data_sources: string[]
}

interface ModulePlan {
  module_type: string
  net_area_m2: number
  lh_type: string
  units_per_floor: number
  floors: number
  total_units: number
  coverage_ratio_pct: number
  floor_area_ratio_pct: number
  roi_pct: number
  is_compliant: boolean
}

interface AutoEvalResult {
  address_input: string
  evaluated_at: string
  parcel: ParcelBasic
  regulations: Record<string, number | string>
  best_module: string
  best_floor: number
  best_units: number
  coverage_ratio: number
  floor_area_ratio: number
  roi_pct: number
  module_plans: ModulePlan[]
  sitec_score: number
  sitec_grade: 'A' | 'B' | 'C' | '탈락'
  sitec_approval_prob: number
  sitec_breakdown: Record<string, number>
  sitec_suggestions: string[]
  demand_score: number
  recommended_units: number
  demand_confidence: number
  demand_region: string
  demand_risk_factors: string[]
  construction_cost_bn: number
  lh_purchase_bn: number
  profit_bn: number
  profit_margin_pct: number
  overall_grade: string
  overall_summary: string
  key_strengths: string[]
  key_risks: string[]
  next_actions: string[]
  is_simulation: boolean
  data_sources: string[]
  errors: string[]
}

// ─── 스타일 헬퍼 ───────────────────────────────────────────────

const gradeStyle = (g: string) => {
  if (g === 'A+' || g === 'A') return 'text-green-700 bg-green-50 border-green-200'
  if (g === 'B') return 'text-blue-700 bg-blue-50 border-blue-200'
  if (g === 'C') return 'text-amber-700 bg-amber-50 border-amber-200'
  return 'text-red-700 bg-red-50 border-red-200'
}

const sitecColor = (g: string) => {
  if (g === 'A') return 'text-green-700'
  if (g === 'B') return 'text-blue-700'
  if (g === 'C') return 'text-amber-700'
  return 'text-red-700'
}

const DL = ({ items }: { items: [string, string | number][] }) => (
  <dl className="space-y-2">
    {items.map(([k, v]) => (
      <div key={k} className="flex justify-between items-center py-1 border-b border-gray-50 last:border-0">
        <dt className="text-xs text-gray-500">{k}</dt>
        <dd className="text-sm font-medium text-gray-800">{v}</dd>
      </div>
    ))}
  </dl>
)

// ─── 메인 컴포넌트 ─────────────────────────────────────────────

export default function ParcelAnalyzer() {
  const [address, setAddress] = useState('')
  const [plannedUnits, setPlannedUnits] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<AutoEvalResult | null>(null)
  const [activeTab, setActiveTab] = useState<'parcel' | 'plan' | 'finance' | 'sitec'>('parcel')
  const [error, setError] = useState('')

  const analyze = async () => {
    const trimmed = address.trim()
    if (!trimmed || trimmed.length < 5) {
      setError('지번 주소를 입력하세요 (예: 서울시 마포구 서교동 395-166)')
      return
    }
    setLoading(true)
    setError('')
    setResult(null)

    try {
      const res = await axios.post(`${API}/auto/evaluate`, {
        address: trimmed,
        planned_units: plannedUnits ? parseInt(plannedUnits) : undefined,
        long_term_rental: true,
        lh_certified: false,
        energy_grade: 2,
      }, { timeout: 60000 })
      setResult(res.data)
      setActiveTab('parcel')
    } catch (e: unknown) {
      if (axios.isAxiosError(e)) {
        const msg = e.response?.data?.detail || e.message
        setError(`분석 실패: ${msg}`)
      } else {
        setError('분석 중 오류가 발생했습니다.')
      }
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') analyze()
  }

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <MapPin size={24} className="text-blue-600" />
          필지 자동 분석
        </h1>
        <p className="text-gray-500 text-sm mt-1">
          주소 입력 → VWorld 실데이터 조회 → 용도지역·면적 자동 확인 → 모듈 최적 배치
        </p>
      </div>

      {/* 입력 폼 */}
      <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
        <h2 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2">
          <Home size={16} className="text-blue-500" />
          필지 주소 입력
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-gray-600 mb-1">지번 주소 *</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={address}
                onChange={e => setAddress(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="예: 서울특별시 중랑구 면목동 612-6"
                className="flex-1 border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <p className="text-xs text-gray-400 mt-1">
              VWorld + Kakao API로 실데이터 조회 (면적·용도지역 자동 확인)
            </p>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">계획 세대수 (선택)</label>
            <input
              type="number"
              value={plannedUnits}
              onChange={e => setPlannedUnits(e.target.value)}
              placeholder="미입력 시 자동 최적화"
              min={1}
              max={200}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <div className="mt-4">
          <button
            onClick={analyze}
            disabled={loading}
            className="w-full md:w-auto bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? (
              <><RefreshCw size={16} className="animate-spin" /> VWorld 데이터 조회 중...</>
            ) : (
              <><Search size={16} /> 자동 분석 실행</>
            )}
          </button>
        </div>

        {error && (
          <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm flex items-center gap-2">
            <AlertTriangle size={16} />
            {error}
          </div>
        )}
      </div>

      {/* 결과 영역 */}
      {result && (
        <>
          {/* 시뮬레이션 경고 */}
          {result.is_simulation && (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-700 text-sm flex items-center gap-2">
              <AlertTriangle size={16} />
              <span>
                <strong>시뮬레이션 데이터</strong> — VWorld API 조회 실패로 추정값 사용. 실제 토지이음 확인 권장.
              </span>
            </div>
          )}

          {/* 데이터 출처 */}
          {result.data_sources?.length > 0 && (
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-gray-400">데이터 출처:</span>
              {result.data_sources.map((src, i) => (
                <span key={i} className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{src}</span>
              ))}
            </div>
          )}

          {/* 종합 요약 카드 */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className={`rounded-xl border p-4 ${gradeStyle(result.overall_grade)}`}>
              <p className="text-xs font-medium opacity-70">종합 등급</p>
              <p className="text-2xl font-black mt-1">{result.overall_grade}</p>
              <p className="text-xs opacity-60 mt-1">{result.overall_summary}</p>
            </div>
            <div className="bg-white rounded-xl border border-gray-200 p-4">
              <p className="text-xs font-medium text-gray-500">필지 면적</p>
              <p className="text-2xl font-black text-gray-900 mt-1">
                {result.parcel.area_m2.toFixed(1)}
                <span className="text-sm ml-1 font-normal text-gray-400">㎡</span>
              </p>
              <p className="text-xs text-gray-400 mt-1">{result.parcel.zone_name}</p>
            </div>
            <div className="bg-white rounded-xl border border-gray-200 p-4">
              <p className="text-xs font-medium text-gray-500">최적 세대 / 층수</p>
              <p className="text-2xl font-black text-gray-900 mt-1">
                {result.best_units}세대
              </p>
              <p className="text-xs text-gray-400 mt-1">
                {result.best_floor}층 / {result.best_module}
              </p>
            </div>
            <div className="bg-white rounded-xl border border-gray-200 p-4">
              <p className="text-xs font-medium text-gray-500">예상 ROI</p>
              <p className="text-2xl font-black text-gray-900 mt-1">
                {result.roi_pct?.toFixed(1)}
                <span className="text-sm ml-1 font-normal text-gray-400">%</span>
              </p>
              <p className="text-xs text-gray-400 mt-1">토지비 미포함</p>
            </div>
          </div>

          {/* 탭 네비게이션 */}
          <div className="flex gap-1 bg-gray-100 rounded-lg p-1 w-fit flex-wrap">
            {[
              { id: 'parcel', label: '📍 필지·규제' },
              { id: 'plan', label: '🏗 배치 계획' },
              { id: 'finance', label: '💰 사업성' },
              { id: 'sitec', label: '🏆 SITE-C' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? 'bg-white text-blue-700 shadow-sm'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* ── 탭 1: 필지·규제 ── */}
          {activeTab === 'parcel' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {/* 필지 정보 */}
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h3 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2">
                  <MapPin size={16} className="text-blue-500" />
                  필지 정보 (VWorld 실데이터)
                </h3>
                <DL items={[
                  ['주소', result.parcel.address || result.address_input],
                  ['필지 면적', `${result.parcel.area_m2.toFixed(1)} ㎡`],
                  ['지목', result.parcel.land_category || '-'],
                  ['용도지역', result.parcel.zone_name || '-'],
                  ['세부 용도', result.parcel.zone_name2 || '지정 없음'],
                  ['좌표', `${result.parcel.lat.toFixed(5)}, ${result.parcel.lng.toFixed(5)}`],
                ]} />
              </div>

              {/* 건축 규제 */}
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h3 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2">
                  <FileText size={16} className="text-purple-500" />
                  건축 규제 한도
                </h3>
                <DL items={[
                  ['건폐율 한도', `${result.parcel.coverage_ratio_max}%`],
                  ['용적률 한도', `${result.parcel.floor_area_ratio_max}%`],
                  ['최고 층수', result.parcel.max_floors === 0 ? '제한 없음' : `${result.parcel.max_floors}층`],
                  ['최대 건축면적', `${(result.parcel.area_m2 * result.parcel.coverage_ratio_max / 100).toFixed(1)} ㎡`],
                  ['최대 연면적', `${(result.parcel.area_m2 * result.parcel.floor_area_ratio_max / 100).toFixed(1)} ㎡`],
                ]} />
              </div>

              {/* 핵심 강점 */}
              <div className="bg-blue-50 rounded-xl border border-blue-200 p-5">
                <h3 className="text-sm font-semibold text-blue-700 mb-3 flex items-center gap-2">
                  <CheckCircle size={16} />
                  핵심 강점
                </h3>
                <ul className="space-y-2">
                  {(result.key_strengths || []).map((s, i) => (
                    <li key={i} className="text-sm text-blue-800 flex items-start gap-2">
                      <ChevronRight size={14} className="mt-0.5 flex-shrink-0 text-blue-400" />
                      {s}
                    </li>
                  ))}
                  {(!result.key_strengths || result.key_strengths.length === 0) && (
                    <li className="text-sm text-blue-600">-</li>
                  )}
                </ul>
              </div>

              {/* 주요 리스크 */}
              <div className="bg-amber-50 rounded-xl border border-amber-200 p-5">
                <h3 className="text-sm font-semibold text-amber-700 mb-3 flex items-center gap-2">
                  <AlertTriangle size={16} />
                  주요 리스크
                </h3>
                <ul className="space-y-2">
                  {(result.key_risks || []).map((r, i) => (
                    <li key={i} className="text-sm text-amber-800 flex items-start gap-2">
                      <ChevronRight size={14} className="mt-0.5 flex-shrink-0 text-amber-400" />
                      {r}
                    </li>
                  ))}
                  {(!result.key_risks || result.key_risks.length === 0) && (
                    <li className="text-sm text-amber-600">-</li>
                  )}
                </ul>
              </div>
            </div>
          )}

          {/* ── 탭 2: 배치 계획 ── */}
          {activeTab === 'plan' && (
            <div className="space-y-5">
              {/* 최적 모듈 배치 */}
              <div className="bg-white rounded-xl border border-blue-200 p-5">
                <h3 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2">
                  <Building2 size={16} className="text-blue-500" />
                  최적 배치 — {result.best_module}
                  <span className="ml-auto text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">
                    {result.best_floor}층 / {result.best_units}세대
                  </span>
                </h3>
                {/* 층별 시각화 */}
                <div className="bg-gray-50 rounded-lg p-3 mb-4">
                  <div className="flex items-end gap-1">
                    {Array.from({ length: Math.min(result.best_floor, 12) }).map((_, i) => (
                      <div
                        key={i}
                        className="flex-1 bg-blue-500 rounded-t text-white text-[10px] flex items-end justify-center pb-1 font-bold"
                        style={{ height: `${Math.max(24, (i + 1) * 8)}px` }}
                        title={`${i + 1}층`}
                      >
                        {i + 1}
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    건폐율 {result.coverage_ratio?.toFixed(1)}% / 용적률 {result.floor_area_ratio?.toFixed(1)}%
                  </p>
                </div>
                <DL items={[
                  ['모듈 타입', result.best_module],
                  ['최적 층수', `${result.best_floor}층`],
                  ['총 세대수', `${result.best_units}세대`],
                  ['건폐율', `${result.coverage_ratio?.toFixed(1)}%`],
                  ['용적률', `${result.floor_area_ratio?.toFixed(1)}%`],
                ]} />
              </div>

              {/* 전체 모듈 플랜 비교 */}
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h3 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2">
                  <Layers size={16} className="text-indigo-500" />
                  모듈 타입별 비교
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-50">
                        {['모듈', '세대', '층', '건폐율', '용적률', 'ROI', '법규'].map(h => (
                          <th key={h} className="text-left px-3 py-2 text-xs text-gray-500 font-medium">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {(result.module_plans || []).map((plan, idx) => (
                        <tr
                          key={idx}
                          className={`border-t border-gray-100 ${plan.module_type === result.best_module ? 'bg-blue-50' : ''}`}
                        >
                          <td className="px-3 py-2 font-mono text-xs">
                            {plan.module_type === result.best_module && <span className="text-blue-600 mr-1">★</span>}
                            {plan.module_type}
                          </td>
                          <td className="px-3 py-2">{plan.total_units}세대</td>
                          <td className="px-3 py-2">{plan.floors}층</td>
                          <td className="px-3 py-2">{plan.coverage_ratio_pct?.toFixed(1)}%</td>
                          <td className="px-3 py-2">{plan.floor_area_ratio_pct?.toFixed(1)}%</td>
                          <td className="px-3 py-2 font-bold text-green-600">{plan.roi_pct?.toFixed(1)}%</td>
                          <td className="px-3 py-2">
                            {plan.is_compliant
                              ? <CheckCircle size={14} className="text-green-500" />
                              : <XCircle size={14} className="text-red-500" />
                            }
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 다음 단계 */}
              <div className="bg-gray-50 rounded-xl border border-gray-200 p-5">
                <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                  <TrendingUp size={16} className="text-gray-500" />
                  다음 단계
                </h3>
                <ul className="space-y-2">
                  {(result.next_actions || []).map((step, i) => (
                    <li key={i} className="text-sm text-gray-600 flex items-start gap-2">
                      <span className="flex-shrink-0 w-5 h-5 bg-blue-100 text-blue-700 rounded-full text-xs flex items-center justify-center font-bold mt-0.5">{i + 1}</span>
                      {step}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* ── 탭 3: 사업성 ── */}
          {activeTab === 'finance' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h3 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2">
                  <DollarSign size={16} className="text-green-500" />
                  사업성 분석 (LH 매입 기준)
                </h3>
                <div className="space-y-3">
                  <div className="bg-orange-50 rounded-lg p-3 flex justify-between items-center">
                    <span className="text-xs text-orange-600">공사비 (토지비 제외)</span>
                    <span className="font-bold text-orange-700">{result.construction_cost_bn?.toFixed(2)} 억원</span>
                  </div>
                  <div className="bg-blue-50 rounded-lg p-3 flex justify-between items-center">
                    <span className="text-xs text-blue-600">LH 매입 예상가</span>
                    <span className="font-bold text-blue-700">{result.lh_purchase_bn?.toFixed(2)} 억원</span>
                  </div>
                  <div className="bg-green-50 rounded-lg p-3 flex justify-between items-center">
                    <span className="text-xs text-green-600">예상 이익</span>
                    <span className="font-bold text-green-700">{result.profit_bn?.toFixed(2)} 억원</span>
                  </div>
                  <div className="bg-gray-900 rounded-lg p-3 flex justify-between items-center">
                    <span className="text-xs text-gray-300">ROI (토지비 미포함)</span>
                    <span className="font-black text-white text-lg">{result.roi_pct?.toFixed(1)}%</span>
                  </div>
                </div>
                <p className="text-xs text-gray-400 mt-3">
                  ⚠️ 토지비·금융비용·인허가비용 별도. LH 매입단가 수도권 기준.
                </p>
              </div>

              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h3 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2">
                  <Info size={16} className="text-indigo-500" />
                  수요 분석
                </h3>
                <DL items={[
                  ['분석 권역', result.demand_region || '-'],
                  ['수요 점수', `${result.demand_score ?? '-'}점`],
                  ['권장 세대수', `${result.recommended_units ?? '-'}세대`],
                  ['신뢰도', `${((result.demand_confidence || 0) * 100).toFixed(0)}%`],
                ]} />

                {(result.demand_risk_factors || []).length > 0 && (
                  <div className="mt-4">
                    <p className="text-xs font-medium text-gray-500 mb-2">수요 리스크 요인</p>
                    <ul className="space-y-1">
                      {result.demand_risk_factors.map((rf, i) => (
                        <li key={i} className="text-xs text-gray-600 flex items-start gap-1">
                          <AlertTriangle size={12} className="text-amber-500 mt-0.5 flex-shrink-0" />
                          {rf}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── 탭 4: SITE-C ── */}
          {activeTab === 'sitec' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h3 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2">
                  <Star size={16} className="text-yellow-500" />
                  SITE-C 예비 점수
                </h3>
                <div className="text-center py-4">
                  <p className={`text-5xl font-black ${sitecColor(result.sitec_grade)}`}>
                    {result.sitec_score ?? '-'}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">점 / 100점</p>
                  <span className={`inline-block mt-2 px-3 py-1 rounded-full text-sm font-bold ${
                    result.sitec_grade === 'A' ? 'bg-green-100 text-green-700' :
                    result.sitec_grade === 'B' ? 'bg-blue-100 text-blue-700' :
                    result.sitec_grade === 'C' ? 'bg-amber-100 text-amber-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {result.sitec_grade} 등급 — 심의 통과 확률 {(result.sitec_approval_prob * 100).toFixed(0)}%
                  </span>
                </div>

                {/* 항목별 점수 */}
                {result.sitec_breakdown && (
                  <div className="mt-4 space-y-2">
                    {Object.entries(result.sitec_breakdown).map(([key, score]) => {
                      const pct = Math.min(100, (score / 30) * 100)
                      return (
                        <div key={key}>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-gray-600">{key.replace(/_/g, ' ')}</span>
                            <span className="font-medium">{typeof score === 'number' ? score.toFixed(1) : score}</span>
                          </div>
                          <div className="w-full bg-gray-100 rounded-full h-1.5">
                            <div
                              className="bg-blue-500 h-1.5 rounded-full"
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>

              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h3 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2">
                  <Zap size={16} className="text-amber-500" />
                  개선 제안
                </h3>
                <ul className="space-y-3">
                  {(result.sitec_suggestions || []).map((s, i) => (
                    <li key={i} className="text-sm text-gray-700 flex items-start gap-2 p-2 bg-amber-50 rounded-lg">
                      <ChevronRight size={14} className="mt-0.5 flex-shrink-0 text-amber-500" />
                      {s}
                    </li>
                  ))}
                  {(!result.sitec_suggestions || result.sitec_suggestions.length === 0) && (
                    <li className="text-sm text-gray-500">제안 없음</li>
                  )}
                </ul>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}
