/**
 * BulkCluster.tsx – 스마트 클러스터 최적화 (500~1000세대 자동 분할)
 * /api/v1/bulk/smart-cluster 엔드포인트 사용
 * - ROI 지역별 LH 매입단가 반영
 * - 클러스터 보고서 DB 저장/조회
 * - 사업지별 상세 분석 리포트 (단일 사업지 수준)
 */
import { useState } from 'react'
import {
  Map, Settings, Play, ChevronDown, ChevronUp,
  Building, DollarSign, Percent, Info, Star,
  CheckCircle, AlertCircle, AlertTriangle, Layers,
  Loader2, Download, TrendingUp, BarChart3,
  Target, Clock, Award, Zap, ArrowRight, RefreshCw,
  FileText, Database, MapPin, Activity
} from 'lucide-react'

const API = '/api/v1'

// ─── 타입 정의 ───────────────────────────────────────────

interface ClusterSite {
  id: number
  name: string
  address: string
  lat: number
  lng: number
  sitec_score?: number
  sitec_grade?: string
  planned_units?: number
  estimated_cost_bn?: number
  lh_price_bn?: number
  roi_pct?: number
  expected_margin?: number
  sitec_approval_prob?: number
  floor_count?: number
  subway_distance_m?: number
  sitec_breakdown?: Record<string, unknown>
}

interface SiteDetailReport {
  site_id: number
  name: string
  address: string
  sitec_score: number
  sitec_grade: string
  grade_label: string
  grade_color: string
  lh_approval_prob: string
  planned_units: number
  floor_count?: number
  land_area_m2?: number
  cost_bn: number
  lh_bn: number
  profit_bn: number
  roi_pct: number
  lh_price_per_m2: number
  lh_region_note: string
  biz_grade: string
  biz_color: string
  transport_notes: string[]
  infra_notes: string[]
  subway_distance_m?: number
  sitec_breakdown?: Record<string, unknown>
  sitec_suggestions?: string[]
  strengths: string[]
  risks: string[]
  is_modular?: boolean
  lh_certified?: boolean
  hazard_risk_level?: string
  sitec_approval_prob?: number
}

interface GanttItem {
  site_id: number
  site_name: string
  address: string
  modules: number
  sitec_score?: number
  batch?: number
  factory_start: number
  factory_end: number
  install_start: number
  install_end: number
  total_months: number
  parallel_production?: boolean
}

interface GanttParallel {
  schedule: GanttItem[]
  batch_summary: Array<{
    batch_no: number
    n_sites: number
    total_units: number
    factory_start_month: number
    factory_end_month: number
    install_end_month: number
  }>
  total_months: number
  factory_capacity: number
  monthly_rate: number
  n_batches: number
  parallel_production: boolean
}

interface ClusterReport {
  cluster_id: number
  rank?: number
  center_lat: number
  center_lng: number
  n_sites: number
  total_units: number
  base_cost_bn: number
  discounted_cost_bn: number
  discount_pct: number
  total_lh_bn: number
  profit_bn: number
  cluster_roi_pct: number
  avg_sitec_score: number
  best_grade: string
  target_fit: string
  viability: string
  viability_color: string
  sites: ClusterSite[]
  site_details?: SiteDetailReport[]
  top_sites: ClusterSite[]
  region_breakdown: Record<string, number>
  grade_distribution: Record<string, number>
  strengths: string[]
  risks: string[]
  next_actions: string[]
  lh_price_breakdown?: Record<string, number>
  discount_breakdown: {
    volume_discount_basis: string
    site_bonus_basis: string
    formula: string
    saving_bn?: number
  }
  gantt: GanttItem[]
  gantt_parallel?: GanttParallel
}

interface SmartClusterResponse {
  session_id: string
  radius_km: number
  target_units_range: [number, number]
  total_sites: number
  total_clusters: number
  clustered: number
  unclustered_count: number
  clusters: ClusterReport[]
  unclustered: Array<{
    id: number; name: string; address: string
    sitec_score?: number; sitec_grade?: string; planned_units?: number; roi_pct?: number
  }>
  saved_report_ids: number[]
  summary: {
    total_clusters: number
    total_clustered_units: number
    total_unclustered: number
    base_cost_bn: number
    discounted_cost_bn: number
    total_saving_bn: number
    total_profit_bn: number
    avg_roi_pct: number
    avg_sitec_score: number
    avg_discount_pct: number
    optimal_clusters: number
    top_cluster: { cluster_id: number; total_units: number; cluster_roi_pct: number; viability: string } | null
  }
}

interface SavedReport {
  id: number
  cluster_name: string
  cluster_no: number
  analysis_session: string
  n_sites: number
  total_units: number
  cluster_roi_pct: number
  viability: string
  target_fit: string
  avg_sitec_score: number
  discount_pct: number
  base_cost_bn: number
  discounted_cost_bn: number
  profit_bn: number
  rank?: number
  created_at: string
}

// ─── ILP 포트폴리오 최적화 타입 ─────────────────────────────

interface PortfolioClusterItem {
  cluster_id: number
  cluster_name: string
  n_sites: number
  total_units: number
  base_cost_bn: number
  discounted_cost_bn: number
  discount_pct: number
  total_lh_bn: number
  profit_bn: number
  cluster_roi_pct: number
  avg_sitec_score: number
  best_grade: string
  viability: string
  viability_color: string
  target_fit: string
  selected: boolean
  selection_reason: string
  rank: number
}

interface GanttPhase {
  phase_no: number
  cluster_id: number
  cluster_name: string
  total_units: number
  start_month: number
  end_month: number
  duration_months: number
  cost_bn: number
  profit_bn: number
  roi_pct: number
  overlap_possible: boolean
}

interface SensitivityItem {
  cluster_id: number
  cluster_name: string
  roi_pct: number
  cost_bn: number
  units: number
}

interface PortfolioResult {
  selected_clusters: PortfolioClusterItem[]
  not_selected_clusters: PortfolioClusterItem[]
  total_investment_bn: number
  total_lh_bn: number
  total_profit_bn: number
  portfolio_roi_pct: number
  total_units: number
  total_sites: number
  n_clusters_selected: number
  n_clusters_total: number
  budget_utilization_pct: number
  objective: string
  optimization_method: string
  constraints_summary: Record<string, unknown>
  execution_summary: string
  gantt_phases: GanttPhase[]
  sensitivity: {
    budget_increase_10pct: SensitivityItem[]
    budget_increase_20pct: SensitivityItem[]
    roi_relax_10pct: SensitivityItem[]
  }
}


// ─── 상수 ────────────────────────────────────────────────

const RADIUS_OPTIONS = [
  { value: 3,  label: '반경 3km',  desc: '도심 밀집 · 긴밀한 물류' },
  { value: 5,  label: '반경 5km',  desc: '권역 표준 · 권장 설정' },
  { value: 10, label: '반경 10km', desc: '광역 · 최대 규모의 경제' },
]

const UNIT_PRESETS = [
  { min: 300,  max: 700,  label: '소형 (300~700세대)' },
  { min: 500,  max: 1000, label: '표준 (500~1000세대)' },
  { min: 700,  max: 1500, label: '대형 (700~1500세대)' },
]

const VIABILITY_STYLE: Record<string, { bg: string; text: string; border: string }> = {
  탁월:  { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-300' },
  우수:  { bg: 'bg-green-50',   text: 'text-green-700',   border: 'border-green-300'   },
  양호:  { bg: 'bg-blue-50',    text: 'text-blue-700',    border: 'border-blue-300'    },
  검토:  { bg: 'bg-amber-50',   text: 'text-amber-700',   border: 'border-amber-300'   },
  부적합:{ bg: 'bg-red-50',     text: 'text-red-700',     border: 'border-red-300'     },
}

const TARGET_FIT_STYLE: Record<string, string> = {
  최적:   'bg-emerald-100 text-emerald-700',
  적정이하: 'bg-yellow-100 text-yellow-700',
  과대:   'bg-orange-100 text-orange-700',
  분할필요: 'bg-red-100 text-red-700',
  소규모: 'bg-gray-100 text-gray-600',
}

const GRADE_COLOR: Record<string, string> = {
  'A+': 'bg-emerald-100 text-emerald-700',
  'A':  'bg-green-100 text-green-700',
  'B+': 'bg-blue-100 text-blue-700',
  'B':  'bg-sky-100 text-sky-700',
  'C':  'bg-yellow-100 text-yellow-700',
  '탈락': 'bg-red-100 text-red-700',
}

const BIZ_COLOR: Record<string, { bg: string; text: string }> = {
  탁월:   { bg: 'bg-emerald-100', text: 'text-emerald-700' },
  우수:   { bg: 'bg-green-100',   text: 'text-green-700'   },
  양호:   { bg: 'bg-blue-100',    text: 'text-blue-700'    },
  검토:   { bg: 'bg-amber-100',   text: 'text-amber-700'   },
  부적합: { bg: 'bg-red-100',     text: 'text-red-700'     },
}

// ─── 메인 컴포넌트 ────────────────────────────────────────

export default function BulkCluster() {
  // 설정
  const [radiusKm, setRadiusKm]       = useState(5)
  const [unitPreset, setUnitPreset]   = useState(1)
  const [minUnits, setMinUnits]       = useState(500)
  const [maxUnits, setMaxUnits]       = useState(1000)
  const [applyDiscount, setApplyDiscount] = useState(true)
  const [saveReport, setSaveReport]   = useState(true)

  // 상태
  const [loading, setLoading]   = useState(false)
  const [result, setResult]     = useState<SmartClusterResponse | null>(null)
  const [error, setError]       = useState<string | null>(null)

  // 저장된 보고서
  const [savedReports, setSavedReports]       = useState<SavedReport[]>([])
  const [loadingReports, setLoadingReports]   = useState(false)
  const [showSavedReports, setShowSavedReports] = useState(false)

  // UI 상태
  const [expandedClusters, setExpandedClusters] = useState<Set<number>>(new Set([0]))
  const [activeTab, setActiveTab] = useState<Record<number, 'overview' | 'sites' | 'gantt' | 'detail'>>({})
  const [expandedSiteDetail, setExpandedSiteDetail] = useState<Set<number>>(new Set())


  // ── ILP 포트폴리오 최적화 상태 ────────────────────────
  const [portfolioBudget, setPortfolioBudget]       = useState(5000)
  const [portfolioMaxUnits, setPortfolioMaxUnits]   = useState(5000)
  const [portfolioMinRoi, setPortfolioMinRoi]       = useState(50)
  const [portfolioMaxParallel, setPortfolioMaxParallel] = useState(5)
  const [portfolioObjective, setPortfolioObjective] = useState<'maximize_roi' | 'maximize_profit' | 'maximize_units'>('maximize_roi')
  const [portfolioSessionId, setPortfolioSessionId] = useState<string>('')
  const [portfolioMustIds, setPortfolioMustIds]     = useState<string>('')
  const [portfolioExcludeIds, setPortfolioExcludeIds] = useState<string>('')
  const [portfolioResult, setPortfolioResult]       = useState<PortfolioResult | null>(null)
  const [portfolioLoading, setPortfolioLoading]     = useState(false)
  const [portfolioError, setPortfolioError]         = useState<string | null>(null)
  const [portfolioSessions, setPortfolioSessions]   = useState<Array<{analysis_session:string; n_clusters:number; total_units:number; avg_roi:number; last_created:string}>>([])
  const [showNotSelected, setShowNotSelected]       = useState(false)
  const [showGanttPhases, setShowGanttPhases]       = useState(false)

  // ── 실행 ──────────────────────────────────────────────


  // ── ILP 포트폴리오 최적화 실행 ────────────────────────

  const runPortfolioOptimization = async () => {
    setPortfolioLoading(true)
    setPortfolioError(null)
    setPortfolioResult(null)
    try {
      const mustIds = portfolioMustIds.trim()
        ? portfolioMustIds.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n))
        : undefined
      const excludeIds = portfolioExcludeIds.trim()
        ? portfolioExcludeIds.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n))
        : undefined

      const res = await fetch(`${API}/bulk/optimize-portfolio`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          budget_bn: portfolioBudget,
          max_units_per_year: portfolioMaxUnits,
          min_cluster_roi: portfolioMinRoi,
          max_parallel_clusters: portfolioMaxParallel,
          objective: portfolioObjective,
          session_id: portfolioSessionId || undefined,
          must_include_ids: mustIds,
          exclude_ids: excludeIds,
        })
      })
      if (!res.ok) {
        const err = await res.json()
        throw new Error(err.detail || `오류 ${res.status}`)
      }
      const data: PortfolioResult = await res.json()
      setPortfolioResult(data)
    } catch (e: unknown) {
      setPortfolioError(e instanceof Error ? e.message : String(e))
    } finally {
      setPortfolioLoading(false)
    }
  }

  const loadPortfolioSessions = async () => {
    try {
      const res = await fetch(`${API}/bulk/portfolio/sessions`)
      if (res.ok) {
        const data = await res.json()
        setPortfolioSessions(data.sessions || [])
      }
    } catch {}
  }

  const downloadPortfolioCSV = () => {
    if (!portfolioResult) return
    const headers = ['순위', '클러스터명', '선택여부', '총세대', '투자비(억)', 'LH매입(억)', '수익(억)', 'ROI(%)', '평균SITEC', '최우수등급', '공사비할인(%)', '선택사유']
    const rows = [
      ...portfolioResult.selected_clusters.map(c => [
        c.rank, c.cluster_name, '선택', c.total_units,
        c.discounted_cost_bn.toFixed(1), c.total_lh_bn.toFixed(1),
        c.profit_bn.toFixed(1), c.cluster_roi_pct.toFixed(1),
        c.avg_sitec_score.toFixed(1), c.best_grade, c.discount_pct.toFixed(1),
        c.selection_reason
      ]),
      ...portfolioResult.not_selected_clusters.map(c => [
        '-', c.cluster_name, '미선택', c.total_units,
        c.discounted_cost_bn.toFixed(1), c.total_lh_bn.toFixed(1),
        c.profit_bn.toFixed(1), c.cluster_roi_pct.toFixed(1),
        c.avg_sitec_score.toFixed(1), c.best_grade, c.discount_pct.toFixed(1),
        c.selection_reason
      ])
    ]
    const csv = [headers, ...rows].map(r => r.join(',')).join('\n')
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `portfolio_optimization_${new Date().toISOString().slice(0,10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const runSmartCluster = async () => {
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      const res = await fetch(`${API}/bulk/smart-cluster`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          radius_km: radiusKm,
          min_units_per_cluster: minUnits,
          max_units_per_cluster: maxUnits,
          apply_cost_discount: applyDiscount,
          save_report: saveReport,
        }),
      })
      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error((err as { detail?: string }).detail || `서버 오류 ${res.status}`)
      }
      const data: SmartClusterResponse = await res.json()
      setResult(data)
      setExpandedClusters(new Set(data.clusters.slice(0, 3).map((_, i) => i)))
      const tabs: Record<number, 'overview' | 'sites' | 'gantt' | 'detail'> = {}
      data.clusters.forEach((_, i) => { tabs[i] = 'overview' })
      setActiveTab(tabs)
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : '클러스터 분석 실패')
    } finally {
      setLoading(false)
    }
  }

  const loadSavedReports = async () => {
    setLoadingReports(true)
    try {
      const res = await fetch(`${API}/bulk/reports?limit=30`)
      const data = await res.json()
      setSavedReports(data.reports || [])
      setShowSavedReports(true)
    } catch (e) {
      console.error('보고서 로드 실패:', e)
    } finally {
      setLoadingReports(false)
    }
  }

  const applyPreset = (idx: number) => {
    setUnitPreset(idx)
    setMinUnits(UNIT_PRESETS[idx].min)
    setMaxUnits(UNIT_PRESETS[idx].max)
  }

  const toggleCluster = (i: number) => {
    const next = new Set(expandedClusters)
    next.has(i) ? next.delete(i) : next.add(i)
    setExpandedClusters(next)
  }

  const setTab = (i: number, tab: 'overview' | 'sites' | 'gantt' | 'detail') => {
    setActiveTab(prev => ({ ...prev, [i]: tab }))
  }

  const toggleSiteDetail = (siteId: number) => {
    const next = new Set(expandedSiteDetail)
    next.has(siteId) ? next.delete(siteId) : next.add(siteId)
    setExpandedSiteDetail(next)
  }

  // ── CSV 다운로드 ───────────────────────────────────────

  const downloadCSV = () => {
    if (!result) return
    const header = [
      'rank', 'cluster_id', 'n_sites', 'total_units', 'target_fit',
      'viability', 'avg_sitec_score', 'best_grade',
      'base_cost_억', 'discounted_cost_억', 'discount_pct',
      'lh_total_억', 'profit_억', 'roi_pct', 'session_id'
    ].join(',') + '\n'
    const rows = result.clusters.map(c =>
      [
        c.rank ?? '', c.cluster_id, c.n_sites, c.total_units, c.target_fit,
        c.viability, c.avg_sitec_score.toFixed(1), c.best_grade,
        c.base_cost_bn.toFixed(1), c.discounted_cost_bn.toFixed(1), c.discount_pct.toFixed(1),
        c.total_lh_bn.toFixed(1), c.profit_bn.toFixed(1), c.cluster_roi_pct.toFixed(1),
        result.session_id
      ].join(',')
    ).join('\n')
    const blob = new Blob(['\uFEFF' + header + rows], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = `smart_cluster_${radiusKm}km_${result.session_id}.csv`; a.click()
    URL.revokeObjectURL(url)
  }

  // ── 사업지별 상세 리포트 렌더 ────────────────────────

  const renderSiteDetailReport = (sd: SiteDetailReport) => {
    const isOpen = expandedSiteDetail.has(sd.site_id)
    const bizStyle = BIZ_COLOR[sd.biz_grade] ?? { bg: 'bg-gray-100', text: 'text-gray-600' }
    const gradeStyle = GRADE_COLOR[sd.sitec_grade] ?? 'bg-gray-100 text-gray-600'

    return (
      <div key={sd.site_id} className="border border-gray-200 rounded-xl overflow-hidden">
        {/* 사업지 헤더 */}
        <button
          onClick={() => toggleSiteDetail(sd.site_id)}
          className="w-full flex items-center justify-between p-3 bg-white hover:bg-gray-50 text-left transition-colors"
        >
          <div className="flex items-center gap-3 min-w-0">
            <span className={`px-2 py-0.5 rounded-lg font-black text-xs ${gradeStyle}`}>{sd.sitec_grade}</span>
            <div className="min-w-0">
              <div className="font-semibold text-gray-800 text-sm truncate">{sd.name}</div>
              <div className="text-xs text-gray-400 truncate">{sd.address}</div>
            </div>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <div className="text-right hidden sm:block">
              <div className="text-xs font-black text-indigo-600">ROI {sd.roi_pct.toFixed(1)}%</div>
              <div className="text-xs text-gray-400">{sd.planned_units}세대</div>
            </div>
            <div className={`hidden md:block px-2 py-1 rounded-lg text-xs font-bold ${bizStyle.bg} ${bizStyle.text}`}>
              {sd.biz_grade}
            </div>
            <div className="text-xs font-bold text-blue-700">SITE-C {sd.sitec_score.toFixed(1)}</div>
            {isOpen ? <ChevronUp size={14} className="text-gray-400" /> : <ChevronDown size={14} className="text-gray-400" />}
          </div>
        </button>

        {/* 상세 펼침 */}
        {isOpen && (
          <div className="border-t border-gray-100 p-4 bg-gray-50 space-y-4">

            {/* 핵심 지표 그리드 */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <div className="bg-white border border-gray-100 rounded-xl p-3 text-center shadow-sm">
                <div className="text-xs text-gray-400 mb-1">SITE-C 점수</div>
                <div className="text-xl font-black text-blue-700">{sd.sitec_score.toFixed(1)}</div>
                <div className={`text-xs mt-1 font-bold px-2 py-0.5 rounded inline-block ${gradeStyle}`}>{sd.grade_label}</div>
              </div>
              <div className="bg-white border border-gray-100 rounded-xl p-3 text-center shadow-sm">
                <div className="text-xs text-gray-400 mb-1">예상 ROI</div>
                <div className={`text-xl font-black ${sd.roi_pct >= 20 ? 'text-emerald-600' : sd.roi_pct >= 10 ? 'text-blue-600' : 'text-amber-600'}`}>
                  {sd.roi_pct.toFixed(1)}%
                </div>
                <div className={`text-xs mt-1 font-bold px-2 py-0.5 rounded inline-block ${bizStyle.bg} ${bizStyle.text}`}>{sd.biz_grade}</div>
              </div>
              <div className="bg-white border border-gray-100 rounded-xl p-3 text-center shadow-sm">
                <div className="text-xs text-gray-400 mb-1">계획 세대수</div>
                <div className="text-xl font-black text-gray-800">{sd.planned_units}</div>
                <div className="text-xs text-gray-400 mt-1">{sd.floor_count ? `${sd.floor_count}층` : '—'}</div>
              </div>
              <div className="bg-white border border-gray-100 rounded-xl p-3 text-center shadow-sm">
                <div className="text-xs text-gray-400 mb-1">LH 심의 통과율</div>
                <div className="text-xl font-black text-purple-700">{sd.lh_approval_prob}</div>
                <div className="text-xs text-gray-400 mt-1">예상 확률</div>
              </div>
            </div>

            {/* 재무 분석 */}
            <div className="bg-white border border-gray-100 rounded-xl p-3 shadow-sm">
              <div className="font-semibold text-gray-700 text-xs mb-2 flex items-center gap-1.5">
                <DollarSign size={12} className="text-gray-500" /> 재무 분석
              </div>
              <div className="space-y-1.5">
                {[
                  { label: '예상 공사비', value: `${sd.cost_bn.toFixed(2)}억원`, color: 'text-gray-700' },
                  { label: 'LH 매입가 추정', value: `${sd.lh_bn.toFixed(2)}억원`, color: 'text-gray-700' },
                  { label: '예상 수익', value: `${sd.profit_bn.toFixed(2)}억원`, color: sd.profit_bn >= 0 ? 'text-emerald-600 font-black' : 'text-red-600 font-black' },
                  { label: `ROI (수익/투자)`, value: `${sd.roi_pct.toFixed(1)}%`, color: sd.roi_pct >= 15 ? 'text-indigo-700 font-black' : 'text-amber-600 font-bold' },
                ].map((row, j) => (
                  <div key={j} className="flex justify-between items-center text-xs border-b border-gray-100 pb-1">
                    <span className="text-gray-500">{row.label}</span>
                    <span className={row.color}>{row.value}</span>
                  </div>
                ))}
              </div>
              <div className="mt-2 text-xs text-gray-400 bg-gray-50 rounded-lg p-2">
                <MapPin size={10} className="inline mr-1" />
                {sd.lh_region_note}
              </div>
            </div>

            {/* 교통/인프라 */}
            {(sd.transport_notes.length > 0 || sd.infra_notes.length > 0) && (
              <div className="grid grid-cols-2 gap-2">
                {sd.transport_notes.length > 0 && (
                  <div className="bg-white border border-gray-100 rounded-xl p-3 shadow-sm">
                    <div className="font-semibold text-gray-600 text-xs mb-2">교통 접근성</div>
                    <ul className="space-y-1">
                      {sd.transport_notes.map((note, j) => (
                        <li key={j} className="text-xs text-gray-600">{note}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {sd.infra_notes.length > 0 && (
                  <div className="bg-white border border-gray-100 rounded-xl p-3 shadow-sm">
                    <div className="font-semibold text-gray-600 text-xs mb-2">생활 인프라</div>
                    <ul className="space-y-1">
                      {sd.infra_notes.map((note, j) => (
                        <li key={j} className="text-xs text-gray-600">{note}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* 강점/리스크 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {sd.strengths.length > 0 && (
                <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-3">
                  <div className="font-semibold text-emerald-700 text-xs mb-2 flex items-center gap-1">
                    <Zap size={11} /> 강점
                  </div>
                  <ul className="space-y-1">
                    {sd.strengths.map((s, j) => (
                      <li key={j} className="flex items-start gap-1 text-xs text-emerald-700">
                        <CheckCircle size={10} className="shrink-0 mt-0.5" /> {s}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {sd.risks.length > 0 && (
                <div className="bg-red-50 border border-red-100 rounded-xl p-3">
                  <div className="font-semibold text-red-700 text-xs mb-2 flex items-center gap-1">
                    <AlertTriangle size={11} /> 리스크
                  </div>
                  <ul className="space-y-1">
                    {sd.risks.map((r, j) => (
                      <li key={j} className="flex items-start gap-1 text-xs text-red-700">
                        <AlertCircle size={10} className="shrink-0 mt-0.5" /> {r}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* SITE-C 항목별 상세 */}
            {sd.sitec_breakdown && Object.keys(sd.sitec_breakdown).length > 0 && (
              <div className="bg-white border border-gray-100 rounded-xl p-3 shadow-sm">
                <div className="font-semibold text-gray-600 text-xs mb-2">SITE-C 항목별 점수</div>
                <div className="grid grid-cols-2 gap-1.5">
                  {Object.entries(sd.sitec_breakdown).map(([key, val]) => (
                    <div key={key} className="flex justify-between text-xs">
                      <span className="text-gray-500">{key}</span>
                      <span className="font-bold text-blue-700">{String(val)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 개선 제안 */}
            {sd.sitec_suggestions && sd.sitec_suggestions.length > 0 && (
              <div className="bg-blue-50 border border-blue-100 rounded-xl p-3">
                <div className="font-semibold text-blue-700 text-xs mb-2">개선 제안</div>
                <ul className="space-y-1">
                  {sd.sitec_suggestions.map((s, j) => (
                    <li key={j} className="text-xs text-blue-700 flex items-start gap-1">
                      <ArrowRight size={10} className="shrink-0 mt-0.5" /> {s}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
    )
  }

  // ─────────────────────────────────────────────────────
  // 렌더
  // ─────────────────────────────────────────────────────
  return (
    <div className="space-y-6 pb-10">

      {/* ── 헤더 ─────────────────────────────────────────── */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-black text-gray-900 flex items-center gap-2">
            <Layers size={22} className="text-blue-600" />
            스마트 클러스터 최적화
          </h1>
          <p className="text-gray-500 text-sm mt-1">
            500~1000세대 목표 · 동시 다중 클러스터 구성 · 지역별 LH 매입단가 반영 ROI · 보고서 저장
          </p>
        </div>
        <div className="flex items-center gap-2">
          {result && (
            <button
              onClick={runSmartCluster}
              className="flex items-center gap-1.5 px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50 transition-colors"
            >
              <RefreshCw size={14} /> 재분석
            </button>
          )}
          <button
            onClick={loadSavedReports}
            disabled={loadingReports}
            className="flex items-center gap-1.5 px-3 py-2 border border-blue-200 rounded-lg text-sm text-blue-600 hover:bg-blue-50 transition-colors"
          >
            {loadingReports ? <Loader2 size={14} className="animate-spin" /> : <Database size={14} />}
            저장된 보고서
          </button>
        </div>
      </div>

      {/* ── 저장된 보고서 목록 ──────────────────────────── */}
      {showSavedReports && savedReports.length > 0 && (
        <div className="card border border-blue-100">
          <div className="flex items-center justify-between mb-4">
            <div className="font-bold text-gray-800 flex items-center gap-2">
              <Database size={16} className="text-blue-500" /> 저장된 클러스터 보고서 ({savedReports.length}개)
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  if (!savedReports.length) return
                  const hdr = ['id','cluster_name','total_units','cluster_roi_pct','viability','target_fit','avg_sitec_score','discount_pct','base_cost_bn','discounted_cost_bn','profit_bn','analysis_session','created_at'].join(',') + '\n'
                  const rows = savedReports.map(r => [
                    r.id, `"${r.cluster_name}"`, r.total_units, r.cluster_roi_pct?.toFixed(1),
                    r.viability, r.target_fit, r.avg_sitec_score?.toFixed(1), r.discount_pct?.toFixed(1),
                    r.base_cost_bn?.toFixed(1), r.discounted_cost_bn?.toFixed(1), r.profit_bn?.toFixed(1),
                    r.analysis_session, r.created_at
                  ].join(',')).join('\n')
                  const blob = new Blob(['\uFEFF' + hdr + rows], {type:'text/csv;charset=utf-8;'})
                  const a = document.createElement('a'); a.href = URL.createObjectURL(blob)
                  a.download = `cluster_reports_${new Date().toISOString().slice(0,10)}.csv`; a.click()
                }}
                className="flex items-center gap-1 px-2 py-1 bg-emerald-100 text-emerald-700 rounded-lg text-xs font-medium hover:bg-emerald-200"
              >
                <Download size={12} /> CSV 추출
              </button>
              <button onClick={() => setShowSavedReports(false)} className="text-gray-400 hover:text-gray-600 text-xs">닫기</button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs min-w-[700px]">
              <thead>
                <tr className="text-gray-400 bg-gray-50">
                  <th className="text-left py-2 px-2">보고서명</th>
                  <th className="text-center py-2 px-2">세대수</th>
                  <th className="text-center py-2 px-2">ROI</th>
                  <th className="text-center py-2 px-2">타당성</th>
                  <th className="text-center py-2 px-2">할인율</th>
                  <th className="text-right py-2 px-2">수익(억)</th>
                  <th className="text-right py-2 px-2">저장일시</th>
                </tr>
              </thead>
              <tbody>
                {savedReports.map(r => (
                  <tr key={r.id} className="border-t border-gray-100 hover:bg-gray-50">
                    <td className="py-1.5 px-2 font-medium text-gray-700">{r.cluster_name}</td>
                    <td className="py-1.5 px-2 text-center">{r.total_units}</td>
                    <td className="py-1.5 px-2 text-center font-black text-indigo-600">{r.cluster_roi_pct?.toFixed(1)}%</td>
                    <td className="py-1.5 px-2 text-center">
                      <span className={`px-1.5 py-0.5 rounded text-xs font-bold ${VIABILITY_STYLE[r.viability]?.bg ?? 'bg-gray-100'} ${VIABILITY_STYLE[r.viability]?.text ?? 'text-gray-600'}`}>
                        {r.viability}
                      </span>
                    </td>
                    <td className="py-1.5 px-2 text-center text-emerald-600 font-bold">{r.discount_pct?.toFixed(1)}%</td>
                    <td className="py-1.5 px-2 text-right text-gray-700">{r.profit_bn?.toFixed(1)}</td>
                    <td className="py-1.5 px-2 text-right text-gray-400">
                      {r.created_at ? new Date(r.created_at).toLocaleDateString('ko-KR') : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── 설정 패널 ────────────────────────────────────── */}
      <div className="card">
        <div className="flex items-center gap-2 text-gray-800 font-bold mb-5">
          <Settings size={16} className="text-blue-500" /> 클러스터 설정
        </div>

        {/* 반경 */}
        <div className="mb-5">
          <label className="block text-sm font-semibold text-gray-700 mb-2">클러스터 반경</label>
          <div className="grid grid-cols-3 gap-3">
            {RADIUS_OPTIONS.map(opt => (
              <button
                key={opt.value}
                onClick={() => setRadiusKm(opt.value)}
                className={`p-3 rounded-xl border-2 text-left transition-all ${
                  radiusKm === opt.value
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-blue-300'
                }`}
              >
                <div className={`font-bold text-sm ${radiusKm === opt.value ? 'text-blue-700' : 'text-gray-800'}`}>
                  {opt.label}
                </div>
                <div className="text-xs text-gray-500 mt-0.5">{opt.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* 세대 범위 */}
        <div className="mb-5">
          <label className="block text-sm font-semibold text-gray-700 mb-2">클러스터 세대 목표 범위</label>
          <div className="grid grid-cols-3 gap-3 mb-3">
            {UNIT_PRESETS.map((p, idx) => (
              <button
                key={idx}
                onClick={() => applyPreset(idx)}
                className={`p-3 rounded-xl border-2 text-left transition-all ${
                  unitPreset === idx
                    ? 'border-indigo-500 bg-indigo-50'
                    : 'border-gray-200 hover:border-indigo-300'
                }`}
              >
                <div className={`font-bold text-sm ${unitPreset === idx ? 'text-indigo-700' : 'text-gray-800'}`}>
                  {p.label}
                </div>
              </button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-gray-500 mb-1">최소 세대 수</label>
              <input
                type="number" min={100} max={2000} step={50}
                value={minUnits}
                onChange={e => { setMinUnits(Number(e.target.value)); setUnitPreset(-1) }}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-500 mb-1">최대 세대 수</label>
              <input
                type="number" min={100} max={5000} step={50}
                value={maxUnits}
                onChange={e => { setMaxUnits(Number(e.target.value)); setUnitPreset(-1) }}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400"
              />
            </div>
          </div>
        </div>

        {/* 옵션 */}
        <div className="mb-5 grid grid-cols-2 gap-3">
          {/* 건축비 할인 */}
          <button
            onClick={() => setApplyDiscount(!applyDiscount)}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl border-2 transition-all ${
              applyDiscount ? 'border-emerald-400 bg-emerald-50' : 'border-gray-200 bg-white'
            }`}
          >
            <div className={`w-5 h-5 rounded-full flex items-center justify-center ${applyDiscount ? 'bg-emerald-500' : 'bg-gray-300'}`}>
              {applyDiscount && <CheckCircle size={12} className="text-white" />}
            </div>
            <div className="text-left">
              <div className={`text-sm font-semibold ${applyDiscount ? 'text-emerald-700' : 'text-gray-600'}`}>
                건축비 할인 {applyDiscount ? '적용' : '미적용'}
              </div>
              <div className="text-xs text-gray-400">최대 22% 절감</div>
            </div>
          </button>

          {/* 보고서 저장 */}
          <button
            onClick={() => setSaveReport(!saveReport)}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl border-2 transition-all ${
              saveReport ? 'border-blue-400 bg-blue-50' : 'border-gray-200 bg-white'
            }`}
          >
            <div className={`w-5 h-5 rounded-full flex items-center justify-center ${saveReport ? 'bg-blue-500' : 'bg-gray-300'}`}>
              {saveReport && <CheckCircle size={12} className="text-white" />}
            </div>
            <div className="text-left">
              <div className={`text-sm font-semibold ${saveReport ? 'text-blue-700' : 'text-gray-600'}`}>
                보고서 DB 저장 {saveReport ? '켜짐' : '꺼짐'}
              </div>
              <div className="text-xs text-gray-400">결과 영구 기록</div>
            </div>
          </button>
        </div>

        {/* 할인 공식 표 */}
        {applyDiscount && (
          <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 mb-5">
            <div className="flex items-center gap-2 text-blue-700 font-semibold text-sm mb-3">
              <Info size={14} /> 모듈 동시제작 건축비 할인 구조
            </div>
            <div className="grid grid-cols-4 gap-2 text-xs">
              {[
                { range: '~20세대', disc: '0%' }, { range: '21~50', disc: '~5%' },
                { range: '51~100', disc: '~10%' }, { range: '101~200', disc: '~15%' },
                { range: '201~500', disc: '~18%' }, { range: '501~1000', disc: '~20%' },
                { range: '현장 보너스', disc: '+~3%' }, { range: '상한', disc: '22%' },
              ].map((row, i) => (
                <div key={i} className="bg-white border border-blue-100 rounded-lg p-2 text-center">
                  <div className="font-black text-blue-700">{row.disc}</div>
                  <div className="text-blue-500 text-[10px] mt-0.5">{row.range}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* LH 지역별 매입단가 안내 */}
        <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 mb-5">
          <div className="flex items-center gap-2 text-amber-700 font-semibold text-sm mb-2">
            <Activity size={14} /> LH 신축매입약정 지역별 단가 반영 (2024~2025 기준)
          </div>
          <div className="grid grid-cols-3 gap-2 text-xs">
            {[
              { area: '강남·서초·송파', price: '950만원/㎡', color: 'text-red-600 font-black' },
              { area: '마포·용산·성동·광진', price: '820만원/㎡', color: 'text-orange-600 font-bold' },
              { area: '영등포·양천·강동', price: '750~780만원/㎡', color: 'text-amber-600 font-bold' },
              { area: '서울 기타', price: '700만원/㎡', color: 'text-yellow-700' },
              { area: '경기도', price: '520~620만원/㎡', color: 'text-blue-600' },
              { area: '지방광역시', price: '400~450만원/㎡', color: 'text-gray-500' },
            ].map((row, i) => (
              <div key={i} className="bg-white rounded-lg p-2">
                <div className="text-gray-600">{row.area}</div>
                <div className={row.color}>{row.price}</div>
              </div>
            ))}
          </div>
        </div>

        {/* 실행 버튼 */}
        <button
          onClick={runSmartCluster}
          disabled={loading}
          className="flex items-center gap-2 px-7 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 disabled:opacity-40 transition-colors shadow-sm text-sm"
        >
          {loading ? <Loader2 size={16} className="animate-spin" /> : <Play size={16} />}
          {loading ? '클러스터 최적화 중...' : '스마트 클러스터 최적화 시작'}
        </button>
      </div>

      {/* ── 에러 ────────────────────────────────────────── */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3 text-red-700">
          <AlertCircle size={18} />
          <span className="font-medium">{error}</span>
        </div>
      )}

      {/* ══ 결과 영역 ════════════════════════════════════ */}
      {result && (
        <div className="space-y-6">

          {/* ── 전체 KPI 요약 ─────────────────────────── */}
          <div className="card bg-gradient-to-br from-blue-600 to-indigo-700 text-white">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-lg font-black">전체 클러스터 최적화 결과</h2>
                <p className="text-blue-200 text-xs mt-0.5">
                  반경 {result.radius_km}km · 목표 {result.target_units_range[0]}~{result.target_units_range[1]}세대 · 총 {result.total_sites}개 사업지
                  {result.session_id && <span className="ml-2 opacity-70">세션 {result.session_id}</span>}
                </p>
              </div>
              <button
                onClick={downloadCSV}
                className="flex items-center gap-1.5 px-3 py-2 bg-white/20 hover:bg-white/30 rounded-lg text-xs font-medium transition-colors"
              >
                <Download size={13} /> CSV
              </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white/15 rounded-xl p-3 text-center">
                <Layers size={18} className="mx-auto mb-1 text-blue-200" />
                <div className="text-3xl font-black">{result.total_clusters}</div>
                <div className="text-xs text-blue-200 mt-0.5">최적 클러스터 수</div>
              </div>
              <div className="bg-white/15 rounded-xl p-3 text-center">
                <Building size={18} className="mx-auto mb-1 text-blue-200" />
                <div className="text-3xl font-black">{result.summary.total_clustered_units}</div>
                <div className="text-xs text-blue-200 mt-0.5">총 세대 수</div>
              </div>
              <div className="bg-white/15 rounded-xl p-3 text-center">
                <TrendingUp size={18} className="mx-auto mb-1 text-blue-200" />
                <div className="text-3xl font-black">{result.summary.avg_roi_pct.toFixed(1)}%</div>
                <div className="text-xs text-blue-200 mt-0.5">평균 ROI</div>
              </div>
              <div className="bg-emerald-400/30 rounded-xl p-3 text-center">
                <Percent size={18} className="mx-auto mb-1 text-emerald-200" />
                <div className="text-3xl font-black text-emerald-200">{result.summary.avg_discount_pct.toFixed(1)}%</div>
                <div className="text-xs text-emerald-200 mt-0.5">평균 건축비 절감</div>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-4 gap-4 border-t border-white/20 pt-4">
              <div>
                <div className="text-xs text-blue-300">기준 총 건축비</div>
                <div className="text-xl font-black">{result.summary.base_cost_bn.toFixed(0)}억</div>
              </div>
              <div>
                <div className="text-xs text-blue-300">할인 적용 후</div>
                <div className="text-xl font-black text-emerald-300">{result.summary.discounted_cost_bn.toFixed(0)}억</div>
              </div>
              <div>
                <div className="text-xs text-blue-300">LH 총 매입가</div>
                <div className="text-xl font-black text-yellow-200">{result.summary.discounted_cost_bn > 0 ? (result.clusters.reduce((a, b) => a + b.total_lh_bn, 0)).toFixed(0) : '—'}억</div>
              </div>
              <div>
                <div className="text-xs text-blue-300">예상 총 수익</div>
                <div className="text-xl font-black text-yellow-300">{result.summary.total_profit_bn.toFixed(0)}억</div>
              </div>
            </div>

            {result.total_clusters > 0 && (
              <div className="mt-3 flex items-center gap-3">
                <div className="text-xs text-blue-200">
                  최적 클러스터: {result.summary.optimal_clusters}/{result.total_clusters}개
                </div>
                <div className="flex-1 h-2 bg-white/20 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-400 rounded-full transition-all"
                    style={{ width: `${(result.summary.optimal_clusters / result.total_clusters) * 100}%` }}
                  />
                </div>
              </div>
            )}

            {result.saved_report_ids.length > 0 && (
              <div className="mt-2 text-xs text-blue-200 flex items-center gap-1">
                <FileText size={11} />
                보고서 {result.saved_report_ids.length}개 DB 저장 완료 (세션: {result.session_id})
              </div>
            )}
          </div>

          {/* ── 개별 클러스터 카드 목록 ───────────────── */}
          <div className="space-y-4">
            <h3 className="text-base font-bold text-gray-800 flex items-center gap-2">
              <BarChart3 size={16} className="text-indigo-500" />
              클러스터별 종합 보고서 (ROI 순)
            </h3>

            {result.clusters.map((c, i) => {
              const isOpen = expandedClusters.has(i)
              const tab    = activeTab[i] ?? 'overview'
              const vstyle = VIABILITY_STYLE[c.viability] ?? VIABILITY_STYLE['검토']

              return (
                <div key={c.cluster_id} className={`rounded-2xl border-2 overflow-hidden transition-all ${isOpen ? vstyle.border : 'border-gray-200'}`}>

                  {/* 클러스터 헤더 (토글) */}
                  <button
                    onClick={() => toggleCluster(i)}
                    className={`w-full flex items-center justify-between p-4 text-left transition-colors ${isOpen ? vstyle.bg : 'bg-white hover:bg-gray-50'}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm ${
                        (c.rank ?? i+1) === 1 ? 'bg-yellow-400 text-yellow-900' :
                        (c.rank ?? i+1) === 2 ? 'bg-gray-300 text-gray-700' :
                        (c.rank ?? i+1) === 3 ? 'bg-orange-300 text-orange-800' :
                        'bg-blue-600 text-white'
                      }`}>
                        {(c.rank ?? i+1) <= 3
                          ? <Star size={16} fill="currentColor" />
                          : `#${c.rank ?? i+1}`
                        }
                      </div>

                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-black text-gray-900 text-sm">클러스터 {c.cluster_id}</span>
                          <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${TARGET_FIT_STYLE[c.target_fit] ?? 'bg-gray-100 text-gray-600'}`}>
                            {c.target_fit}
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded-full font-bold border ${vstyle.bg} ${vstyle.text} ${vstyle.border}`}>
                            {c.viability}
                          </span>
                        </div>
                        <div className="text-xs text-gray-500 mt-0.5">
                          사업지 {c.n_sites}개 · {c.total_units}세대 · SITE-C {c.avg_sitec_score.toFixed(1)}점 · {c.best_grade}등급
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 shrink-0">
                      <div className="text-right hidden sm:block">
                        <div className="text-sm font-black text-indigo-600">ROI {c.cluster_roi_pct.toFixed(1)}%</div>
                        <div className="text-xs text-emerald-600 font-semibold">-{c.discount_pct.toFixed(1)}% 할인</div>
                      </div>
                      <div className="text-right hidden md:block">
                        <div className="text-sm font-bold text-gray-700">{c.profit_bn.toFixed(1)}억 수익</div>
                        <div className="text-xs text-gray-400">{c.discounted_cost_bn.toFixed(0)}억 비용</div>
                      </div>
                      {isOpen ? <ChevronUp size={18} className="text-gray-400" /> : <ChevronDown size={18} className="text-gray-400" />}
                    </div>
                  </button>

                  {/* 펼침 내용 */}
                  {isOpen && (
                    <div className="border-t border-gray-100">
                      {/* 탭 */}
                      <div className="flex border-b border-gray-100 bg-gray-50 overflow-x-auto">
                        {(['overview', 'detail', 'sites', 'gantt'] as const).map(t => (
                          <button
                            key={t}
                            onClick={() => setTab(i, t)}
                            className={`px-4 py-2.5 text-xs font-semibold transition-colors border-b-2 -mb-px whitespace-nowrap ${
                              tab === t
                                ? 'border-blue-500 text-blue-700 bg-white'
                                : 'border-transparent text-gray-500 hover:text-gray-700'
                            }`}
                          >
                            {t === 'overview' ? '📊 종합 개요' :
                             t === 'detail'   ? '🔍 사업지 상세' :
                             t === 'sites'    ? '🏗 사업지 목록' : '📅 공정 간트'}
                          </button>
                        ))}
                      </div>

                      <div className="p-4">

                        {/* ── 종합 개요 탭 ──────────────────── */}
                        {tab === 'overview' && (
                          <div className="space-y-4">
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                              <div className="bg-white border border-gray-100 rounded-xl p-3 text-center shadow-sm">
                                <Target size={16} className="mx-auto text-blue-500 mb-1" />
                                <div className="text-xl font-black text-gray-900">{c.total_units}</div>
                                <div className="text-xs text-gray-500">총 세대 수</div>
                              </div>
                              <div className="bg-white border border-gray-100 rounded-xl p-3 text-center shadow-sm">
                                <TrendingUp size={16} className="mx-auto text-indigo-500 mb-1" />
                                <div className="text-xl font-black text-indigo-600">{c.cluster_roi_pct.toFixed(1)}%</div>
                                <div className="text-xs text-gray-500">예상 ROI</div>
                              </div>
                              <div className="bg-white border border-gray-100 rounded-xl p-3 text-center shadow-sm">
                                <Percent size={16} className="mx-auto text-emerald-500 mb-1" />
                                <div className="text-xl font-black text-emerald-600">{c.discount_pct.toFixed(1)}%</div>
                                <div className="text-xs text-gray-500">건축비 절감</div>
                              </div>
                              <div className="bg-white border border-gray-100 rounded-xl p-3 text-center shadow-sm">
                                <Award size={16} className="mx-auto text-amber-500 mb-1" />
                                <div className="text-xl font-black text-amber-600">{c.avg_sitec_score.toFixed(1)}</div>
                                <div className="text-xs text-gray-500">평균 SITE-C</div>
                              </div>
                            </div>

                            {/* 재무 분석 */}
                            <div className="bg-gray-50 rounded-xl p-4">
                              <div className="font-semibold text-gray-700 text-sm mb-3 flex items-center gap-2">
                                <DollarSign size={15} className="text-gray-500" /> 재무 분석
                              </div>
                              <div className="space-y-2">
                                {[
                                  { label: '기준 건축비', value: `${c.base_cost_bn.toFixed(2)}억원`, color: 'text-gray-700' },
                                  { label: `클러스터 할인 (${c.discount_pct.toFixed(1)}%)`, value: `-${(c.base_cost_bn - c.discounted_cost_bn).toFixed(2)}억원`, color: 'text-emerald-600' },
                                  { label: '적용 후 건축비 (투자비)', value: `${c.discounted_cost_bn.toFixed(2)}억원`, color: 'text-blue-700 font-black' },
                                  { label: 'LH 매입가 합계 (지역별 단가)', value: `${c.total_lh_bn.toFixed(2)}억원`, color: 'text-gray-700' },
                                  { label: '예상 수익 (LH매입 - 투자비)', value: `${c.profit_bn.toFixed(2)}억원`, color: 'text-indigo-700 font-black' },
                                  { label: 'ROI = 수익 / 투자비 × 100', value: `${c.cluster_roi_pct.toFixed(1)}%`, color: 'text-purple-700 font-black' },
                                ].map((row, j) => (
                                  <div key={j} className="flex justify-between items-center text-sm border-b border-gray-100 pb-1.5">
                                    <span className="text-gray-500">{row.label}</span>
                                    <span className={row.color}>{row.value}</span>
                                  </div>
                                ))}
                              </div>
                              <div className="mt-2 text-xs text-gray-400 bg-white rounded-lg p-2">
                                {c.discount_breakdown.formula}
                              </div>
                            </div>

                            {/* LH 지역별 매입단가 */}
                            {c.lh_price_breakdown && Object.keys(c.lh_price_breakdown).length > 0 && (
                              <div className="bg-amber-50 border border-amber-100 rounded-xl p-3">
                                <div className="font-semibold text-amber-700 text-xs mb-2 flex items-center gap-1.5">
                                  <MapPin size={12} /> 적용 LH 매입단가 (지역별)
                                </div>
                                <div className="grid grid-cols-2 gap-2">
                                  {Object.entries(c.lh_price_breakdown).map(([gu, price]) => (
                                    <div key={gu} className="flex justify-between text-xs">
                                      <span className="text-amber-600">{gu}</span>
                                      <span className="font-bold text-amber-800">{price}만원/㎡</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* 강점 / 리스크 */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                              {c.strengths.length > 0 && (
                                <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-3">
                                  <div className="font-semibold text-emerald-700 text-sm mb-2 flex items-center gap-1.5">
                                    <Zap size={14} /> 강점 요인
                                  </div>
                                  <ul className="space-y-1.5">
                                    {c.strengths.map((s, j) => (
                                      <li key={j} className="flex items-start gap-1.5 text-xs text-emerald-700">
                                        <CheckCircle size={12} className="shrink-0 mt-0.5" /> {s}
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                              {c.risks.length > 0 && (
                                <div className="bg-red-50 border border-red-100 rounded-xl p-3">
                                  <div className="font-semibold text-red-700 text-sm mb-2 flex items-center gap-1.5">
                                    <AlertTriangle size={14} /> 리스크 요인
                                  </div>
                                  <ul className="space-y-1.5">
                                    {c.risks.map((r, j) => (
                                      <li key={j} className="flex items-start gap-1.5 text-xs text-red-700">
                                        <AlertCircle size={12} className="shrink-0 mt-0.5" /> {r}
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                            </div>

                            {/* 추천 액션 */}
                            {c.next_actions.length > 0 && (
                              <div className="bg-blue-50 border border-blue-100 rounded-xl p-3">
                                <div className="font-semibold text-blue-700 text-sm mb-2 flex items-center gap-1.5">
                                  <ArrowRight size={14} /> 권장 다음 액션
                                </div>
                                <ol className="space-y-1.5">
                                  {c.next_actions.map((a, j) => (
                                    <li key={j} className="flex items-start gap-2 text-xs text-blue-700">
                                      <span className="w-4 h-4 rounded-full bg-blue-200 text-blue-700 flex items-center justify-center font-bold shrink-0 mt-0.5 text-[10px]">
                                        {j + 1}
                                      </span>
                                      {a}
                                    </li>
                                  ))}
                                </ol>
                              </div>
                            )}

                            {/* 지역 / 등급 분포 */}
                            <div className="grid grid-cols-2 gap-3">
                              <div className="bg-white border border-gray-100 rounded-xl p-3 shadow-sm">
                                <div className="text-xs font-semibold text-gray-600 mb-2">지역 구성</div>
                                <div className="space-y-1">
                                  {Object.entries(c.region_breakdown).map(([gu, cnt]) => (
                                    <div key={gu} className="flex justify-between text-xs">
                                      <span className="text-gray-600">{gu}</span>
                                      <span className="font-bold text-gray-800">{cnt}개</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                              <div className="bg-white border border-gray-100 rounded-xl p-3 shadow-sm">
                                <div className="text-xs font-semibold text-gray-600 mb-2">SITE-C 등급 분포</div>
                                <div className="space-y-1">
                                  {Object.entries(c.grade_distribution).map(([grade, cnt]) => (
                                    <div key={grade} className="flex items-center gap-2 text-xs">
                                      <span className={`px-1.5 py-0.5 rounded font-bold ${GRADE_COLOR[grade] ?? 'bg-gray-100 text-gray-600'}`}>{grade}</span>
                                      <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                        <div className="h-full bg-blue-400 rounded-full" style={{ width: `${(cnt / c.n_sites) * 100}%` }} />
                                      </div>
                                      <span className="text-gray-500">{cnt}개</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* ── 사업지 상세 리포트 탭 ─────────── */}
                        {tab === 'detail' && (
                          <div>
                            <div className="flex items-center justify-between mb-3">
                              <div className="text-xs text-gray-500 flex items-center gap-1.5">
                                <FileText size={12} />
                                {c.n_sites}개 사업지 · 단일 사업지 수준 상세 분석
                              </div>
                              {c.site_details && c.site_details.length > 0 && (
                                <div className="text-xs text-gray-400">
                                  클릭하면 상세 정보를 확인할 수 있습니다
                                </div>
                              )}
                            </div>
                            {c.site_details && c.site_details.length > 0 ? (
                              <div className="space-y-2">
                                {c.site_details.map(sd => renderSiteDetailReport(sd))}
                              </div>
                            ) : (
                              <div className="text-xs text-gray-400 text-center py-6">
                                상세 보고서 데이터가 없습니다.
                              </div>
                            )}
                          </div>
                        )}

                        {/* ── 사업지 목록 탭 ────────────────── */}
                        {tab === 'sites' && (
                          <div>
                            <div className="text-xs text-gray-500 mb-3">
                              총 {c.sites.length}개 사업지 · {c.total_units}세대
                            </div>
                            <div className="overflow-x-auto">
                              <table className="w-full text-xs min-w-[620px]">
                                <thead>
                                  <tr className="text-gray-400 bg-gray-50">
                                    <th className="text-left py-2 px-2 rounded-l-lg">#</th>
                                    <th className="text-left py-2 px-2">사업지명</th>
                                    <th className="text-left py-2 px-2">주소</th>
                                    <th className="text-center py-2 px-2">SITE-C</th>
                                    <th className="text-center py-2 px-2">등급</th>
                                    <th className="text-right py-2 px-2">세대</th>
                                    <th className="text-right py-2 px-2">ROI</th>
                                    <th className="text-right py-2 px-2 rounded-r-lg">건축비(억)</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {c.sites.map((s, j) => (
                                    <tr key={s.id} className="border-t border-gray-100 hover:bg-gray-50">
                                      <td className="py-1.5 px-2 text-gray-400">{j+1}</td>
                                      <td className="py-1.5 px-2 font-semibold text-gray-800">{s.name}</td>
                                      <td className="py-1.5 px-2 text-gray-500 max-w-[120px] truncate">{s.address}</td>
                                      <td className="py-1.5 px-2 text-center font-black text-blue-700">
                                        {s.sitec_score?.toFixed(1) ?? '-'}
                                      </td>
                                      <td className="py-1.5 px-2 text-center">
                                        {s.sitec_grade ? (
                                          <span className={`inline-block px-1.5 py-0.5 rounded font-bold ${GRADE_COLOR[s.sitec_grade] ?? 'bg-gray-100 text-gray-600'}`}>
                                            {s.sitec_grade}
                                          </span>
                                        ) : '-'}
                                      </td>
                                      <td className="py-1.5 px-2 text-right">{s.planned_units ?? '-'}</td>
                                      <td className="py-1.5 px-2 text-right font-bold text-indigo-600">
                                        {s.roi_pct != null ? `${s.roi_pct.toFixed(1)}%` : '-'}
                                      </td>
                                      <td className="py-1.5 px-2 text-right text-gray-600">
                                        {s.estimated_cost_bn?.toFixed(1) ?? '-'}
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                                <tfoot>
                                  <tr className="bg-blue-50 font-bold text-blue-700">
                                    <td colSpan={5} className="py-2 px-2 text-right text-xs">합계</td>
                                    <td className="py-2 px-2 text-right text-xs">{c.total_units}</td>
                                    <td className="py-2 px-2 text-right text-xs">{c.cluster_roi_pct.toFixed(1)}%</td>
                                    <td className="py-2 px-2 text-right text-xs">{c.discounted_cost_bn.toFixed(1)}</td>
                                  </tr>
                                </tfoot>
                              </table>
                            </div>
                          </div>
                        )}

                        {/* ── 공정 간트 탭 ──────────────────── */}
                        {tab === 'gantt' && (
                          <div>
                            <div className="text-xs text-gray-500 mb-3 flex items-center gap-2">
                              <Clock size={12} />
                              병렬 제조 간트 · 동시 최대 300세대 생산 · 배치별 병렬 스케줄
                            </div>
                            {c.gantt.length === 0 ? (
                              <div className="text-xs text-gray-400 text-center py-6">간트 데이터 없음</div>
                            ) : (() => {
                              const gp = c.gantt_parallel
                              const schedule = gp?.schedule ?? c.gantt
                              const totalMonths = gp?.total_months ?? Math.max(...schedule.map(g => g.install_end), 1)
                              const nBatches = gp?.n_batches ?? 1
                              const batchColors = ['bg-blue-400','bg-indigo-400','bg-violet-400','bg-purple-400','bg-fuchsia-400']
                              return (
                                <div className="space-y-3">
                                  {/* 범례 */}
                                  <div className="flex flex-wrap items-center gap-3 text-xs">
                                    {Array.from({length: nBatches}, (_, i) => (
                                      <div key={i} className="flex items-center gap-1.5">
                                        <div className={`w-3 h-3 rounded ${batchColors[i % batchColors.length]}`}></div>
                                        <span className="text-gray-500">배치{i+1} 공장</span>
                                      </div>
                                    ))}
                                    <div className="flex items-center gap-1.5">
                                      <div className="w-3 h-3 rounded bg-emerald-400"></div>
                                      <span className="text-gray-500">현장 설치</span>
                                    </div>
                                    {gp?.parallel_production && (
                                      <span className="px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full text-[10px] font-bold">
                                        ⚡ 병렬 생산 (최대 {gp.factory_capacity}세대)
                                      </span>
                                    )}
                                  </div>

                                  {/* 배치 요약 (있을 경우) */}
                                  {gp?.batch_summary && gp.batch_summary.length > 1 && (
                                    <div className="bg-blue-50 border border-blue-100 rounded-lg p-2 text-xs">
                                      <div className="font-semibold text-blue-700 mb-1.5">배치별 생산 스케줄</div>
                                      <div className="grid grid-cols-3 gap-1.5">
                                        {gp.batch_summary.map(bs => (
                                          <div key={bs.batch_no} className="bg-white rounded-lg p-1.5 text-center border border-blue-100">
                                            <div className="font-black text-blue-700 text-xs">배치{bs.batch_no}</div>
                                            <div className="text-gray-500">{bs.n_sites}현장/{bs.total_units}세대</div>
                                            <div className="text-blue-500">M{bs.factory_start_month}→M{bs.install_end_month}</div>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  )}

                                  {/* 개별 현장 간트 */}
                                  {schedule.map((g) => {
                                    const batchIdx = (g.batch ?? 1) - 1
                                    const factoryColor = batchColors[batchIdx % batchColors.length]
                                    return (
                                      <div key={g.site_id} className="flex items-center gap-2">
                                        <div className="w-24 text-xs text-gray-600 truncate shrink-0 text-right">
                                          {g.batch && nBatches > 1 && (
                                            <span className={`inline-block w-4 h-4 rounded text-white text-[9px] font-black text-center leading-4 mr-1 ${batchColors[(g.batch-1) % batchColors.length]}`}>
                                              {g.batch}
                                            </span>
                                          )}
                                          {g.site_name}
                                        </div>
                                        <div className="flex-1 h-6 bg-gray-100 rounded-lg overflow-hidden relative">
                                          <div
                                            className={`absolute h-full ${factoryColor} flex items-center justify-center text-[10px] text-white font-bold`}
                                            style={{
                                              left: `${(g.factory_start / totalMonths) * 100}%`,
                                              width: `${Math.max(((g.factory_end - g.factory_start) / totalMonths) * 100, 1)}%`,
                                            }}
                                          >
                                            {g.factory_end - g.factory_start > 0 ? `${g.factory_end - g.factory_start}M` : ''}
                                          </div>
                                          <div
                                            className="absolute h-full bg-emerald-400 flex items-center justify-center text-[10px] text-white font-bold"
                                            style={{
                                              left: `${(g.install_start / totalMonths) * 100}%`,
                                              width: `${Math.max(((g.install_end - g.install_start) / totalMonths) * 100, 1)}%`,
                                            }}
                                          >
                                            {g.install_end - g.install_start > 0 ? `${g.install_end - g.install_start}M` : ''}
                                          </div>
                                        </div>
                                        <div className="text-xs text-gray-400 w-12 shrink-0">
                                          {g.modules}세대
                                        </div>
                                      </div>
                                    )
                                  })}

                                  <div className="mt-2 text-xs text-gray-400 bg-gray-50 rounded-lg p-2 flex justify-between">
                                    <span>총 {schedule.length}개 현장 · {nBatches}배치 병렬 생산</span>
                                    <span>전체 완료: {gp?.total_months ?? Math.max(...schedule.map(g => g.install_end))}개월 예상</span>
                                  </div>
                                </div>
                              )
                            })()}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>

          {/* ── 미배정 사업지 ────────────────────────── */}
          {result.unclustered_count > 0 && (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
              <div className="flex items-center gap-2 text-slate-600 font-semibold text-sm mb-2">
                <AlertCircle size={15} />
                클러스터 미포함 사업지 {result.unclustered_count}개
              </div>
              <p className="text-xs text-slate-400 mb-3">
                반경 {radiusKm}km 내에 세대 목표 범위({minUnits}~{maxUnits}세대)를 충족하는 인접 사업지 부족
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {result.unclustered.map(s => (
                  <div key={s.id} className="bg-white border border-slate-100 rounded-lg p-2 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-semibold text-gray-700">{s.name}</div>
                      <div className="text-gray-400 truncate max-w-[180px]">{s.address}</div>
                    </div>
                    <div className="text-right">
                      {s.sitec_grade && (
                        <span className={`px-1.5 py-0.5 rounded font-bold ${GRADE_COLOR[s.sitec_grade] ?? 'bg-gray-100 text-gray-600'}`}>
                          {s.sitec_grade}
                        </span>
                      )}
                      <div className="text-gray-400 mt-0.5">{s.planned_units ?? '-'}세대</div>
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-xs text-slate-400 mt-2">
                💡 반경을 늘리거나 최소 세대 수를 낮추면 추가 클러스터 구성이 가능합니다.
              </p>
            </div>
          )}

        </div>
      )}


      {/* ══════════════════════════════════════════════
          ILP 포트폴리오 최적화 섹션
          ══════════════════════════════════════════════ */}
      <div className="mt-8 bg-white rounded-2xl border border-indigo-200 shadow-sm overflow-hidden">
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center">
                <Target size={20} className="text-white" />
              </div>
              <div>
                <h2 className="text-white font-bold text-lg">포트폴리오 최적화 (ILP)</h2>
                <p className="text-indigo-200 text-xs">예산·세대수·ROI 제약 기반 최적 클러스터 조합 자동 추천</p>
              </div>
            </div>
            <button
              onClick={loadPortfolioSessions}
              className="text-xs text-white/70 hover:text-white flex items-center gap-1 px-3 py-1.5 bg-white/10 rounded-lg"
            >
              <RefreshCw size={12} /> 세션 불러오기
            </button>
          </div>
        </div>

        <div className="p-6">
          {/* 제약 조건 설정 패널 */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">

            {/* 총 예산 */}
            <div className="bg-gray-50 rounded-xl p-4">
              <label className="block text-xs font-semibold text-gray-500 mb-2 flex items-center gap-1">
                <DollarSign size={12} /> 총 투자 예산 (억원)
              </label>
              <input
                type="number"
                value={portfolioBudget}
                onChange={e => setPortfolioBudget(Number(e.target.value))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm font-bold text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-300"
                min={100} step={100}
              />
              <div className="flex gap-1 mt-2">
                {[1000, 3000, 5000, 10000].map(v => (
                  <button key={v} onClick={() => setPortfolioBudget(v)}
                    className={`flex-1 text-xs py-1 rounded-lg font-medium transition-colors ${portfolioBudget === v ? 'bg-indigo-500 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-indigo-300'}`}>
                    {v >= 10000 ? '1조' : `${v}억`}
                  </button>
                ))}
              </div>
            </div>

            {/* 연간 최대 세대수 */}
            <div className="bg-gray-50 rounded-xl p-4">
              <label className="block text-xs font-semibold text-gray-500 mb-2 flex items-center gap-1">
                <Building size={12} /> 연간 최대 착수 세대수
              </label>
              <input
                type="number"
                value={portfolioMaxUnits}
                onChange={e => setPortfolioMaxUnits(Number(e.target.value))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm font-bold text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-300"
                min={500} step={500}
              />
              <div className="flex gap-1 mt-2">
                {[2000, 3000, 5000, 10000].map(v => (
                  <button key={v} onClick={() => setPortfolioMaxUnits(v)}
                    className={`flex-1 text-xs py-1 rounded-lg font-medium transition-colors ${portfolioMaxUnits === v ? 'bg-indigo-500 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-indigo-300'}`}>
                    {v.toLocaleString()}
                  </button>
                ))}
              </div>
            </div>

            {/* 최소 ROI */}
            <div className="bg-gray-50 rounded-xl p-4">
              <label className="block text-xs font-semibold text-gray-500 mb-2 flex items-center gap-1">
                <Percent size={12} /> 최소 클러스터 ROI (%)
              </label>
              <input
                type="number"
                value={portfolioMinRoi}
                onChange={e => setPortfolioMinRoi(Number(e.target.value))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm font-bold text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-300"
                min={0} max={200} step={5}
              />
              <div className="flex gap-1 mt-2">
                {[30, 50, 80, 100].map(v => (
                  <button key={v} onClick={() => setPortfolioMinRoi(v)}
                    className={`flex-1 text-xs py-1 rounded-lg font-medium transition-colors ${portfolioMinRoi === v ? 'bg-indigo-500 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-indigo-300'}`}>
                    {v}%
                  </button>
                ))}
              </div>
            </div>

            {/* 동시 착수 클러스터 수 */}
            <div className="bg-gray-50 rounded-xl p-4">
              <label className="block text-xs font-semibold text-gray-500 mb-2 flex items-center gap-1">
                <Layers size={12} /> 동시 착수 최대 클러스터 수
              </label>
              <input
                type="number"
                value={portfolioMaxParallel}
                onChange={e => setPortfolioMaxParallel(Number(e.target.value))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm font-bold text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-300"
                min={1} max={20}
              />
              <div className="flex gap-1 mt-2">
                {[3, 5, 8, 10].map(v => (
                  <button key={v} onClick={() => setPortfolioMaxParallel(v)}
                    className={`flex-1 text-xs py-1 rounded-lg font-medium transition-colors ${portfolioMaxParallel === v ? 'bg-indigo-500 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-indigo-300'}`}>
                    {v}개
                  </button>
                ))}
              </div>
            </div>

            {/* 최적화 목표 */}
            <div className="bg-gray-50 rounded-xl p-4">
              <label className="block text-xs font-semibold text-gray-500 mb-2 flex items-center gap-1">
                <TrendingUp size={12} /> 최적화 목표
              </label>
              <div className="flex flex-col gap-2 mt-1">
                {([
                  { value: 'maximize_roi',    label: 'ROI 최대화',   desc: '수익률 극대화' },
                  { value: 'maximize_profit', label: '수익 최대화',  desc: '절대 이익 극대화' },
                  { value: 'maximize_units',  label: '세대수 최대화', desc: 'LH 공급 극대화' },
                ] as const).map(opt => (
                  <label key={opt.value} className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer border transition-colors ${portfolioObjective === opt.value ? 'border-indigo-400 bg-indigo-50' : 'border-gray-200 bg-white hover:border-indigo-200'}`}>
                    <input type="radio" name="objective" value={opt.value}
                      checked={portfolioObjective === opt.value}
                      onChange={() => setPortfolioObjective(opt.value)}
                      className="accent-indigo-600" />
                    <div>
                      <div className="text-xs font-semibold text-gray-800">{opt.label}</div>
                      <div className="text-[10px] text-gray-400">{opt.desc}</div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* 세션/고급 설정 */}
            <div className="bg-gray-50 rounded-xl p-4">
              <label className="block text-xs font-semibold text-gray-500 mb-2 flex items-center gap-1">
                <Database size={12} /> 세션 및 고급 설정
              </label>
              <div className="space-y-2">
                {portfolioSessions.length > 0 && (
                  <select
                    value={portfolioSessionId}
                    onChange={e => setPortfolioSessionId(e.target.value)}
                    className="w-full border border-gray-200 rounded-lg px-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-300"
                  >
                    <option value="">전체 보고서 사용</option>
                    {portfolioSessions.map(s => (
                      <option key={s.analysis_session} value={s.analysis_session}>
                        {s.analysis_session.slice(0,8)} · {s.n_clusters}클러스터 · avg ROI {s.avg_roi?.toFixed(1)}%
                      </option>
                    ))}
                  </select>
                )}
                <input
                  type="text"
                  placeholder="반드시 포함할 클러스터 ID (쉼표 구분, 예: 147,148)"
                  value={portfolioMustIds}
                  onChange={e => setPortfolioMustIds(e.target.value)}
                  className="w-full border border-gray-200 rounded-lg px-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-300"
                />
                <input
                  type="text"
                  placeholder="제외할 클러스터 ID (쉼표 구분)"
                  value={portfolioExcludeIds}
                  onChange={e => setPortfolioExcludeIds(e.target.value)}
                  className="w-full border border-gray-200 rounded-lg px-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-300"
                />
              </div>
            </div>
          </div>

          {/* 실행 버튼 */}
          <button
            onClick={runPortfolioOptimization}
            disabled={portfolioLoading}
            className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold rounded-xl hover:from-indigo-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-base shadow-md"
          >
            {portfolioLoading ? (
              <><Loader2 size={18} className="animate-spin" /> 포트폴리오 최적화 계산 중...</>
            ) : (
              <><Zap size={18} /> 포트폴리오 최적화 실행</>
            )}
          </button>

          {/* 에러 */}
          {portfolioError && (
            <div className="mt-4 bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-2">
              <AlertCircle size={16} className="text-red-500 mt-0.5 shrink-0" />
              <p className="text-sm text-red-700">{portfolioError}</p>
            </div>
          )}

          {/* 결과 */}
          {portfolioResult && (
            <div className="mt-6 space-y-5">

              {/* KPI 카드 */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="bg-indigo-50 rounded-xl p-4 text-center">
                  <div className="text-2xl font-black text-indigo-700">{portfolioResult.n_clusters_selected}</div>
                  <div className="text-xs text-indigo-500 mt-0.5">선택 클러스터</div>
                  <div className="text-[10px] text-indigo-400">전체 {portfolioResult.n_clusters_total}개 중</div>
                </div>
                <div className="bg-emerald-50 rounded-xl p-4 text-center">
                  <div className="text-2xl font-black text-emerald-700">{portfolioResult.portfolio_roi_pct.toFixed(1)}%</div>
                  <div className="text-xs text-emerald-500 mt-0.5">포트폴리오 ROI</div>
                  <div className="text-[10px] text-emerald-400">가중 평균</div>
                </div>
                <div className="bg-blue-50 rounded-xl p-4 text-center">
                  <div className="text-2xl font-black text-blue-700">{portfolioResult.total_investment_bn.toFixed(0)}억</div>
                  <div className="text-xs text-blue-500 mt-0.5">총 투자금액</div>
                  <div className="text-[10px] text-blue-400">예산 {portfolioResult.budget_utilization_pct.toFixed(1)}% 사용</div>
                </div>
                <div className="bg-purple-50 rounded-xl p-4 text-center">
                  <div className="text-2xl font-black text-purple-700">{portfolioResult.total_profit_bn.toFixed(0)}억</div>
                  <div className="text-xs text-purple-500 mt-0.5">예상 총 수익</div>
                  <div className="text-[10px] text-purple-400">{portfolioResult.total_units.toLocaleString()}세대</div>
                </div>
              </div>

              {/* 실행 요약 */}
              <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4">
                <p className="text-sm text-indigo-800 font-medium">{portfolioResult.execution_summary}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">
                    알고리즘: {portfolioResult.optimization_method}
                  </span>
                  <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">
                    총 {portfolioResult.total_sites}개 사업지
                  </span>
                  <button
                    onClick={downloadPortfolioCSV}
                    className="text-xs bg-white border border-indigo-300 text-indigo-600 px-3 py-0.5 rounded-full hover:bg-indigo-50 flex items-center gap-1"
                  >
                    <Download size={10} /> CSV 다운로드
                  </button>
                </div>
              </div>

              {/* 선택된 클러스터 목록 */}
              <div>
                <h3 className="text-sm font-bold text-gray-800 mb-3 flex items-center gap-2">
                  <CheckCircle size={15} className="text-emerald-500" />
                  선택된 클러스터 ({portfolioResult.n_clusters_selected}개)
                </h3>
                <div className="space-y-3">
                  {portfolioResult.selected_clusters.map((c, idx) => (
                    <div key={c.cluster_id} className="bg-gradient-to-r from-emerald-50 to-green-50 border border-emerald-200 rounded-xl p-4">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <div className="w-7 h-7 bg-emerald-500 text-white rounded-full flex items-center justify-center text-xs font-black shrink-0">
                            {idx + 1}
                          </div>
                          <div className="min-w-0">
                            <div className="font-semibold text-gray-800 text-sm truncate">{c.cluster_name}</div>
                            <div className="text-xs text-emerald-600 mt-0.5">{c.selection_reason}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${GRADE_COLOR[c.best_grade] ?? 'bg-gray-100 text-gray-600'}`}>
                            {c.best_grade}
                          </span>
                          <span className="text-xs font-black text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                            ROI {c.cluster_roi_pct.toFixed(1)}%
                          </span>
                        </div>
                      </div>
                      <div className="mt-3 grid grid-cols-4 gap-2 text-xs">
                        <div className="bg-white rounded-lg p-2 text-center">
                          <div className="font-bold text-gray-800">{c.total_units}</div>
                          <div className="text-gray-400">세대수</div>
                        </div>
                        <div className="bg-white rounded-lg p-2 text-center">
                          <div className="font-bold text-blue-700">{c.discounted_cost_bn.toFixed(0)}억</div>
                          <div className="text-gray-400">투자비</div>
                        </div>
                        <div className="bg-white rounded-lg p-2 text-center">
                          <div className="font-bold text-purple-700">{c.profit_bn.toFixed(0)}억</div>
                          <div className="text-gray-400">수익</div>
                        </div>
                        <div className="bg-white rounded-lg p-2 text-center">
                          <div className="font-bold text-amber-700">{c.discount_pct.toFixed(1)}%</div>
                          <div className="text-gray-400">할인율</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 착수 간트 계획 */}
              {portfolioResult.gantt_phases.length > 0 && (
                <div>
                  <button
                    onClick={() => setShowGanttPhases(v => !v)}
                    className="w-full flex items-center justify-between text-sm font-bold text-gray-800 bg-gray-50 rounded-xl px-4 py-3 hover:bg-gray-100"
                  >
                    <span className="flex items-center gap-2"><Clock size={14} className="text-blue-500" /> 착수 순서 계획 ({portfolioResult.gantt_phases.length}단계)</span>
                    {showGanttPhases ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                  </button>
                  {showGanttPhases && (
                    <div className="mt-3 space-y-2">
                      {(() => {
                        const totalMonths = Math.max(...portfolioResult.gantt_phases.map(p => p.end_month), 1)
                        const phaseColors = ['bg-indigo-400','bg-purple-400','bg-blue-400','bg-violet-400','bg-sky-400','bg-fuchsia-400','bg-cyan-400','bg-pink-400']
                        return portfolioResult.gantt_phases.map((phase, idx) => (
                          <div key={phase.phase_no} className="flex items-center gap-3">
                            <div className="text-xs text-gray-500 w-24 shrink-0 text-right">
                              {phase.cluster_name.slice(0, 10)}
                            </div>
                            <div className="flex-1 h-7 bg-gray-100 rounded-lg relative overflow-hidden">
                              <div
                                className={`absolute h-full ${phaseColors[idx % phaseColors.length]} flex items-center px-2 text-[10px] text-white font-bold rounded-lg`}
                                style={{
                                  left: `${(phase.start_month / totalMonths) * 100}%`,
                                  width: `${Math.max(((phase.end_month - phase.start_month) / totalMonths) * 100, 3)}%`,
                                }}
                              >
                                {phase.duration_months}M
                              </div>
                            </div>
                            <div className="text-xs text-gray-500 w-20 shrink-0">
                              ROI {phase.roi_pct.toFixed(0)}%
                            </div>
                          </div>
                        ))
                      })()}
                      <div className="text-xs text-gray-400 text-right mt-1">
                        전체 완료: {Math.max(...portfolioResult.gantt_phases.map(p => p.end_month))}개월 예상
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* 민감도 분석 */}
              {(portfolioResult.sensitivity.budget_increase_10pct.length > 0 ||
                portfolioResult.sensitivity.roi_relax_10pct.length > 0) && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                  <h4 className="text-sm font-bold text-amber-800 mb-3 flex items-center gap-2">
                    <Activity size={14} /> 민감도 분석 (추가 최적화 여지)
                  </h4>
                  {portfolioResult.sensitivity.budget_increase_10pct.length > 0 && (
                    <div className="mb-3">
                      <p className="text-xs font-semibold text-amber-700 mb-1.5">💰 예산 10% 증가 시 추가 선택 가능</p>
                      <div className="space-y-1">
                        {portfolioResult.sensitivity.budget_increase_10pct.map(s => (
                          <div key={s.cluster_id} className="flex items-center justify-between text-xs bg-white rounded-lg px-3 py-1.5">
                            <span className="text-gray-700 font-medium">{s.cluster_name}</span>
                            <span className="text-amber-700 font-bold">ROI {s.roi_pct.toFixed(1)}% · {s.cost_bn.toFixed(0)}억 · {s.units}세대</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {portfolioResult.sensitivity.roi_relax_10pct.length > 0 && (
                    <div>
                      <p className="text-xs font-semibold text-amber-700 mb-1.5">📊 ROI 기준 10% 완화 시 추가 후보</p>
                      <div className="space-y-1">
                        {portfolioResult.sensitivity.roi_relax_10pct.slice(0,3).map(s => (
                          <div key={s.cluster_id} className="flex items-center justify-between text-xs bg-white rounded-lg px-3 py-1.5">
                            <span className="text-gray-700 font-medium">{s.cluster_name}</span>
                            <span className="text-amber-700 font-bold">ROI {s.roi_pct.toFixed(1)}% · {s.cost_bn.toFixed(0)}억</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* 미선택 클러스터 (토글) */}
              {portfolioResult.not_selected_clusters.length > 0 && (
                <div>
                  <button
                    onClick={() => setShowNotSelected(v => !v)}
                    className="w-full flex items-center justify-between text-xs font-semibold text-gray-500 bg-gray-50 rounded-xl px-4 py-2.5 hover:bg-gray-100"
                  >
                    <span className="flex items-center gap-1.5">
                      <AlertTriangle size={12} className="text-amber-400" />
                      미선택 클러스터 ({portfolioResult.not_selected_clusters.length}개) — 제외 사유 보기
                    </span>
                    {showNotSelected ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                  </button>
                  {showNotSelected && (
                    <div className="mt-2 space-y-1.5">
                      {portfolioResult.not_selected_clusters.map(c => (
                        <div key={c.cluster_id} className="flex items-center justify-between bg-gray-50 border border-gray-100 rounded-lg px-3 py-2 text-xs">
                          <div className="flex items-center gap-2 min-w-0">
                            <span className={`px-1.5 py-0.5 rounded font-bold shrink-0 ${GRADE_COLOR[c.best_grade] ?? 'bg-gray-100 text-gray-600'}`}>{c.best_grade}</span>
                            <span className="font-medium text-gray-700 truncate">{c.cluster_name}</span>
                            <span className="text-gray-400 shrink-0">ROI {c.cluster_roi_pct.toFixed(1)}%</span>
                          </div>
                          <span className="text-gray-400 shrink-0 ml-2 max-w-[200px] text-right">{c.selection_reason}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

            </div>
          )}

        </div>
      </div>

      {/* ── 초기 안내 ────────────────────────────────── */}
      {!result && !loading && !error && (
        <div className="card text-center py-16 text-gray-400">
          <Layers size={44} className="mx-auto mb-3 opacity-20" />
          <p className="font-semibold text-gray-600">스마트 클러스터 결과가 없습니다</p>
          <p className="text-sm mt-1">반경과 세대 범위를 설정하고 최적화를 시작하세요</p>
          <div className="mt-4 grid grid-cols-3 gap-4 max-w-sm mx-auto text-xs">
            <div className="bg-blue-50 rounded-xl p-3">
              <Map size={20} className="mx-auto text-blue-400 mb-1" />
              <div className="font-medium text-blue-600">지리적 반경</div>
              <div className="text-blue-400">3/5/10km 선택</div>
            </div>
            <div className="bg-indigo-50 rounded-xl p-3">
              <Target size={20} className="mx-auto text-indigo-400 mb-1" />
              <div className="font-medium text-indigo-600">세대 목표</div>
              <div className="text-indigo-400">500~1000세대</div>
            </div>
            <div className="bg-emerald-50 rounded-xl p-3">
              <Percent size={20} className="mx-auto text-emerald-400 mb-1" />
              <div className="font-medium text-emerald-600">자동 할인</div>
              <div className="text-emerald-400">최대 22% 절감</div>
            </div>
          </div>
          <p className="text-xs mt-4 text-gray-300">대규모 검토에서 사업지를 먼저 등록하세요</p>
        </div>
      )}
    </div>
  )
}
