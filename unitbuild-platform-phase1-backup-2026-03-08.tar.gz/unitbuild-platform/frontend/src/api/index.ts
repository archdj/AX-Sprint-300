import axios from 'axios'

const api = axios.create({
  baseURL: '/api/v1',
  headers: { 'Content-Type': 'application/json' },
  timeout: 30000,
})

// ─── 타입 정의 ───────────────────────────────────────
export interface SiteCInput {
  cbd_distance_km: number
  subway_distance_m: number
  bus_stop_distance_m: number
  elementary_school_distance_m: number
  hospital_distance_m: number
  mart_distance_m: number
  planned_units: number
  small_unit_ratio: number
  seismic_grade: number
  slope_percent: number
  energy_efficiency_grade: number
  sunshine_hours: number
  is_modular: boolean
  long_term_rental: boolean
  lh_certified: boolean
}

export interface SiteCResult {
  total_score: number
  grade: 'A' | 'B' | 'C' | '탈락'
  approval_probability: number
  breakdown: Record<string, number>
  improvement_suggestions: string[]
  transportation_score: number
  infrastructure_score: number
  scale_score: number
  structure_score: number
  energy_score: number
  bonus_score: number
}

export interface HazardResult {
  hazard_type: string
  hazard_label: string
  is_compliant: boolean
  nearest_distance_m: number | null
  required_distance_m: number
  nearest_facility_name: string
  improvement: string
}

export interface HazardReport {
  site_lat: number
  site_lng: number
  overall_compliant: boolean
  risk_level: 'SAFE' | 'WARNING' | 'DANGER'
  compliant_count: number
  non_compliant_count: number
  verification_timestamp: string
  data_source: string
  results: HazardResult[]
}

export interface ForecastMonth {
  month: string
  demand_score: number
  estimated_units: number
  confidence_low: number
  confidence_high: number
}

export interface DemandResult {
  lat: number
  lng: number
  region_name: string
  demand_score: number
  recommended_units: number
  confidence: number
  hierarchy: {
    sigungu_score: number
    emd_score: number
    parcel_score: number
  }
  forecast_monthly: ForecastMonth[]
  risk_factors: string[]
  model_version: string
  predicted_at: string
}

export interface SiteCreate {
  name: string
  address: string
  lat: number
  lng: number
  planned_units?: number
  small_unit_ratio?: number
  is_modular?: boolean
  cbd_distance_km?: number
  subway_distance_m?: number
  bus_stop_distance_m?: number
  elementary_school_distance_m?: number
  hospital_distance_m?: number
  mart_distance_m?: number
  seismic_grade?: number
  slope_percent?: number
  energy_efficiency_grade?: number
  sunshine_hours?: number
  long_term_rental?: boolean
  lh_certified?: boolean
}

export interface SiteResponse {
  id: number
  name: string
  address: string
  lat: number
  lng: number
  planned_units: number | null
  sitec_score: number | null
  sitec_grade: string | null
  sitec_approval_prob: number | null
  hazard_compliant: boolean | null
  hazard_risk_level: string | null
  demand_score: number | null
  expected_margin: number | null
  status: string
  is_modular: boolean
  created_at: string | null
}

export interface SiteDetailResponse extends SiteResponse {
  pnu?: string | null
  land_area_m2?: number | null
  small_unit_ratio?: number | null
  floor_count?: number | null
  recommended_units?: number | null
  lh_purchase_price?: number | null
  estimated_cost?: number | null
  sitec_breakdown?: Record<string, number> | null
  sitec_suggestions?: string[] | null
  cbd_distance_km?: number | null
  subway_distance_m?: number | null
  bus_stop_distance_m?: number | null
  elementary_school_distance_m?: number | null
  hospital_distance_m?: number | null
  mart_distance_m?: number | null
  seismic_grade?: number | null
  slope_percent?: number | null
  energy_efficiency_grade?: number | null
  sunshine_hours?: number | null
  long_term_rental?: boolean | null
  lh_certified?: boolean | null
  hazard_report?: any
  notes?: string | null
}

export interface AISummary {
  site_id: number
  summary: {
    verdict: string
    verdict_desc: string
    verdict_color: string
    grade: string
    score: number
    approval_prob: number
    location_points: string[]
    location_risks: string[]
    module_analysis: string
    financial_analysis: string
    safety_notes: string[]
    recommended_actions: string[]
  }
  generated_at: string
}

// ─── API 함수 ───────────────────────────────────────

export const sitecAPI = {
  evaluate: (input: SiteCInput) =>
    api.post<SiteCResult>('/sitec/evaluate', input).then(r => r.data),
  
  getWeights: () =>
    api.get('/sitec/weights').then(r => r.data),
  
  simulate: (payload: { base_criteria: SiteCInput; changes: Record<string, number | boolean> }) =>
    api.post('/sitec/simulate', payload).then(r => r.data),
}

export const hazardAPI = {
  verify: (lat: number, lng: number, radius_m = 500) =>
    api.post<HazardReport>(`/hazard/verify?lat=${lat}&lng=${lng}&radius_m=${radius_m}`)
       .then(r => r.data),
  
  getRules: () =>
    api.get('/hazard/rules').then(r => r.data),
}

export const demandAPI = {
  predict: (lat: number, lng: number, radius_m = 1000) =>
    api.post<DemandResult>(`/demand/predict?lat=${lat}&lng=${lng}&radius_m=${radius_m}`)
       .then(r => r.data),
}

export const sitesAPI = {
  list: () => api.get<SiteResponse[]>('/sites/').then(r => r.data),
  create: (data: SiteCreate) => api.post<SiteResponse>('/sites/', data).then(r => r.data),
  get: (id: number) => api.get<SiteDetailResponse>(`/sites/${id}`).then(r => r.data),
  delete: (id: number) => api.delete(`/sites/${id}`),
  evaluate: (id: number) => api.post<SiteResponse>(`/sites/${id}/evaluate`).then(r => r.data),
  aiSummary: (id: number) => api.get<AISummary>(`/sites/${id}/ai-summary`).then(r => r.data),
}

// ─── VWorld API (브라우저 직접 호출) ──────────────────────
// VWorld는 등록된 도메인(브라우저 Origin)에서만 동작합니다.
// 서버사이드 호출은 해외 IP 차단으로 불가 → 브라우저에서 직접 호출 후 백엔드로 전달

const VWORLD_KEY = '0F9773C6-F395-3084-ADDE-5BD59A71D4C1'
const VWORLD_BASE = 'https://api.vworld.kr'

export interface VWorldGeoResult {
  lat: number
  lng: number
  address_parcel: string
  address_road: string
  pnu?: string
  source: 'vworld'
}

export interface VWorldLandInfo {
  area_m2: number
  land_category: string
  land_category_code: string
  pnu: string
}

export interface VWorldLandChar {
  zone_name: string
  zone_name2: string
  road_side: string
  land_use: string
}

export const vworldAPI = {
  /**
   * VWorld 주소→좌표 변환 (브라우저에서 직접 호출)
   * 브라우저가 자동으로 Origin 헤더를 추가하여 VWorld 도메인 인증 통과
   */
  geocode: async (address: string, addrType: 'PARCEL' | 'ROAD' = 'PARCEL'): Promise<VWorldGeoResult | null> => {
    try {
      const params = new URLSearchParams({
        service: 'address',
        version: '2.0',
        request: 'GetCoord',
        format: 'json',
        key: VWORLD_KEY,
        address,
        type: addrType,
        crs: 'epsg:4326',
      })
      const resp = await fetch(`${VWORLD_BASE}/req/address?${params}`)
      if (!resp.ok) return null
      const data = await resp.json()
      const response = data?.response
      if (response?.status !== 'OK') return null
      const point = response?.result?.point
      if (!point?.x || !point?.y) return null
      return {
        lat: parseFloat(point.y),
        lng: parseFloat(point.x),
        address_parcel: response?.result?.refined?.text || address,
        address_road: '',
        source: 'vworld',
      }
    } catch (e) {
      console.warn('[VWorld] geocode 오류:', e)
      return null
    }
  },

  /**
   * VWorld 토지임야정보 (면적, 지목) — PNU 필요
   */
  getLandInfo: async (pnu: string): Promise<VWorldLandInfo | null> => {
    try {
      const params = new URLSearchParams({
        format: 'json',
        key: VWORLD_KEY,
        pnu,
        numOfRows: '1',
      })
      const resp = await fetch(`${VWORLD_BASE}/ned/data/ladfrlList?${params}`)
      if (!resp.ok) return null
      const data = await resp.json()
      const voRoot = data?.ladfrlVOList
      // NED는 오류 시 error 필드에 'INCORRECT_KEY' 등 문자열 반환
      if (voRoot?.error && voRoot.error !== '') {
        console.warn('[VWorld] getLandInfo NED 오류:', voRoot.error)
        return null
      }
      const totalCount = parseInt(voRoot?.totalCount || '0')
      if (totalCount === 0) return null
      const items = voRoot?.ladfrlVOList
      const item = Array.isArray(items) ? items[0] : items
      if (!item) return null
      return {
        area_m2: parseFloat(item.lndpclAr || '0'),
        land_category: item.lndcgrCodeNm || '대',
        land_category_code: item.lndcgrCode || '08',
        pnu,
      }
    } catch (e) {
      console.warn('[VWorld] getLandInfo 오류:', e)
      return null
    }
  },

  /**
   * VWorld 토지특성정보 (용도지역, 도로접면) — PNU 필요
   */
  getLandChar: async (pnu: string): Promise<VWorldLandChar | null> => {
    try {
      const currentYear = new Date().getFullYear()
      const params = new URLSearchParams({
        format: 'json',
        key: VWORLD_KEY,
        pnu,
        stdrYear: String(currentYear - 1),
        numOfRows: '5',
      })
      const resp = await fetch(`${VWORLD_BASE}/ned/data/getLandCharacteristics?${params}`)
      if (!resp.ok) return null
      const data = await resp.json()
      const lcRoot = data?.landCharacteristicss
      if (lcRoot?.resultCode && lcRoot.resultCode !== 'OK' && lcRoot.resultCode !== '') {
        console.warn('[VWorld] getLandChar NED 오류:', lcRoot.resultCode, lcRoot.resultMsg)
        return null
      }
      const totalCount = parseInt(lcRoot?.totalCount || '0')
      if (totalCount === 0) return null
      const fieldList = lcRoot?.landCharacteristics
      const items = Array.isArray(fieldList) ? fieldList : [fieldList]
      if (!items[0]) return null
      const item = items.sort((a: any, b: any) =>
        (b.lastUpdtDt || '').localeCompare(a.lastUpdtDt || '')
      )[0]
      return {
        zone_name: item.prposArea1Nm || item.prposArea1 || '',
        zone_name2: item.prposArea2Nm || item.prposArea2 || '',
        road_side: item.roadSideCodeNm || '',
        land_use: item.lndcgrCodeNm || '',
      }
    } catch (e) {
      console.warn('[VWorld] getLandChar 오류:', e)
      return null
    }
  },

  /**
   * VWorld 전체 필지 조회 (geocode → landInfo + landChar 병렬)
   * PNU는 Kakao API로 사전 취득한 값을 사용
   */
  enrichParcel: async (address: string, pnu: string): Promise<{
    geo: VWorldGeoResult | null
    landInfo: VWorldLandInfo | null
    landChar: VWorldLandChar | null
    success: boolean
  }> => {
    const [geo, landInfo, landChar] = await Promise.all([
      vworldAPI.geocode(address, 'PARCEL'),
      pnu ? vworldAPI.getLandInfo(pnu) : Promise.resolve(null),
      pnu ? vworldAPI.getLandChar(pnu) : Promise.resolve(null),
    ])
    return {
      geo,
      landInfo,
      landChar,
      success: !!(geo || landInfo || landChar),
    }
  },

  /**
   * VWorld 조회결과를 백엔드로 전달 (SITE-C 평가 보완용)
   */
  sendEnrichToBackend: async (enrichData: {
    pnu: string
    area_m2?: number
    land_category?: string
    zone_name?: string
    zone_name2?: string
    road_side?: string
    lat?: number
    lng?: number
    address_parcel?: string
  }) => {
    try {
      const resp = await api.post('/parcel/vworld-enrich', {
        ...enrichData,
        source: 'vworld_browser',
      })
      return resp.data
    } catch (e) {
      console.warn('[VWorld] enrich 전송 오류:', e)
      return null
    }
  },
}

export default api
