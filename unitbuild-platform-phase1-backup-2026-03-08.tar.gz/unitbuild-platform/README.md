# 🏗️ UnitBuild Platform

**LH 신축매입약정 연동 모듈러 사업지 자동평가 플랫폼**

> 유닛랩(UnitLab)의 모듈러 건축 사업지를 LH 심의 기준으로 자동 정량화하여  
> 포트폴리오 최적화 및 수익성 분석을 일원화하는 풀스택 플랫폼

---

## 🌐 실행 URL (샌드박스)

| 서비스 | URL |
|--------|-----|
| **Frontend** | https://3000-i967v25ztibzlwrrih4rw-3844e1b6.sandbox.novita.ai |
| **Backend API** | https://8000-i967v25ztibzlwrrih4rw-3844e1b6.sandbox.novita.ai |
| **API Docs (Swagger)** | https://8000-i967v25ztibzlwrrih4rw-3844e1b6.sandbox.novita.ai/docs |

---

## ✅ Phase 1 구현 완료 기능

### 1. SITE-C 자동 평가 엔진
LH 신축매입약정 심의 기준을 정량화한 핵심 엔진

| 항목 | 가중치 | 세부 기준 |
|------|--------|-----------|
| A. 교통 접근성 | 25% | CBD 거리, 지하철 역세권, 버스정류장 |
| B. 생활 인프라 | 20% | 초등학교, 병원, 마트/편의점 |
| C. 사업 규모 | 20% | 세대수, 전용60㎡이하 비율 |
| D. 구조·안전 | 15% | 내진등급, 경사도 |
| E. 에너지·환경 | 10% | 에너지효율등급, 일조시간 |
| F. 사업자 가점 | 10% | 모듈러 공법, 장기임대, LH 인증 |

**등급 기준**
- 🟢 A등급 (≥80점): LH 심의 통과 확률 90%+
- 🔵 B등급 (65~79점): 75%
- 🟡 C등급 (50~64점): 50%
- 🔴 탈락 (<50점): 10%

### 2. GPS·GIS 위해시설 자동 검증
| 위해시설 | 이격거리 기준 |
|---------|--------------|
| 주유소·LPG충전소 | 25m 이상 |
| 고압선 철탑 | 30m 이상 |
| 공장·창고 | 50m 이상 |
| 유해업소 | 200m 이상 |
| 소각장·납골당 | 300m 이상 |

> Phase 1: Mock 데이터 / Phase 2: 브이월드+카카오맵 API 실제 연동

### 3. AI 수요 예측 (시뮬레이션)
- 좌표 기반 지역 분류 (서울도심/수도권/지방)
- 계층적 예측: 시군구 → 읍면동 → 필지
- 12개월 수요 예측 시계열
- 리스크 요인 자동 도출

> Phase 2: LH OpenAPI + 통계청 + 실거래가 + LSTM/Transformer 모델

### 4. ILP 클러스터 포트폴리오 최적화
- PuLP 기반 정수선형계획법
- 제약조건: 투자자본, 공장 CAPA, 최소 모듈 수, 동시 진행 현장
- 공장-현장 통합 간트 일정 자동 생성
- 민감도 분석

### 5. 시나리오 시뮬레이션
- 변경 전/후 SITE-C 점수 비교
- 등급 변경 여부 자동 판정

---

## 🔧 API 엔드포인트

```
POST /api/v1/sitec/evaluate          # SITE-C 단일 평가
POST /api/v1/sitec/batch-evaluate    # 배치 평가 (최대 50개)
POST /api/v1/sitec/simulate          # 시나리오 시뮬레이션
GET  /api/v1/sitec/weights           # 가중치 체계 조회

POST /api/v1/hazard/verify           # 위해시설 자동 검증
GET  /api/v1/hazard/rules            # 위해시설 기준 조회

POST /api/v1/demand/predict          # AI 수요 예측

GET  /api/v1/sites/                  # 사업지 목록
POST /api/v1/sites/                  # 사업지 등록
GET  /api/v1/sites/{id}              # 사업지 상세
POST /api/v1/sites/{id}/evaluate     # 저장 사업지 SITE-C 평가

POST /api/v1/clusters/optimize       # ILP 포트폴리오 최적화
POST /api/v1/clusters/               # 클러스터 저장
GET  /api/v1/clusters/{id}/gantt     # 간트 일정 조회
```

---

## 📁 프로젝트 구조

```
unitbuild-platform/
├── backend/
│   ├── app/
│   │   ├── main.py                    # FastAPI 앱
│   │   ├── core/                      # 설정, DB, 보안
│   │   ├── models/                    # SQLAlchemy 모델
│   │   ├── schemas/                   # Pydantic 스키마
│   │   ├── api/v1/                    # API 라우터
│   │   └── services/                  # 핵심 서비스
│   │       ├── sitec_engine.py        # SITE-C 평가 엔진 ✅
│   │       ├── hazard_verifier.py     # 위해시설 검증 ✅
│   │       ├── demand_predictor.py    # AI 수요예측 ✅
│   │       └── cluster_optimizer.py  # ILP 최적화 ✅
│   └── requirements.txt
├── frontend/
│   └── src/
│       ├── pages/
│       │   ├── Dashboard.tsx          # 메인 대시보드 ✅
│       │   ├── SiteEvaluator.tsx      # 사업지 평가 ✅
│       │   └── PortfolioOptimizer.tsx # 포트폴리오 최적화 ✅
│       └── api/index.ts               # API 클라이언트
└── docker-compose.yml
```

---

## 🛢️ 데이터 모델

**Site (사업지)**
- 기본 정보: name, address, lat/lng, PNU
- SITE-C 결과: score, grade, approval_prob, breakdown, suggestions
- 교통/인프라 데이터: 6개 거리 항목
- 구조/에너지: 내진등급, 경사도, 에너지효율, 일조시간
- 위해시설: compliant, risk_level, report
- 수요: demand_score, recommended_units

**Cluster (클러스터)**
- ILP 최적화 결과: selected site_ids, total_modules, ROI
- 간트 일정: factory/installation periods

---

## 🚀 로컬 실행

```bash
# Backend
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000

# Frontend  
cd frontend
npm install
npm run dev
```

---

## 📋 Phase 로드맵

| Phase | 기간 | 주요 작업 | 상태 |
|-------|------|-----------|------|
| **Phase 1** | 2주 | SITE-C 엔진, 위해시설(Mock), AI수요(시뮬), ILP 최적화 | ✅ 완료 |
| **Phase 2** | 3주 | 공공 GIS API 연동, LSTM 모델 학습, Celery 비동기 | 🔄 예정 |
| **Phase 3** | 2주 | BIM IFC 파싱, QTO 원가 산정, WebSocket, PDF 리포트 | 📅 예정 |

---

## ⚙️ 기술 스택

| 영역 | 기술 |
|------|------|
| Backend | FastAPI 0.111, SQLAlchemy 2.0, aiosqlite |
| Frontend | React 19, TypeScript, Vite, TailwindCSS v4 |
| 최적화 | PuLP (CBC 솔버) |
| 시각화 | Recharts |
| 상태관리 | TanStack Query v5, Zustand |
| 배포 | Docker Compose, PM2 |

---

*UnitBuild Platform v1.0 — Phase 1 · 2026-03-07*
